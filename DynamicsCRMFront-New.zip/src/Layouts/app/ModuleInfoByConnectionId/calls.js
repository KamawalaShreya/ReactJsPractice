import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import {
  GET_MODULE_INFO_BY_CONNECTION_ID,
  GET_FORM_BY_TITLE,
} from "../../../Redux/actions/comman";
import { Link } from "react-router-dom";
// import { getFormsByTitle } from "../../Redux/userSlice";
import DynamicListing from "./dynamicListing";

const getUserId = () => {
  return JSON.parse(localStorage.getItem("userData"))?.userData;
};

const Calls = ({
  id,
  prePathname,
  moduleName,
  permission,
  ownerid,
  formType,
}) => {
  const dispatch = useDispatch();
  const [calls, setCalls] = useState([]);
  const [newModule, setNewModule] = useState(false);

  const asyncGetCalls = async () => {
    dispatch(GET_FORM_BY_TITLE("Calls")).then((res) => {
      const data = res.data?.data ? false : true;
      setNewModule(data);
    });

    let endPoint = "calls-by-connection";
    let res = await dispatch(GET_MODULE_INFO_BY_CONNECTION_ID(endPoint, id));
    if (res?.data) {
      const updatedCalls = res?.data?.callData?.map((call) => {
        // Parse the ClosedTime into a Date object
        const CallStartTime = new Date(call?.CallStartTime);
        // Get the current time
        const currentTime = new Date();
        // If the CallStartTime is in the past, mark the call as closed
        if (CallStartTime <= currentTime) {
          return { ...call, callClosed: "closed" };
        }
        return call;
      });
      setCalls(updatedCalls);
    }
  };

  useEffect(() => {
    asyncGetCalls();
  }, [dispatch]);
  console.log("newModule---->>", newModule);
  const checkPermission = () => {
    if (
      ownerid === getUserId()?._id ||
      getUserId()?.profile === "Administrator"
    ) {
      return (
        <>
          <div className="pb-2 flex justify-between items-center">
            <p className="font-medium text-lg">Calls</p>
            {!newModule ? (
              <Link
                to={`/crm/create-call?connectionId=${id}?prePathname=${prePathname}&type=${formType}&parentModule=${formType}`}
                className="bg-primary p-2 rounded-lg text-white"
              >
                Create
              </Link>
            ) : (
              <Link
                to={`/crm/createModule?name=${moduleName}`}
                type="button"
                className="text-white mt-4 bg-primary hover:bg-priamry/20 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 focus:outline-none "
              >
                Create New module
              </Link>
            )}
          </div>
        </>
      );
    } else if (permission?.read) {
      return (
        <>
          <div className="pb-2 flex justify-between items-center">
            <p className="font-medium text-lg">Calls</p>
            {permission?.write && (
              <>
                {!newModule ? (
                  <Link
                    to={`/crm/create-call?connectionId=${id}?prePathname=${prePathname}&type=${formType}&parentModule=${formType}`}
                    className="bg-primary p-2 rounded-lg text-white"
                  >
                    Create
                  </Link>
                ) : (
                  <Link
                    to={`/crm/createModule?name=${moduleName}`}
                    type="button"
                    className="text-white mt-4 bg-primary hover:bg-priamry/20 focus:ring-4 focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 focus:outline-none "
                  >
                    Create New module
                  </Link>
                )}
              </>
            )}
          </div>
        </>
      );
    }
  };

  return (
    <div className="w-full my-3 pt-[200px] mt-[-200px]" id="calls">
      {checkPermission()}
      <div className="bg-white mb-2 rounded-xl p-2">
        <p className="font-[500] text-gray-600">Open Activity</p>
        <DynamicListing
          detailPath="/crm/call-details"
          data={calls?.filter((item) => item?.callClosed === undefined)}
          moduleName={moduleName}
        />
      </div>
      <div className="bg-white mb-2 rounded-xl p-2">
        <p className="font-[500] text-gray-600">Close Activity</p>
        <DynamicListing
          detailPath="/crm/call-details"
          data={calls?.filter((item) => item?.callClosed === "closed")}
          moduleName={moduleName}
        />
      </div>
    </div>
  );
};

export default Calls;
