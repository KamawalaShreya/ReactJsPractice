import { useEffect, useState, Fragment } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { Dialog, Transition } from "@headlessui/react";
import {
  GET_FORM_BY_TITLE,
  CONVERT_BY_CONNECTION_ID,
} from "../../../../Redux/actions/comman";
import { Info } from "react-feather";
import { CheckObjectValidation } from "../../../../utility/validation";
import OppotunityForm from "./opportunityForm";

const CreatRedirect = ({ path, name }) => {
  return (
    <Link to={path} className="text-primary underline">
      First Create Module for {name}
    </Link>
  );
};

const Convert = ({ id, sections, values }) => {
  console.log("sections-->>", values);
  const [opportunities, setOpportunities] = useState(false);
  // const [oppPayload, setOppPayload] = useState({
  //   leadType: "",
  //   dealName: "",
  //   closingDate: "",
  //   campaignSource: "",
  //   Pipeline: "",
  //   stage: "",
  // });
  const [contact, setContact] = useState(false);
  const [account, setAccount] = useState(false);
  const [quickForm, setQuickForm] = useState(false);
  const dispatch = useDispatch();
  let [isOpen, setShow] = useState(false);
  // const detail = useSelector((state) => state.user.detail);

  function closeModal() {
    setShow(false);
  }

  function openModal() {
    setShow(true);
  }

  const handleSubmit = (formdata) => {
    let payload = {
      leadId: id,
      opportunities,
      opportunitiesData: formdata,
    };

    let isvalid = CheckObjectValidation(payload, []);
    if (isvalid?.isvalid) {
      dispatch(CONVERT_BY_CONNECTION_ID(payload));
      setShow(false);
    }
  };

  const asyncCheckModules = async () => {
    // dispatch(GET_FORM_BY_TITLE("Opportunities")).then((res) => {
    //   let data = res?.data?.data ? true : false;
    //   setOpportunity(data);
    // });
    dispatch(GET_FORM_BY_TITLE("Accounts")).then((res) => {
      let data = res?.data?.data ? true : false;
      setAccount(data);
    });
    dispatch(GET_FORM_BY_TITLE("Contacts")).then((res) => {
      let data = res?.data?.data ? true : false;
      setContact(data);
    });
    dispatch(GET_FORM_BY_TITLE("Opportunities")).then((res) => {
      let data = res?.data?.data;
      setQuickForm(data);
    });
  };

  useEffect(() => {
    asyncCheckModules();
  }, [dispatch]);

  return (
    <>
      <button
        type="button"
        onClick={openModal}
        className="rounded-lg border bg-primary h-1-0 shadow-lg  px-2 py-1 text-sm font-medium text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75"
        id="convert-button"
      >
        Convert
      </button>

      <Transition appear show={isOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50" onClose={closeModal}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-25" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4 text-center">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-[1100px] transform overflow-hidden rounded-2xl bg-white p-6 text-left align-middle shadow-xl transition-all">
                  <Dialog.Title
                    as="h3"
                    className="text-lg font-medium leading-6 text-gray-900"
                  >
                    Convert Lead
                  </Dialog.Title>
                  <div className="h-[70vh] overflow-scroll p-10">
                    <div className="h-full">
                      <div className="flex justify-start items-center">
                        <div className="mb-0 flex justify-start items-center ">
                          <Info size={16} color="gray" />
                          <span className="mx-1 text-gray-600 font-[200]">
                            Create New Account{" "}
                            {values?.Company ? `(${values?.Company})` : ""}
                          </span>
                        </div>
                        {account ? (
                          ""
                        ) : (
                          <CreatRedirect name="Account" path="/crm/modules" />
                        )}
                      </div>
                      <div className="flex justify-start items-center">
                        <div className="flex justify-start items-center ">
                          {" "}
                          <Info size={16} color="gray" />{" "}
                          <span className="mx-1 text-gray-600 font-[200]">
                            Create New Contact{" "}
                            {values?.FirstName
                              ? `(${values?.FirstName} ${values?.LastName})`
                              : ""}
                          </span>
                        </div>
                        {contact ? (
                          ""
                        ) : (
                          <CreatRedirect
                            name="Contact"
                            path="/crm/createModule?name=Contacts"
                          />
                        )}
                      </div>
                      {quickForm?.quickCreateFieldsForUpdate ? (
                        <div className="mt-2 text-gray-400 font-[200] flex justify-start items-center">
                          <input
                            checked={opportunities}
                            onChange={(e) => setOpportunities(e.target.checked)}
                            className="mx-2"
                            type="checkbox"
                          />
                          <p className="mb-1">
                            Create a new Opportunity for this Account.
                          </p>
                        </div>
                      ) : (
                        <div className="flex justify-start items-center space-x-2">
                          <span>
                            You don't have Quick form please create it
                          </span>
                          <CreatRedirect
                            name="Opportunities"
                            path="/crm/modules"
                          />
                        </div>
                      )}
                      <br />
                      <div>
                        {opportunities ? (
                          <>
                            <OppotunityForm
                              formType="Leads"
                              handleSubmit={handleSubmit}
                              setShow={setShow}
                              quickform={quickForm?.quickCreateFieldsForUpdate}
                            />
                          </>
                        ) : (
                          <div className="flex justify-end items-center space-x-2">
                            <button
                              className="bg-gray-300 p-2 rounded-lg shadow min-w-[100px] text-primary"
                              onClick={() => setShow(false)}
                            >
                              Cancel
                            </button>
                            <button
                              className="bg-primary p-2 rounded-lg shadow min-w-[100px] text-white"
                              onClick={() => handleSubmit({})}
                            >
                              Convert
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </>
  );
};

export default Convert;
