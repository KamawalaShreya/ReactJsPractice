import { Link, useLocation } from "react-router-dom";

const DynamicListing = ({ data, detailPath, moduleName }) => {
  const location = useLocation();

  return (
    <div className="p-5 bg-white rounded-xl  min-h-[200px]">
      <div className="grid grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-3">
        {data?.map((item) => {
          return (
            <Link
              key={item?._id}
              to={`${detailPath}/${item?._id}?prePathname=${location.pathname}`}
              className="bg-gray-50 border overflow-hidden p-3 rounded-md"
            >
              <div className="mb-2 flex justify-between items-center">
                <p className="text-primary">{moduleName} Owner</p>
                <p className="text-gray-500">
                  {item?.ownerData?.firstName} {item?.ownerData?.lastName}
                </p>
              </div>
              {moduleName !== "Note" && moduleName !== "Site visit" && < div className="mb-2 flex justify-between items-center">
                <p className="text-primary truncate">Subject</p>
                <p className="text-gray-500 truncate ">{item["Subject"] || item['Title']}</p>
              </div>
              }
            </Link>
          );
        })}
      </div>
    </div >
  );
};

export default DynamicListing;
