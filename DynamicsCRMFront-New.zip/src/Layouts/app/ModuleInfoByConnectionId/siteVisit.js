import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { GET_MODULE_INFO_BY_CONNECTION_ID } from "../../../Redux/actions/comman";
import DynamicListing from "./dynamicListing";
import SiteVisitModal from "./SiteVisitModal";

const getUserId = () => {
  return JSON.parse(localStorage.getItem("userData"))?.userData;
};

const SiteVisit = ({ id, moduleName, formType, ownerid, permission }) => {
  const dispatch = useDispatch();
  const [invoice, setInvoice] = useState([]);
  const [modal, setModal] = useState(false);

  const asyncGetInvoice = async () => {
    let endPoint = "siteVisit-by-connection";
    let res = await dispatch(GET_MODULE_INFO_BY_CONNECTION_ID(endPoint, id));
    if (res?.data) {
      setInvoice(res?.data?.siteVisitData);
    }
  };

  useEffect(() => {
    asyncGetInvoice();
  }, [dispatch]);

  const reloadData = () => {
    asyncGetInvoice();
  };

  const checkPermission = () => {
    if (
      ownerid === getUserId()?._id ||
      getUserId()?.profile === "Administrator"
    ) {
      return (
        <>
          <div className="pb-2 flex justify-between items-center">
            <p className="font-medium text-lg">Site Visit</p>
            <button
              onClick={() => setModal(true)}
              className="bg-primary p-2 rounded-lg text-white"
              type="button"
            >
              Create
            </button>
          </div>
          <DynamicListing
            detailPath="/crm/SiteVisit-details"
            data={invoice}
            moduleName={moduleName}
          />
          <SiteVisitModal
            modal={modal}
            setModal={setModal}
            module="Inventory"
            formType={formType}
            id={id}
            reloadData={reloadData}
          />
        </>
      );
    } else if (permission?.read) {
      return (
        <>
          <div className="pb-2 flex justify-between items-center">
            <p className="font-medium text-lg">Site Visit</p>
            {permission?.write && (
              <button
                onClick={() => setModal(true)}
                className="bg-primary p-2 rounded-lg text-white"
                type="button"
              >
                Create
              </button>
            )}
          </div>
          <DynamicListing
            detailPath="/crm/SiteVisit-details"
            data={invoice}
            moduleName={moduleName}
          />
          <SiteVisitModal
            modal={modal}
            setModal={setModal}
            module="Inventory"
            formType={formType}
            id={id}
            reloadData={reloadData}
          />
        </>
      );
    }
  };

  return (
    <div className="w-full my-3 pt-[200px] mt-[-200px]" id="siteVisit">
      {checkPermission()}
    </div>
  );
};

export default SiteVisit;
