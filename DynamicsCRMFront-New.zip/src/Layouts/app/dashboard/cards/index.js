import React from "react";
import rate from "../../../../assets/images/dashboard/rate.svg";
import rateRed from "../../../../assets/images/dashboard/rate-red.svg";
import chart from "../../../../assets/images/dashboard/chart.svg";

const CardsLayout = () => {
  return (
    <>
      <div className="grid lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <div className="bg-white border-[1px] rounded-2xl py-4 px-3">
          <div className="text-xl font-semibold mb-3">Conversion Rate</div>
          <div className="flex items-center gap-3 justify-between">
            <div>
              <div className="text-primary text-4xl font-semibold mb-4">
                0.81%
              </div>
              <div className="flex items-center gap-1">
                <div className="flex items-center w-max gap-1 bg-green-100 p-1 rounded text-sm font-medium text-green-500">
                  0.2%
                  <img src={rate} alt="rate" />
                </div>
                <div className="text-gray-600 text-xs font-medium">
                  than last week
                </div>
              </div>
            </div>
            <div>
              <img src={chart} alt="chart" />
            </div>
          </div>
        </div>
        <div className="bg-white border-[1px] rounded-2xl py-4 px-3">
          <div className="text-xl font-semibold mb-3">Unique Purchases</div>
          <div className="flex items-center gap-3 justify-between">
            <div>
              <div className="text-primary text-4xl font-semibold mb-4">
                3137
              </div>
              <div className="flex items-center gap-1">
                <div className="flex items-center w-max gap-1 bg-[#FCE2DC] p-1 rounded text-sm font-medium text-[#C52C22]">
                  0.7%
                  <img src={rateRed} alt="rate-img" />
                </div>
                <div className="text-gray-600 text-xs font-medium">
                  than last week
                </div>
              </div>
            </div>
            <div>
              <img src={chart} alt="chart-img" />
            </div>
          </div>
        </div>
        <div className="bg-white border-[1px] rounded-2xl py-4 px-3">
          <div className="text-xl font-semibold mb-3">Avg, Order Value</div>
          <div className="flex items-center gap-3 justify-between">
            <div>
              <div className="text-primary text-4xl font-semibold mb-4">
                $306.20
              </div>
              <div className="flex items-center gap-1">
                <div className="flex items-center w-max gap-1 bg-[#FCE2DC] p-1 rounded text-sm font-medium text-[#C52C22]">
                  0.3%
                  <img src={rateRed} alt="rate-img" />
                </div>
                <div className="text-gray-600 text-xs font-medium">
                  than last week
                </div>
              </div>
            </div>
            <div>
              <img src={chart} alt="chart-img" />
            </div>
          </div>
        </div>
        <div className="bg-white border-[1px] rounded-2xl py-4 px-3">
          <div className="text-xl font-semibold mb-3">Order Quantity</div>
          <div className="flex items-center gap-3 justify-between">
            <div>
              <div className="text-primary text-4xl font-semibold mb-4">
                1650
              </div>
              <div className="flex items-center gap-1">
                <div className="flex items-center w-max gap-1 bg-green-100 p-1 whitespace-nowrap rounded text-sm font-medium text-green-500">
                  2.1 %
                  <img src={rate} alt="rate-img" />
                </div>
                <div className="text-gray-600 text-xs font-medium">
                  than last week
                </div>
              </div>
            </div>
            <div>
              <img src={chart} alt="chart-img" />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default CardsLayout;
