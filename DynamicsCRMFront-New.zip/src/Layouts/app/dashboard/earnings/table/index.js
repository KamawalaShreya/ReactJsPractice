const EarningTableLayout = () => {
  return <div>{/* <Table /> */}</div>;
};

export default EarningTableLayout;
