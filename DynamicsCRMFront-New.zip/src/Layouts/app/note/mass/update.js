import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateNote = () => {
  return <MassUpdateList key="Note" moduleName="Note" />;
};

export default MassUpdateNote;
