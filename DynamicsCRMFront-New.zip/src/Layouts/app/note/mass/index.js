import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteNote = () => {
  return <MassTableList key="Note" moduleName="Note" />;
};

export default MassDeleteNote;
