import DetailTab from '../../ModuleInfoByConnectionId/detailTab'

const NoteDetails = ({ formType, id }) => {
    return (
        <DetailTab formType={formType} id={id} />
    )
}

export default NoteDetails;
