import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateWhatsapp = () => {
  return <MassUpdateList key="Whatsapps" moduleName="Whatsapps" />;
};

export default MassUpdateWhatsapp;
