import React from "react";
import MassTransferList from "../../../../Components/massTransferList";

const MassTransferWhatsapp = () => {
  return <MassTransferList key="Whatsapps" moduleName="Whatsapps" />;
};

export default MassTransferWhatsapp;
