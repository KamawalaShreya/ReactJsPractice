import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassWhatsapp = () => {
  return <MassTableList key="Whatsapps" moduleName="Whatsapps" />;
};

export default MassWhatsapp;
