import React from "react";
import TableList from "../../../../Components/table";
import { useSelector } from "react-redux";
import InventorySubHeader from "../InventorySubHeader";

function InventoryList() {
  // const [view, setView] = useState(defaultView())
  const form = useSelector((state) => state.user.form);

  return (
    <>
      <InventorySubHeader moduleName='Inventory' form={form?.sections} />
      <TableList key="inventory" moduleName="Inventory" />
    </>
  );
}

export default InventoryList;
