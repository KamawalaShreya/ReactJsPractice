import DetailTab from '../../ModuleInfoByConnectionId/detailTab'

const InventoryDetails = ({ formType, id }) => {
    return (
       <>
        <DetailTab formType={formType} id={id} />
       </>
    )
}

export default InventoryDetails;
