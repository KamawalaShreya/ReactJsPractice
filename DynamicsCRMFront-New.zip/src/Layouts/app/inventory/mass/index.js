import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteInventory = () => {
  return <MassTableList key="Inventory" moduleName="Inventory" />;
};

export default MassDeleteInventory;
