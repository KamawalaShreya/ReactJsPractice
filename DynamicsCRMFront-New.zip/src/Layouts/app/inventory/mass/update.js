import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateInventory = () => {
  return <MassUpdateList key="Inventory" moduleName="Inventory" />;
};

export default MassUpdateInventory;
