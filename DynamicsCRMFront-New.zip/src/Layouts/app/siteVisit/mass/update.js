import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassSiteUpdate = () => {
  return <MassUpdateList key="siteVisit" moduleName="siteVisit" />;
};

export default MassSiteUpdate;
