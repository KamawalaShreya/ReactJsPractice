import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassSiteDelete = () => {
  return <MassTableList key="siteVisit" moduleName="siteVisit" />;
};

export default MassSiteDelete;
