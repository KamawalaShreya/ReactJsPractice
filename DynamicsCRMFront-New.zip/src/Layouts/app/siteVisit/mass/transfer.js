import React from "react";
import MassTransferList from "../../../../Components/massTransferList";

const MassTransferSite = () => {
  return <MassTransferList key="siteVisit" moduleName="siteVisit" />;
};

export default MassTransferSite;
