import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";
import MassTransferList from "../../../../Components/massTransferList";

const MassTransfer = () => {
  return <MassTransferList key="Contacts" moduleName="Contacts" />;
};

export default MassTransfer;
