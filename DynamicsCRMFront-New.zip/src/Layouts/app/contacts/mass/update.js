import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassContactUpdate = () => {
  return <MassUpdateList key="Contacts" moduleName="Contacts" />;
};

export default MassContactUpdate;
