import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassContact = () => {
  return <MassTableList key="Contacts" moduleName="Contacts" />;
};

export default MassContact;
