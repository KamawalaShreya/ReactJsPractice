

const UserList = ()=>{
    return (
        <div className="min-h-screen ">
            user list complete ui here 
        </div>
    )
}

export default UserList;