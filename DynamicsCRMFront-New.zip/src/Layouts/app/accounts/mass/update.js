import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateAccount = () => {
  return <MassUpdateList key="Accounts" moduleName="Accounts" />;
};

export default MassUpdateAccount;
