import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteAccount = () => {
  return <MassTableList key="Accounts" moduleName="Accounts" />;
};

export default MassDeleteAccount;
