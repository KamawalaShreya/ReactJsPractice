import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassCallUpdate = () => {
  return <MassUpdateList key="Calls" moduleName="Calls" />;
};

export default MassCallUpdate;
