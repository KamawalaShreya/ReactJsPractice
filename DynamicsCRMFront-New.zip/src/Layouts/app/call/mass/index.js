import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteCall = () => {
  return <MassTableList key="Calls" moduleName="Calls" />;
};

export default MassDeleteCall;
