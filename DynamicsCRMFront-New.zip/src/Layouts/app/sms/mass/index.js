import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassSms = () => {
  return <MassTableList key="Sms" moduleName="Sms" />;
};

export default MassSms;
