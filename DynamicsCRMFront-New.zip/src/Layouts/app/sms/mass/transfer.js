import React from "react";
import MassTransferList from "../../../../Components/massTransferList";

const MassTransferSms = () => {
  return <MassTransferList key="Sms" moduleName="Sms" />;
};

export default MassTransferSms;
