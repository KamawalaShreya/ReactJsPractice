import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateSms = () => {
  return <MassUpdateList key="Sms" moduleName="Sms" />;
};

export default MassUpdateSms;
