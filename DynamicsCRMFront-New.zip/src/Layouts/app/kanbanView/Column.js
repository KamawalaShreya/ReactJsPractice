import React, { Fragment, memo } from "react";
import Card, { NoDataCard } from "./Card";
import { Droppable } from "react-beautiful-dnd";

const Column = ({
  column,
  isDropDisabled,
  tasks,
  moduleName,
  byModuleData,
}) => {
  const cardData = (name) => {
    if (name === "Opportunities") {
      return tasks?.filter((it) => it?.Stage === column?._id);
    } else {
      return tasks;
    }
  };

  return (
    <div className="w-1/4 flex-none ">
      <div className="bg-[#F0F0F5] p-[16px] rounded-lg border-t-2 border-[#E6E6EB]">
        <p className="text-[#18181B]  text-[14px] font-medium mb-[6px]">
          {moduleName === "Opportunities" ? column?.stageTitle : column?.title}
        </p>
        {!moduleName === "Opportunities" ? (
          <div className="flex items-center">
            <span className="text-[#18181B] text-[14px] font-semibold">
              ₹ {column.totalPrice}
            </span>
            <span className="inline-block h-[4px] w-[4px] bg-[#D6D6DA] rounded-full mx-[4px]"></span>
            <span className="text-[#18181B]  text-[14px]">
              {column?.taskIds?.length || 0} {moduleName}
            </span>
          </div>
        ) : (
          ""
        )}
      </div>
      <Droppable droppableId={column?.id} isDropDisabled={isDropDisabled}>
        {(provided, snapshot) => (
          <div ref={provided.innerRef} {...provided.droppableProps}>
            {tasks?.length !== 0 ? (
              cardData(moduleName)?.map((task, index) => {
                return (
                  <Fragment key={index}>
                    <Card
                      key={index}
                      task={task}
                      index={index}
                      byModuleData={byModuleData}
                      moduleName={moduleName}
                    />
                  </Fragment>
                );
              })
            ) : (
              <NoDataCard />
            )}
          </div>
        )}
      </Droppable>
    </div>
  );
};

export default memo(Column);
