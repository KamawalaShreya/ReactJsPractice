import React from "react";
import { Draggable } from "react-beautiful-dnd";

const Card = ({ index, task, byModuleData, moduleName }) => {
  const isDragDisabled = false;
  return (
    <Draggable
      draggableId={task.id}
      isDragDisabled={isDragDisabled}
      index={index}
    >
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          className={`mt-[8px] bg-[#FFFFFF] border-2  border-dashed ${
            snapshot.isDragging ? "border-primary" : "border-white"
          }  p-[16px] rounded-lg`}
        >
          <div {...provided.dragHandleProps}>
            {!moduleName === "Opportunities" ? (
              byModuleData?.fields?.map((item, index) => (
                <div key={index}>
                  <span className="text-[#18181B]  text-[14px] leading-6">
                    {Object?.keys(task)?.includes(item?.value)
                      ? task[item?.value]
                      : ""}{" "}
                  </span>
                </div>
              ))
            ) : (
              <div>
                {moduleName === "Opportunities" ? (
                  <div>
                    <p className="text-[#18181B]  text-[14px] leading-6">
                      <span className="text-gray-900 font-[500]">
                        Opportunity Name:{" "}
                      </span>{" "}
                      <span className="text-gray-600">
                        {task?.OpportunityName || "N/A"}
                      </span>
                    </p>
                    <p className="text-[#18181B]  text-[14px] leading-6">
                      <span className="text-gray-900 font-[500]">
                        Contact Name:{" "}
                      </span>{" "}
                      <span className="text-gray-600">
                        {task?.ContactData?.length > 0
                          ? `${task?.ContactData[0]?.FirstName} ${task?.ContactData[0]?.LastName}`
                          : "N/A"}
                      </span>
                    </p>
                    <p className="text-[#18181B]  text-[14px] leading-6">
                      <span className="text-gray-900 font-[500]">
                        Account Name:{" "}
                      </span>{" "}
                      <span className="text-gray-600">
                        {task?.AccountData?.length > 0
                          ? task?.AccountData[0]?.AccountName
                          : "N/A"}
                      </span>
                    </p>
                    <p className="text-[#18181B]  text-[14px] leading-6">
                      <span className="text-gray-900 font-[500]">
                        Pipeline:{" "}
                      </span>{" "}
                      <span className="text-gray-600">
                        {task?.pipelineData?.pipelineTitle || "N/A"}
                      </span>
                    </p>
                  </div>
                ) : (
                  ""
                )}
                <div key={index}>
                  {byModuleData?.fields?.map((item, index) => (
                    <div key={index}>
                      <span className="text-[#18181B]  text-[14px] leading-6">
                        {Object?.keys(task)?.includes(item?.value)
                          ? task[item?.value] && item?.value
                            ? task[item?.value]
                            : ""
                          : ""}{" "}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div>
              <span className="text-[#18181B]  text-[14px] leading-6">
                ₹{" "}
                {Object.keys(task)?.includes(byModuleData?.AggregateBy)
                  ? task[byModuleData?.AggregateBy] && byModuleData?.AggregateBy
                    ? task[byModuleData?.AggregateBy]
                    : 0
                  : 0}
              </span>
            </div>
          </div>
        </div>
      )}
    </Draggable>
  );
};

export default Card;

export const NoDataCard = () => {
  return (
    <div className="mt-[8px]  bg-[#F0F0F5] p-[16px] rounded-lg  justify-center flex items-center">
      <p>No Leads Found.</p>
    </div>
  );
};
