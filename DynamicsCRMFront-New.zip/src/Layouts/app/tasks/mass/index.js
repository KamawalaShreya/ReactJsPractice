import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteTasks = () => {
  return <MassTableList key="Tasks" moduleName="Tasks" />;
};

export default MassDeleteTasks;
