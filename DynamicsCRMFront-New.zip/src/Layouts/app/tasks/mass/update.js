import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateTasks = () => {
  return <MassUpdateList key="Tasks" moduleName="Tasks" />;
};

export default MassUpdateTasks;
