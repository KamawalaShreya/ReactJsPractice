import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeletechannelPartner = () => {
  return <MassTableList key="channelPartner" moduleName="channelPartner" />;
};

export default MassDeletechannelPartner;
