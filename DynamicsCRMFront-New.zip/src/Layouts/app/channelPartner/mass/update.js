import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdatechannelPartner = () => {
  return <MassUpdateList key="channelPartner" moduleName="channelPartner" />;
};

export default MassUpdatechannelPartner;
