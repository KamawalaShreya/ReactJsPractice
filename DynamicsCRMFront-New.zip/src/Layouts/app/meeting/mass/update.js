import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassMeetingUpdate = () => {
  return <MassUpdateList key="Meeting" moduleName="Meeting" />;
};

export default MassMeetingUpdate;
