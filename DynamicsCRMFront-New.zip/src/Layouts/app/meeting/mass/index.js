import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteMeeting = () => {
  return <MassTableList key="Meeting" moduleName="Meeting" />;
};

export default MassDeleteMeeting;
