const childModuleofMain = ['Tasks', 'Calls', 'Meeting', 'Inventory', 'Note', 'Invoice', 'SiteVisit', 'Quotes']

export const ModuleDataFrame = {
    Leads : childModuleofMain,
    Contacts : childModuleofMain,
    Accounts : childModuleofMain,
    Deals: childModuleofMain,
}