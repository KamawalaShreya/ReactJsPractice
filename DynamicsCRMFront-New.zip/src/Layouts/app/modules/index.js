import { ArrowIcon } from "../../../assets/svgIcons";
import DataTable from "react-data-table-component";
import { useDispatch, useSelector } from "react-redux";
import ReactPaginate from "react-paginate";
import { GET_ALL_FORMS } from "../../../Redux/actions/modules";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, Settings } from "react-feather";
import { Link } from "react-router-dom";
import useAccessibleRole from "../../../hooks/useAccessibleRole";
import { getTitle } from "../../../utility/serviceMethod";
import { menuItems } from "../../../../src/Components/appbar/menuItems";


const ModulesListing = () => {
  const listOfForms = useSelector(
    (state) => state?.ModulesReducer?.listOfForms
  );
  const [currentPage, setCurrentPage] = useState(1);
  const dispatch = useDispatch();

  const {
    edit,
    read,
    write,
    delete: deleteValue,
  } = useAccessibleRole("settings");

  useEffect(() => {
    dispatch(GET_ALL_FORMS(1, 20));
  }, [dispatch]);

  const handlePagination = (page) => {
    dispatch(GET_ALL_FORMS(page.selected + 1, 20));
    setCurrentPage(page.selected + 1);
  };

  const reorderData = (menuItems, data) => {
    const filteredMenuItems = menuItems?.reduce((result, menu) => {
      if (menu.hamburger) {
        const filteredHamburger = menu.hamburger
          ?.filter((item) =>
            data?.some((d) => d?._id.toLowerCase() === item?.id.toLowerCase())
          )
          ?.map((item) => (item?.label ? { _id: item?.label, label: item?.label.toLowerCase().replace(/\s/g, "") } : { _id: item?.id }));
        if (filteredHamburger?.length > 0) {
          result.push(...filteredHamburger);
        }
      } else {
        const existsInData = data?.some(
          (d) => d?._id === menu?.label
        );
        if (existsInData) {
          result.push({ _id: menu?.label, label: menu?.label.toLowerCase().trim() });
        }
      }
      return result;
    }, []);

    const unmatchedData = data?.filter(
      (d) => !filteredMenuItems?.some((item) => item?.label === d?._id.toLowerCase().replace(/\s/g, ""))
    );
    if (unmatchedData && unmatchedData?.length) {
      filteredMenuItems.push(...unmatchedData?.map((item) => ({ _id: item?._id })));
    }

    return filteredMenuItems;
  };


  const columns = [
    {
      name: "Module ",
      width: "50%",
      selector: (row) => row.formTitle,
      cell: (row) => getTitle(row?._id) || "N/A",
      sortable: true,
    },
    {
      name: "Setting",
      width: "50%",
      cell: (row) => (
        <Link
          className="text-primary"
          to={`${edit ? `/crm/form-layout-by-module/${row?._id}` : "/crm/modules"
            }`}
        >
          <Settings />
        </Link>
      ),
      sortable: true,
    },
  ];

  const CustomPagination = () => {
    const count = Number(Math.ceil(listOfForms?.pagination?.total / 20));
    return (
      <div className="px-2">
        <ReactPaginate
          previousLabel={<ArrowLeft />}
          nextLabel={<ArrowRight />}
          pageCount={count || 1}
          breakLabel=".."
          pageRangeDisplayed={0}
          marginPagesDisplayed={1}
          activeClassName="active"
          forcePage={currentPage !== 0 ? currentPage - 1 : 0}
          onPageChange={(page) => handlePagination(page)}
          containerClassName="pagination react-paginate text-sm gap-2 flex justify-end my-2 rounded-full"
        />
      </div>
    );
  };
  return (
    <div className="mt-4 rounded-md  bg-white p-2">
      <h3 className="mt-6 mb-2 text-primary text-base font-semibold">
        Modules
      </h3>
      <div>
        <DataTable
          noHeader={false}
          data={reorderData(menuItems, listOfForms?.formData) || []}
          pagination={false}
          subHeader={false}
          responsive
          selectableRows={false}
          noDataComponent={
            <div className="text-center rounded-2xl">
              <h5 className="mt-2">Sorry! No Result Found</h5>
              <p className="text-gray-400 mb-0">
                We've searched more than 150+ Orders We did not find any orders
                for you search.
              </p>
            </div>
          }
          id="_id"
          columns={columns}
          sortIcon={<ArrowIcon />}
          className="w-[80%] overflow-hidden overflow-x-auto overflow-y-auto rounded-lg react-dataTable dataTables_wrapper"
        />
      </div>
      <div className="flex justify-end">{CustomPagination()}</div>
    </div>
  );
};

export default ModulesListing;
