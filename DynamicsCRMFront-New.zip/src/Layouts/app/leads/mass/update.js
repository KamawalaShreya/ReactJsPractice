import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateLead = () => {
  return <MassUpdateList key="Leads" moduleName="Leads" />;
};

export default MassUpdateLead;
