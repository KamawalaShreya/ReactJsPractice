import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassLead = () => {
  return <MassTableList key="Leads" moduleName="Leads" />;
};

export default MassLead;
