import React from "react";
import MassTableList from "../../../../Components/massTable";

const MassDeleteOpportunity = () => {
  return <MassTableList key="Opportunities" moduleName="Opportunities" />;
};

export default MassDeleteOpportunity;
