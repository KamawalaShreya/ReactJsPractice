import React from "react";
import MassUpdateList from "../../../../Components/massUpdateTable";

const MassUpdateOpportunity = () => {
  return <MassUpdateList key="Opportunities" moduleName="Opportunities" />;
};

export default MassUpdateOpportunity;
