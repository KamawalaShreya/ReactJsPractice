import React from "react";
import FormBuilder from "../../Components/Common/Form/FormBuilder";

function CreateAccounts() {
  return <FormBuilder formType="Accounts" />;
}

export default CreateAccounts;
