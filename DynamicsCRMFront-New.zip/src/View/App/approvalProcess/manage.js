import React from "react";
import ApprovalProcessManageLayout from "../../../Layouts/app/approvalProcess/manage";


const ApprovalProcessManage = () => {
  return (
    <div>
      <ApprovalProcessManageLayout />
    </div>
  )
};

export default ApprovalProcessManage;
