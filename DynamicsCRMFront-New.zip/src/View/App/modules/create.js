
import React from "react";
import { CreateModuleLayout } from "../../../Layouts";

const CreateModule = () => {
    return (
        <div className="mt-5">
            <CreateModuleLayout />
        </div>
    )
}

export default CreateModule;