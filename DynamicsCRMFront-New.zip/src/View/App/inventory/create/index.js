import React from "react";
import FormBuilder from "../../../../Components/Common/Form/FormBuilder";

function CreateInventory() {
  return <FormBuilder formType="Inventory" />;
}

export default CreateInventory;
