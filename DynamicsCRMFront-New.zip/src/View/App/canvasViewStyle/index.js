
import { CanvasViewLayout } from '../../../Layouts'

const canvasViewStyle = () => {
    return (
        <div>
            <CanvasViewLayout />
        </div>
    )
}

export default canvasViewStyle;