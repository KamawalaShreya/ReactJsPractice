import React from "react";
import RuleDetails from "../../../../Layouts/app/automation/workflow/rules/RuleDetails";

const DetailRule = () => {
  return (
    <div>
      <RuleDetails />
    </div>
  );
};

export default DetailRule;
