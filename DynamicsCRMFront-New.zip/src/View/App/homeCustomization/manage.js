import React from "react";
import HomeCustomizationManageLayout from "../../../Layouts/app/homeCustomization/create";


const HomeCustomizationManage = () => {
  return (
    <div>
      <HomeCustomizationManageLayout />
    </div>
  )
};

export default HomeCustomizationManage;
