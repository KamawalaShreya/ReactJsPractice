import React from "react";
import ManageMacro from "../../../Layouts/app/macro/manage";


const DashboardView = () => {
  return (
    <>
      <ManageMacro />
    </>
  );
};

export default DashboardView;
