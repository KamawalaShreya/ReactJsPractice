import React from "react";
import MacroLayout from "../../../Layouts/app/macro/create";


const DashboardView = () => {
  return (
    <>
    <MacroLayout/>
    </>
  );
};

export default DashboardView;
