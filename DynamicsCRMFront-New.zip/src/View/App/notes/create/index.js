import React from "react";
import FormBuilder from "../../../../Components/Common/Form/FormBuilder";

function CreateNote() {
  return <FormBuilder formType="Note" />;
}

export default CreateNote;
