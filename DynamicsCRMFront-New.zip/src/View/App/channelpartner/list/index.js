import ChannelPartnerList from "../../../../Layouts/app/channelPartner/list";

const ListchannelPartnerApp = () => {
  return (
    <>
      <div className="w-full min-h-screen">
        <ChannelPartnerList />
      </div>
    </>
  );
};

export default ListchannelPartnerApp;
