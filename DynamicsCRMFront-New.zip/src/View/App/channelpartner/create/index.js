import React from "react";
import FormBuilder from "../../../../Components/Common/Form/FormBuilder";

function CreatechannelPartner() {
  return <FormBuilder formType="channelPartner" />;
}

export default CreatechannelPartner;
