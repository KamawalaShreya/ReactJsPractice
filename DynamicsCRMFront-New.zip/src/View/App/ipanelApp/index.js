import IpanelLayout from "../../../Layouts/app/ipanel"


const IpanelApp =()=>{
    return (
        <div>
            <IpanelLayout />
        </div>
    )
}
export default IpanelApp