import React from "react";
import { LeftBackArrowWhite, RightBackArrowWhite } from "../../assets/svgIcons";
import { useState } from "react";
import { Plus } from "feather-icons-react/build/IconComponents";
import { useLocation, useParams, Link } from "react-router-dom";

function RelatedList() {
  const [sideBarShow, setSidebarShow] = useState(true);
  const { id } = useParams();
  const location = useLocation();
  const { pathname } = location;

  return (
    <>
      {sideBarShow ? (
        <div
          className="fixed left-0 top-48 h-12 w-12 rounded-tr-2xl rounded-br-2xl bg-primary flex items-center justify-center cursor-pointer z-10"
          onClick={() => {
            setSidebarShow(false);
          }}
        >
          <LeftBackArrowWhite />
        </div>
      ) : (
        <div
          className="fixed left-0 top-48 h-12 w-12 rounded-tr-2xl rounded-br-2xl bg-primary flex items-center justify-center cursor-pointer z-10"
          onClick={() => {
            setSidebarShow(true);
          }}
        >
          <RightBackArrowWhite />
        </div>
      )}
      {sideBarShow && (
        <div className="rounded-2xl bg-white h-full p-6 w-[270px] min-w-[270px] mt-3 sticky top-[200px] ">
          <h4 className="pt-[10px] pl-10 pb-2 text-base font-[500] text-gray-950">
            <a href="#details"> Details</a>
          </h4>
          <ul>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a href="#task" className="flex justify-between items-center  w-full">
                <span>
                  Tasks</span>
              </a>
              <Link
                to={`/crm/create-tasks?connectionId=${id}?prePathname=${pathname}`}
              >
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#calls"> <span>
                Calls</span>
              </a>
              <Link
                to={`/crm/create-call?connectionId=${id}?prePathname=${pathname}`}
              >
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#meetings">
                <span>Meetings</span>
              </a>
              <Link
                to={`/crm/create-meeting?connectionId=${id}?prePathname=${pathname}`}
              >
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#inventory">
                Inventory
              </a>
              <Link
                to={`/crm/create-inventory?connectionId=${id}?prePathname=${pathname}`}
              >
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#notes">
                Notes
              </a>
              <Link
                to={`/crm/create-note?connectionId=${id}?prePathname=${pathname}`}
              >
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#sale-order">
                Sale Order
              </a>
              <Link to={`/crm/create-saleOrder?connectionId=${id}?prePathname=${pathname}`}>
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#purchase-order">
                Purchase Order
              </a>
              <Link to={`/crm/create-purchaseorder?connectionId=${id}?prePathname=${pathname}`}>
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#invoice">
                Invoice
              </a>
              <Link to={`/crm/create-invoice?connectionId=${id}?prePathname=${pathname}`}>
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#siteVisit">
                Site Visit
              </a>
              <Link to={`/crm/create-sitevisit?connectionId=${id}?prePathname=${pathname}`}>
                <Plus size={16} />
              </Link>
            </li>
            <li className="pt-[10px] flex justify-start pl-10 pb-2 text-base font-[500] cursor-pointer hover:text-primary text-[#929296]">
              <a className="flex justify-between items-center  w-full" href="#quotes">
                <span>Quotes</span>
              </a>
              <Link to={`/crm/create-quotes?connectionId=${id}?prePathname=${pathname}`}>
                <Plus size={16} />
              </Link>
            </li>
          </ul>
        </div>
      )}
    </>
  );
}

export default RelatedList;
