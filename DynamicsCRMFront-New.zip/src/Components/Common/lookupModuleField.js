import { Field } from "formik";
import { useMemo, useState } from "react";
import { useDispatch } from "react-redux";
import { GET_LOOKUP } from "../../Redux/actions/user";
import { Fragment } from "react";
import { Listbox, Transition } from "@headlessui/react";

const modulesList = [
  { name: "Leads", lookup: "Leads" },
  { name: "Contacts", lookup: "Contacts" },
  { name: "Accounts", lookup: "Accounts" },
  { name: "Opportunity", lookup: "deals" },
  { name: "Calls", lookup: "calls" },
  { name: "Vendor", lookup: "Vendor" },
  { name: "Tasks", lookup: "Tasks" },
  { name: "Inventory", lookup: "inventory" },
  { name: "Meeting", lookup: "meetings" },
  { name: "Site Visit", lookup: "siteVisit" },
  { name: "Invoice", lookup: "invoices" },
  { name: "Sale orders", lookup: "sale-orders" },
  { name: "Purchase orders", lookup: "purchase-orders" },
  { name: "Purchase orders", lookup: "purchase-orders" },
  { name: "Quotes", lookup: "quotes" },
];

function SelectModule({ lookupDataType, setLookupDataType, labelType }) {
  const [selected, setSelected] = useState(
    modulesList.find(
      (it) =>
        it?.lookup?.toLocaleLowerCase() === lookupDataType?.toLocaleLowerCase()
    )
  );

  return (
    <div>
      <Listbox
        value={selected}
        onChange={(e) => {
          setSelected(e);
          setLookupDataType(e?.lookup);
        }}
      >
        <div className="relative min-w-[120px] mt-1">
          <Listbox.Button className="relative border w-full cursor-default rounded-lg bg-white p-2.5 text-left shadow-md focus:outline-none focus-visible:border-indigo-500 focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-opacity-75 focus-visible:ring-offset-2 focus-visible:ring-offset-orange-300 sm:text-sm">
            <span className="block truncate">{selected?.name}</span>
          </Listbox.Button>
          <Transition
            as={Fragment}
            leave="transition ease-in duration-100"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <Listbox.Options
              style={{ zIndex: 1 }}
              className="absolute mt-1 max-h-60 w-full overflow-auto rounded-md bg-white py-1 text-base shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none sm:text-sm"
            >
              {labelType === "contact"
                ? modulesList
                    .filter((item, index) => index <= 1)
                    ?.map((person, personIdx) => (
                      <Listbox.Option
                        key={personIdx}
                        className={({ active }) =>
                          `relative cursor-default select-none p-2 ${
                            active
                              ? "bg-blue-100 text-primary"
                              : "text-gray-900"
                          }`
                        }
                        value={person}
                      >
                        {({ selected }) => (
                          <>
                            <span
                              className={`block truncate ${
                                selected ? "font-medium" : "font-normal"
                              }`}
                            >
                              {person?.name}
                            </span>
                          </>
                        )}
                      </Listbox.Option>
                    ))
                : modulesList?.map((person, personIdx) => (
                    <Listbox.Option
                      key={personIdx}
                      className={({ active }) =>
                        `relative cursor-default select-none p-2 ${
                          active ? "bg-blue-100 text-primary" : "text-gray-900"
                        }`
                      }
                      value={person}
                    >
                      {({ selected }) => (
                        <>
                          <span
                            className={`block truncate ${
                              selected ? "font-medium" : "font-normal"
                            }`}
                          >
                            {person?.name}
                          </span>
                        </>
                      )}
                    </Listbox.Option>
                  ))}
            </Listbox.Options>
          </Transition>
        </div>
      </Listbox>
    </div>
  );
}

const LookupModuleField = ({
  input,
  editable,
  CustomLookup,
  formType,
  setValues,
  labelType,
  values,
  open,
  changeModuleOption = false,
}) => {
  const [data, setData] = useState([]);
  const dispatch = useDispatch();
  const [fulldata, setFulldata] = useState([]);
  const [lookupDataType, setLookupDataType] = useState(input?.lookupModule);

  const canChangeModuleName = () => {
    if (formType === "Calls" || formType === "tasks" || formType === "Tasks") {
      return true;
    } else if (formType === "Meeting" || formType === "siteVisit") {
      return true;
    } else {
      return false;
    }
  };

  useMemo(async () => {
    const items = [];
    let urlEndPoint = () => {
      if (lookupDataType === "Opportunities") {
        return "deals";
      }
      return lookupDataType;
    };
    await dispatch(GET_LOOKUP(`/search-${urlEndPoint()}`)).then((res) => {
      setFulldata(res);
      if (res?.length > 0) {
        for (let item of res) {
          if (lookupDataType === "Accounts") {
            let _i = {
              value: item?._id,
              label: item?.AccountName || "(Quick Create)",
            };

            items.push(_i);
          } else if (lookupDataType === "Vendor") {
            let _i = {
              value: item?._id,
              label: item?.VendorName,
            };

            items.push(_i);
          } else if (lookupDataType === "Contacts") {
            let _i = {
              value: item?._id,
              label: `${item?.FirstName} ${item?.LastName}`,
            };

            items.push(_i);
          } else if (
            lookupDataType === "opportunities" ||
            lookupDataType === "Opportunities" ||
            lookupDataType === "deals"
          ) {
            let _i = {
              value: item?._id,
              label: item?.OpportunityName || "N/A",
            };
            items.push(_i);
          } else if (lookupDataType === "leads" || lookupDataType === "Leads") {
            let _i = {
              value: item?._id,
              label: `${item?.FirstName} ${item?.LastName}`,
            };

            items.push(_i);
          } else if (lookupDataType === "call") {
            let _i = {
              value: item?._id,
              label: item?.ContactName,
            };

            items.push(_i);
          } else if (lookupDataType === "tasks" || lookupDataType === "Tasks") {
            let _i = {
              value: item?._id,
              label: item?.Subject || item?.ContactName,
            };

            items.push(_i);
          } else if (lookupDataType === "inventory") {
            let _i = {
              value: item?._id,
              label: item?.InventoryName,
            };

            items.push(_i);
          } else {
            let _i = {
              value: item?._id,
              label: item?.Subject || item?.ContactName,
            };

            items.push(_i);
          }
        }
      }
    });
    setData(items);
  }, [lookupDataType, open]);
  console.log("lookupDataType", lookupDataType);
  return (
    <div className="flex justify-start space-x-2 items-center">
      {canChangeModuleName() && changeModuleOption && (
        <SelectModule
          lookupDataType={lookupDataType}
          setLookupDataType={setLookupDataType}
          labelType={labelType}
        />
      )}
      <Field
        values={values}
        fulldata={fulldata}
        formType={formType}
        setValues={setValues}
        value={input?.value}
        className="custom-select-edit w-full"
        name={input?.value}
        options={data}
        component={CustomLookup}
        placeholder={input?.label}
        disabled={editable}
      />
    </div>
  );
};

export default LookupModuleField;
