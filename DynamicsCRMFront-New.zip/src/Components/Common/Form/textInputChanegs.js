

const TextInputChanges = ({ input, placeholder, type, className, setValues, values, row }) => {
    const handleChange = (e) => {
        let { value, name } = e.target
        setValues({ ...values, [name]: value })
    }

    return (
        <>
            {input?.type === 'textarea' ? <textarea
                value={values[input?.value]} rows={row} onChange={handleChange} className={className} placeholder={placeholder} name={input?.value} type={type} /> : <input
                value={values[input?.value]} minLength={input?.min || 0} maxLength={input?.maxLength}
                onChange={(e) => {
                    if(type === 'number'){
                        if (/^[0-9]*$/.test(e.target.value)) {
                            handleChange(e)
                        }
                    }else{
                        handleChange(e)
                    }
                   
                }}
                className={className} placeholder={placeholder} name={input?.value} />}
        </>
    )
}

export default TextInputChanges;