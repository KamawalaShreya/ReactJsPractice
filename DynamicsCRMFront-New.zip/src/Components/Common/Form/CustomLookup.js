import React, { memo, useMemo } from "react";
import Creatable from "react-select/creatable";

export const CustomLookup = ({
  className,
  placeholder,
  field,
  form,
  options,
  isMulti = false,
  disabled,
  formType,
  setValues,
  values,
  fulldata,
  edit,
}) => {
  const onChange = (option) => {
    if (
      formType === "Opportunities" &&
      (field?.name === "ContactName" || field?.name === "AccountName")
    ) {
      let accoutId = fulldata?.find((it) => it?._id === option?.value);
      setValues({
        ...values,
        AccountName: edit ? accoutId?._id : accoutId?.AccountName,
        ContactName: option?.value,
      });
    } else {
      setValues({ ...values, [field?.name]: option?.value });
    }
    form.setFieldValue(
      field.name,
      isMulti ? option.map((item) => item.value) : option.value
    );
  };

  const getValue = useMemo(() => {
    if (options) {
      let valueis = isMulti
        ? options?.filter((option) => field?.value?.indexOf(option.value) >= 0)
        : options?.find((option) => option?.value === field?.value);
      return valueis;
    } else {
      return isMulti ? [] : "";
    }
  }, [options, field]);

  return (
    <Creatable
      className={className}
      name={field.name}
      value={getValue}
      onChange={onChange}
      placeholder={placeholder}
      options={options}
      isMulti={isMulti}
      isDisabled={disabled}
      noOptionsMessage={() => "Quick Create "}
    />
  );
};

export default memo(CustomLookup);
