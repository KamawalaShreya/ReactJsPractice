import { Field } from "formik"
import { useMemo, useState } from "react"
import { useDispatch } from "react-redux"
import { GET_LOOKUP } from "../../Redux/actions/user"


const LookupModuleFieldEdit = ({ input, editable, CustomLookup, detail, setValues, formType, values, open }) => {
    const [data, setData] = useState([])
    const dispatch = useDispatch()
    const [fulldata, setFulldata] = useState([])

    useMemo(async () => {
        let lookupDataType = input?.lookupModule
        const items = [];
        await dispatch(GET_LOOKUP(`/search-${lookupDataType}`)).then((res) => {
            setFulldata(res)
            if (res?.length > 0) {
                for (let item of res) {
                    if (lookupDataType === 'Accounts') {
                        let _i = {
                            value: item?._id,
                            label: item?.AccountName,
                        }

                        items.push(_i);
                    } else if (lookupDataType === 'Vendor') {
                        let _i = {
                            value: item?._id,
                            label: item?.VendorName,
                        }

                        items.push(_i);
                    } else if (lookupDataType === 'Contacts') {
                        let _i = {
                            value: item?._id,
                            label: `${item?.FirstName} ${item?.LastName}`,
                        }
                        items.push(_i);
                    } else if (lookupDataType === 'opportunities') {
                        let _i = {
                            value: item?._id,
                            label: item?.OpportunityName,
                        }

                        items.push(_i);
                    } else if (lookupDataType === 'leads' || lookupDataType === 'Leads') {
                        let _i = {
                            value: item?._id,
                            label: `${item?.FirstName} ${item?.LastName}`,
                        }

                        items.push(_i);
                    } else if (lookupDataType === 'call') {
                        let _i = {
                            value: item?._id,
                            label: item?.ContactName,
                        }

                        items.push(_i);
                    } else if (lookupDataType === 'tasks' || lookupDataType === "Tasks") {
                        let _i = {
                            value: item?._id,
                            label: item?.Subject || 'N/A',
                        }

                        items.push(_i);
                    }else if (lookupDataType === 'inventory') {
                        let _i = {
                            value: item?._id,
                            label: item?.InventoryName,
                        }

                        items.push(_i);
                    } else {
                        let _i = {
                            value: item?._id,
                            label: item?.Subject || item?.ContactName,
                        }

                        items.push(_i);
                    }

                }
            }
        });
        setData(items);
    }, [input?.lookupModule, open])

    return (
        <>
           <Field
                values={values}
                fulldata={fulldata}
                formType={formType}
                setValues={setValues}
                value={input?.value}
                className="custom-select-edit disabled:bg-[#f2f2f2]"
                name={input?.value}
                options={data}
                component={CustomLookup}
                placeholder={input?.label}
                disabled={editable}
                edit={true}
            />
        </>
    )
}

export default LookupModuleFieldEdit