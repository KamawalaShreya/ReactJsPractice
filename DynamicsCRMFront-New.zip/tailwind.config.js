/** @type {import('tailwindcss').Config} */

module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      backgroundImage: {
        'star-one': "url('/assets/images/Star 1.png')",
      },
      colors: {
        primary: '#142D6C',
        secondary: '#FEE500',
        textpara: '#626263',
        btnColorPrimary: '#142D6C'
      }
    }
  },
  plugins: [],
}