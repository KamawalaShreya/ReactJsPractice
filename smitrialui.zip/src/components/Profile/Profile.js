import { Field, Form, Formik } from "formik";
import React, { useEffect, useRef, useState } from "react";
import { get, post } from "../../utils/HttpRequest";
import Footerview from "../Footer/Footer";
import Header from "../Header/Header";
import { Toast } from "primereact/toast";
import config from "../../config/config.json";
import UserPool from "../../utils/UserPool";
import { CognitoUser } from "amazon-cognito-identity-js";
import { Card, Col, Modal, Row } from "react-bootstrap";

const Profile = () => {
  const toast = useRef(null);
  const [languages, setlanguages] = useState([]);
  const [languageInitialValue, setLanguageInitialValue] = useState({});
  const [emailReminderInitialValue, setEmailReminderInitialValue] = useState(
    {}
  );
  const [message, setMessage] = useState("");
  const [isResetPassClicked, setIsResetPassClicked] = useState(false);

  const [inititLoading, setInitLoading] = useState(false);

  const [langDialogVisible, setLangDialogVisible] = useState(false);
  const urlParams = new URLSearchParams(window.location.search);
  var msg = urlParams.get("msg");

  useEffect(() => {
    const url = config.api.url + "getTrialConfig/language";
    const getUserDetailsUrl =
      config.api.url + "getUserDetails/" + localStorage.getItem("email");

    if (msg && msg !== null && msg === "1") {
      setLangDialogVisible(true);
    }
    setInitLoading(true);
    get(url).then((languageResponse) => {
      setlanguages(JSON.parse(languageResponse?.data?.value));
    });
    get(getUserDetailsUrl).then((userData) => {
      setLanguageInitialValue(userData?.data?.languagePreference);
      setEmailReminderInitialValue(userData?.data?.emailReminders === "true");
      setTimeout(() => {
        setInitLoading(false);
      }, 500);
    });
  }, []);

  const handleLanguageChange = (value) => {
   
    const postData = JSON.stringify({
      email: localStorage.getItem("email"),
      language: value,
    });
    var url = config.api.url + "updateUserLanguage";
    post(url, postData).then(() => {
      localStorage.setItem("userLanguage", value);
      setLanguageInitialValue(value);
      toast.current.show({
        severity: "success",
        summary: "Language updated",
        detail: "Your language has been updated.",
      });
    });
  };

  const createCognitoUser = (email) => {
    return new CognitoUser({
      Username: email,
      Pool: UserPool,
    });
  };

  const resetMyPassword = () => {
    setIsResetPassClicked(true);
   
    let email = localStorage.getItem("email");
    var cognitoUser = createCognitoUser(email);

    cognitoUser.forgotPassword({
      onSuccess: function (result) {
        console.log("Password reset message on success: " + result);
        // $('#profilePageResetPasswordDiv').addClass('d-none');
        // $('#profilePageVerifyCode').addClass('d-block').removeClass('d-none');
        // show password verification code form
      },
      onFailure: function (err) {
        switch (err.code) {
          case "CodeMismatchException": {
            setMessage("Verification code is incorrect.");
            // $('#resetPasswordFormMessage').html("Verification code is incorrect.");
            break;
          }
          case "InvalidPasswordException": {
            setMessage(
              "New password is not strong enough. Your password much be 8 characters long and contain at least one number, special character, uppercase letter and lowercase letter"
            );
            // $('#resetPasswordFormMessage').html("New password is not strong enough. Your password much be 8 characters long and contain at least one number, special character, uppercase letter and lowercase letter");
            break;
          }
          case "InvalidParameterException": {
            setMessage("Verification code is incorrect.");
            // $('#resetPasswordFormMessage').html("Verification code is incorrect.");
            break;
          }
          default: {
            // $('#resetPasswordFormMessage').html(err);
            setMessage(err.message);
          }
        }
        console.log("onFailure: " + err);
        console.log("onFailure: " + err.code);
      },
      inputVerificationCode: null,
    });
  };

  const handleSubmit = (values, { setSubmitting }) => {

    handleResetPasswordVerify(
      values.code,
      values.confirmPassword,
      values.newPassword,
      setSubmitting
    );
  };

  const handleResetPasswordVerify = (
    code,
    confirmpass,
    newpass,
    setSubmitting
  ) => {
    let email = localStorage.getItem("email");
   

    if (newpass === confirmpass) {
      

      var cognitoUser = createCognitoUser(email);

      cognitoUser.confirmPassword(code, newpass, {
        onFailure: function (err) {
          setSubmitting(false);
          switch (err.code) {
            case "CodeMismatchException": {
              setMessage("Verification code is incorrect.");
              break;
            }
            case "InvalidPasswordException": {
              setMessage(
                "New password is not strong enough. Your password much be 8 characters long and contain at least one number, special character, uppercase letter and lowercase letter"
              );
              break;
            }
            case "InvalidParameterException": {
              setMessage(
                "Verification code is incorrect or new password is not strong enough. Your password much be 8 characters long and contain at least one number, special character, uppercase letter and lowercase letter"
              );
              break;
            }
            case "LimitExceededException": {
              setMessage("Too may attempts. Please try after some time.");
              break;
            }
            case "ExpiredCodeException": {
              setMessage(
                "Your verification code has expired. Please click forgot password link again."
              );
              break;
            }
            default: {
              setMessage(err.message);
            }
          }
          console.log("onFailure: " + err);
          console.log("onFailure: " + err.code);
        },
        onSuccess: function (res) {
          console.log("Password has been reset : " + res);
          setMessage("Your password has been reset.");
        },
      });
    } else {
      setMessage("New password and confirm password does not match.");
      setSubmitting(false);
    }
  };

  const changeEmailRemindersValue = () => {
    let status = `${!emailReminderInitialValue}`;
    setEmailReminderInitialValue(!emailReminderInitialValue);
    post(config.api.url + "userReminderStatus", { status: status })
      .then((result) => {
        let reminderUpdate = result.data;
      
      })
      .catch((err) => {
        console.log("Error updating userreminderstatus ", err);
      });
  };

  return (
    <div className="profilePage app">
      <Toast ref={toast}></Toast>
      <Header />
      <div className="page-inner">
        <div className="row">
          <div className="col-12 col-sm-6 col-lg-0">
            <div className="card card-fluid p-4">
              <div className="form-group">
                <label> Name </label>
                <input
                  value={localStorage.getItem("userName")}
                  className="form-control input-group bg-secondary"
                  id="profileName"
                  disabled={true}
                />
              </div>
              <div className="form-group">
                <label> Email </label>
                <input
                  value={localStorage.getItem("email")}
                  className="form-control input-group bg-secondary"
                  id="profileEmail"
                  disabled={true}
                />
              </div>
            </div>

            <div className="card card-fluid p-4">
              <div className="form-group">
                <h6 className="card-title"> Select your default language </h6>
                <div className="table-responsive" id="languageAssignmentDiv">
                  <Formik
                    initialValues={{
                      userLanguage: languageInitialValue,
                    }}
                    enableReinitialize
                  >
                    {(formik) => (
                      <Form>
                        <table className="table" id="languageAssignmentTable">
                          <thead>
                            <tr>
                              <th> language Name </th>
                              <th className="text-center1"> Assign</th>
                            </tr>
                          </thead>

                          {languages.map((item, index) => (
                            <tbody key={index} className="w-100">
                              <tr>
                                <td> {item.languageName} </td>
                                <td>
                                  <div
                                    className={`custom-control custom-radio`}
                                  >
                                    <Field
                                      id={`lang_` + index}
                                      className="custom-control-input"
                                      type="radio"
                                      name="userLanguage"
                                      value={item.languageName}
                                      checked={
                                        item.languageName ===
                                        languageInitialValue
                                      }
                                      onClick={() => {
                                        handleLanguageChange(item.languageName);
                                      }}
                                    />
                                    <label
                                      className="custom-control-label"
                                      htmlFor={`lang_` + index}
                                    ></label>
                                  </div>
                                </td>
                              </tr>
                              {formik.userLanguage}
                            </tbody>
                          ))}
                        </table>
                      </Form>
                    )}
                  </Formik>
                </div>
              </div>
            </div>
          </div>
          <div className="col-12 col-sm-6 col-lg-0">
            <div className="card card-fluid p-4">
              {/* profile page here */}
              <div
                className={`form-group mb-0 mt-3 ${
                  isResetPassClicked ? "d-none" : ""
                }`}
                id="profilePageResetPasswordDiv"
              >
                <input
                  type="submit"
                  onClick={() => {
                    resetMyPassword();
                  }}
                  className="btn btn-lg btn-block btn-primary profilePageResetPassword"
                  value="Reset My Password"
                />
                <p className="pt-4">
                  Click on the button above to reset your password. We will
                  email you a verification code. You will need to enter the
                  verification code and new password on the next page.
                </p>
              </div>
              <div className={isResetPassClicked ? "" : "d-none"}>
                <Formik
                  initialValues={{
                    code: "",
                    newPassword: "",
                    confirmPassword: "",
                  }}
                  onSubmit={handleSubmit}
                >
                  {({ isSubmitting, errors }) => (
                    <Form
                      id="profilePageVerifyCode"
                      className="needs-validation1"
                    >
                      <div className="px-3">
                        <p>We have emailed you a verification code.</p>
                        <div className="form-group mt-3 mb-3">
                          <label htmlFor="profilePageCode">
                            Enter your verification code from email.
                          </label>
                          <Field
                            type="text"
                            name="code"
                            id="profilePageCode"
                            className="form-control form-control-lg"
                            placeholder="Code"
                            required
                          />
                          {isSubmitting && !errors.code && (
                            <div className="invalid-feedback">
                              Verification code is required.
                            </div>
                          )}
                        </div>

                        <div className="form-group mt-3 mb-3">
                          <label htmlFor="profilePageNewPassword">
                            Enter new password.
                          </label>
                          <Field
                            type="password"
                            name="newPassword"
                            id="profilePageNewPassword"
                            className="form-control form-control-lg"
                            placeholder="Password"
                            required
                          />
                          {isSubmitting && !errors.newPassword && (
                            <div className="invalid-feedback">
                              New password is required.
                            </div>
                          )}
                        </div>

                        <div className="form-group mt-3 mb-3">
                          <label htmlFor="profilePageConfimPassword">
                            Confirm password.
                          </label>
                          <Field
                            type="password"
                            name="confirmPassword"
                            id="profilePageConfimPassword"
                            className="form-control form-control-lg"
                            placeholder="Password"
                            required
                          />
                          {isSubmitting && !errors.confirmPassword && (
                            <div className="invalid-feedback">
                              Confirm password is required.
                            </div>
                          )}
                        </div>

                        <div className="form-group mb-0">
                          <button
                            type="submit"
                            className="btn btn-lg btn-block btn-primary mt-3"
                            disabled={isSubmitting}
                          >
                            Reset Password
                          </button>
                        </div>

                        <p id="profilePageMessage" className="pt-3"></p>
                      </div>
                    </Form>
                  )}
                </Formik>
              </div>

              <div id="newpasswordMessage">{message}</div>
            </div>

            <div className="card card-fluid p-4">
              <div className="form-group">
                <h6 className="card-title"> Email reminders </h6>
                <div className="table-responsive" id="emailRemindersDiv">
                  <table className="table" id="emailRemindersTable">
                    <thead>
                      <tr>
                        <th> Actions </th>
                        <th className="text-center1"> Status</th>
                      </tr>
                      <tr>
                        <td>Email reminders</td>
                        <td>
                          <div>
                            <span className="d-none"></span>
                            <div className="d-flex requiredCheckbox">
                              <label
                                className={`switcher-control ${
                                  emailReminderInitialValue
                                    ? "switcher-control-success"
                                    : ""
                                }`}
                              >
                                <input
                                  type="checkbox"
                                  className="switcher-input StatusCheckBox"
                                  name="formLessonStatus"
                                  checked={
                                    emailReminderInitialValue ? true : false
                                  }
                                  onChange={() => {
                                    changeEmailRemindersValue();
                                  }}
                                />
                                <span className="switcher-indicator"></span>
                              </label>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </thead>
                    <tbody></tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Modal
        show={langDialogVisible}
        onHide={() => setLangDialogVisible(false)}
        size="sm"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header className="w-100">
          <Modal.Title className="w-100">Set you default language</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div>
            <p>
              {" "}
              You must set your language preference before you can start using
              SMi Trial.{" "}
            </p>
            <p>
              {" "}
              Please select one language from the available language options.{" "}
            </p>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              setLangDialogVisible(false);
            }}
            data-dismiss="modal"
          >
            Close
          </button>
        </Modal.Footer>
      </Modal>
      <Modal
        show={inititLoading}
        onHide={() => setInitLoading(false)}
        size="sm"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Card.Body
          style={{ height: "200px" }}
          className="d-flex justify-content-center align-items-center"
        >
          <Row>
            <Col lg={12}>
              <div className="text-center">
                <h6 className="card-title">
                  Please wait while loading profile details
                </h6>
                <div className="mb-3">
                  <i
                    className="pi pi-spin pi-spinner"
                    style={{ fontSize: "3rem" }}
                  ></i>
                </div>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Modal>
      <Footerview />
    </div>
  );
};
export default Profile;
