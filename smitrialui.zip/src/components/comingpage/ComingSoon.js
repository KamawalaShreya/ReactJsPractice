import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../Header/Header";

const ComingSoonPage = () => {
  return (
    <div className="app">
      <Container fluid>
        <Header />
        <div className="SiteManagerPage">
          <Row>
            <Col lg={12}>
              <div className="manager_bar">
                <span className="card-title ">coming soon</span>
              </div>
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default ComingSoonPage;
