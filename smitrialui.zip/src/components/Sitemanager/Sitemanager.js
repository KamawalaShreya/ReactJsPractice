import React, { useEffect } from "react";
import Header from "../Header/Header";
import { Card, Col, Container, Row } from "react-bootstrap";
import { Button } from "primereact/button";
import Datatable from "../Common/Datatable";
import { useRef } from "react";
import { useState } from "react";
import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import ExcelUploadDialog from "../Exceluploadview/ExcelUploadDialog";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChartPie, faPen } from "@fortawesome/free-solid-svg-icons";
import SiteCreateForm from "./SiteCreateForm";
import { useNavigate } from "react-router-dom";
import { Dialog } from "primereact/dialog";
import { Toast } from "primereact/toast";

const Sitemanager = () => {

  const toast = useRef(null);

  const navigate = useNavigate();

  // state variables
  const [sitesData, setSitesData] = useState([]);

  const [editSiteData, seteditSiteData] = useState(null);
  const [editSiteId, setEditSiteId] = useState([]);

  const [visible, setVisible] = useState(false);
  const [position, setPosition] = useState("center");

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(sitesData);

  // excel upload dialog state variable
  const [dialogVisible, setDialogVisible] = useState(false);

  // for edit user functionality
  const [fetchDataFlag, setFetchDataFlag] = useState(null);

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);
 

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 991);
  };

  useEffect(() => {
    // variables
    window.addEventListener("resize", handleResize);
    var url = config.api.url + "getMySitesV2";

    if (fetchDataFlag === null) {
      get(url)
        .then((response) => {
          setSitesData(response.data);
          setFilteredData(response.data);
        })
        .catch((error) => {
          console.log("Error getting sites :", error.response.status);
        });
    }
    if (fetchDataFlag) {
      const editUserUrl = config.api.url + "getOneSite/" + editSiteId;
      get(editUserUrl).then((editSiteResponse) => {
        let sitedata = editSiteResponse.data;
        seteditSiteData(sitedata);
        setFetchDataFlag(false);
        show("top");
      });
    }
  }, [fetchDataFlag]);

  const show = (position) => {
    setPosition(position);
    setVisible(true);
  };

  const openExcelDialog = () => {
    setDialogVisible(true);
  };

  const closeExcelDialog = () => {
    setDialogVisible(false);
  };

  const createSiteLinkAction = (position) => {
    setEditSiteId(null);
    seteditSiteData(null);
    show(position);
  };

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? sitesData.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : sitesData;
    setFilteredData(filtered);
    setSearchText(searchText);
  };
  const defaultSorted = [
    {
      dataField: "sitename",
      order: "asc",
    },
  ];
  const siteColumns = [
    {
      dataField: "sitename",
      text: "Site Code",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <a
            href={"/sitedetails?siteid=" + row.siteid}
            onClick={(e) => {
              e.preventDefault();
              navigate("/sitedetails?siteid=" + row.siteid);
            }}
          >
            {row.sitename}
          </a>
        );
      },
    },
    {
      dataField: "description",
      text: "Site Description",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "address",
      text: "Site Address",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "country",
      text: "Site Country",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "userCount",
      text: "No. Of Users",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "Action",
      text: "Action",
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <div className="list-group-item-figure">
              <a
                href="#"
                className="btn btn-sm btn-icon btn-secondary mr-1"
                onClick={() => {
                  setEditSiteId(row.siteid);
                  setFetchDataFlag(true);
                }}
              >
                <FontAwesomeIcon icon={faPen} />
              </a>
              <a
                href={"/sitereports?siteid=" + row.siteid}
                className="btn btn-sm btn-icon btn-secondary"
              >
                <FontAwesomeIcon
                  icon={faChartPie}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate("/sitereports?siteid=" + row.siteid);
                  }}
                />
              </a>
            </div>
          </div>
        );
      },
    },
  ];

  return (
    <div className="userManagerPage app">
      <Header />

      {!isMobile ? (
        <Container fluid style={{ width: "100%" }}>
          <div className="page-inner">
            <Row>
              <Col lg={12}>
                <Card className="mt-3 ">
                  <Card.Body>
                    <div className="card-title" style={{ textAlign: "Left" }}>
                      <Row>
                        <Col md={4} lg={4}>
                          <span>Site Manager</span>
                        </Col>
                        <Col
                          md={8}
                          lg={8}
                          style={{
                            textAlign: "right",
                            display: "flex",
                            justifyContent: "flex-end",
                            alignItems: "center",
                          }}
                        >
                          Create Site &nbsp;
                          <Button
                            icon="pi pi-plus"
                            rounded
                            severity="secondary"
                            onClick={() => createSiteLinkAction("top")}
                            style={{ background: "#4d4d4d" }}
                            aria-label="Create User"
                          />
                          &nbsp; &nbsp; Bulk Upload Sites &nbsp;
                          <Button
                            icon="pi pi-upload"
                            rounded
                            severity="secondary"
                            style={{ background: "#4d4d4d" }}
                            onClick={() => openExcelDialog()}
                            aria-label="Add Multiple Users using XLSX file"
                          />
                        </Col>
                      </Row>
                    </div>
                    <div className="mt-2">
                      <Datatable
                        keyField={"siteid"}
                        defaultSorted={defaultSorted}
                        data={sitesData}
                        Pagination={true}
                        handleSearchChange={handleSearchChange}
                        columns={siteColumns}
                        filteredData={filteredData}
                        searchText={searchText}
                      />
                    </div>
                  </Card.Body>
                  <Toast ref={toast}></Toast>
                  <Dialog
                    header={`${editSiteData ? "Edit Site" : "Create Site"}`}
                    visible={visible}
                    position={position}
                    style={{ width: "37vw" }}
                    onHide={() => setVisible(false)}
                    // onMaskClick={() => setVisible(false)}
                    dismissableMask={true}
                    draggable={false}
                    resizable={false}
                  >
                    <SiteCreateForm
                      setVisible={setVisible}
                      initialValues={editSiteData}
                      toast={toast}
                      submitDetect={(eventValue) => {
                        setTimeout(() => {
                          console.log("SubmitEvent Detected", eventValue);
                          setFetchDataFlag(null);
                        }, 2000);
                      }}
                    />
                  </Dialog>

                  <ExcelUploadDialog
                    dialogTitle={"Upload File for Bulk Site creation"}
                    dialogSubTitle={
                      "For better performance upload less than 500 sites per file."
                    }
                    excelDialogVisible={dialogVisible}
                    excelDialogOnClose={closeExcelDialog}
                  ></ExcelUploadDialog>
                </Card>
              </Col>
            </Row>
          </div>
        </Container>
      ) : (
        <div className={`alert alert-dark mt-2 ml-2 mr-2 text-center`}>
          <p> Desktop access is required to view Site manager</p>
        </div>
      )}
    </div>
  );
};
export default Sitemanager;
