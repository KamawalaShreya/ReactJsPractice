import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import config from "../../config/config.json";
import { post } from "../../utils/HttpRequest";
import "./SiteCreateForm.css";

const SiteCreateForm = (props) => {
  var initialValues = {
    sitename: "",
    description: "",
    address: "",
    country: "",
  };
  var oldSite = null;

  const validateForm = (values) => {
    const errors = {};
    if (!values.sitename) {
      errors.sitename = "Valid site code is required.";
    }
    if (!values.description) {
      errors.description = "Valid site description is required.";
    }
    return errors;
  };

  let editFlag = false;

  if (props.initialValues) {
    initialValues = props.initialValues;
    editFlag = true;
    oldSite = props.initialValues;
  } else {
    editFlag = false;
    oldSite = null;
  }

  const handleSubmit = (values, { setSubmitting }) => {
    var url = config.api.url + "updateSite";
    var createSiteitle = "Site Create";
    var createSiteMessage = "Site Created successfully.";
    if (editFlag) {
      url = config.api.url + "editSiteDetails";
      values.siteid = oldSite.siteid;
      values.sitenameOld = oldSite.sitename;
    }
    let localValues = values;
   
    if (props.submitDetect) {
      props.submitDetect("success");
    }
    post(url, localValues)
      .then(() => {
        props.toast.current.show({
          severity: "success",
          summary: createSiteitle,
          detail: createSiteMessage,
        });
        props.setVisible(false);
        setSubmitting(false);
        if (props.submitDetect) {
          props.submitDetect("success");
        }
      })
      .catch((reason) => {
      
        props.toast.current.show({
          severity: "warn",
          summary: createSiteitle,
          detail: "Something went wrong.",
        });
        props.setVisible(false);
        setSubmitting(false);
        if (props.submitDetect) {
          props.submitDetect("error");
        }
      });
  };

  return (
    <Formik
      initialValues={initialValues}
      validate={validateForm}
      onSubmit={handleSubmit}
    >
      {({ isSubmitting }) => (
        <Form>
          <div className="p-field mt-5">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="sitename"
                name="sitename"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="sitename">Site Code</label>
            </span>
            <ErrorMessage name="sitename" component="div" className="p-error" />
          </div>
          <div className="p-field mt-5">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="description"
                name="description"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="description">Site Description</label>
            </span>
            <ErrorMessage
              name="description"
              component="div"
              className="p-error"
            />
          </div>
          <div className="p-field mt-5">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="address"
                name="address"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="address">Address</label>
            </span>
            <ErrorMessage name="address" component="div" className="p-error" />
          </div>
          <div className="p-field mt-5">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="country"
                name="country"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="country">Country</label>
            </span>
            <ErrorMessage name="country" component="div" className="p-error" />
          </div>
          <Button
            type="submit"
            label={`${editFlag ? "Save" : "Create Site"}`}
            style={{
              background: "#4d4d4d",
              textAlign: "left",
              fontWeight: "400",
            }}
            disabled={isSubmitting}
            className={`p-button-primary ${
              isSubmitting ? "p-disabled" : ""
            } mt-4`}
          />
        </Form>
      )}
    </Formik>
  );
};
export default SiteCreateForm;
