import "./Dashboard.css";

import { Card, Col } from "react-bootstrap";
import React, { useEffect, useState } from "react";
import { faAward, faEllipsisV } from "@fortawesome/free-solid-svg-icons";
import { get, post } from "../../utils/HttpRequest";
import { useNavigate, useSearchParams } from "react-router-dom";
import Dropdown from "react-bootstrap/Dropdown";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Footerview from "../Footer/Footer";
import Header from "../Header/Header";
import axios from "axios";
import config from "../../config/config.json";
// import { createAndDownloadBlobFile } from "../../utils/Common";
import { env } from "../../env";

const Dashboard = () => {
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");
  var parentids = params.get("parentids");
  var parentNames = params.get("parentNames");
  var [parentLessonNames, setparentLessonNames] = useState([]);
  var [parentLessonIds, setparentLessonIds] = useState([]);
  const [dashboardData, setDashboardData] = useState([]);
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  var url = env.REACT_APP_api_url + "getDashboardData?location=dashboard";
  const [dashboardAlertData, setDashboardAlertData] = useState("");
  const [cardClassToggle, setCardClassToggle] = useState(false);
  const [searchDashboardData, setSearchDashboardData] = useState([]);
  const [retries, setRetries] = useState(0);

  const [namee, setNamee] = useState([]);

  function createAndDownloadBlobFile(body, filename, extension = "txt") {
    const blob = new Blob([body]);
    const fileName = `${filename}.${extension}`;
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, fileName);
    } else {
      const link = document.createElement("a");
      // Browsers that support HTML5 download attribute
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", fileName);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  const removeFileExtension = (url) => {
    const fileName = url.split("/").pop();
    const extension = fileName.split(".").pop();
    const baseName = fileName.replace("." + extension, "");
    const urlWithoutExtension = url.replace(fileName, baseName);
    return urlWithoutExtension;
  };

  const changeImageUrl = (element) => {
    const srcEle = element.src.split(".");

    if (retries <= 7) {
      setRetries(retries + 1);
      const urlWithoutExtension = removeFileExtension(element.src);
      const extension = srcEle.pop();
      if (extension === "png") {
        element.src = urlWithoutExtension + ".jpg";
      } else if (extension === "jpg") {
        element.src = urlWithoutExtension + ".jpeg";
      } else if (extension === "jpeg") {
        setNamee((previous) => [
          ...previous,
          { src: srcEle.join("."), isError: true },
        ]);
      }
    } else {
      srcEle.pop();


      setNamee((previous) => [
        ...previous,
        { src: srcEle.join("."), isError: true },
      ]);
    }
  };

  useEffect(() => {
    if (parentNames !== null && parentids !== null) {
      setparentLessonNames(parentNames.split("|").filter((n) => n));
      setparentLessonIds(parentids.split("|").filter((n) => n));
    } else {
      setparentLessonNames([]);
      setparentLessonIds([]);
    }
    if (lessonid && lessonid != null && lessonid !== "") {
      document
        .querySelector("#nestedlessonBreadcrumb")
        .classList.remove("d-none");
      document
        .querySelector("#nestedlessonBreadcrumb")
        .classList.add("d-block");
      url = url + "&lessonid=" + lessonid;
      // prepareBreadCrumbs()
    } else {
      document
        .querySelector("#nestedlessonBreadcrumb")
        .classList.remove("d-block");
      document.querySelector("#nestedlessonBreadcrumb").classList.add("d-none");
    }
    get(url).then((response) => {
      var subRoleData = response.data.getUserSubroleResponse;
      if (subRoleData.statusCode === 200) {
        subRoleData = subRoleData.response;
      
        if (subRoleData.languagePreference) {
          localStorage.setItem("userLanguage", subRoleData.languagePreference);
        }
        if ("subrole" in subRoleData) {
          localStorage.setItem("userSubRole", subRoleData.subrole);
        } else {
          localStorage.setItem("userSubRole", "");
        }
      }
      if (
        localStorage.getItem("userLanguage") &&
        !localStorage.getItem("userLanguage").length > 2
      ) {
      
        navigate("/profile?msg=1");
      }
      setSearchDashboardData(
        response.data.getSearchTermsResponse.response.dashboard
      );
      setDashboardData(
        response.data.getParticularUserBoardResponse.response.dashboard
      );
    });
  }, [searchParams]);

  const getDashboardAlert = async () => {
    try {
      const url = env.REACT_APP_api_url + "getTrialConfig/dashboardAlert";
      get(url).then((response) => {
        setDashboardAlertData(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  // const prepareBreadCrumbs = () => {
  //   if (parentNames !== null && parentids !== null) {
  //     let parentLessonNames = parentNames.split("|");
  //     parentLessonNames = parentLessonNames.filter((n) => n);
  //     let parentLessonIds = parentids.split("|");
  //     parentLessonIds = parentLessonIds.filter((n) => n);
  //     // for (var j = 0; j < parentLessonNames.length; j++) {
  //     //     document.querySelector('#nestedlessonBreadcrumb ol.breadcrumb').append('<li class="breadcrumb-item"><a class="breadcrumb-link" href="dashboard?lessonid=' + parentLessonIds[j] + "&parentids=" + parentLessonIds.slice(0, j + 1).join('|') + "&parentNames=" + parentLessonNames.slice(0, j + 1).join('|') + '">' + parentLessonNames[j] + '</a></li>');
  //     // }
  //   }
  // };

  const handleDownloadCertificate = (lessonid) => {
    var url = env.REACT_APP_api_url + "createCertificate";
    let data = { lessonid: lessonid };
    const urlParams = new URLSearchParams(window.location.search);
    var userEmail = urlParams.get("user");
    if (userEmail != null) {
      userEmail = userEmail.replace(/ /g, "+");
    }
    if (
      localStorage.getItem("userRole") === "smiadmin" &&
      userEmail !== null &&
      userEmail.length > 6
    ) {
      data = { lessonid: lessonid, email: userEmail };
    }
    post(url, data)
      .then((result) => {
        let certificateData = result.data;
        let fileName =
          "certificate_" +
          certificateData
            .substring(certificateData.lastIndexOf("/") + 1)
            .split(".")[0];
        const s3FetchInstance = axios.create();
        s3FetchInstance
          .get(certificateData, { responseType: "blob" })
          .then((result) => {
            createAndDownloadBlobFile(result.data, fileName, "pdf");
          })
          .catch((err) => {
            console.log("Error fetching certificate file from s3", err);
          });
      })
      .catch((err) => {
        console.log("Error fetching certificate ", err);
      });
  };

  useEffect(() => {
    getDashboardAlert();
  }, []);
  return (
    <div className="dashboardPage app">
      <Header searchDashboardData={searchDashboardData} />
      {dashboardAlertData && dashboardAlertData.length > 0 ? (
        <div className="userAlert bg-smi-green">{dashboardAlertData}</div>
      ) : null}
      <div className="page" style={{ minHeight: "calc(100vh - 10rem)" }}>
        <div className="mr-2 mt-4">
          <nav
            aria-label="breadcrumb"
            id="nestedlessonBreadcrumb"
            className="d-none pl-4"
          >
            <ol className="breadcrumb breadcrumb-no-gutter">
              <li className="breadcrumb-item">
                <a
                  className="breadcrumb-link"
                  href="dashboard"
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(`/dashboard`);
                  }}
                >
                  Home
                </a>
              </li>
              {parentLessonNames.map((parentName, j) => (
                <li className="breadcrumb-item" key={parentName}>
                  <a
                    className="breadcrumb-link"
                    href={`dashboard?lessonid=${parentLessonIds[j]
                      }&parentids=${parentLessonIds
                        .slice(0, j + 1)
                        .join("|")}&parentNames=${parentLessonNames
                          .slice(0, j + 1)
                          .join("|")}`}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(
                        `/dashboard?lessonid=${parentLessonIds[j]
                        }&parentids=${parentLessonIds
                          .slice(0, j + 1)
                          .join("|")}&parentNames=${parentLessonNames
                            .slice(0, j + 1)
                            .join("|")}`
                      );
                    }}
                  >
                    {parentLessonNames[j]}
                  </a>
                </li>
              ))}
            </ol>
          </nav>
          <div id="dashboardContainer">
            {dashboardData.length === 0 &&
              Array.from({ length: 8 }).map((_, index) => (
                <Col
                  key={index}
                  xs={12}
                  md={4}
                  lg={3}
                  sm={6}
                  className="smi-card-outer"
                // style={{ padding: "1rem 0.4rem" }}
                >
                  <Card
                    className={`smi-card ${!cardClassToggle ? "card-hover-shadow" : ""
                      }`} /* card-hover-shadow */
                  >
                    <Card.Header style={{ padding: "0.2rem" }}>
                      <div className="row ml-1">
                        <h6 className="col-10 truncateText text-left float-left">
                          <span
                            width="100%"
                            className="mb-1 mt-2 shine lines"
                          ></span>
                        </h6>
                      </div>
                    </Card.Header>
                    <Card.Body className="smi-card-body onclickLesson shine">
                      <div>
                        <div
                          className="img-fluid d-flex align-items-center justify-content-center cardImg"
                          height="150px"
                        ></div>
                      </div>
                    </Card.Body>
                    <div className="smi-card-footer">
                      <div className="smi-lessoncard-header">
                        <div className="task-title mr-auto w-100">
                          <div className="row">
                            <div className="small p-0 text-left float-left"></div>
                            <span
                              className="mb-1 mt-2 shine lines"
                              style={{ width: "7rem" }}
                            ></span>
                          </div>
                        </div>
                        <Dropdown
                          className="dropdown_dahsboard_card"
                          id={"cardFtrDropdown_" + index}
                        >
                          <Dropdown.Toggle
                            className="btn btn-icon btn-light"
                            id="dropdown-split-basic"
                          >
                            <button
                              className="btn btn-icon btn-light"
                              id="dropdown-basic"
                            >
                              <FontAwesomeIcon icon={faEllipsisV} />
                            </button>
                          </Dropdown.Toggle>
                        </Dropdown>
                      </div>
                    </div>
                  </Card>
                </Col>
              ))}
            {dashboardData.map((lesson, k) => (
              <Col
                key={k}
                xs={12}
                md={4}
                lg={3}
                sm={6}
                className="smi-card-outer"
              >
                <Card
                  className={`smi-card ${lesson.lessoncardtype || ""} ${lesson.lessoncardtype === "pinkCard" ? "card-border" : ""
                    } ${lesson.lessoncardtype === "blackCard" ? "card-border" : ""
                    } ${lesson.lessoncardtype === "greenCard" ? "card-border" : ""
                    } ${lesson.lessoncardtype === "lightblueCard"
                      ? "card-border"
                      : ""
                    } ${lesson.lessoncardtype === "blueCard" ? "card-border" : ""
                    } ${!cardClassToggle ? "card-hover-shadow" : ""
                    }`} /* card-hover-shadow */
                >
                  <Card.Header style={{ padding: "0.2rem" }}>
                    <div className="row ml-1">
                      <h6 className="col-10 truncateText text-left float-left">
                        {lesson.name}
                      </h6>
                      {lesson.status === "completed" &&
                        (lesson.result === "NA" || lesson.result === "Pass") ? (
                        <FontAwesomeIcon
                          onClick={(e) => {
                            e.preventDefault();
                            handleDownloadCertificate(lesson.id);
                          }}
                          icon={faAward}
                          color="green"
                          className="col-1 downloadCertificate  c-smi-green smi-btn text-right float-right mt-1"
                        />
                      ) : (
                        ""
                      )}
                    </div>
                  </Card.Header>

                  <Card.Body
                    className="smi-card-body onclickLesson"
                    data-id={lesson.id}
                    onClick={(e) => {
                      e.preventDefault();
                      if (lesson.lessontype === "nestedcard") {
                        navigate(
                          `/dashboard?lessonid=${lesson.id}&parentids=${parentids ? parentids + "|" + lesson.id : lesson.id
                          }&parentNames=${parentNames
                            ? parentNames + "|" + lesson.name
                            : lesson.name
                          }`,
                          { replace: false }
                        );
                      } else if (lesson.lessontype === "externallink") {
                        window.open(lesson.lessonurl, "_blank");
                      } else {
                        if (window.innerWidth <= 768) {
                          if (lesson.lessontype === "assessment") {
                            navigate(
                              `/lessonviewassessmentmobile?lessonid=${lesson.id
                              }${parentids
                                ? `&parentids=${parentids
                                  ? parentids + "|" + lesson.id
                                  : lesson.id
                                }&parentNames=${parentNames
                                  ? parentNames + "|" + lesson.name
                                  : lesson.name
                                }`
                                : ``
                              }`,
                              { replace: false }
                            );
                          } else {
                            navigate(
                              `/lessonviewmobile?lessonid=${lesson.id}${parentids
                                ? `&parentids=${parentids
                                  ? parentids + "|" + lesson.id
                                  : lesson.id
                                }&parentNames=${parentNames
                                  ? parentNames + "|" + lesson.name
                                  : lesson.name
                                }`
                                : ``
                              }`,
                              { replace: false }
                            );
                          }
                        } else {
                          navigate(
                            `/lessonview?lessonid=${lesson.id}${parentids
                              ? `&parentids=${parentids
                                ? parentids + "|" + lesson.id
                                : lesson.id
                              }&parentNames=${parentNames
                                ? parentNames + "|" + lesson.name
                                : lesson.name
                              }`
                              : ``
                            }`
                          );
                        }
                      }
                    }}
                  >
                    {lesson.lessoncardheader && (
                      <div
                        className={`cardOptionalText1 ${lesson.lessoncardtype === "whiteCard"
                            ? "cardOptionalText1"
                            : ""
                          } ${lesson.lessoncardtype === "blueCard"
                            ? "blueHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "greenCard"
                            ? "greenHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "pinkCard"
                            ? "pinkHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "blackCard"
                            ? "blackHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "lightblueCard"
                            ? "lightblueHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "yellowCard"
                            ? "yellowHeaderBg"
                            : ""
                          } ${lesson.lessoncardtype === "lightgrayCard"
                            ? "lightgrayHeaderCard"
                            : ""
                          }`}
                      >
                        <h6 className="font-weight-300 truncateText">
                          {lesson.lessoncardheader}
                        </h6>
                      </div>
                    )}
                    {lesson.lessontype === "nestedcard" ||
                      lesson.lessontype === "externallink" ? (
                      <div>
                        <a
                          href={
                            lesson.lessontype === "nestedcard"
                              ? `dashboard?lessonid=${lesson.id}&parentids=${parentids
                                ? parentids + "|" + lesson.id
                                : lesson.id
                              }&parentNames=${parentNames
                                ? parentNames + "|" + lesson.name
                                : lesson.name
                              }`
                              : lesson.lessontype === "externallink"
                                ? lesson.lessonurl
                                : ""
                          }
                          // onClick={(e) => {
                          //   console.log("???????????");
                          //   e.preventDefault();
                          //   if (lesson.lessontype === "nestedcard") {
                          //     navigate(
                          //       `/dashboard?lessonid=${lesson.id}&parentids=${
                          //         parentids
                          //           ? parentids + "|" + lesson.id
                          //           : lesson.id
                          //       }&parentNames=${
                          //         parentNames
                          //           ? parentNames + "|" + lesson.name
                          //           : lesson.name
                          //       }`
                          //     );
                          //   } else if (lesson.lessontype === "externallink") {
                          //     window.open(lesson.lessonurl, "_blank");
                          //   }
                          // }}
                          className="img-link h-100 d-sm-block d-md-block d-lg-block d-xl-block"
                        >
                          <div>
                            {namee.find(
                              (item) =>
                                item?.src ===
                                `${config.content.url}${lesson.id}/${lesson.id}`
                            )?.isError ? (
                              <p
                                className="p-8"
                                style={{
                                  textAlign: "center",
                                  fontSize: "large",
                                }}
                              >
                                {lesson.name}
                              </p>
                            ) : (
                              <Card.Img
                                className={`img-fluid align-items-center justify-content-center cardImg  ${lesson.status === "completed"
                                    ? "completeLesson"
                                    : ""
                                  } ${lesson.lessoncardtype &&
                                    lesson.lessoncardtype !== ""
                                    ? "d-none"
                                    : "d-flex"
                                  }`}
                                loading="lazy"
                                src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                                alt={lesson.id}
                                onError={(e) => changeImageUrl(e.target)}
                              />
                            )}
                            {lesson.lessoncarddescription && (
                              <p className="p-2 cardText">
                                {lesson.lessoncarddescription}
                              </p>
                            )}
                          </div>
                        </a>
                      </div>
                    ) : (
                      <div>
                        <a
                          href={`lessonview?lessonid=${lesson.id}${parentids
                              ? `&parentids=${parentids
                                ? parentids + "|" + lesson.id
                                : lesson.id
                              }&parentNames=${parentNames
                                ? parentNames + "|" + lesson.name
                                : lesson.name
                              }`
                              : ``
                            }`}
                          // onClick={(e) => {
                          //   e.preventDefault();
                          //   console.log("hellloowww");
                          //   navigate(
                          //     `/lessonview?lessonid=${lesson.id}${
                          //       parentids
                          //         ? `&parentids=${
                          //             parentids
                          //               ? parentids + "|" + lesson.id
                          //               : lesson.id
                          //           }&parentNames=${
                          //             parentNames
                          //               ? parentNames + "|" + lesson.name
                          //               : lesson.name
                          //           }`
                          //         : ``
                          //     }`
                          //   );
                          // }}
                          className="img-link h-100 d-none d-sm-block d-md-block d-lg-block d-xl-block"
                        >
                          <div>
                            {namee.find(
                              (item) =>
                                item?.src ===
                                `${config.content.url}${lesson.id}/${lesson.id}`
                            )?.isError ? (
                              <p
                                className="p-8"
                                style={{
                                  textAlign: "center",
                                  fontSize: "large",
                                }}
                              >
                                {lesson.name}
                              </p>
                            ) : (
                              <Card.Img
                                className={`img-fluid align-items-center justify-content-center cardImg  ${lesson.status === "completed"
                                    ? "completeLesson"
                                    : ""
                                  } ${lesson.lessoncardtype &&
                                    lesson.lessoncardtype !== ""
                                    ? "d-none"
                                    : "d-flex"
                                  }`}
                                loading="lazy"
                                src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                                alt={lesson.id}
                                onError={(e) => changeImageUrl(e.target)}
                              />
                            )}
                          </div>
                          <p className="p-2 cardText">
                            {lesson.lessoncarddescription}
                          </p>
                        </a>
                        <a
                          href={
                            lesson.lessontype === "assessment"
                              ? `lessonviewassessmentmobile?lessonid=${lesson.id
                              }${parentids
                                ? `&parentids=${parentids
                                  ? parentids + "|" + lesson.id
                                  : lesson.id
                                }&parentNames=${parentNames
                                  ? parentNames + "|" + lesson.name
                                  : lesson.name
                                }`
                                : ``
                              }`
                              : `lessonviewmobile?lessonid=${lesson.id}${parentids
                                ? `&parentids=${parentids
                                  ? parentids + "|" + lesson.id
                                  : lesson.id
                                }&parentNames=${parentNames
                                  ? parentNames + "|" + lesson.name
                                  : lesson.name
                                }`
                                : ``
                              }`
                          }
                          className="img-link h-100 d-block d-sm-none"
                        >
                          {" "}
                          {/* Mobile view tag */}
                          <div>
                            {namee.find(
                              (item) =>
                                item?.src ===
                                `${config.content.url}${lesson.id}/${lesson.id}`
                            )?.isError ? (
                              <p
                                className="p-8"
                                style={{
                                  textAlign: "center",
                                  fontSize: "large",
                                }}
                              >
                                {lesson.name}
                              </p>
                            ) : (
                              <Card.Img
                                className={`img-fluid align-items-center justify-content-center cardImg  ${lesson.status === "completed"
                                    ? "completeLesson"
                                    : ""
                                  }  ${lesson.lessoncardtype &&
                                    lesson.lessoncardtype !== ""
                                    ? "d-none"
                                    : "d-flex"
                                  }`}
                                loading="lazy"
                                src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                                alt={lesson.id}
                                onError={(e) => changeImageUrl(e.target)}
                              />
                            )}
                          </div>
                        </a>
                        {lesson.status === "completed" ? (
                          lesson.lessontype === "assessment" ? (
                            lesson.result === "Pass" ? (
                              <div
                                className={`col-12 ${lesson.lessoncardfooter
                                    ? "lessonStatus1"
                                    : "lessonStatus"
                                  }`}
                              >
                                COMPLETED
                              </div>
                            ) : (
                              <div
                                className={`col-12 ${lesson.lessoncardfooter
                                    ? "retakeLesson1"
                                    : "retakeLesson"
                                  }`}
                              >
                                RETAKE
                              </div>
                            )
                          ) : lesson.result === "NA" ? (
                            <div
                              className={`col-12 ${lesson.lessoncardfooter
                                  ? "lessonStatus1"
                                  : "lessonStatus"
                                }`}
                            >
                              COMPLETED
                            </div>
                          ) : (
                            <div
                              className={`col-12 ${lesson.lessoncardfooter
                                  ? "retakeLesson1"
                                  : "retakeLesson"
                                }`}
                            >
                              RETAKE
                            </div>
                          )
                        ) : null}
                      </div>
                    )}

                    {lesson.lessoncardfooter && (
                      <div
                        className={`${lesson.lessoncardtype === "whiteCard"
                            ? "cardFooterOptional1"
                            : ""
                          } ${lesson.lessoncardtype === "blueCard"
                            ? "blueFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "greenCard"
                            ? "greenFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "pinkCard"
                            ? "pinkFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "blackCard"
                            ? "blackFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "lightblueCard"
                            ? "lightblueFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "yellowCard"
                            ? "yellowFooterBg"
                            : ""
                          } ${lesson.lessoncardtype === "lightgrayCard"
                            ? "lightgrayFooterBg"
                            : ""
                          } footer-border`}
                      >
                        <h6 className="font-weight-100 truncateText">
                          {lesson.lessoncardfooter}
                        </h6>
                      </div>
                    )}
                  </Card.Body>
                  <div className="smi-card-footer">
                    <div className="smi-lessoncard-header">
                      <div className="task-title mr-auto w-100">
                        <div className="row">
                          <div className="small p-0 text-left float-left">
                            {" "}
                            {lesson.lessonRequired === "true"
                              ? "REQUIRED"
                              : "OPTIONAL"}
                          </div>
                        </div>
                      </div>
                      <Dropdown
                        onToggle={(e) => {
                          if (e === true && cardClassToggle === true) {
                            setTimeout(() => {
                              setCardClassToggle(e);
                            }, 100);
                          } else {
                            setCardClassToggle(e);
                          }
                        }}
                        className="dropdown_dahsboard_card"
                        id={"cardFtrDropdown_" + lesson.id}
                      >
                        <Dropdown.Toggle
                          className="btn btn-icon btn-light"
                          id="dropdown-split-basic"
                        >
                          <button
                            className="btn btn-icon btn-light"
                            id="dropdown-basic"
                          >
                            <FontAwesomeIcon icon={faEllipsisV} />
                          </button>
                        </Dropdown.Toggle>

                        <Dropdown.Menu>
                          <Dropdown.Item href="#">
                            Added: {lesson.lessonAdded}
                          </Dropdown.Item>

                          {lesson.lessonDuration !== "NaN min" ? (
                            <Dropdown.Item href="#">
                              Duration: {lesson.lessonDuration}
                            </Dropdown.Item>
                          ) : (
                            <Dropdown.Item href="#">
                              Duration:"0 min"
                            </Dropdown.Item>
                          )}

                          {lesson.version !== undefined ? (
                            <Dropdown.Item href="#">
                              Version: {lesson.version}
                            </Dropdown.Item>
                          ) : (
                            ""
                          )}
                        </Dropdown.Menu>
                      </Dropdown>
                    </div>
                  </div>
                </Card>
              </Col>
            ))}
          </div>
        </div>
      </div>
      <Footerview />
    </div>
  );
};
export default Dashboard;
