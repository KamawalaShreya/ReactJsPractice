import React, { useState } from "react";
import { Button } from "react-bootstrap";
import { Editor } from "primereact";
import { post } from "../../utils/HttpRequest";
import config from "../../config/config.json";
import { useNavigate } from "react-router-dom";
const MessageForm = (props) => {
  const urlParams = new URLSearchParams(window.location.search);
  var box = urlParams.get("box");

  const [editorContent, setEditorContent] = useState("");
  const navigate = useNavigate();

  const handleSubmit = () => {
    let obj = {
      to: props.inMessageDetails.from,
      subject: "RE: " + props.inMessageDetails.subject,
      body: editorContent,
      from: "",
      priority: "normal",
      status: "unread",
    };

    post(config.api.url + "postMessage", obj)
      .then((result) => {
        props.toastRef.current.show({
          severity: "success",
          summary: "Reply Message",
          detail: result.data,
        });
        setTimeout(function () {
          // window.location.href = "/messages"
          navigate("/messages");
          if (props.submitDetect) {
            props.submitDetect();
          }
        }, 5000);
      })
      .catch((err) => {
        console.log("Error posting message", err);
      });

    setEditorContent("");
  };

  return (
    props.inMessageDetails && (
      <div className="sidebar-section sidebar-section-fill container-fluid py-4">
        <h6 className="card-title">
          {box === "out" ? "Outbox" : box === "in" ? "Inbox" : ""}
        </h6>
        <div className="card p-4 ">
          <div className="card-header">
            <h6>
              {box === "out" ? (
                <>
                  <span
                    id="messageDetailsFromCircle"
                    className="tile tile-circle bg-blue align-middle mr-1"
                  >
                    {props.inMessageDetails.to.substring(0, 1).toUpperCase()}
                  </span>
                  <span id="messageDetailsFrom">
                    {props.inMessageDetails.to}
                  </span>
                </>
              ) : (
                <>
                  <span
                    id="messageDetailsFromCircle"
                    className="tile tile-circle bg-blue align-middle mr-1"
                  >
                    {props.inMessageDetails.fromName
                      .substring(0, 1)
                      .toUpperCase()}
                  </span>
                  <span id="messageDetailsFrom">
                    {props.inMessageDetails.fromName}
                  </span>
                </>
              )}
              <small className=" float-right text-muted">
                {props.inMessageDetails.addedString}
              </small>
            </h6>
            <p></p>
            <dt>
              <span id="messageDetailsSubject">
                {props.inMessageDetails.subject}
              </span>
            </dt>
          </div>
          <div className="card-body pt-4">
            <span
              id="messageDetailsBody"
              dangerouslySetInnerHTML={{ __html: props.inMessageDetails.body }}
            ></span>
          </div>
        </div>

        {box === "in" && (
          <form className="needs-validation">
            <Editor
              value={editorContent}
              placeholder={"Reply"}
              onTextChange={(e) => setEditorContent(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="my-3">
              <Button
                className="btn btn-primary px-3"
                type="submit"
                onClick={(e) => {
                  e.preventDefault();
                  handleSubmit();
                }}
              >
                Reply
              </Button>
            </div>
          </form>
        )}
      </div>
    )
  );
};
export default MessageForm;
