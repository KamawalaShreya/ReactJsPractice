import React, { useEffect, useRef, useState } from "react";
import Header from "../Header/Header";
import { Col, Row, Form, InputGroup } from "react-bootstrap";
import { get } from "../../utils/HttpRequest";
import config from "../../config/config.json";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMagnifyingGlass, faPlus } from "@fortawesome/free-solid-svg-icons";
import Messageform from "./MessageForm";
import { useNavigate, useSearchParams } from "react-router-dom";
import NewMessageForm from "./NewMessageForm";
import { Toast } from "primereact/toast";
import "./Messages.css";

const Messages = () => {
  const urlParams = new URLSearchParams(window.location.search);

  var messageid = urlParams.get("messageid");
  var newMessage = urlParams.get("newmessage");
  var lessonLink = urlParams.get("lessonlink");
  var lessonName = urlParams.get("lessonname");
  var emailTo = urlParams.get("emailto");
  var box = urlParams.get("box");

  const toastRef = useRef(null);

  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [boxType, setBoxType] = useState("in");
  const [inboxData, setInboxData] = useState([]);
  const [outboxData, setOutboxData] = useState([]);
  const [inMessageDetails, setInMessageDetails] = useState(null);

  const [newMsgFlag, setNewMsgFlag] = useState(false);
  const [isNewButtonVisible, setIsNewButtonVisible] = useState(true);
  const demttot = boxType === "in" ? inboxData : outboxData;
  const [filteredData, setFilteredData] = useState(demttot);

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 767);
  const [isEmailListVisible, setIsEmailListVisible] = useState(true);
  const [isEmailListVisibleOut, setIsEmailListVisibleOut] = useState(true);
  const [isEmailListVisibleForm, setIsEmailListVisibleForm] = useState(false);
  const [isEmailListVisibleFormOut, setIsEmailListVisibleFormOut] =
    useState(false);

  const visibleinout = isEmailListVisibleForm !== isEmailListVisibleFormOut;

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 767);
  };

  const [searchInputValue, setSearchInputValue] = useState("");
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? boxType === "in"
        ? inboxData.filter((item) =>
            ["addedString", "fromName", "subject"].some((key) =>
              String(item[key]).toLowerCase().includes(searchText.toLowerCase())
            )
          )
        : outboxData.filter((item) =>
            ["addedString", "subject", "emailTo"].some((key) =>
              String(item[key]).toLowerCase().includes(searchText.toLowerCase())
            )
          )
      : demttot;
    setFilteredData(filtered);
    setSearchInputValue(searchText);
  };

  const getformss = () => {
    if (!isMobile) {
      setIsEmailListVisible(true);
      setIsEmailListVisibleFormOut(false);
      setIsEmailListVisibleForm(true);
    } else {
      setIsEmailListVisibleForm(true);
      setIsEmailListVisible(false);
    }
  };

  const getformsout = () => {
    if (!isMobile) {
      setIsEmailListVisibleOut(true);
      setIsEmailListVisibleForm(false);
      setIsEmailListVisibleFormOut(true);
    } else {
      setIsEmailListVisibleOut(false);
      setIsEmailListVisibleForm(false);
      setIsEmailListVisibleFormOut(true);
    }
  };

  const getList = () => {
    if (isMobile) {
      setIsEmailListVisible(true);
      setIsEmailListVisibleForm(false);
      setIsEmailListVisibleFormOut(false);
      setIsEmailListVisibleOut(true);
    } else {
      if (boxType === "in") {
        setIsEmailListVisibleForm(true);
        setIsEmailListVisibleFormOut(false);
      } else {
        setIsEmailListVisibleForm(false);
        setIsEmailListVisibleFormOut(true);
      }
      setIsEmailListVisible(true);
      setIsEmailListVisibleOut(true);
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);

    get(config.api.url + "getMyTopMessages/50")
      .then((result) => {
        setInboxData(filterDates(result?.data));
        setFilteredData(result?.data);
        setFilteredData(filterDates(result?.data));
      })
      .catch((err) => {
        console.log("Error getting inbox messages ", err);
      });
    get(config.api.url + "getMySentMessages/50")
      .then((result) => {
        setOutboxData(filterDates(result?.data));
        setFilteredData(result?.data);
        setFilteredData(filterDates(result?.data));
      })
      .catch((err) => {
        console.log("Error getting inbox messages ", err);
      });
    if (messageid && messageid !== null && messageid !== "") {
      let getMessageUrl = "";
      if (box === "out") {
        // getMessageUrl =
        //   config.api.url +
        //   "getSpecificSentMessage?timestamp_subject=" +
        //   messageid +
        //   "&emailto=" +
        //   emailTo?.replace(/ /g, "%20");
        getMessageUrl =
          config.api.url +
          "getSpecificSentMessage?timestamp_subject=" +
          messageid +
          "&emailto=" +
          emailTo;
       
      } else {
        getMessageUrl =
          config.api.url + "getSpecificMessage?timestamp_subject=" + messageid;
      }
      get(getMessageUrl)
        .then((result) => {
         
          setInMessageDetails(result.data);
        })
        .catch((err) => {
          console.log("Errror fetching getSpecificMessage ", err);
        });
    }

    const urlParams = new URLSearchParams(window.location.search);
    const boxParam = urlParams.get("box");
    const newmessage = urlParams.get("newmessage");
    setIsNewButtonVisible(newmessage ? false : true);

    if (boxParam === "out") {
      setBoxType("out");
    } else {
      setBoxType("in");
    }
    setNewMsgFlag(true);
  }, [searchParams, newMsgFlag, isMobile]);

  useEffect(() => {
    if (!isMobile) {
      setIsEmailListVisible(true);
      setIsEmailListVisibleOut(true);
      if (boxType === "in") {
        setFilteredData(inboxData);
        setIsEmailListVisibleForm(true);
        // setIsEmailListVisibleFormOut(false);
      } else {
        setFilteredData(outboxData);
        setIsEmailListVisibleForm(false);
        // setIsEmailListVisibleFormOut(true);
      }
    }
  }, [boxType, inboxData, outboxData, isMobile]);

  const filterDates = (messageData) => {
  
    const one_day = 1000 * 60 * 60 * 24;
    const present_date = new Date();
    var x = document.querySelectorAll(".smi-board")[0];
    var computedStyle = getComputedStyle(x);
    let elementWidth = x.clientWidth;
    if (elementWidth < 20) {
      x = document.querySelectorAll(".sidebar-header")[0];
      computedStyle = getComputedStyle(x);
      elementWidth = x.clientWidth;
    }
    elementWidth -=
      parseFloat(computedStyle.paddingLeft) +
      parseFloat(computedStyle.paddingRight);
    elementWidth -= 32 - 16 - 16 - 16;
    const elementTotalFont = Math.floor(elementWidth / (0.875 * 16));
    for (let i = 0; i < messageData.messages.length; i++) {
      var given = "";
      given = messageData.messages[i]["addedEpoch"];
      let given_date = new Date(given);
      var remaining_days = (
        Math.round(present_date.getTime() - given_date.getTime()) / one_day
      ).toFixed(0);
      if (remaining_days < 1) {
        var addedString = given_date.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        });
      } else if (remaining_days == 1) {
        addedString = "Yesterday";
      } else if (remaining_days < 7) {
        addedString = given_date.toLocaleString("default", { weekday: "long" });
      } else {
        //addedString = given_date.getDate() + '/' + given_date.getMonth() + '/' + given_date.getFullYear();
        addedString =
          given_date.getMonth() +
          1 +
          "/" +
          given_date.getDate() +
          "/" +
          given_date.getFullYear();
      }
      messageData.messages[i]["addedString"] = addedString;

      if (messageData.messages[i]["subject"].length > elementTotalFont) {
        messageData.messages[i]["subject"] =
          messageData.messages[i]["subject"].slice(0, elementTotalFont) +
          " " +
          "...";
      }

      if(!messageData.messages[i]["to"].includes('...')) {
        messageData.messages[i].emailTo = messageData.messages[i]["to"];
        let outboxHeader =
          messageData.messages[i]["to"].length +
          messageData.messages[i]["addedString"].length;
        if (outboxHeader > elementTotalFont) {
          messageData.messages[i]["to"] =
            messageData.messages[i]["to"].slice(0, elementTotalFont - 8) +
            " " +
            "...";
        }
      }
    }
    return messageData.messages;
  };

  return (
    <div className="messagePage">
      <Header />
      <Toast ref={toastRef} />
      <div className="page">
        <div style={{ padding: "0.4rem", paddingBottom: "0" }}>
          <ul
            className="nav nav-tabs"
            style={{ padding: "0.4rem", backgroundColor: "#fff" }}
          >
            <li className="smi-nav-item">
              <span
                className={`smi-nav-link ${
                  boxType === "in" ? "active show" : ""
                }`}
                onClick={() => {
                  setBoxType("in");
                  setIsEmailListVisible(true);
                  if (isMobile) {
                    setIsEmailListVisibleForm(false);
                    setIsEmailListVisibleFormOut(false);
                  }
                }}
                id="inboxtab"
                data-toggle="tab"
              >
                Inbox
              </span>
            </li>
            <li className="smi-nav-item">
              <span
                className={`smi-nav-link ${
                  boxType === "out" ? "active show" : ""
                }`}
                onClick={() => {
                  setBoxType("out");
                  setIsEmailListVisibleOut(true);
                  if (isMobile) {
                    setIsEmailListVisibleForm(false);
                    setIsEmailListVisibleFormOut(false);
                  }
                }}
                id="outboxtab"
                data-toggle="tab"
              >
                Outbox
              </span>
            </li>
          </ul>
        </div>
        <div className="page">
          <Row style={{ margin: "0px" }}>
            {boxType === "in"
              ? isEmailListVisible && (
                  <Col
                    lg={4}
                    md={6}
                    className="pl-1 scroll d-block"
                    id="email-list"
                  >
                    <header className="page-navs bg-light shadow-sm ml-3 mr-1">
                      <div className="row">
                        <div className="col-10">
                          <InputGroup className="smi-radius">
                            <InputGroup.Text>
                              <FontAwesomeIcon icon={faMagnifyingGlass} />
                            </InputGroup.Text>
                            <Form.Control
                              type="search"
                              placeholder="Search"
                              className="me-2"
                              aria-label="Search"
                              onChange={handleSearchChange}
                              value={searchInputValue}
                            />
                          </InputGroup>
                        </div>
                        {!new URLSearchParams(window.location.search)
                          .entries()
                          .next().done &&
                          isNewButtonVisible && (
                            <div className="col-2 text-center">
                              <span className="tile tile-circle tile-md text-white smi-tile-primary createLesson smi-btn">
                                <FontAwesomeIcon
                                  icon={faPlus}
                                  onClick={() => {
                                    navigate("/messages?newmessage=yes");
                                  }}
                                />
                              </span>
                            </div>
                          )}
                      </div>
                    </header>
                    <div className="smi-board pt-0 pl-3 pr-1">
                      {filteredData &&
                        filteredData.length > 0 &&
                        filteredData.map((item, index) => (
                          <div key={"inbox_item_" + index}>
                            <div
                              onClick={getformss}
                              id={item.timestamp_subject}
                              className={`list-group-item messageSideBarTemplateData border-top-0 border-bottom-1 border-left-0 border-right-0 border-light ${
                                item.status === "unread" ? "active" : ""
                              } 
                          ${
                            messageid !== null &&
                            messageid === item.timestamp_subject
                              ? "bg-secondary"
                              : "bg-white"
                          }`}
                            >
                              <a
                                href={`messages?messageid=${item.timestamp_subject}&box=in`}
                                className="stretched-link"
                              >
                                {" "}
                              </a>
                              <div className="list-group-item-figure pr-3">
                                <a
                                  href={`messages?messageid=${item.timestamp_subject}&box=in`}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    navigate(
                                      `/messages?messageid=${item.timestamp_subject}&box=in`
                                    );
                                  }}
                                  className="stretched-link"
                                >
                                  <div className="tile tile-circle bg-blue">
                                    {" "}
                                    {item?.from[0]?.toUpperCase()}{" "}
                                  </div>
                                </a>
                              </div>
                              <div className="list-group-item-body">
                                <h4 className="list-title list-group-item-title-light">
                                  {" "}
                                  {item.fromName}{" "}
                                  <small className=" float-right">
                                    {item.addedString}
                                  </small>
                                </h4>
                                <p className="smi-margin-bottom list-group-item-text pt-1">
                                  {" "}
                                  {item.subject}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </Col>
                )
              : isEmailListVisibleOut && (
                  <Col
                    lg={4}
                    md={6}
                    className="pl-1 d-md-block scroll"
                    id="email-list"
                  >
                    <header className="page-navs bg-light shadow-sm ml-3 mr-1">
                      <div className="row">
                        <div className="col-10">
                          <InputGroup className="smi-radius">
                            <InputGroup.Text>
                              <FontAwesomeIcon icon={faMagnifyingGlass} />
                            </InputGroup.Text>
                            <Form.Control
                              type="search"
                              placeholder="Search"
                              className="me-2"
                              aria-label="Search"
                              onChange={handleSearchChange}
                              value={searchInputValue}
                            />
                          </InputGroup>
                        </div>
                        <div className="col-2 text-center">
                          {isNewButtonVisible && (
                            <span className="tile tile-circle tile-md text-white smi-tile-primary createLesson smi-btn">
                              <FontAwesomeIcon
                                icon={faPlus}
                                onClick={() => {
                                  navigate("/messages?newmessage=yes");
                                }}
                              />
                            </span>
                          )}
                        </div>
                      </div>
                    </header>
                    <div className="smi-board pt-0 pl-3 pr-1">
                   
                      {filteredData &&
                        filteredData.length > 0 &&
                        filteredData.map((item, index) => (
                          <div key={"outbox_item_" + index}>
                            <div
                              onClick={getformsout}
                              id={item.timestamp_subject}
                              className={`list-group-item messageSideBarTemplateData border-top-0 border-bottom-1 border-left-0 border-right-0 border-light
                          ${
                            messageid !== null &&
                            messageid === item.timestamp_subject
                              ? "bg-secondary"
                              : "bg-white"
                          }`}
                            >
                              <a
                                href={`messages?messageid=${item.timestamp_subject}&emailto=${item.emailTo}&box=out`}
                                className="stretched-link"
                              >
                                {" "}
                              </a>
                              <div className="list-group-item-figure pr-3">
                                <a
                                  href={`messages?messageid=${item.timestamp_subject}&emailto=${item.emailTo}&box=out`}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    navigate(
                                      `/messages?messageid=${item.timestamp_subject}&emailto=${item.emailTo}&box=out`
                                    );
                                  }}
                                  className="stretched-link"
                                >
                                  <div className="tile tile-circle bg-blue">
                                    {" "}
                                    {item?.to[0]?.toUpperCase()}{" "}
                                  </div>
                                </a>
                              </div>
                              <div className="list-group-item-body">
                                <h4 className="list-title list-group-item-title-light">
                                  {" "}
                                  {item.to}{" "}
                                  <small className=" float-right">
                                    {item.addedString}
                                  </small>
                                </h4>
                                <p className="smi-margin-bottom list-group-item-text pt-1">
                                  {" "}
                                  {item.subject}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                    </div>
                  </Col>
                )}
            <Col lg={8} md={6} sm={12} id="backform" className="d-block">
              {messageid && messageid !== null && messageid !== "" && true ? (
                <>
                  {visibleinout && (
                    <header className="sidebar-header d-xl-none mt-3">
                      <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                          <li className="breadcrumb-item active">
                            <a id="back" href="#" onClick={getList}>
                              <i className="breadcrumb-icon fa-solid fa-less-than mr-2"></i>
                              Back
                            </a>
                          </li>
                        </ol>
                      </nav>
                    </header>
                  )}

                  {visibleinout && (
                    <Messageform
                      inMessageDetails={inMessageDetails}
                      submitDetect={() => {
                        setNewMsgFlag(true);
                      }}
                    />
                  )}
                  {/* {boxType === "in" ? (
                    isEmailListVisibleForm ? (
                      <Messageform
                        inMessageDetails={inMessageDetails}
                        submitDetect={(e) => {
                          setNewMsgFlag(true);
                        }}
                      />
                    ) : null
                  ) : (
                    isEmailListVisibleFormOut && (
                      <Messageform
                        inMessageDetails={inMessageDetails}
                        submitDetect={(e) => {
                          setNewMsgFlag(true);
                        }}
                      />
                    )
                  )} */}
                  {/* {isEmailListVisibleFormOut && (
                    <Messageform
                      inMessageDetails={inMessageDetails}
                      submitDetect={(e) => {
                        setNewMsgFlag(true);
                      }}
                    />
                  )} */}
                </>
              ) : newMessage &&
                newMessage !== null &&
                newMessage !== "" &&
                boxType === "in" ? (
                !isMobile ? (
                  <NewMessageForm
                    lessonName={lessonName}
                    lessonLink={lessonLink}
                    toastRef={toastRef}
                    submitDetect={() => {
                      setNewMsgFlag(true);
                    }}
                  />
                ) : (
                  ""
                )
              ) : boxType === "in" ? (
                <>
                  {!isMobile && (
                    <NewMessageForm
                      toastRef={toastRef}
                      submitDetect={() => {
                        setNewMsgFlag(true);
                      }}
                    />
                  )}
                </>
              ) : null}
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
};
export default Messages;
