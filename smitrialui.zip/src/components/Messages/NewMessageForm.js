import React, { useEffect, useState } from "react";
import { Editor } from "primereact";
import { ErrorMessage, Field, Form, Formik } from "formik";
import config from "../../config/config.json";
import { post } from "../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";
import { get } from "../../utils/HttpRequest";

const NewMessageForm = (props) => {
  const [editorContentNewMsg, setEditorContentNewMsg] = useState(
    props.lessonLink
      ? `<a href="${props.lessonLink}"><h6>${props.lessonName}</h6></a>`
      : props.lessonName
  );
  const [initialValues, setInitialValues] = useState({});
  const [monitors, setMonitors] = useState([]);
  const [submitBtnText, setSubmitBtnText] = useState("Send");
  const navigate = useNavigate();

  const inputFiledValue = (e) => {
    const inputFiled = e.target.value;
    setMonitors(inputFiled);
  };

  const handleGetSiteMonitor = async () => {
    try {
      const url = config.api.url + "getMyMonitors";

      get(url).then((response) => {
        let userEmailList = "";
        if (response.data.length !== 0) {
          for (var i = 0; i < response.data.length; i++) {
            userEmailList += response.data[i].username + ";";
          }
          setMonitors(userEmailList);
        }
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    if (props.lessonName) {
      setInitialValues({
        newMessageTo: "",
        newMessageSubject: props.lessonName,
        editorContentNewMsg: props.lessonName,
      });
    } else {
      setEditorContentNewMsg("");
      setInitialValues({
        newMessageTo: "",
        newMessageSubject: "",
        editorContentNewMsg: "",
      });
    }
  }, [props.lessonName]);

  const handleSubmit = (values, { setSubmitting, resetForm }) => {
    values["editorContentNewMsg"] = editorContentNewMsg;
    let obj = {
      to: monitors.split(";"),
      subject: values.newMessageSubject,
      body: editorContentNewMsg,
      from: "",
      priority: "normal",
      status: "unread",
    };
    setSubmitBtnText("Sending...");
    post(config.api.url + "sendMultipleMessages", obj)
      .then((result) => {
        props.toastRef.current.show({
          severity: "success",
          summary: "New Message",
          detail: result.data,
        });
        setTimeout(function () {
          navigate("/messages");
          if (props.submitDetect) {
            props.submitDetect();
          }
        }, 5000);
      })
      .catch((err) => {
        console.log("Error posting message", err);
      });
    setMonitors("");
    setSubmitting(false);
    setSubmitBtnText("Send");
    resetForm();
    setInitialValues({
      newMessageTo: "",
      newMessageSubject: "",
      editorContentNewMsg: "",
    });
    setEditorContentNewMsg("");
  };

  return (
    <div className="sidebar-section sidebar-section-fill container-fluid d-block">
      <h6 className="card-title"> Send Message </h6>
      <Formik
        initialValues={initialValues}
        onSubmit={handleSubmit}
        enableReinitialize
      >
        {({ isSubmitting }) => (
          <Form id="newMessageForm" className="needs-validation1">
            <div className="form-group mb-0">
              <div className="input-group input-group-alt">
                <div
                  // className="input-group-prepend d-none"
                  className={`${
                    ["sitepi", "crc", "kp"].includes(
                      localStorage.getItem("userRole")
                    )
                      ? ""
                      : "d-none"
                  } input-group-prepend`}
                  id="messagePageGetMonitorDiv"
                >
                  <button
                    className="btn btn-secondary"
                    id="messagePageGetMonitor"
                    type="button"
                    onClick={handleGetSiteMonitor}
                  >
                    Email site monitor
                  </button>
                </div>
                <Field
                  type="text"
                  className="form-control input-group"
                  name="newMessageTo"
                  placeholder="Email to"
                  required
                  onChange={inputFiledValue}
                  value={monitors}
                />
                <label
                  className="d-flex justify-content-between"
                  htmlFor="newMessageTo"
                >
                  <ErrorMessage
                    name="newMessageTo"
                    component="div"
                    className="invalid-feedback"
                  />
                </label>
              </div>
              <br />
            </div>
            <div className="form-group mb-0">
              <Field
                type="text"
                className="form-control input-group"
                id="newMessageSubject"
                name="newMessageSubject"
                placeholder="Subject"
                required
              />
              <label
                className="d-flex justify-content-between"
                htmlFor="newMessageSubject"
              >
                <ErrorMessage
                  name="newMessageSubject"
                  component="div"
                  className="invalid-feedback"
                />
              </label>
              <br />
            </div>

            <Editor
              name="editorContentNewMsg"
              value={editorContentNewMsg}
              placeholder={"Message"}
              onTextChange={(e) => {
                setEditorContentNewMsg(e.htmlValue);
              }}
              style={{ height: "250px" }}
            />

            <div className="my-3">
              <button
                className="btn btn-primary px-3"
                type="submit"
                disabled={isSubmitting}
              >
                {submitBtnText}
              </button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};
export default NewMessageForm;
