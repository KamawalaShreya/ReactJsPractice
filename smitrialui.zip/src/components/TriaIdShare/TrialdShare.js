import React from "react";
import Header from "../Header/Header";
import Datatable from "../Common/Datatable";
import { useState } from "react";
import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import { useEffect, useRef } from "react";
import { Button, Col, Container, Row } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import { post } from "../../utils/HttpRequest";
import copy from "copy-to-clipboard";

const TrialdShare = () => {
  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState(data);
  const [subroleOptions, setSubroleOptions] = useState([]);
  const [subroles, setSubroles] = useState("");
  const [validated, setValidated] = useState(false);
  const [apiResponse, setApiResponse] = useState("");
  const [buttonText, setButtonText] = useState("Copy Login Details");
  const [bgColor, setBgColor] = useState(true);
  const [isLoding, setIsLoading] = useState(false);

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 767);

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 767);
  };

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value;
    let dataAll = newData ? newData : data;
 
    const filtered = newsearchText
      ? [...dataAll].filter((item) =>
          Object.values(item).some((value) => {
            return String(value)
              .toLowerCase()
              .includes(newsearchText.toLowerCase());
          })
        )
      : dataAll;
    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getData = async () => {
    try {
      const url = config.api.url + "getTrialdUsers";
      get(url).then((response) => {
        setData(response.data);
        setFilteredData(response.data);
        handleSearchChange(
          {
            target: {
              value: searchTextRef.current ? searchTextRef.current : "",
            },
          },
          [...response.data]
        );
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);

    getData();

    const subrolesUrl = config.api.url + "getTrialDSubRoles";
    get(subrolesUrl)
      .then((response) => {
        setSubroleOptions(response.data);
      })
      .catch((error) => {
        console.error("Error fetching subroles data:", error);
      });
  }, []);

  const handleSubrolesChange = (event) => {
    setSubroles(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    } else {
      setIsLoading(true);
    }
    try {
      const formData = {
        givenName: form.givenName.value,
        familyName: form.familyName.value,
        description: form.description.value,
        subrole: form.subrole.value,
        usertype: "triald",
      };
      var url = config.api.url + "adminCreateTrialDUser";
      post(url, formData).then((response) => {
        setApiResponse(response.data?.url);
        setIsLoading(false);
      });
      setValidated(false);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  // Function to copy text to the clipboard
  const handleCopyClick = () => {
    copy(apiResponse);
    setButtonText("Copied");
    setBgColor("#f5c374");

    setTimeout(() => {
      setButtonText("Copy Login Details");
      setBgColor(false);
    }, 2000);
  };

  const handleStatusChange = async (row) => {
    try {
      const newStatus = row.status === "enabled" ? "disabled" : "enabled";
      const updatedRow = { ...row, status: newStatus };

      // Update the status of the row in the filtered data
      setFilteredData((prevData) => {
        return prevData.map((item) =>
          item.group === row.group ? updatedRow : item
        );
      });

      const formData = {
        Username: row.group,
        status: row.status === "enabled" ? "disabled" : "enabled",
      };
      var url = config.api.url + "changeUserStatus";
      post(url, formData).then(() => {
        getData();
      });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const defaultSorted = [
    {
      dataField: "givenName",
      order: "asc",
    },
  ];
  const siteColumn = [
    {
      dataField: "givenName",
      text: "First Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "familyName",
      text: "Last Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "subrole",
      text: "Subrole",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        const valueChange = (pre) =>
          pre.map((item) =>
            item.addedEpoch === row.addedEpoch && item.group === row.group
              ? {
                  ...item,
                  status: row.status === "enabled" ? "disabled" : "enabled",
                }
              : item
          );
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "enabled" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "enabled" ? true : false}
                  onChange={() => {
                    setData(valueChange);
                    setFilteredData(valueChange);
                    handleStatusChange(row);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "addedString",
      text: "Created",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "description",
      text: "Description",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];

  return (
    <div className="app">
      <Container fluid>
        <Header />
        <Row>
          <Col lg={6}>
            <div className="formData">
              <Form
                className="needs-validation"
                onSubmit={handleSubmit}
                noValidate
                validated={validated}
              >
                <span className="card-title d-block"> Create a share link</span>
                <Row className="m-auto">
                  <Col lg={12} className="mb-3">
                    <Form.Group controlId="validationCustom01">
                      <Form.Label>First name (Optional)</Form.Label>
                      <Form.Control
                        type="text"
                        className="form-control input-group"
                        name="givenName"
                        placeholder="First name"
                      />
                    </Form.Group>
                  </Col>

                  <Col lg={12} className="mb-3">
                    <Form.Group>
                      <Form.Label>Last name (Optional)</Form.Label>
                      <Form.Control
                        type="text"
                        className="form-control input-group"
                        name="familyName"
                        placeholder="Last name"
                      />
                    </Form.Group>
                  </Col>
                  <Col lg={12} className="mb-3">
                    <Form.Group>
                      <Form.Label>Description (Optional) </Form.Label>
                      <Form.Control
                        type="text"
                        className="form-control input-group "
                        name="description"
                        placeholder="description"
                      />
                    </Form.Group>
                  </Col>
                  <Col lg={12} className="mb-3">
                    <Form.Group controlId="validationCustom02">
                      <Form.Label>Select lesson to share*</Form.Label>
                      <Form.Select
                        className="form-control"
                        aria-label="Select Subrole"
                        name="subrole"
                        onChange={handleSubrolesChange}
                        required
                        value={subroles}
                      >
                        <option value=""> Select Subrole </option>
                        {subroleOptions?.map((subrole) => {
                          return (
                            <option
                              value={subrole?.subrolename}
                              key={subrole.subrolename}
                            >
                              {subrole?.subrolename}
                            </option>
                          );
                        })}
                      </Form.Select>
                      {validated && (
                        <Form.Control.Feedback type="invalid">
                          Please select a subrole.
                        </Form.Control.Feedback>
                      )}
                    </Form.Group>
                  </Col>
                </Row>
                <div className="ml-3 pb-3 pt-3">
                  <Button
                    type="submit"
                    className="btn btn-primary"
                    disabled={isLoding}
                  >
                    Create a share link
                    {isLoding && (
                      <>
                        &nbsp;
                        <i className="loader pi pi-spinner pi-spin color-white"></i>
                      </>
                    )}
                  </Button>
                </div>
              </Form>
            </div>
          </Col>
          <Col lg={6}>
            <div style={{ display: apiResponse ? "block" : "none" }}>
              <div className="page-section" style={{ margin: "20px 0px" }}>
                <div className="card card-fluid">
                  <div className="card-body p-3">
                    <h6 className="card-title">
                      Please share the link below with your user
                    </h6>
                    <div id="loginDetails">
                      <div className="mb-3">
                        <span
                          id="apiResponse"
                          style={{ backgroundColor: bgColor }}
                        >
                          {apiResponse}
                        </span>
                      </div>

                      <div className="form-actions ml-2 mb-4">
                        <Button
                          onClick={handleCopyClick}
                          className="btn btn-primary"
                        >
                          {buttonText}
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
        <div className="SiteManagerPage">
          <Row>
            <Col lg={12}>
              <div className="manager_bar">
                <span className="card-title "> TrialD users created by me</span>
              </div>
              {!isMobile ? (
                <Datatable
                  keyField={"addedEpoch"}
                  data={data}
                  defaultSorted={defaultSorted}
                  handleSearchChange={handleSearchChange}
                  columns={siteColumn}
                  filteredData={filteredData}
                  searchText={searchText}
                />
              ) : (
                ""
              )}
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default TrialdShare;
