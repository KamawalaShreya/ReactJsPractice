const AccordionItem = ({ question, answer, isOpen, onClick }) => {
    return (
      <div className="accordion-wrapper">
        <button
          className={`accordion ${isOpen ? 'active' : ''}`}
          onClick={onClick}
        >
          {question}
        </button>
        <div
          className="details"
          style={{
            maxHeight: isOpen ? '100px' : '0',
          }}
        >
          <p style={{ marginTop: '1rem' }}>{answer}</p>
        </div>
      </div>
    );
  };

  export default AccordionItem;