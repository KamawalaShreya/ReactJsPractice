import React, { useEffect } from "react";
import Header from "../Header/Header";
import { useState } from "react";
import { Container } from "react-bootstrap";
import AccordionItem from "./Accordionview";
import Footerview from "../Footer/Footer";

const Helpview = () => {
  const [faqData, setFaqData] = useState([
    {
      isOpen: false,
      question: "How do I reset my password?",
      answer:
        "Navigate to your profile by clicking on your name near the upper right corner of the screen. Click Profile, then click “Reset My Password”.",
    },
    {
      isOpen: false,
      question: "How can I see my training record?",
      answer:
        "From the Home screen, click on the Training Records button. You will see a list of training content, detailing whether each item is required, your completion status, and ability to print a certificate.",
    },
    {
      isOpen: false,
      question: "How can I print a certificate of completion?",
      answer:
        "If you have completed a lesson or assessment you may print a certificate of completion by going to your Home screen and clicking on the Training Records button.",
    },
    {
      isOpen: false,
      question: "How do I complete a lesson?",
      answer:
        "Once you have reviewed all topics within a lesson, an Acknowledge Completion button will appear. Once you click on this button, the lesson will be marked as complete. To see which lessons you have completed or which that you still need to complete, navigate to the Home screen and click the Training Records button.",
    },
    {
      isOpen: false,
      question:
        "What if I completed a lesson, but have not gotten credit on my training record?",
      answer:
        "Make sure you have reviewed all topics within a lesson and clicked on the Acknowledge Completion button.",
    },
    {
      isOpen: false,
      question: "Why are some lessons optional while others are required?",
      answer:
        "Lessons may be marked as required or optional depending on your role and leadership decisions.",
    },
    {
      isOpen: false,
      question: "What did I score on the assessment?",
      answer: "For most users, assessments are simply marked pass/fail.",
    },
    {
      question: "How can I review my team’s training records?",
      answer:
        "Only administrative level users (e.g., monitors, sponsors, etc.) may review their team’s training records. To review, navigate to the Home Screen and click on Reports. From Reports, you may be able to review Lesson Completion Reports or Assessment Reports, detailing both summary metrics and individual lesson progress and individual assessment scores, answers, etc.",
    },
    {
      isOpen: false,
      question: "How do I create a site?",
      answer:
        "Only administrative users (e.g., monitors, sponsors, etc.) can create a site. Navigate to the Home screen and click User/Site Management. Click on Sites. Enter the new site’s name and address.",
    },
    {
      isOpen: false,
      question: "How do I create new users?",
      answer:
        "Only administrative users (e.g., monitors, sponsors, etc.) can create a user. Navigate to the Home screen and click User/Site Management. Click on Users. Fill out the form detailing the user’s name, email address, and role.",
    },
    {
      isOpen: false,
      question: "How do I change a user’s lesson assignment?",
      answer:
        "Only administrative users (e.g., monitors, sponsors, etc.) can change the lesson assignment matrix. Navigate to the Home screen and click User/Site Management. Click on Users. For the user you’d like to modify, click the lesson assignment button under the Action header.",
    },
  ]);

  const [emailLink, setEmailLink] = useState("");

  useEffect(() => {
    const userName = localStorage.getItem("userName");
    const emailSubject = encodeURIComponent(
      "Question about SMi Trial from " +
      userName +
      " in " +
      window.location.hostname
    );

    const emailHref = "mailto:help@smitrial.com?subject=" + emailSubject;
    setEmailLink(emailHref);
  }, []);

  const toggleAccordion = (index) => {
    setFaqData((prevFaqData) => {
      return prevFaqData.map((faq, i) => ({
        ...faq,
        isOpen: i === index ? !faq.isOpen : faq.isOpen,
      }));
    });
  };

  return (
    <div className="app">
      <Container fluid>
        <Header />
        <div className="page-inner">
          <div className="card">
            <div className="card-body p-4 mx-auto">
              <h2 className="page-title text-center">
                Question not answered below?
              </h2>
              <h6 className="text-center">
                {" "}
                Please email our support team at&nbsp;
                <a id="helpEmailLink" href={emailLink}>
                  help@smitrial.com
                </a>
              </h6>
            </div>
          </div>
          <div className="card">
            <div className="card-body p-4">
              <h1 className="page-title">Technical Support</h1>
              {faqData.map((faq, index) => (
                <AccordionItem
                  key={index}
                  question={faq.question}
                  answer={faq.answer}
                  isOpen={faq.isOpen}
                  onClick={() => toggleAccordion(index)}
                />
              ))}
            </div>
          </div>
        </div>
      </Container>
      <Footerview />
    </div>
  );
};
export default Helpview;
