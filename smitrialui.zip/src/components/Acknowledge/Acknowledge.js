import React from "react";
import Header from "../Header/Header";
import config from "../../config/config.json";
import { Card, Col, Row } from "react-bootstrap";
import { useEffect } from "react";
import { useState } from "react";
import { get, post } from "../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";

const Acknowledge = () => {
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");
  const selectedLanguage = params.get("language");

  const navigate = useNavigate();

  const [acknowledgePageHeader, setacknowledgePageHeader] = useState(
    "Please confirm that you have completed the assessment by checking the box below."
  );
  const [acknowledgePageMessage, setacknowledgePageMessage] = useState(
    "I attest that I personally completed all of the assessment questions."
  );
  const [acknowledgePageSubmitMessage, setacknowledgePageSubmitMessage] =
    useState(
      "Press “Submit” to acknowledge completion and view the results of your assessment."
    );
  const [lessonDetails, setLessonDetails] = useState(null);
  const [lessonLangs, setLessonLangs] = useState([]);
  const [notAllowedFlag, setNotAllowedFlag] = useState(false);
  const [loadingFlag, setLoadingFlag] = useState(true);
  const [ackCheckValue, setAckCheckValue] = useState(false);
  const [ackLangValue, setAckLangValue] = useState("English");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    let url = config.api.url + "getLessonDetails/" + lessonid;
    get(url)
      .then((result) => {
        let lessonData = result.data;

        if (lessonData.lessontype == "assessment") {
          setacknowledgePageHeader(
            "Please confirm that you have completed the assessment by checking the box below."
          );
          setacknowledgePageMessage(
            "I attest that I personally completed all of the assessment questions."
          );
          setacknowledgePageSubmitMessage(
            "Press “Submit” to acknowledge completion and view the results of your assessment."
          );
        } else {
          setacknowledgePageHeader(
            "Please confirm that you have completed the lesson by checking the box below."
          );
          setacknowledgePageMessage(
            "I attest that I personally completed the lesson."
          );
          setacknowledgePageSubmitMessage(
            "Press “Submit” to acknowledge completion and view your training record."
          );
        }
        if (lessonData.status == "review") {
          setacknowledgePageHeader(
            "Acknowledgement is not allowed for review lesson."
          );
          setacknowledgePageMessage("");
          setacknowledgePageSubmitMessage("");
          setNotAllowedFlag(true);
        }
        if (lessonData.lessonlanguages) {
          let langs = [];
          try {
            langs = lessonData.lessonlanguages.split(",").map((x) => x.trim());
            setLessonLangs(langs);
          } catch (err) {
            setLessonLangs(["English"]);
          }
          if (selectedLanguage && selectedLanguage !== "") {
            setAckLangValue(selectedLanguage);
          } else {
            let langValue = localStorage.getItem("prevLanguage");
            setAckLangValue(
              langValue ? langValue : langs ? langs[0] : "English"
            );
          }
          // setAckLangValue(langs[0]);
        } else {
          setLessonLangs(["English"]);
        }
        setLessonDetails(lessonData);
        setLoadingFlag(false);
      })
      .catch((err) => {
        console.log("Error getting lesson details", err);
      });
  }, []);

  const handleSubmitAckForm = () => {
    setIsSubmitting(true);
    let obj = {};
    obj["lessonid"] = lessonDetails.lessonid;
    obj["language"] = ackLangValue;
    let url = config.api.url + "updateLessonCompletion";
    post(url, JSON.stringify(obj))
      .then((result) => {
        setIsSubmitting(false);
        // redirect to training records
        // window.location.href = 'trainingrecord.html?lessonid=' + lessonid;
        navigate("/trainingrecord?lessonid=" + lessonDetails.lessonid);
      })
      .catch((err) => {
        console.log("Error submitting lesson acknowledgement", err);
        setIsSubmitting(false);
      });
  };

  return (
    <div className="lessonAcknowledgePage app" style={{ overflowX: "hidden" }}>
      <Header />
      <div className="page-inner">
        <Row>
          <Col sm={12} md={12} lg={12}>
            <div align="center">
              <Card>
                <Card.Body
                  className={`p-4 ${loadingFlag === false ? "" : "d-none"}`}
                >
                  <Card.Title>{acknowledgePageHeader}</Card.Title>
                  {!notAllowedFlag && (
                    <div>
                      <div
                        className="col-sm-12 col-md-3 d-block"
                        id="languageSelectDiv"
                      >
                        <div className="pl-5 pr-5">
                          <label className="" htmlFor="languageSelectAck">
                            {" "}
                            Lesson languages
                          </label>
                          <select
                            className="custom-select custom-select-sm d-inline-block  mt-2 mb-2"
                            value={ackLangValue}
                            onChange={(e) => {
                              setAckLangValue(e.target.value);
                            }}
                            id="languageSelectAck"
                          >
                            {lessonLangs &&
                              lessonLangs.map((value) => (
                                <option key={value} value={value}>
                                  {value}
                                </option>
                              ))}
                          </select>
                          <div
                            className={`p-error ${isSubmitting && !ackLangValue ? "" : "d-none"
                              }`}
                          >
                            {" "}
                            Acknowledge Language is required.{" "}
                          </div>
                        </div>
                      </div>
                      <div className="form-group col-md-6 mb-4">
                        <div className="custom-control custom-checkbox mb-3 ">
                          <input
                            type="checkbox"
                            className="custom-control-input"
                            id="validationTooltip06"
                            onChange={(e) => {
                              setAckCheckValue(e.target.checked);
                            }}
                            required=""
                          />
                          <label
                            className="custom-control-label"
                            htmlFor="validationTooltip06"
                            id="acknowledgePageMessage"
                          >
                            {acknowledgePageMessage}
                          </label>
                          <div
                            className={`p-error ${isSubmitting && !ackCheckValue ? "" : "d-none"
                              }`}
                          >
                            {" "}
                            You must click the checkbox before submitting.{" "}
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6 mb-3 mt-4">
                        <div
                          className="ml-2 mt-2 "
                          id="acknowledgePageSubmitMessage"
                        >
                          {acknowledgePageSubmitMessage}
                        </div>
                        <div className="form-group pt-3">
                          <button
                            className="btn btn-primary"
                            disabled={!ackCheckValue || isSubmitting}
                            onClick={() => {
                              handleSubmitAckForm();
                            }}
                            type="submit"
                          >
                            Submit
                            {isSubmitting && (
                              <>
                                &nbsp;
                                <i
                                  className="loader pi pi-spinner pi-spin"
                                  aria-hidden="true"
                                ></i>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </Card.Body>
              </Card>
            </div>
          </Col>
        </Row>
      </div>
    </div>
  );
};
export default Acknowledge;
