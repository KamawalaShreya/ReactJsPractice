import { AuthenticationDetails, CognitoUser } from "amazon-cognito-identity-js";
import { Navigate, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";

import UserPool from "../../utils/UserPool";
import background from "../../asset/image/img/login_image_med.png";
import { isUserLoggedin } from "../../utils/Common";
import config from "../../config/config.json";

const Auth = () => {
  const [authenticated, setauthenticated] = useState(null);
  const navigate = useNavigate();
  useEffect(() => {
    const result = isUserLoggedin();
    result && result.data && setauthenticated(true);
  }, []);
  const [email, setEmail] = useState("");
  const [loginMessage, setLoginMessage] = useState("");

  const [password, setPassword] = useState("");
  const announcementStyle = {
    backgroundImage: `url(${background})`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    padding: "0px",
  };
  const style = {
    background: "rgba(32,78,119,0.3)",
    backgroundSize: "cover",
    zIndex: 2,
    width: "100%",
    height: "100%",
    padding: "0px",
  };
  const buttonStyle = {
    backgroundColor: "transparent",
    borderColor: "white",
    padding: "0px 10px 0px 10px",
    fontSize: "1.2rem",
  };
  const onSubmit = (event) => {
    event.preventDefault();
    signin(
      email.trim().toLowerCase(),
      password.trim(),
      function signinSuccess(role) {
        // window.location = "dashboard";
        navigate("/dashboard");
      },
      function signinError(err) {
        if (JSON.stringify(err).includes("PasswordResetRequiredException")) {
          navigate("/newpassword");
        } else if (
          JSON.stringify(err).includes("Temporary password has expired")
        ) {
          setLoginMessage(
            "Your temporary password has expired. Click the forgot password link below to reset your password."
          );
        } else if (err.message === "User is disabled.") {
          setLoginMessage(
            "User has been disabled. Please contract your administrator."
          );
        } else if (
          JSON.stringify(err).includes("UserNotFoundException") ||
          JSON.stringify(err).includes("NotAuthorizedException") ||
          JSON.stringify(err).includes("InternalErrorException")
        ) {
          setLoginMessage("Username or password is invalid");
        } else {
          setLoginMessage(err);
        }
      },
      function singinNewPasswordRequired() {
        navigate("/newpassword?email=" + email);
      }
    );
  };
  const signin = (email, password, onSuccess, onFailure, onResetPassword) => {
    let role = "";
    let authenticationDetails = new AuthenticationDetails({
      Username: email,
      Password: password,
      ValidationData: [],
    });
    let cognitoUser = createCognitoUser(email);
    let firstName = "";
    let lastName = "";
    let userRole = "";
    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: function (result_token) {
        let authenticationToken = result_token.getIdToken().getJwtToken();
        cognitoUser.getUserAttributes(function (err, result) {
          if (err) {
            return;
          } else {
            for (let i = 0; i < result.length; i++) {
              if (result[i].getName() === "custom:role") {
                role = result[i].getValue();
                userRole = result[i].getValue();
              }
              if (result[i].getName() === "given_name") {
                firstName = result[i].getValue();
              }
              if (result[i].getName() === "family_name") {
                lastName = result[i].getValue();
              }
            }
            localStorage.setItem("userName", firstName + " " + lastName);
            localStorage.setItem("userRole", userRole);
            localStorage.setItem("email", email);
          }
          onSuccess(role);
        });
      },
      newPasswordRequired: onResetPassword,
      onFailure: onFailure,
    });
  };
  const createCognitoUser = (email) => {
    return new CognitoUser({
      Username: email,
      Pool: UserPool,
    });
  };
  if (authenticated) {
    return <Navigate replace to="/dashboard" />;
  } else {
    return (
      <div className="loginPage">
        <main className="auth auth-floated">
          <form
            onSubmit={onSubmit}
            id="signinForm"
            name="signinForm"
            className="auth-form"
          >
            <div className="">
              <img
                className="rounded"
                src={require(`../../asset/image/logos/${config.site.logo}`)}
                alt=" "
                height=" "
                style={{ padding: "0px 0px 0px 0px", width: "50%" }}
              />
            </div>
            <div className="px-3" id="loginForm">
              <div className="form-group mt-10 mb-3">
                <input
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  id="emailInputSignin"
                  className="form-control form-control-lg "
                  placeholder="Email"
                  required=" "
                  autoFocus=" "
                />
              </div>
              <div className="form-group mb-3 ">
                <input
                  type="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  id="passwordInputSignin"
                  className="form-control form-control-lg "
                  placeholder="Password"
                  required=" "
                />
              </div>
              <p id="loginMessage">{loginMessage}</p>
              <div className="form-group mb-0 ">
                <button
                  className="btn btn-lg btn-primary btn-block "
                  type="submit"
                  id="loginFormSignin"
                >
                  Sign In
                </button>
              </div>
              <p className=" py-2 ">
                <a href="/password" className="link ">
                  Forgot Password?
                </a>
              </p>

              {/* <p className=" py-2 ">
                <a href="/SignUp" className="link ">
                  Sign Up
                </a>
              </p> */}

            </div>
            <div>
              <p className="py-2">
                <a href="mailto:help@smitrial.com" className="link">
                  {" "}
                  Need Help?{" "}
                </a>
              </p>
            </div>
            <div className="px-3 pt-4 mt-4 d-none" id="iesection">
              <h5>
                <strong>Sorry!</strong> Internet Explorer is no longer
                Supported. Please use Chrome, Safari, Firefox or Edge browser.
              </h5>
            </div>
            <div className="smi-container">
              <div
                className="mb-3"
                style={{ width: "100%", bottom: "0", position: "absolute" }}
              >
                <a href="https://www.sciencemedia.com/trial">
                  <img
                    alt="trial-main-box-logo.png"
                    src={require("../../asset/image/logos/trial-main-box-logo.png")}
                    style={{ height: "15%", width: "15%", bottom: "0" }}
                  />
                </a>

                <div className="mb-1 text-muted text-center mt-3 ">
                  {" "}
                  &copy; 2024 All Rights Reserved.{" "}
                  <a href="https://sciencemedia.com/privacy">Privacy</a> and
                  Terms
                </div>
              </div>
            </div>
          </form>
          <div
            id="announcement "
            className="auth-announcement"
            style={announcementStyle}
          >
            <div className="cover-login" style={style}>
              <div className="announcement-body">
                <h3
                  className="announcement-title1 h3 h4-sm"
                  style={{ padding: "300px 0px 0px 0px" }}
                >
                  SMi Trial&trade; - Protocol Compliance Management
                </h3>
                <br />
                <br />
                <a href="https://www.sciencemedia.com/trial">
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={buttonStyle}
                  >
                    Learn More
                  </button>
                </a>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
};

export default Auth;
