import { Navigate, useNavigate } from "react-router-dom";
import React, { useEffect, useRef, useState } from "react";

import { Toast } from "primereact/toast";
import axios from "axios";
import background from "../../asset/image/img/login_image_med.png";
import config from "../../config/config.json";
import { isUserLoggedin } from "../../utils/Common";

const SignUp = () => {
  const toast = useRef(null);

  const [authenticated, setauthenticated] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const result = isUserLoggedin();
    result && result.data && setauthenticated(true);
  }, []);
  const [email, setEmail] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastname, setLastname] = useState("");
  const [errorForm1] = useState("");

  const [site, setSite] = useState("");
  const announcementStyle = {
    backgroundImage: `url(${background})`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    padding: "0px",
  };
  const style = {
    background: "rgba(32,78,119,0.3)",
    backgroundSize: "cover",
    zIndex: 2,
    width: "100%",
    height: "100%",
    padding: "0px",
  };
  const buttonStyle = {
    backgroundColor: "transparent",
    borderColor: "white",
    padding: "0px 10px 0px 10px",
    fontSize: "1.2rem",
  };
  // const onSubmit = (event) => {
  //   event.preventDefault();
  //   signin(
  //     firstname.trim(),
  //     lastname.trim(),
  //     email.trim().toLowerCase(),
  //     site.trim(),
  //     function signinSuccess(role) {
  //       // window.location = "dashboard";
  //       navigate("/dashboard");
  //     },
  //     function signinError(err) {
  //       console.log("JSON.stringify(err)" + JSON.stringify(err.message));
  //     }
  //   );
  // };

  const submitSignUpForm = (e) => {
    e.preventDefault();
    const bodyObj = {
      email: email,
      familyName: lastname,
      givenName: firstname,
      site: site,
    };
    try {
      const postInstance = axios.create();
      postInstance
        .post(config.api.url + "signup", JSON.stringify(bodyObj))
        .then((result) => {

          let signUpResponse = result.data;
          if (result.status === 201 || result.status === 200) {
            toast.current.show({
              severity: "success",
              summary:
                "User created successfully, please check your email for details.",
              detail: "Success",
            });
            setTimeout(() => {
              navigate("/newpassword?email=" + email);
            }, 3000);
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: "Message",
            });
          }
        })
        .catch((err) => {
          console.log("Error in singup", err);
          if (err.response.status === 403) {
            toast.current.show({
              severity: "error",
              summary: "User Already exist",
              detail: "User Already exist",
            });
          }
        });
    } catch (err) {
      console.log("error in calling api", err);
      if (err.response.status === 400 || err.response.status === 401) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "something want wrong",
        });
      }
    }
  };

  // const signin = (
  //   firstname,
  //   lastname,
  //   email,
  //   site,
  //   selectlanguage,
  //   onSuccess,
  //   onFailure
  //   // onResetPassword
  // ) => {
  //   let authenticationDetails = {
  //     firstname: firstname ? firstname : "MyFirstName",
  //     lastname: lastname ? lastname : "MyLastName",
  //     email: email,
  //     site: site,
  //     selectlanguage: "English",

  //     //   ValidationData: [],
  //   };
  //   console.log("authenticationDetails", authenticationDetails);

  //   let jsonAuthenticationDetails = JSON.stringify(authenticationDetails);
  //   console.log(jsonAuthenticationDetails);

  //   // console.log("before signin", cognitoUser);
  //   // let cognitoUser = createCognitoUser(email);
  //   // let firstName = "";
  //   // let lastName = "";
  //   // let userRole = "";
  //   // cognitoUser.authenticateUser(authenticationDetails, {
  //   //   onSuccess: function (result_token) {
  //   //     let authenticationToken = result_token.getIdToken().getJwtToken();
  //   //     console.log("token: " + authenticationToken);
  //   //     // setToken(authenticationToken);
  //   //     cognitoUser.getUserAttributes(function (err, result) {
  //   //       console.log(err, result);
  //   //       if (err) {
  //   //         console.log(err, "test");
  //   //         return;
  //   //       } else {
  //   //         console.log("cognito user login successful");
  //   //         for (let i = 0; i < result.length; i++) {
  //   //           console.log(
  //   //             "attribute " +
  //   //               result[i].getName() +
  //   //               " has value " +
  //   //               result[i].getValue()
  //   //           );
  //   //           if (result[i].getName() === "custom:role") {
  //   //             role = result[i].getValue();
  //   //             userRole = result[i].getValue();
  //   //           }
  //   //           if (result[i].getName() === "given_name") {
  //   //             firstName = result[i].getValue();
  //   //           }
  //   //           if (result[i].getName() === "family_name") {
  //   //             lastName = result[i].getValue();
  //   //           }
  //   //         }
  //   //         localStorage.setItem("userName", firstName + " " + lastName);
  //   //         localStorage.setItem("userRole", userRole);
  //   //         localStorage.setItem("email", email);
  //   //       }
  //   //       console.log("brefore onSuccess: Role: " + userRole);
  //   //       onSuccess(role);
  //   //     });
  //   //   },
  //   //   //   newPasswordRequired: onResetPassword,
  //   //   onFailure: onFailure,
  //   // });
  // };

  // const createCognitoUser = (email) => {
  //   return new CognitoUser({
  //     Username: email,
  //     Pool: UserPool,
  //   });
  // };
  if (authenticated) {
    return <Navigate replace to="/profile" />;
  } else {
    return (
      <div className="loginPage">
        <Toast ref={toast}></Toast>

        <main className="auth auth-floated">
          <form
            onSubmit={submitSignUpForm}
            id="signinForm"
            name="signinForm"
            className="auth-form"
          >
            <div className="">
              <img
                className="rounded"
                src={require(`../../asset/image/logos/${config.site.logo}`)}
                alt=" "
                height=" "
                style={{ padding: "0px 0px 0px 0px", width: "50%" }}
              />
            </div>
            <div className="px-3" id="loginForm">
              <div className="form-group mt-10 mb-3">
                <input
                  type="firstname"
                  value={firstname}
                  onChange={(event) => setFirstname(event.target.value)}
                  id="firstnameInputSignup"
                  className="form-control form-control-lg "
                  placeholder="First name"
                  autoFocus=" "
                />
              </div>
              <div className="form-group mb-3">
                <input
                  type="lastname"
                  value={lastname}
                  onChange={(event) => setLastname(event.target.value)}
                  id="lastnameInputSignup"
                  className="form-control form-control-lg "
                  placeholder="Last name"
                  autoFocus=" "
                />
              </div>
              <div className="form-group mb-3 ">
                <input
                  type="email"
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  id="emailInputSignin"
                  className="form-control form-control-lg "
                  placeholder="Email * "
                  required=" "
                  autoFocus=" "
                />
              </div>
              <div className="form-group mb-3 ">
                <input
                  type=""
                  value={site}
                  onChange={(event) => setSite(event.target.value)}
                  id="siteInputSignin"
                  className="form-control form-control-lg "
                  placeholder="site"
                />
              </div>
              <p className="mt-2">{errorForm1}</p>
              <div className="form-group mb-0 ">
                <button
                  className="btn btn-lg btn-primary btn-block "
                  type="submit"
                  id="loginFormSignin"
                >
                  Sign Up
                </button>
              </div>
            </div>
            <div>
              <p className="py-2">
                <a href="mailto:help@smitrial.com" className="link">
                  {" "}
                  Need Help?{" "}
                </a>
              </p>
            </div>
            <div className="px-3 pt-4 mt-4 d-none" id="iesection">
              <h5>
                <strong>Sorry!</strong> Internet Explorer is no longer
                Supported. Please use Chrome, Safari, Firefox or Edge browser.
              </h5>
            </div>
            <div className="smi-container">
              <div
                className="mb-3"
                style={{ width: "100%", bottom: "0", position: "absolute" }}
              >
                <a href="https://www.sciencemedia.com/trial">
                  <img
                    alt=""
                    src={require("../../asset/image/logos/trial-main-box-logo.png")}
                    style={{ height: "15%", width: "15%", bottom: "0" }}
                  />
                </a>
                <div className="mb-1 text-muted text-center mt-3 ">
                  {" "}
                  &copy; 2024 All Rights Reserved.{" "}
                  <a href="https://sciencemedia.com/privacy">Privacy</a> and
                  Terms
                </div>
              </div>
            </div>
          </form>
          <div
            id="announcement "
            className="auth-announcement"
            style={announcementStyle}
          >
            <div className="cover-login" style={style}>
              <div className="announcement-body">
                <h3
                  className="announcement-title1 h3 h4-sm"
                  style={{ padding: "300px 0px 0px 0px" }}
                >
                  SMi Trial&trade; - Protocol Compliance Management
                </h3>
                <br />
                <br />
                <a href="https://www.sciencemedia.com/trial">
                  <button
                    type="button"
                    className="btn btn-primary"
                    style={buttonStyle}
                  >
                    Learn More
                  </button>
                </a>
              </div>
            </div>
          </div>
        </main>
      </div>
    );
  }
};

export default SignUp;
