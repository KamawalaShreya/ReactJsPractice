import { AuthenticationDetails, CognitoUser } from "amazon-cognito-identity-js";
import React, { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";

import UserPool from "../../utils/UserPool";
import background from "../../asset/image/img/login_image_med.png";
import config from "../../config/config.json";

const NewPassword = () => {
  // const [authenticated, setauthenticated] = useState(null);
  let [searchParams] = useSearchParams();
  const code = searchParams.get("email");
  const navigate = useNavigate();

  const [email] = useState(code?.replace(/ /g, "+"));
  const [oldPassword, setOldPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newPasswordConfirm, setNewPasswordConfirm] = useState("");
  const [message, setMessage] = useState("");

  const handleResetPassword = (event) => {
    event.preventDefault();
    if (newPassword === oldPassword) {
      setMessage("New password can't be the same as the old password.");
    } else {
      if (newPasswordConfirm === newPassword && newPassword !== oldPassword) {
        // Replace this part with your resetPassword function or API call
        resetPassword(email, oldPassword, newPassword);
      } else {
        setMessage("New password and confirm password don't match.");
      }
    }
  };

  const resetPassword = (email, oldPassword, newPassword) => {
    var cognitoUser = createCognitoUser(email);
    const authenticationDetails = new AuthenticationDetails({
      Username: email,
      Password: oldPassword,
    });
    cognitoUser = createCognitoUser(email);
    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: () => {
        console.log("login successful from resetPassword");
      },
      onFailure: () => {
        setMessage("Username and old password are incorrect.");
      },
      newPasswordRequired: (userAttributes) => {
        delete userAttributes.email_verified;
        delete userAttributes.phone_number_verified;

        userAttributes.name = authenticationDetails.username;
        cognitoUser.completeNewPasswordChallenge(newPassword, userAttributes, {
          onSuccess: () => {
            localStorage.clear();
            navigate("/");
          },
          onFailure: (err) => {
            switch (err.code) {
              case "InvalidPasswordException":
                setMessage(
                  "New password is not strong enough. Your password must be 8 characters long and contain at least one number, special character, uppercase letter, and lowercase letter"
                );
                break;
              default:
                setMessage(err.message);
            }
            console.log(err);
          },
        });
      },
    });
  };

  const createCognitoUser = (email) => {
    return new CognitoUser({
      Username: email,
      Pool: UserPool,
    });
  };

  const announcementStyle = {
    backgroundImage: `url(${background})`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    padding: "0px",
  };
  const style = {
    background: "rgba(32,78,119,0.3)",
    backgroundSize: "cover",
    zIndex: 2,
    width: "100%",
    height: "100%",
    padding: "0px",
  };
  const buttonStyle = {
    backgroundColor: "transparent",
    borderColor: "white",
    padding: "0px 10px 0px 10px",
    fontSize: "1.2rem",
  };

  // if (authenticated) {
  //   return <Navigate replace to="/" />;
  // } else {
  return (
    <div className="loginPage">
      <main className="auth auth-floated">
        <form
          onSubmit={handleResetPassword}
          id="signinForm"
          name="signinForm"
          className="auth-form"
        >
          <div className="">
            <img
              className="rounded"
              src={require(`../../asset/image/logos/${config.site.logo}`)}
              alt=" "
              height=" "
              style={{ padding: "0px 0px 0px 0px", width: "50%" }}
            />
          </div>
          <div className="px-3" id="loginForm">
            <div className="form-group mt-10 mb-3">
              <input
                type="email"
                value={email}
                className="form-control form-control-lg "
                placeholder="Email"
                required=" "
                autoFocus=" "
              />
            </div>
            <p>Please choose a new password.</p>
            <div className="form-group mb-3 ">
              <input
                type="password"
                className="form-control form-control-lg "
                placeholder="Current Password"
                required
                onChange={(e) => setOldPassword(e.target.value)}
              />
            </div>
            <div className="form-group mb-3 ">
              <input
                type="password"
                className="form-control form-control-lg "
                placeholder="New Password"
                required
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
            <div className="form-group mb-3 ">
              <input
                type="password"
                className="form-control form-control-lg "
                placeholder="Confirm Password"
                required
                onChange={(e) => setNewPasswordConfirm(e.target.value)}
              />
            </div>
            <div id="newpasswordMessage">{message}</div>
            <div className="form-group mb-0 ">
              <input
                type="submit"
                className="btn btn-lg btn-block btn-primary mt-3"
                value="Update Password"
              />
            </div>
          </div>
          <div className="px-3 pt-4 mt-4 d-none" id="iesection">
            <h5>
              <strong>Sorry!</strong> Internet Explorer is no longer Supported.
              Please use Chrome, Safari, Firefox or Edge browser.
            </h5>
          </div>
          <div className="smi-container">
            <div
              className="mb-3"
              style={{ width: "100%", bottom: "0", position: "absolute" }}
            >
              <a href="https://www.sciencemedia.com/trial">
                <img
                  alt=""
                  src={require("../../asset/image/logos/trial-main-box-logo.png")}
                  style={{ height: "15%", width: "15%", bottom: "0" }}
                />
              </a>

              <div className="mb-1 text-muted text-center mt-3 ">
                {" "}
                &copy; 2024 All Rights Reserved.{" "}
                <a href="https://sciencemedia.com/privacy">Privacy</a> and Terms
              </div>
            </div>
          </div>
        </form>
        <div
          id="announcement "
          className="auth-announcement"
          style={announcementStyle}
        >
          <div className="cover-login" style={style}>
            <div className="announcement-body">
              <h3
                className="announcement-title1 h3 h4-sm"
                style={{ padding: "300px 0px 0px 0px" }}
              >
                SMi Trial&trade; - Protocol Education to Optimize Clinical
                Trials
              </h3>
              <br />
              <br />
              <a href="https://www.sciencemedia.com/trial">
                <button
                  type="button"
                  className="btn btn-primary"
                  style={buttonStyle}
                >
                  Learn More
                </button>
              </a>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};
// };

export default NewPassword;
