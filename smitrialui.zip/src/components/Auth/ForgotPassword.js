import React, { useState } from "react";

import { CognitoUser } from "amazon-cognito-identity-js";
import UserPool from "../../utils/UserPool";
import axios from "axios";
import background from "../../asset/image/img/login_image_med.png";
import config from "../../config/config.json";
import { useNavigate } from "react-router-dom";

const ForgotPassword = () => {
  // State variables
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [formSwitch, setFormSwitch] = useState(true);
  const [errorForm1, setErrorForm1] = useState("");
  const [errorForm2, setErrorForm2] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");

  // Define error messages
  const errorMessages = {
    CodeMismatchException: "Verification code is incorrect.",
    InvalidParameterException:
      "Verification code is incorrect or the new password is not strong enough. Your password must be 8 characters long and contain at least one number, special character, uppercase letter, and lowercase letter.",
    LimitExceededException:
      "Too many attempts. Please try again after some time.",
    UserNotFoundException:
      "Your password can't be reset. Please contact support.",
    InvalidPasswordException:
      "New password is not strong enough. Your password must be 8 characters long and contain at least one number, special character, uppercase letter, and lowercase letter.",
    ExpiredCodeException:
      'Your verification code has expired. Please click the "forgot password" link again.',
  };

  // CSS styles
  const announcementStyle = {
    backgroundImage: `url(${background})`,
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center",
    backgroundSize: "cover",
    padding: "0px",
  };

  const style = {
    background: "rgba(32,78,119,0.3)",
    backgroundSize: "cover",
    zIndex: 2,
    width: "100%",
    height: "100%",
    padding: "0px",
  };

  const buttonStyle = {
    backgroundColor: "transparent",
    borderColor: "white",
    padding: "0px 10px 0px 10px",
    fontSize: "1.2rem",
  };

  const createCognitoUser = () =>
    new CognitoUser({
      Username: email,
      Pool: UserPool,
    });

  // Handle password confirmation
  const handlePasswordConfirmation = (event) => {
    event.preventDefault();

    if (newPassword === confirmPassword) {
      try {
        const cognitoUser = createCognitoUser();

        cognitoUser.confirmPassword(code, newPassword, {
          onSuccess: handlePasswordConfirmationSuccess,
          onFailure: handlePasswordConfirmationFailure,
        });
      } catch (error) {
        setErrorForm2("An error occurred. Please try again.");
      }
    } else {
      setErrorForm2("New password and confirm password do not match.");
    }
  };

  const handlePasswordConfirmationSuccess = () => {
    navigate("/login");
  };

  const handlePasswordConfirmationFailure = (err) => {
    if (errorMessages[err.code]) {
      setErrorForm2(errorMessages[err.code]);
    } else {
      setErrorForm2(err.message);
    }
  };

  // Handle initial password reset request
  const handleInitialPasswordReset = (event) => {
    event.preventDefault();

    var cognitoUser = createCognitoUser();

    cognitoUser.forgotPassword({
      onSuccess: handleInitialPasswordResetSuccess,
      onFailure: handleInitialPasswordResetFailure,
      inputVerificationCode: null,
    });
  };

  const handleInitialPasswordResetSuccess = () => {
    setFormSwitch(false);
  };

  const handleInitialPasswordResetFailure = (err) => {
    if (errorMessages[err.code]) {
      setErrorForm1(errorMessages[err.code]);
    } else if (err.message === "User is disabled.") {
      setErrorForm1(
        "User has been disabled. Please contact your administrator."
      );
    } else if (
      err.message === "User password cannot be reset in the current state."
    ) {
      // Send a password reset email and display a message
      const userResend = axios.create();
      var url = `${config.api.url}userResendPassword`;
      let bodyData = JSON.stringify({ email: email });

      userResend
        .post(url, bodyData, {
          headers: { "Content-Type": "application/json" },
        })
        .then((response) => {
          if (response.status === 200) {
            setErrorForm1(
              "Your password has been reset. Please check your email for instructions."
            );
          } else {
            setErrorForm1(
              "You will first need to log in with your temporary password."
            );
          }
          navigate("/");
        })
        .catch(() => {
          setErrorForm1("An error occurred. Please try again.");
        });
    } else {
      setErrorForm1(err);
    }
  };

  return (
    <div className="resetPasswordPage app">
      <main className="auth auth-floated">
        {formSwitch ? (
          <form
            onSubmit={handleInitialPasswordReset}
            id="resetPasswordForm"
            className="auth-form"
          >
            <div className="">
              <img
                className="rounded"
                src={require(`../../asset/image/logos/${config.site.logo}`)}
                alt=""
                height=""
                style={{ padding: "0px 0px 0px 0px", width: "30%" }}
              />
            </div>
            <div className="px-3" id="resetPasswordForm">
              <div className="form-group mt-3 mb-3">
                <label htmlFor="emailInputForgotPassword">
                  Enter your email.
                </label>
                <input
                  type="email"
                  value={email}
                  pattern="^\S+@\S+\.\S+$"
                  onChange={(event) => setEmail(event.target.value)}
                  id="emailInputForgotPassword"
                  className="form-control form-control-lg"
                  placeholder="Email"
                  required
                  autoFocus=""
                />
              </div>
              <div className="form-group mb-0 ">
                <button
                  className="btn btn-lg btn-primary btn-block"
                  type="submit"
                  id="forgotPasswordFormSubmit"
                >
                  Forgot Password
                </button>
              </div>
            </div>
            <p className="mt-2">{errorForm1}</p>

            <div className="smi-container">
              <div
                className="mb-3"
                style={{ width: "100%", bottom: "0", position: "absolute" }}
              >
                <a href="https://www.sciencemedia.com/trial">
                  <img
                    alt=""
                    src={require("../../asset/image/logos/trial-main-box-logo.png")}
                    style={{ height: "15%", width: "15%", bottom: "0" }}
                  />
                </a>

                <div className="mb-1 text-muted text-center mt-3 ">
                  &copy; 2024 All Rights Reserved.{" "}
                  <a href="https://sciencemedia.com/privacy">Privacy</a> and
                  Terms
                </div>
              </div>
            </div>
          </form>
        ) : (
          <form
            id="resetPasswordFormCode"
            className="needs-validation1 auth-form"
            onSubmit={handlePasswordConfirmation}
          >
            <div className="">
              <img
                className="rounded"
                src={require(`../../asset/image/logos/${config.site.logo}`)}
                alt=""
                height=""
                style={{ padding: "0px 0px 0px 0px", width: "50%" }}
              />
            </div>
            <div className="px-3">
              <div className="form-group mt-3 mb-3">
                <input
                  type="text"
                  name="code"
                  id="resetPasswordPageCode"
                  className="form-control form-control-lg"
                  placeholder="Code"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
                <div className="invalid-feedback">
                  Verification code is required.
                </div>
              </div>
              <p>Enter your verification code from email.</p>
              <div className="form-group mt-3 mb-3">
                <input
                  type="password"
                  name="newPassword"
                  id="resetPasswordPageNewPassword"
                  className="form-control form-control-lg"
                  placeholder="Password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
                <p>Enter a new password.</p>
                <div className="invalid-feedback">Password is required.</div>
              </div>
              <div className="form-group mt-3 mb-3">
                <input
                  type="password"
                  name="confirmPassword"
                  id="resetPasswordPageConfimPassword"
                  className="form-control form-control-lg"
                  placeholder="Password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
                <p>Confirm password.</p>
                <div className="invalid-feedback">
                  Confirm password is required.
                </div>
              </div>
            </div>
            <div className="form-group mb-0">
              <input
                type="submit"
                className="btn btn-lg btn-block btn-primary mt-3"
                value="Reset Password"
              />
            </div>
            <p className="mt-2">{errorForm2}</p>
            <div className="smi-container">
              <div
                className="mb-3"
                style={{ width: "100%", bottom: "0", position: "absolute" }}
              >
                <a href="https://www.sciencemedia.com/trial">
                  <img
                    alt=""
                    src={require("../../asset/image/logos/trial-main-box-logo.png")}
                    style={{ height: "15%", width: "15%", bottom: "0" }}
                  />
                </a>

                <div className="mb-1 text-muted text-center mt-3 ">
                  &copy; 2024 All Rights Reserved.{" "}
                  <a href="https://sciencemedia.com/privacy">Privacy</a> and
                  Terms
                </div>
              </div>
            </div>
          </form>
        )}

        <div
          id="announcement"
          className="auth-announcement"
          style={announcementStyle}
        >
          <div className="cover-login" style={style}>
            <div className="announcement-body">
              <h3
                className="announcement-title1 h3 h4-sm"
                style={{ padding: "300px 0px 0px 0px" }}
              >
                SMi Trial&trade; - Protocol Compliance Management
              </h3>
              <br />
              <br />
              <a href="https://www.sciencemedia.com/trial">
                <button
                  type="button"
                  className="btn btn-primary"
                  style={buttonStyle}
                >
                  Learn More
                </button>
              </a>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ForgotPassword;
