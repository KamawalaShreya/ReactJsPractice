import React, { useState } from "react";
import "./LessonDetailsForm.css";
import { Card, Col, Row } from "react-bootstrap";
import "./TopicsPage.css";
import TopicForm from "./TopicForms/TopicForm";
import { Dialog } from "primereact/dialog";
import { Toast } from "primereact/toast";
import { useRef } from "react";
import { useEffect } from "react";
import config from "../../config/config.json";
import { post } from "../../utils/HttpRequest";
import axios from "axios";
import { Button } from "primereact/button";
import LessonConfirmDialog from "./LessonConfirmDialog";
import AssessmentTopicForm from "./TopicForms/AssessmentTopicForm";
import { useNavigate } from "react-router-dom";

const TopicsPage = (props) => {
  const toast = useRef(null);
  const [visible, setVisible] = useState(false);
  const [topics, setTopics] = useState([]);

  const [uploadTopicsProgress, setUploadTopicsProgress] = useState([]);

  const [editTopicData, setEditTopicData] = useState(null);
  const [topicCounterHeader, setTopicCounterHeader] = useState(1);
  const [formInitializedFlag, setFormInitializedFlag] = useState(null);

  const [confirmDialogVisible, setConfirmDialogVisible] = useState(false);
  const [deleteTopicIndex, setDeleteTopicIndex] = useState(null);

  const navigate = useNavigate();
  const [loadingFlag, setLoadingFlag] = useState(false);

  const newCardClickListener = () => {
    // setTopics([...topics, topics.length])
    setEditTopicData(null);
    setTopicCounterHeader(topics.length + 1);
    setVisible(true);
  };

  const removeTopicCardClickListener = (index) => {
    // if (!editTopicData) {
    setConfirmDialogVisible(true);
    setDeleteTopicIndex(index);
    // }
  };

  const deleteTopicInServer = (topicToDelete) => {
    setLoadingFlag(true);
    let topic = {};
    let url = config.api.url + "updateTopic?action=delete";
    if (
      props.lessonFormData.formLessonType === "assessment" ||
      props.lessonFormData.formLessonType === "survey"
    ) {
      url = url + "&isSurvey=true";
      let object = {};
      object["topicid"] = topicToDelete.topicid;
      object["lessonid"] = props.lessonFormData.formLessonId;
      object["topicLanguages"] = props.lessonFormData.languageSelectField;
      topic = object;
    } else {
      topic = JSON.stringify(topicToDelete);
    }
    post(url, topic)
      .then((result) => {
        setLoadingFlag(false);
        console.log("delete topic response ", result.data);
      })
      .catch((err) => {
        console.log("Error deleteing topic in server", err);
      });
  };

  const openEditTopic = (topicCount) => {
    setEditTopicData(topics[topicCount - 1]);
    setTopicCounterHeader(topicCount);
    setVisible(true);
  };

  const resetProgressBar = (topicorder) => {
    document
      .querySelector(`#ftr_progress_element_${topicorder}`)
      .classList.remove("d-block");
    document
      .querySelector(`#ftr_progress_element_${topicorder}`)
      .classList.add("d-none");
    document
      .querySelector(`#ftr_${topicorder}_progressbarMainToolTip`)
      .setAttribute("data-original-title", "1%");
    document
      .querySelector(`#ftr_${topicorder}_progressbarMain`)
      .setAttribute("aria-valuenow", "1");
    document.querySelector(`#ftr_${topicorder}_progressbarMain`).style.width =
      "1%";
  };

  const uploadTopicFiles = async (topic, topicfilesResponse) => {
    // await new Promise(async (resolve, reject) => {
    const uploadPromises = [];
    // modifyProgressBarInCard(topic.topicorder - 1, 'add');
    document
      .querySelector(`#ftr_progress_element_${topic.topicorder - 1}`)
      .classList.add("d-block");
    document
      .querySelector(`#ftr_progress_element_${topic.topicorder - 1}`)
      .classList.remove("d-none");
    const s3UploadInstance = axios.create();
    let totalFilesCount = 0;
    var progressIncreaseCounter = 0;
    for (
      let totalFileCounter = 0;
      totalFileCounter < topicfilesResponse.length;
      totalFileCounter++
    ) {
      totalFilesCount += topicfilesResponse[totalFileCounter].files.length;
    }
    if (totalFilesCount > 0) {
      progressIncreaseCounter = 100 / totalFilesCount;
    }
    let topicfiles = topic.topicFilesOrg.filter((x) => x.files.length > 0);
    for (let obCount = 0; obCount < topicfilesResponse.length; obCount++) {
      let files = topicfiles[obCount].files;
      let filesResponse = topicfilesResponse[obCount].files;
      if (
        topicfiles[obCount].language == topicfilesResponse[obCount].language
      ) {
        for (let count = 0; count < files.length; count++) {
          if (files[count].filename == filesResponse[count].filename) {
            const headers = {
              "Content-Type": filesResponse[count].filetype,
            };
            const uploadPromise = s3UploadInstance
              .put(filesResponse[count].signedURL, files[count].file, {
                headers,
              })
              .then(() => {
                setUploadTopicsProgress((prevProgress) => {
                  let cardsProgressArray = [...prevProgress];
                  let currentProgress = cardsProgressArray[topic.topicorder - 1]
                    ? cardsProgressArray[topic.topicorder - 1]
                    : 1;
                  currentProgress = Math.min(
                    currentProgress + progressIncreaseCounter,
                    100
                  );
                  cardsProgressArray[topic.topicorder - 1] = currentProgress;
                  document
                    .querySelector(
                      `#ftr_${topic.topicorder - 1}_progressbarMainToolTip`
                    )
                    .setAttribute("data-original-title", currentProgress + "%");
                  document
                    .querySelector(
                      `#ftr_${topic.topicorder - 1}_progressbarMain`
                    )
                    .setAttribute("aria-valuenow", currentProgress);
                  document.querySelector(
                    `#ftr_${topic.topicorder - 1}_progressbarMain`
                  ).style.width = currentProgress + "%";

                  // console.log('cardsProgressArray', cardsProgressArray)
                  // setUploadTopicsProgress(cardsProgressArray)

                  return cardsProgressArray; // Return the updated state
                });
              })
              .catch((err) => {
                console.log("Error uploading file to server ", err);
              });
            uploadPromises.push(uploadPromise);
          }
        }
      }
    }
    await Promise.all(uploadPromises);
    // modifyProgressBarInCard(topic.topicorder - 1, 'remove');

    setTimeout(() => {
      resetProgressBar(topic.topicorder - 1);
      setUploadTopicsProgress((prevProgress) => {
        setLoadingFlag(false);
        let cardsProgressArray = [...prevProgress];
        cardsProgressArray[topic.topicorder - 1] = 1;
        return cardsProgressArray;
      });
    }, 1000);
    // return resolve("success")

    return "success";
    // })
  };

  const generateSurveyTopicObject = (topic) => {
    topic["assessmentversion"] = topic["version"];
    topic["assessmentorder"] = topic["topicorder"];
    topic["assessmentid"] = topic["topicid"];
    topic["topicFiles"] = [];
    // delete topic['version'];
    // delete topic['topicorder'];
    return topic;
  };

  const updateTopicInServer = async (topicArg, actionFlag) => {
    setLoadingFlag(true);
    let queryParams = [];
    let topic = null;
    var url = config.api.url + "updateTopic";
    if (actionFlag == "add") {
      queryParams.push("action=add");
    }
    if (
      props.lessonFormData.formLessonType === "assessment" ||
      props.lessonFormData.formLessonType === "survey"
    ) {
      queryParams.push("isSurvey=true");
      topic = generateSurveyTopicObject(topicArg);
    } else {
      topic = JSON.stringify(topicArg);
    }
    url = url + "?" + queryParams.join("&");

    post(url, topic)
      .then(async (result) => {
        let topicData = result.data;

        if (props.lessonFormData.formLessonType === "regularlesson") {
          let response = await uploadTopicFiles(topicArg, topicData.topicFiles);
        } else {
          setLoadingFlag(false);
        }
        if (props.toast) {
          props.toast.current.show({
            severity: "info",
            summary: "Topic update",
            detail: "Topic Updated Successfully",
          });
        }
      })
      .catch((err) => {
        console.log("Error in updateTopic ", err);
      });
  };

  const addedTopicCard = (topicCount, topicName, topicMedia) => {
    let uploadFlag = topics[topicCount - 1]["topicUploadFlag"]
      ? topics[topicCount - 1]["topicUploadFlag"]
      : true; // false
    return (
      <Col
        md={4}
        lg={4}
        id="addedTopicCard"
        key={`addedTopicCard${topicCount}`}
      >
        <div
          className="card card-hover-shadow smi-card"
          style={{ height: "13rem", cursor: "pointer" }}
        >
          <h5 className="card-header">Topic {topicCount}</h5>
          {props.lessonFormData.formLessonType == "regularlesson" ? (
            <div className="card-body pl-2 pl-2 pt-2">
              <p className="card-text">Topic Name: {topicName}</p>
              <p className="card-text">Topic Media: {topicMedia}</p>
            </div>
          ) : (
            <div className="card-body pl-2 pl-2 pt-2">
              <p className="card-text">Question: {topicName}</p>
              <p className="card-text">Question Type: {topicMedia}</p>
            </div>
            //     <div
            //       className="card-body pl-2 pl-2 pt-2"
            //       dangerouslySetInnerHTML={{
            //         __html: `
            //         <div  style="display: flex;">
            //   <p className="card-text">Topic Name: ${topicName}</p>
            //   </div>
            //   <div className='flex'  style="display: flex;">
            //   <p className="card-text">Topic Media: ${topicMedia}</p>
            //   </div>
            // `,
            //       }}
            //     />
            //   ) : (
            //     <div
            //       className="card-body pl-2 pl-2 pt-2"
            //       dangerouslySetInnerHTML={{
            //         __html: `
            //         <div className='flex'  style="display: flex;">
            //   <p className="card-text">Question: ${topicName}</p>
            //   </div>
            //   <div className='flex'  style="display: flex;">
            //   <p className="card-text">Question Type: ${topicMedia}</p>
            //   </div>

            // `,
            //       }}
            //     />
          )}

          <div className={`card-footer p-2 ${uploadFlag ? "disabled" : ""}`}>
            <button
              className="btn btn-primary editTopicWizard"
              onClick={() => {
                openEditTopic(topicCount);
              }}
              data-order="1"
              id="editTopicWizard_1"
              disabled={loadingFlag}
            >
              Edit
            </button>
            <div className="float-right w-100">
              <button
                className="btn btn-primary deleteTopicWizard float-right"
                onClick={() => {
                  removeTopicCardClickListener(topicCount);
                }}
                data-order={topicCount}
                id={`deleteTopicWizard_${topicCount}`}
                disabled={loadingFlag}
              >
                Delete
              </button>
            </div>
          </div>
          <div id={`ftr_progress_element_${topicCount - 1}`} className="d-none">
            <div
              className="progress progress-xs"
              data-toggle="tooltip"
              id={`ftr_${topicCount - 1}_progressbarMainToolTip`}
              title=""
              data-original-title={`1%`}
            >
              <div
                className="progress-bar bg-teal"
                id={`ftr_${topicCount - 1}_progressbarMain`}
                role="progressbar"
                aria-valuenow={1}
                aria-valuemin="0"
                aria-valuemax="100"
                style={{ width: `1%` }}
              >
                <span className="sr-only">1%</span>
              </div>
            </div>
          </div>
        </div>
      </Col>
    );
  };
  const addNewTopicCardWizard = (index) => {
    return (
      <Col
        md={4}
        lg={4}
        id="addNewTopicCardWizard"
        key={`addNewTopicCardWizard${index}`}
        onClick={() => {
          newCardClickListener();
        }}
      >
        <div
          className="card p-2 card-hover-shadow smi-card addTopicCardWizard"
          style={{ height: "13rem", cursor: "pointer" }}
        >
          <div
            className="card-body"
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <div className="d-flex">
              <a className="tile tile-circle tile-md text-white smi-tile-primary smi-btn">
                <span
                  className="pi pi-plus fa-fw "
                  title="Add Topic"
                  aria-hidden="true"
                ></span>
                <span className="sr-only">Add Topic</span>
              </a>
            </div>
          </div>
        </div>
      </Col>
    );
  };

  useEffect(() => {
    if (!formInitializedFlag && props.topics) {
      setFormInitializedFlag(true);
      setTopics(props.topics);
      setEditTopicData(null);
      setLoadingFlag(false);
    }
  }, []);

  return (
    <div>
      <Row>
        {topics.map((value, index) => {
          if (props.lessonFormData.formLessonType === "regularlesson") {
            return addedTopicCard(index + 1, value.topicname, value.topicmedia);
          } else {
            return addedTopicCard(
              index + 1,
              value?.question?.substring(0, 50),
              value.questiontype
            );
          }
        })}
        {Array.from(
          { length: 6 - topics.length <= 0 ? 1 : 6 - topics.length },
          (_, index) => addNewTopicCardWizard(index)
        )}
      </Row>
      <div>
        <Toast ref={toast}></Toast>
        <Dialog
          header={`Topic ${topicCounterHeader}`}
          visible={visible}
          position={"top"}
          style={{
            width:
              props.lessonFormData.formLessonType === "survey" ||
              props.lessonFormData.formLessonType === "assessment"
                ? "50Vw"
                : "65vw",
          }}
          onHide={() => setVisible(false)}
          draggable={false}
          resizable={false}
        >
          <Card className="mt-1">
            <Card.Body className="p-2">
              {props.lessonFormData &&
              (props.lessonFormData.formLessonType === "survey" ||
                props.lessonFormData.formLessonType === "assessment") ? (
                <AssessmentTopicForm
                  lessonFormData={props.lessonFormData}
                  setVisible={setVisible}
                  editTopicData={editTopicData}
                  topics={topics}
                  topicCount={topicCounterHeader}
                  submitDetect={(eventValue, topicObject) => {
                    console.log(
                      "SubmitEvent Detected",
                      eventValue,
                      topicObject
                    );
                    // setFetchDataFlag(null);
                    let actionFlag = "add";
                    let localTopics = topics;
                    if (editTopicData != null) {
                      let order = topicObject.topicorder - 1;
                      localTopics[order] = topicObject;
                      actionFlag = "edit";
                    } else {
                      localTopics.push(topicObject);
                      // Add topic call here
                    }
                    setEditTopicData(null);
                    setTopics(localTopics);
                    updateTopicInServer(topicObject, actionFlag);
                  }}
                  toast={toast}
                />
              ) : (
                <TopicForm
                  lessonFormData={props.lessonFormData}
                  setVisible={setVisible}
                  editTopicData={editTopicData}
                  topics={topics}
                  topicCount={topicCounterHeader}
                  submitDetect={(eventValue, topicObject) => {
                    console.log(
                      "SubmitEvent Detected",
                      eventValue,
                      topicObject
                    );
                    // setFetchDataFlag(null);
                    let actionFlag = "add";
                    let localTopics = topics;
                    if (editTopicData != null) {
                      let order = topicObject.topicorder - 1;
                      localTopics[order] = topicObject;
                      actionFlag = "edit";
                    } else {
                      localTopics.push(topicObject);
                      // Add topic call here
                    }
                    setEditTopicData(null);
                    setTopics(localTopics);
                    updateTopicInServer(topicObject, actionFlag);
                  }}
                  toast={toast}
                />
              )}
            </Card.Body>
          </Card>
        </Dialog>
      </div>
      <LessonConfirmDialog
        // onMaskClick={setConfirmDialogVisible(true)}
        modalTitle={"Confirm the delete."}
        modalMessage={"Click confirm to delete or cancel to go back."}
        modalSubTitle={" "}
        confirmDialogVisible={confirmDialogVisible}
        setConfirmDialogVisible={setConfirmDialogVisible}
        submitDetect={(value) => {
          if (value === "confirm" && deleteTopicIndex) {
            let localTopics = [...topics];
            let topicToDelete = topics[deleteTopicIndex - 1];
            topicToDelete["topicLanguages"] =
              props.lessonFormData.languageSelectField;
            localTopics.splice(deleteTopicIndex - 1, 1);

            deleteTopicInServer(topicToDelete); // uncomment for calling delete topic API
            setTopics(localTopics);
            setDeleteTopicIndex(null);
          }
        }}
      />
      {props.editFlag && props.editFlag === true ? (
        <Button
          label={`Previous`}
          style={{ background: "black", textAlign: "left" }}
          onClick={() => {
            if (props.setActiveStepIndex) {
              props.setActiveStepIndex(1);
            }
          }}
          className={`btn btn-primary mt-4 mb-4 float-left`}
        />
      ) : (
        <div></div>
      )}
      <Button
        label={`Save`}
        disabled={loadingFlag}
        {...(loadingFlag ? { icon: "pi pi-spinner pi-spin" } : {})}
        title="Save lesson and go to lessonmanager"
        style={{
          background: "#4d4d4d",
          textAlign: "left",
          borderRadius: "0.25rem",
          padding: "6px 12px",
          fontFamily: "inherit",
          border: "none",
        }}
        onClick={() => {
          if (props.editFlag) {
            navigate("/lessonmanager");
          } else {
            navigate("/lessonreviewmanager");
          }
        }}
        className={`btn btn-primary mt-4 mb-4 float-right spinsavebtn`}
      />
    </div>
  );
};
export default TopicsPage;
