import React, { useState } from "react";
import { Button } from "primereact/button";
import { MultiSelect } from "primereact/multiselect";
import "./LessonDetailsForm.css";
import config from "../../config/config.json";
import { Col, Container, Row } from "react-bootstrap";
import resizeImage from "../Common/ImageResizeFunc";
import { useEffect } from "react";
import "./Lessonwizard.css";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";

const AdditionalLessonDetailsForm = (props) => {
  const [selectedLanguages, setSelectedLanguages] = useState(["English"]);
  const [retakeSelectedLangs, setRetakeSelectedLangs] = useState({});
  const [lessonStatusValue, setLessonStatusValue] = useState(true);
  const [enablelessonvalue, setEnablelessonvalue] = useState(false);
  const [lessoncardtype, setLessoncardtype] = useState("");

  const [ackValue, setAckValue] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [fileChooserLabel, setFileChooserLabel] = useState("Choose file");
  const [lessonImageFile, setLessonImageFile] = useState(null);
  const [previewLessonImage, setPreviewLessonImage] = useState(null);
  const [saveButtonText, setSaveButtonText] = useState("Next");
  // const [formInitializedFlag, setFormInitializedFlag] = useState(null);

  const [lessoncardheader, setLessoncardheader] = useState(null);
  const [lessoncardfooter, setLessoncardfooter] = useState(null);
  const [Lessoncarddescription, setLessoncarddescription] = useState(null);

  const [imgSrc, setImgSrc] = useState(null);
  const [imageExtensions] = useState([".png", ".jpg", ".jpeg"]);
  const [currentExtensionIndex, setCurrentExtensionIndex] = useState(0);

  const [isInitialized, setIsInitialized] = useState(false);

  const [lessonLanguages, setLessonLanguages] = useState([
    { label: "English", value: "English" },
    { label: "Chinese", value: "Chinese" },
    { label: "Japanese", value: "Japanese" },
  ]);

  const resetFileInput = () => {
    setLessonImageFile(null);
    setFileChooserLabel("Choose file");
  };

  const CardcolourOption = [
    { name: "White", value: "whiteCard" },
    { name: "Blue", value: "blueCard" },
    { name: "Green", value: "greenCard" },
    { name: "Pink", value: "pinkCard" },
    { name: "Black", value: "blackCard" },
    { name: "Light Blue", value: "lightblueCard" },
    { name: "Yellow", value: "yellowCard" },
    { name: "Light Gray", value: "lightgrayCard" },
  ];

  const handleLessonCardChange = (e) => {
    setLessoncardtype(e.value);
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length) {
      setLessonImageFile(e.target.files[0]);
      setFileChooserLabel(e.target.files[0].name);
      let file = e.target.files[0];
      var reader = new FileReader();
      reader.onload = async function (e) {
        const imgEl = document.createElement("img");
        imgEl.addEventListener("load", () => {
          const resizedDataUri = resizeImage(imgEl, 300);
          // document.querySelector('#imagePreview').src = resizedDataUri;
          setPreviewLessonImage(resizedDataUri);
        });
        imgEl.src = e.target.result;
      };
      reader.readAsDataURL(file);
      const imagePreviewDiv = document.getElementById("imagePreviewDiv");
      if (imagePreviewDiv) {
        imagePreviewDiv.classList.remove("d-none");
      }
    } else if (
      e.target.files.length > 0 &&
      e.target.files[0].type !== "image/png" &&
      e.target.files[0].type !== "image/jpeg"
    ) {
      props.toast.current.show({
        severity: "info",
        summary: "Lesson Image",
        detail: "Only JPEG/PNG images are allowed",
      });
      resetFileInput();
    }
  };

  useEffect(() => {
    if (typeof props.editFlag == "boolean") {
      if (props && props.lessonFormData) {
        if (props.lessonFormData.allLessonLanguages) {
          setLessonLanguages(props.lessonFormData.allLessonLanguages);
        }
        let formData = props.lessonFormData;

        if (
          formData.lessonImageFile &&
          formData.lessonImageFile !== undefined &&
          formData.lessonImageFile !== null
        ) {
          setLessonImageFile(formData.lessonImageFile);
          handleFileChange({ target: { files: [formData.lessonImageFile] } });
        }
        if (
          formData.formLessonType === "survey" ||
          formData.formLessonType === "assessment"
        ) {
          setSelectedLanguages(["English"]);
          formData.languageSelectField = ["English"];
          setRetakeSelectedLangs({
            ...retakeSelectedLangs,
            ["English"]: false,
          });
        }
        if (
          formData.languageSelectField &&
          formData.languageSelectField !== undefined &&
          formData.languageSelectField !== null
        ) {
          setSelectedLanguages(formData.languageSelectField);
          formData.languageSelectField.map((lang) => {
            setRetakeSelectedLangs({ ...retakeSelectedLangs, [lang]: false });
          });
        }
        if (
          formData.formLessonStatus !== undefined &&
          formData.formLessonStatus !== null
        ) {
          setLessonStatusValue(formData.formLessonStatus);
        }
        if (
          formData.formAcknowledgementRequired !== undefined &&
          formData.formAcknowledgementRequired !== null
        ) {
          setAckValue(formData.formAcknowledgementRequired);
        }
        if (
          formData.formLessonType === "externallink" ||
          formData.formLessonType === "nestedcard"
        ) {
          setSaveButtonText("Save");
        }
        setLessoncardheader(
          formData.lessoncardheader ? formData.lessoncardheader : ""
        );
        setLessoncardfooter(
          formData.lessoncardfooter ? formData.lessoncardfooter : ""
        );
        setLessoncardtype(
          formData.lessoncardtype ? formData.lessoncardtype : ""
        );
        setLessoncarddescription(
          formData.lessoncarddescription ? formData.lessoncarddescription : ""
        );
        if (formData.lessoncardheader || formData.lessoncardtype) {
          setEnablelessonvalue(true);
        }
        setIsInitialized(true);
      }
      if (props.editFlag === true) {
        setImgSrc(
          config.content.url +
            props.lessonFormData.formLessonId +
            "/" +
            props.lessonFormData.formLessonId +
            ".png"
        );
        loadImageWithNextExtension();
      }
    }
  }, [props.editFlag, currentExtensionIndex]);

  const handleBack = () => {
    setIsSubmitting(false);
    if (props.submitDetect) {
      let obj = {
        ...props.lessonFormData,
        lessonImageFile: lessonImageFile,
        previewLessonImage: previewLessonImage,
        languageSelectField: selectedLanguages,
        formLessonStatus: lessonStatusValue,
        formAcknowledgementRequired: ackValue,
        lessoncardheader: lessoncardheader,
        lessoncarddescription: Lessoncarddescription,
        lessoncardfooter: lessoncardfooter,
        lessoncardtype: lessoncardtype,
      };
      props.setLessonFormData(obj);
      props.submitDetect("previous", obj);
    }
  };

  const enablelessoncard = () => {
    setEnablelessonvalue(!enablelessonvalue);
    resetFileInput();
    setPreviewLessonImage("");
    if (!enablelessonvalue === false) {
      setLessoncarddescription("");
      setLessoncardfooter("");
      setLessoncardheader("");
      setLessoncardtype("");
    }
  };

  const handleSubmit = () => {
    setIsSubmitting(false);
    resetFileInput();
    if (props.submitDetect && selectedLanguages.length > 0) {
      let obj = {
        ...props.lessonFormData,
        lessonImageFile: lessonImageFile,
        previewLessonImage: previewLessonImage,
        languageSelectField: selectedLanguages,
        formLessonStatus: lessonStatusValue,
        formAcknowledgementRequired: ackValue,
        lessoncardheader: lessoncardheader,
        lessoncarddescription: Lessoncarddescription,
        lessoncardfooter: lessoncardfooter,
        lessoncardtype: lessoncardtype,
      };
      if (
        props.lessonFormData.formLessonType === "regularlesson" ||
        props.lessonFormData.formLessonType === "assessment"
      ) {
        let retakeLanguages = [];
        Object.keys(retakeSelectedLangs).map((language) => {
          if (retakeSelectedLangs[language]) {
            retakeLanguages.push(language);
          }
        });
        obj["lessonRetakeConfiguration"] = retakeLanguages.join(",");
      }
      props.setLessonFormData(obj);
      props.submitDetect("next", obj);
    }
  };

  const loadImageWithNextExtension = () => {
    if (currentExtensionIndex < imageExtensions.length) {
      const extension = imageExtensions[currentExtensionIndex];
      const imgSrc =
        config.content.url +
        props.lessonFormData.formLessonId +
        "/" +
        props.lessonFormData.formLessonId +
        extension;
      const img = new Image();
      img.src = imgSrc;
      img.onload = () => {
        setImgSrc(imgSrc);
      };
      img.onerror = () => {
        setCurrentExtensionIndex(currentExtensionIndex + 1);
      };
    } else {
      setImgSrc(null);
    }
  };

  return props.lessonFormData ? (
    <div>
      <div className={`mt-3 mb-3 w-50 m-auto`}>
        <Row>
          <Col md={10}>
            No Image Lesson
            {lessonStatusValue}
          </Col>
          <Col md={2}>
            <div className={isInitialized ? "" : "d-none"}>
              <span className="d-none"></span>
              <div className="d-flex requiredCheckbox">
                <label
                  className={`switcher-control ${
                    lessonStatusValue ? "switcher-control-success" : ""
                  }`}
                >
                  <input
                    type="checkbox"
                    className="switcher-input StatusCheckBox"
                    name="formLessonStatus"
                    checked={enablelessonvalue}
                    onChange={enablelessoncard}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Col>
        </Row>
      </div>

      <div className="fade-in-image w-50 mx-auto">
        {!enablelessonvalue && (
          <div
            id="LessonImageDiv"
            className={`${
              props.lessonFormData.formLessonType === "survey" ? "d-none" : ""
            }`}
          >
            <label htmlFor="formFileInput">Lesson Image</label>
            <div className="p-field">
              <div className="custom-file">
                <input
                  type="file"
                  className="custom-file-input"
                  id="formFileInput"
                  accept=".jpg, .jpeg, .png"
                  onChange={handleFileChange}
                />
                <label className="custom-file-label" htmlFor="tf3">
                  {fileChooserLabel}
                </label>
              </div>
              <div
                id="imagePreviewDiv"
                className={`img img-responsive ${
                  !previewLessonImage ? "d-none" : ""
                } mt-3`}
                align="center"
              >
                <img
                  id="imagePreview"
                  height="200px"
                  width="350px"
                  src={previewLessonImage}
                />
              </div>
              <div
                id="imagePreviewEditDiv"
                className={`img img-responsive ${
                  props.editFlag && !previewLessonImage ? "" : "d-none"
                } mt-3`}
                align="center"
              >
                <img
                  id="imagePreviewEdit"
                  src={props.editFlag ? imgSrc : ""}
                  alt="No Image Selected"
                  height="200px"
                  width="350px"
                />
              </div>
            </div>
          </div>
        )}

        {enablelessonvalue && (
          <Row>
            <Container fluid>
              <div className="mb-3">
                <label htmlFor="LessonCardTitle">Lesson Card Header</label>
                <InputText
                  type="text"
                  name="LessonCardTitle"
                  className="w-full p-inputtext-sm forminput"
                  onChange={(e) => setLessoncardheader(e.target.value)}
                  value={lessoncardheader}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="LessonCardDescription">
                  Lesson Card Description
                </label>
                <InputText
                  type="text"
                  name="LessonCardDescription"
                  className="w-full p-inputtext-sm forminput"
                  onChange={(e) => setLessoncarddescription(e.target.value)}
                  value={Lessoncarddescription}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="LessonCardSubtitle">Lesson Card Footer</label>
                <InputText
                  type="text"
                  name="LessonCardSubtitle"
                  className="w-full p-inputtext-sm forminput"
                  onChange={(e) => setLessoncardfooter(e.target.value)}
                  value={lessoncardfooter}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="LessonCardColor">Lesson Card Color</label>
                <Dropdown
                  value={lessoncardtype}
                  onChange={handleLessonCardChange}
                  options={CardcolourOption}
                  optionLabel="name"
                  name="LessonCardColor"
                  className="w-full p-inputtext-sm forminput"
                  placeholder="Choose..."
                  required
                />
              </div>
            </Container>
          </Row>
        )}

        <div
          className={`mt-2 ${
            ["externallink", "nestedcard"].includes(
              props.lessonFormData.formLessonType
            )
              ? "d-none"
              : ""
          }`}
        >
          <Row>
            <Container fluid>
              <label className="control-label" htmlFor="languageSelectField">
                Lesson Language/s<abbr>*</abbr>
              </label>
            </Container>
          </Row>
          <div className="justify-content-center ">
            <MultiSelect
              value={
                ["survey", "assessment"].includes(
                  props.lessonFormData.formLessonType
                )
                  ? ["English"]
                  : selectedLanguages
              }
              onChange={(e) => setSelectedLanguages(e.value)}
              className={`w-full forminput ${
                ["survey", "assessment"].includes(
                  props.lessonFormData.formLessonType
                )
                  ? "p-disabled"
                  : ""
              }`}
              options={lessonLanguages}
              optionLabel="label"
              optionValue="value"
              id="languageSelectField"
              display="chip"
            />
            <span
              name="givenName"
              component="div"
              className={`p-error  ${
                selectedLanguages.length === 0 ? "d-block" : "d-none"
              }`}
            >
              Please select at least 1 language.
            </span>
          </div>
        </div>
        <div className={`mt-3`}>
          <Row>
            <Col md={10}>
              Lesson Status
              {lessonStatusValue}
            </Col>
            <Col md={2}>
              <div className={isInitialized ? "" : "d-none"}>
                <span className="d-none"></span>
                <div className="d-flex requiredCheckbox">
                  <label
                    className={`switcher-control ${
                      lessonStatusValue ? "switcher-control-success" : ""
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="switcher-input StatusCheckBox"
                      name="formLessonStatus"
                      checked={lessonStatusValue ? true : false}
                      onChange={() => {
                        setLessonStatusValue(!lessonStatusValue);
                      }}
                    />
                    <span className="switcher-indicator"></span>
                  </label>
                </div>
              </div>
            </Col>
          </Row>
        </div>

        <div
          className={`mt-3 ${
            ["externallink", "nestedcard", "survey"].includes(
              props.lessonFormData.formLessonType
            )
              ? "d-none"
              : ""
          }`}
        >
          <Row>
            <Col md={10}>Acknowledgement Required</Col>
            <Col md={2}>
              <div className={isInitialized ? "" : "d-none"}>
                <span className="d-none"></span>
                <div className="d-flex requiredCheckbox">
                  <label
                    className={`switcher-control ${
                      ackValue ? "switcher-control-success" : ""
                    }`}
                  >
                    <input
                      type="checkbox"
                      className="switcher-input StatusCheckBox"
                      name="formLessonStatus"
                      checked={ackValue ? true : false}
                      onChange={() => {
                        setAckValue(!ackValue);
                      }}
                    />
                    <span className="switcher-indicator"></span>
                  </label>
                </div>
              </div>
            </Col>
          </Row>
        </div>
        {props.editFlag === true &&
        (props.lessonFormData.formLessonType === "regularlesson" ||
          props.lessonFormData.formLessonType === "assessment") &&
        props.lessonFormData.languageSelectField ? (
          props.lessonFormData.languageSelectField.map((lang, index) => {
            return (
              <div className={`mt-3`} key={`retakeToggles_${index}`}>
                <Row>
                  <Col md={10}>Retake {lang} Lesson</Col>
                  <Col md={2}>
                    <div>
                      <span className="d-none"></span>
                      <div className="d-flex requiredCheckbox">
                        <label
                          className={`switcher-control ${
                            retakeSelectedLangs[lang]
                              ? "switcher-control-success"
                              : ""
                          }`}
                        >
                          <input
                            type="checkbox"
                            className="switcher-input StatusCheckBox"
                            name="formLessonStatus"
                            checked={retakeSelectedLangs[lang] ? true : false}
                            onChange={() => {
                              setRetakeSelectedLangs({
                                ...retakeSelectedLangs,
                                [lang]: !retakeSelectedLangs[lang],
                              });
                            }}
                          />
                          <span className="switcher-indicator"></span>
                        </label>
                      </div>
                    </div>
                  </Col>
                </Row>
              </div>
            );
          })
        ) : (
          <></>
        )}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Button
          label={`Previous`}
          style={{
            background: "#4d4d4d",
            textAlign: "left",
            fontFamily: "inherit",
            padding: "6px 12px",
            borderRadius: "0.25rem",
            border: "none",
          }}
          disabled={isSubmitting}
          onClick={() => {
            handleBack();
          }}
          className={`btn btn-primary previousbtn ${
            isSubmitting ? "disabled" : ""
          } mt-4 mb-4 float-left`}
        />

        <Button
          type="submit"
          label={saveButtonText}
          style={{
            background: "#4d4d4d",
            textAlign: "left",
            padding: "6px 12px",
            borderRadius: "0.25rem",
            fontFamily: "inherit",
            border: "none",
          }}
          disabled={isSubmitting}
          onClick={() => {
            handleSubmit();
          }}
          className={`btn btn-primary float-right previousbtn ${
            isSubmitting || selectedLanguages.length === 0 ? "disabled" : ""
          } mt-4 mb-4 float-right`}
        />
      </div>
    </div>
  ) : (
    <div></div>
  );
};
export default AdditionalLessonDetailsForm;
