import React, { useState, useRef, useEffect } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";
import { Toast } from "primereact/toast";
import "./LessonConfirmDialog.css";

const LessonConfirmDialog = (props) => {
  const urlParams = new URLSearchParams(window.location.search);
  var lessonid = urlParams.get("lessonid");

  const toast = useRef(null);
  const [modalTitle, setModalTitle] = useState("Confirm the Lesson");
  const [modalMessage, setModalMessage] = useState(
    "Click confirm to save all changes or cancel to go back."
  );
  const [modalSubTitle, setModalSubTitle] = useState(
    lessonid
      ? "Note: Removing a language will remove any associated topics and they are not recoverable."
      : ""
  );

  useEffect(() => {
    if (props.modalTitle) {
      setModalTitle(props.modalTitle);
    }
    if (props.modalMessage) {
      setModalMessage(props.modalMessage);
    }
    if (lessonid) {
      setModalSubTitle(
        "Note: Removing a language will remove any associated topics and they are not recoverable."
      );
    }
    if (props.modalSubTitle) {
      setModalSubTitle(props.modalSubTitle);
    }
  }, [props.modalTitle, props.modalMessage, props.modalSubTitle]);

  const confirmationClickHandler = (value) => {
    if (props.submitDetect) {
      props.submitDetect(value);
    }
    props.setConfirmDialogVisible(false);
  };
  const footerContent = (
    <div className="float-left">
      <Button
        label="Confirm"
        style={{ background: "#4d4d4d", textAlign: "left" }}
        className="btn btn-primary confirmbtn"
        onClick={() => confirmationClickHandler("confirm")}
        autoFocus
      />
      <Button
        label="Cancel"
        style={{ background: "#4d4d4d", textAlign: "left" }}
        className="btn btn-primary confirmbtn"
        onClick={() => confirmationClickHandler("cancel")}
      />
    </div>
  );

  return (
    <div className="card flex justify-content-center">
      <Toast ref={toast}></Toast>
      <Dialog
        header={modalTitle}
        position="top"
        visible={props.confirmDialogVisible}
        onHide={() => props.setConfirmDialogVisible(false)}
        draggable={false}
        resizable={false}
        style={{ width: "50vw" }}
        footer={footerContent}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
      >
        <p className="text-muted ml-1" id="modalMessageText">
          {modalMessage}
        </p>
        <p className="text-muted ml-1">{modalSubTitle}</p>
      </Dialog>
    </div>
  );
};
export default LessonConfirmDialog;
