import React, { useState, useEffect } from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import DropdownField from "../Common/DropdownField";
import "./LessonDetailsForm.css";
import { MultiSelect } from "primereact/multiselect";
import { Container, Row } from "react-bootstrap";
import { OrderList } from "primereact/orderlist";
import "./Lessonwizard.css";

const LessonDetailsForm = (props) => {
  const [lessonTypeValue, setLessonTypeValue] = useState(null);
  const [selectedLessonIds, setSelectedLessonIds] = useState([]);
  // const [formInitializedFlag, setFormInitializedFlag] = useState(null);
  const [initialValues, setInitialValues] = useState({
    formLessonId: "",
    formLessonType: "regularlesson",
    formVersion: 1,
    formLessonName: "",
    formLessonDescription: "",
    formLessonUrl: "",
  });
  useEffect(() => {
    if (typeof props.editFlag == "boolean") {
      if (props.initialValues) {
        let initialValues = props.initialValues;
        // setFormInitializedFlag(true)
        if (props.initialValues.formLessonType) {
          setLessonTypeValue(props.initialValues.formLessonType);
          props.lessonTypeChangeDetector(props.initialValues.formLessonType);
        }
        if (props.initialValues.nestedlessonList) {
          setSelectedLessonIds(props.initialValues.nestedlessonList);
        }
        setInitialValues(initialValues);
      }
    }
    // else {
    //     setInitialValues({
    //         formLessonId: '',
    //         formLessonType: 'regularlesson',
    //         formVersion: 1,
    //         formLessonName: '',
    //         formLessonDescription: '',
    //         formLessonUrl: ''
    //     })
    // }
  }, [props.initialValues, props.editFlag]);

  const lessonTypes = [
    { label: "Regular lesson", value: "regularlesson" },
    { label: "External Link", value: "externallink" },
    { label: "Nested Lesson", value: "nestedcard" },
    { label: "Survey Lesson", value: "survey" },
    { label: "Assessment Lesson", value: "assessment" },
  ];

  const validateForm = (values) => {
    const errors = {};
    // console.log(lessonTypeValue)
    if (!values.formLessonId) {
      errors.formLessonId = "Valid lesson ID is required.";
    }
    if (!values.formVersion || values.formVersion < 1) {
      errors.formVersion = "Valid lesson version is required.";
    }
    if (!values.formLessonName) {
      errors.formLessonName = "Valid lesson name is required.";
    }
    if (lessonTypeValue === "externallink" && !values.formLessonUrl) {
      errors.formLessonUrl = "Valid external url is required.";
    }
    if (lessonTypeValue === "nestedcard" && selectedLessonIds.length === 0) {
      errors.nestedlessonList = "Please select at least 1 lesson.";
    }
    return errors;
  };

  const handleSubmit = (values, { setSubmitting }) => {
    // console.log(values);
    setSubmitting(false);
    if (props.submitDetect) {
      let obj = {
        ...values,
        nestedlessonList: selectedLessonIds,
      };
      props.submitDetect("next", obj);
    }
  };

  const itemTemplate = (item) => {
    return (
      <div className="flex flex-wrap p-2 align-items-center gap-3">
        <div className="flex-1 flex flex-column gap-2 xl:mr-8">
          <div className="align-items-center drag-handle" draggable="false">
            <span className="drag-indicator"></span>
            <span className="">{item}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="fade-in-image w-100">
      <Formik
        initialValues={initialValues}
        validate={validateForm}
        onSubmit={handleSubmit}
        enableReinitialize
      >
        {({ isSubmitting }) => (
          <Form className="w-50 mx-auto">
            <div className="p-field mt-5">
              <label htmlFor="formLessonId">
                Lesson ID<span style={{ color: " #b76ba3" }}>*</span>
              </label>
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="formLessonId"
                  name="formLessonId"
                  as={InputText}
                  disabled={props.editFlag}
                  className={`p-inputtext  ${isSubmitting ? "p-disabled" : ""}`}
                />
              </span>
              <ErrorMessage
                name="formLessonId"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-4">
              <label htmlFor="formLessonId">Lesson Type</label>
              <Field
                id="formLessonType"
                name="formLessonType"
                component={DropdownField}
                options={lessonTypes}
                className={`dropdownfield ${isSubmitting ? "p-disabled" : ""}`}
                changeDetector={(selectedValue) => {
                  setLessonTypeValue(selectedValue);
                  if (props.lessonTypeChangeDetector) {
                    props.lessonTypeChangeDetector(selectedValue);
                  }
                }}
              />
            </div>

            <div className="p-field mt-4">
              <label htmlFor="formVersion">Lesson Version</label>
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="number"
                  id="formVersion"
                  name="formVersion"
                  as={InputText}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
              </span>
              <ErrorMessage
                name="formVersion"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-4">
              <label htmlFor="formLessonName">
                Lesson Name<span style={{ color: " #b76ba3" }}>*</span>
              </label>

              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="formLessonName"
                  name="formLessonName"
                  as={InputText}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
              </span>
              <ErrorMessage
                name="formLessonName"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-4">
              <label htmlFor="formLessonDescription">Lesson Description</label>
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="formLessonDescription"
                  name="formLessonDescription"
                  as={InputText}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
              </span>
              <ErrorMessage
                name="formLessonDescription"
                component="div"
                className="p-error"
              />
            </div>

            <div
              className={`p-field mt-4 ${lessonTypeValue === "externallink" ? "" : "d-none"
                }`}
            >
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="formLessonUrl"
                  name="formLessonUrl"
                  placeholder="https://www.sciencemedia.com"
                  as={InputText}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
                <label htmlFor="formLessonUrl">External URL</label>
              </span>
              <ErrorMessage
                name="formLessonUrl"
                component="div"
                className="p-error"
              />
            </div>

            <div
              className={`mt-2 ${!["nestedcard"].includes(lessonTypeValue) ? "d-none" : ""
                }`}
              style={{ widows: "100%" }}
            >
              <Row>
                <Container>
                  <label
                    className="control-label"
                    htmlFor="languageSelectField"
                  >
                    Select child lessons
                  </label>
                </Container>
              </Row>
              <div className="" style={{ widows: "100%" }}>
                <MultiSelect
                  value={selectedLessonIds}
                  filter
                  onChange={(e) => setSelectedLessonIds(e.value)}
                  options={props.lessonIds}
                  optionLabel="label"
                  optionValue="value"
                  id="nestedlessonList"
                  style={{ width: "100%" }}
                  display="chip"
                  className="forminput"
                />
                <span
                  name="nestedlessonList"
                  component="div"
                  className={`p-error ${selectedLessonIds.length === 0 ? "d-block" : "d-none"
                    }`}
                >
                  Please select at least 1 lesson.
                </span>
              </div>

              {selectedLessonIds.length > 0 ? (
                <div className="card xl:flex xl:justify-content-center mt-3">
                  <OrderList
                    value={selectedLessonIds}
                    onChange={(e) => setSelectedLessonIds(e.value)}
                    itemTemplate={itemTemplate}
                    header="Rearrange the lessons to change the order"
                    dragdrop
                  ></OrderList>
                </div>
              ) : (
                <></>
              )}
            </div>
            <div>
              <Button
                type="submit"
                label={`Next`}
                style={{
                  background: "#4d4d4d",
                  textAlign: "left",
                  position: "absolute",
                  bottom: "-20px",
                  right: "0px",
                  border: "none",
                }}
                disabled={isSubmitting}
                className={`btn btn-primary stepperNext${isSubmitting ? "disabled" : ""
                  } mt-4 mb-4 float-right`}
              />
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};
export default LessonDetailsForm;
