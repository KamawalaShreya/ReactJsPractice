import React, { useEffect, useState } from "react";
import "../LessonDetailsForm.css";
import { InputText } from "primereact/inputtext";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { Button } from "primereact/button";
import LessonConfirmDialog from "../LessonConfirmDialog";
// import { Divider } from "primereact/divider";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheckCircle,
  faPlusCircle,
  faTimesCircle,
  faTrashAlt,
} from "@fortawesome/free-solid-svg-icons";
import { Editor } from "primereact";

const AssessmentTopicForm = (props) => {
  
  //   const [isSubmitting, setIsSubmitting] = useState(false);
  const [topicStatus, setTopicStatus] = useState(true);
  // const [formInitializedFlag, setFormInitializedFlag] = useState(null);

  const [initialValues, setInitialValues] = useState({
    topicorder: 1,
    questionlabel: "",
    answer: "",
    topicid: "",
    formAddTopicIDDummy_wizard: "",
    question: "",
    questiontype: "Multiplechoice",
    version: 1,
    status: true,
  });
  const [questionTypeValue, setQuestionTypeValue] = useState("Multiplechoice");

  const [formValue, setFormValue] = useState(null);
  const [answers, setAnswers] = useState([""]);

  const [isLoading, setIsLoading] = useState(true);

  const [correctAnswerIndex, setCorrectAnswerIndex] = useState(0);

  const [confirmDialogVisible, setConfirmDialogVisible] = useState(false);

  const questionTypesArray = [
    { label: "Multiple Choice Answers", value: "Multiplechoice" },
    { label: "Free form text", value: "text" },
  ];

  const getDisplayTopicCount = (topicCount) => {
    return topicCount < 10 ? "0" + topicCount : topicCount;
  };

  useEffect(() => {
    setIsLoading(true);
    let obj = {
      topicorder: 1,
      questionlabel: "",
      answer: "",
      topicid: "",
      formAddTopicIDDummy_wizard: "",
      question: "",
      questiontype: "Multiplechoice",
      version: 1,
      status: true,
    };
    if (props.lessonFormData && props.topicCount) {
      obj.topicorder = props.topicCount;
      obj.formAddTopicIDDummy_wizard =
        "s01-" + getDisplayTopicCount(props.topicCount);
      obj.topicid =
        props.lessonFormData.formLessonId +
        "-" +
        obj.formAddTopicIDDummy_wizard;
    }
    if (props.lessonFormData && props.editTopicData) {
      obj.topicorder = props.editTopicData.topicorder;
      obj.questionlabel = props.editTopicData.questionlabel;
      obj.answer = props.editTopicData.answer;
      obj.topicid = props.editTopicData?.topicid.replace("topicid-", "");
      // obj.formAddTopicIDDummy_wizard = 's01-' + getDisplayTopicCount(props.editTopicData.topicorder);
      obj.formAddTopicIDDummy_wizard = obj?.topicid.replace(
        `${props.lessonFormData.formLessonId}-`,
        ""
      );
      obj.question = props.editTopicData.question;
      obj.questiontype = props.editTopicData.questiontype;
      setQuestionTypeValue(obj.questiontype);
      obj.version = props.editTopicData.version;
      obj.status = props.editTopicData.status;
      let updatedAnswers = [];
      for (let key of Object.keys(props.editTopicData)) {
        if (key.includes("answer") && key !== "answer") {
          if (props.editTopicData[key] != "") {
            updatedAnswers[parseInt(key.replace("answer", "") - 1)] =
              props.editTopicData[key];
          }
          if (
            props.lessonFormData.formLessonType == "assessment" &&
            props.editTopicData[key] === props.editTopicData["answer"]
          ) {
            let correctIndex = parseInt(key.replace("answer", "")) - 1;
           
            setCorrectAnswerIndex(parseInt(correctIndex));
          }
        }
      }

      setAnswers(updatedAnswers);
      setTopicStatus(props.editTopicData.status === "active" ? true : false);
    }
    setInitialValues(obj);
    setIsLoading(false);
  }, [props.lessonFormData, props.editTopicData]);

  const updateFieldValue = (fieldName, newValue, formik) => {
    formik.setFieldValue(fieldName, newValue);
  };

  const handleTopicIdChange = (e, formik) => {
    updateFieldValue("formAddTopicIDDummy_wizard", e.target.value, formik);
    updateFieldValue(
      "topicid",
      props.lessonFormData.formLessonId + "-" + e.target.value,
      formik
    );
  };

  const validateForm = (values) => {
   
    const errors = {};
    if (values.formAddTopicIDDummy_wizard === "") {
      errors.formAddTopicIDDummy_wizard = "TopicId is required.";
    }
    if (values.question === "") {
      errors.question = "Question is required.";
    }
    if (values.topicorder === "" || values.topicorder < 1) {
      errors.topicorder = "Topic Order is not valid.";
    }
    if (values.version === "" || values.version < 1) {
      errors.version = "Topic Version is not valid.";
    }
    return errors;
  };

  const handleSubmit = (values, { setSubmitting }) => {
   
    let topicObj = values;
    topicObj["lessonid"] = props.lessonFormData.formLessonId;
    answers.map((value, index) => {
      topicObj[`answer${index + 1}`] = answers[value];
    });
    topicObj["answers"] = answers;
    for (let i = 0; i < 10; i++) {
      topicObj[`answer${i + 1}`] = answers[i] ? answers[i] : "";
    }
    if (props.lessonFormData.formLessonType == "assessment") {
      if(questionTypeValue == 'text') {
        topicObj["answer"] = "";
      } else {
        topicObj["answer"] = answers[correctAnswerIndex];
      }
    } else {
      topicObj["answer"] = "";
    }
    topicObj["status"] = topicStatus ? "active" : "inactive";
    topicObj["questiontype"] = questionTypeValue;
    setConfirmDialogVisible(true);
    // props.submitDetect("save", topicObj)
    setSubmitting(false);
    setFormValue(topicObj);
  };

  return (
    <div>
      {isLoading ? (
        <i className="loader pi pi-spinner pi-spin" aria-hidden="true" />
      ) : (
        <Formik
          initialValues={initialValues}
          validate={validateForm}
          onSubmit={handleSubmit}
          enableReinitialize
        >
          {(formik) => (
            <Form>
              <div className="p-field mt-2">
                <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                  <label htmlFor="formAddTopicIDDummy_wizard">Topic ID</label>
                  <Field
                    type="text"
                    id="formAddTopicIDDummy_wizard"
                    name="formAddTopicIDDummy_wizard"
                    as={InputText}
                    onChange={(e) => {
                      handleTopicIdChange(e, formik);
                    }}
                    className={`form-control ${
                      formik.isSubmitting ? "p-disabled" : ""
                    }`}
                  />
                </span>
                <ErrorMessage
                  name="formAddTopicIDDummy_wizard"
                  component="div"
                  className="p-error"
                />
              </div>
              <div
                className="p-field mt-2 d-none"
                id="formAddTopicIDGroup"
                hidden={props.editTopicData ? false : true}
              >
                <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                  <label htmlFor="topicid">Old Topic ID</label>
                  <Field
                    type="text"
                    as={InputText}
                    id="topicid"
                    name="topicid"
                    required
                    disabled
                    className={`form-control ${
                      formik.isSubmitting ? "p-disabled" : ""
                    }`}
                  />
                </span>
                <ErrorMessage
                  name="topicid"
                  component="div"
                  className="p-error"
                />
              </div>

              <div className="p-field mt-2">
                <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                  <label htmlFor="question">Question</label>
                  {props.lessonFormData.formLessonType !== "assessment" ? (
                    <Field
                      type="text"
                      id="question"
                      name="question"
                      as={InputText}
                      className={`form-control ${
                        formik.isSubmitting ? "p-disabled" : ""
                      }`}
                    />
                  ) : (
                    <Editor
                      id="question"
                      name="question"
                      type="text"
                      value={formik.values.question}
                      onTextChange={(e) =>
                        updateFieldValue("question", e.htmlValue, formik)
                      }
                      style={{ height: "320px" }}
                    />
                  )}
                </span>
                <ErrorMessage
                  name="question"
                  component="div"
                  className="p-error"
                />
              </div>

              <div className="p-field mt-2">
                <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                  <label htmlFor="topicorder">Topic Order</label>
                  <Field
                    type="text"
                    id="topicorder"
                    name="topicorder"
                    as={InputText}
                    required
                    className={`form-control ${
                      formik.isSubmitting ? "p-disabled" : ""
                    }`}
                  />
                </span>
                <ErrorMessage
                  name="topicorder"
                  component="div"
                  className="p-error"
                />
              </div>

              <div className="form-group">
                <label htmlFor="questiontype">
                  Topic Type<abbr>*</abbr>
                </label>
                <Field
                  as="select"
                  className="custom-select form-control"
                  name="questiontype"
                  id="questiontype"
                  onChange={(e) => {
                    setQuestionTypeValue(e.target.value);
                    updateFieldValue("questiontype", e.target.value, formik);
                  }}
                  required
                >
                  {questionTypesArray.map((item, index) => {
                    return (
                      <option
                        key={`questionTypeOptions_${index}`}
                        value={item.value}
                      >
                        {item.label}
                      </option>
                    );
                  })}
                </Field>
                <ErrorMessage
                  name="questiontype"
                  component="div"
                  className="p-error"
                />
              </div>

              {questionTypeValue == "Multiplechoice" ? (
                <div className="mcqAnswersBlock d-block">
                  <div className="card card-fluid">
                    <div className="card-header">Multiple Choice Answers</div>
                    <div className="card-body">
                      <ul className="list-group list-group-flush list-group-bordered mcqInputsDiv">
                        {answers.map((_, index) => (
                          <li
                            className="list-group-item align-items-center"
                            key={`AssessmentAnswers_${index + 1}`}
                          >
                            {props.lessonFormData.formLessonType ==
                            "assessment" ? (
                              <div
                                className="btn-group mr-2 selectCorrectMultipleChoiceAnswerDiv"
                                title={
                                  index === correctAnswerIndex
                                    ? "Correct answer"
                                    : "Click to select the correct answer"
                                }
                                disabled={false}
                              >
                                <button
                                  type="button"
                                  className="btn btn-sm btn-secondary selectCorrectMultipleChoiceAnswer"
                                  onClick={() => {
                                  
                                    setCorrectAnswerIndex(index);
                                  }}
                                  data-index={1}
                                  disabled={
                                    index === correctAnswerIndex ? true : false
                                  }
                                >
                                  {index === correctAnswerIndex ? (
                                    <FontAwesomeIcon
                                      className="c-smi-green"
                                      icon={faCheckCircle}
                                      aria-hidden="true"
                                    />
                                  ) : (
                                    <FontAwesomeIcon
                                      className="text-red"
                                      icon={faTimesCircle}
                                      aria-hidden="true"
                                    />
                                  )}
                                </button>
                              </div>
                            ) : (
                              <></>
                            )}

                            <input
                              type="text"
                              className="form-control mr-2"
                              id={`answer_${index + 1}`}
                              onChange={(e) => {
                                const updatedAnswers = [...answers];
                                updatedAnswers[index] = e.target.value;
                                setAnswers(updatedAnswers);
                              }}
                              name={`answer_${index + 1}`}
                              placeholder={`Answer ${index + 1}`}
                              value={answers[index]}
                              required
                            />

                            <div
                              className="btn-group ml-auto"
                              type="button"
                              data-index={index + 1}
                            >
                              <button
                                type="button"
                                className="btn btn-sm btn-secondary"
                                onClick={() => {
                                  setAnswers(
                                    answers.filter((_, i) => i !== index)
                                  );
                                }}
                              >
                                <FontAwesomeIcon
                                  icon={faTrashAlt}
                                  aria-hidden="true"
                                />
                              </button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="card-footer card-footer-item justify-content-center">
                      <button
                        id="addNewMCQtoDiv"
                        type="button"
                        onClick={() => {
                          setAnswers([...answers, [""]]);
                        }}
                        className="btn btn-primary justify-content-center addNewMCQtoDiv"
                        disabled={answers.length >= 10 ? true : false}
                      >
                        <span>
                          <FontAwesomeIcon
                            icon={faPlusCircle}
                            aria-hidden="true"
                          />
                          &nbsp;Add Answer
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              ) : (
                <></>
              )}

              <div className="p-field mt-2">
                <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                  <label htmlFor="version">Topic Version</label>
                  <Field
                    type="text"
                    id="version"
                    name="version"
                    as={InputText}
                    className={`form-control ${
                      formik.isSubmitting ? "p-disabled" : ""
                    }`}
                  />
                </span>
                <ErrorMessage
                  name="version"
                  component="div"
                  className="p-error"
                />
              </div>

              <div className="mt-3 custom-control-inline w-100">
                <div>Topic Status</div>
                <div className="d-flex justify-content-center align-items-center ml-4">
                  <div>
                    <span className="d-none"></span>
                    <div className="d-flex requiredCheckbox">
                      <label
                        className={`switcher-control ${
                          topicStatus ? "switcher-control-success" : ""
                        }`}
                      >
                        <input
                          type="checkbox"
                          className="switcher-input StatusCheckBox"
                          name="status"
                          checked={topicStatus ? true : false}
                          onChange={() => {
                            setTopicStatus(!topicStatus);
                          }}
                        />
                        <span className="switcher-indicator"></span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                label={`Save`}
                style={{ background: "black", textAlign: "left" }}
                disabled={formik.isSubmitting}
                className={`btn btn-primary float-right ${
                  formik.isSubmitting ? "disabled" : ""
                } mt-4 mb-2 float-right`}
              />
            </Form>
          )}
        </Formik>
      )}

      <LessonConfirmDialog
        modalTitle={
          props.editTopicData
            ? "Confirm the changes"
            : "Confirm to add question"
        }
        modalMessage={
          props.editTopicData
            ? "Click confirm to save all changes or cancel to go back."
            : "Click confirm to add the question or cancel to go back."
        }
        modalSubTitle={" "}
        confirmDialogVisible={confirmDialogVisible}
        setConfirmDialogVisible={setConfirmDialogVisible}
        submitDetect={(value) => {
        
          if (value === "confirm") {
          
            props.submitDetect("save", formValue);
            props.setVisible(false);
          }
        }}
      />
    </div>
  );
};
export default AssessmentTopicForm;
