import React, { useState } from "react";
import "../LessonDetailsForm.css";
import { InputText } from "primereact/inputtext";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { Button } from "primereact/button";
import LessonConfirmDialog from "../LessonConfirmDialog";

const TopicForm = (props) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [folderTopicToggle, setFolderTopicToggle] = useState(true);
  const [topicStatus, setTopicStatus] = useState(true);
  const [fileOptionsList, setfileOptionsList] = useState([]);
  const [formInitializedFlag, setFormInitializedFlag] = useState(null);

  const [initialValues, setInitialValues] = useState({});

  const [languageFiles, setLanguageFiles] = useState({});

  const [filesError, setFilesError] = useState({});

  const [confirmDialogVisible, setConfirmDialogVisible] = useState(false);

  const [formValue, setFormValue] = useState(null);

  const getDisplayTopicCount = (topicCount) => {
    return topicCount < 10 ? "0" + topicCount : topicCount;
  };

  if (!formInitializedFlag) {
    setFormInitializedFlag(true);
    let obj = {
      formAddTopicIDDummy_wizard: "",
      topicid: "",
      topicname: "",
      topicorder: 1,
      topicduration: 1,
      topictype: "topic",
      formTopicMediaTypeGroup: "FolderTopicType",
      topicfolder: "",
      topicversion: 1,
      topicStatus: true,
      topicmedia: "",
      formTopicMediaPickerSelect_wizard: undefined,
    };
    if (props.lessonFormData && props.topicCount) {
      obj.topicorder = props.topicCount;
      obj.formAddTopicIDDummy_wizard =
        "s01-" + getDisplayTopicCount(props.topicCount);
      obj.topicid =
        props.lessonFormData.formLessonId +
        "-" +
        obj.formAddTopicIDDummy_wizard;
      obj.topicfolder =
        props.lessonFormData.formLessonId +
        "-" +
        obj.formAddTopicIDDummy_wizard;
      let localLangFiles = {};
      if (props.lessonFormData.languageSelectField) {
        props.lessonFormData?.languageSelectField?.forEach((language) => {
          localLangFiles[language] = null;
          obj[`formAddTopicFileInputID${language.substring(0, 3)}_wizard`] = "";
        });
      }
      setLanguageFiles(localLangFiles);
    }
    if (props.editTopicData) {
      obj.topicorder = props.editTopicData.topicorder;
      obj.topicid = props.editTopicData?.topicid.replace("topicid-", "");
      // obj.formAddTopicIDDummy_wizard = 's01-' + getDisplayTopicCount(props.editTopicData.topicorder);
      obj.formAddTopicIDDummy_wizard = obj?.topicid.replace(
        `${props.lessonFormData.formLessonId}-`,
        ""
      );
      obj.topicname = props.editTopicData.topicname;
      obj.topicduration = props.editTopicData.topicduration;
      obj.formTopicMediaPickerSelect_wizard = props.editTopicData.topicmedia;
      obj.topicmedia = props.editTopicData.topicmedia;
      obj.topictype = props.editTopicData.topictype;
      obj.topicversion = props.editTopicData.topicversion
        ? props.editTopicData.topicversion
        : props.editTopicData.version;
      obj.topicfolder =
        props.editTopicData.topicfolder !== ""
          ? props.editTopicData.topicfolder
          : props.lessonFormData.formLessonId +
            "-" +
            obj.formAddTopicIDDummy_wizard;
      obj.topicStatus = props.editTopicData.status;
      setTopicStatus(props.editTopicData.status === "active" ? true : false);
    }
    setInitialValues(obj);
  }

  const handleFileChange = (e, language, formik) => {
    e.preventDefault();
    const input = e.currentTarget;
    const label = input.nextElementSibling;
    let localFilesVariable = { ...languageFiles, [language]: e.target.files };
    setLanguageFiles({ ...languageFiles, [language]: e.target.files });
    if (e.target.files && e.target.files.length) {
      if (folderTopicToggle) {
        label.textContent = e.target.files.length + " files selected";
      } else {
        label.textContent = e.target.files[0].name;
      }
      if (language === "English") {
        updateFieldValue("topicmedia", e.target.files[0].name, formik);
        let topicFilesList = [];
        for (let file of e.target.files) {
          let filename = "";
          if (file.webkitRelativePath && file.webkitRelativePath !== "") {
            filename = file.webkitRelativePath.substring(
              file.webkitRelativePath.indexOf("/") + 1
            );
          } else {
            filename = file.name;
          }
          if (formik.values.formTopicMediaTypeGroup == "FileTopicType") {
            filename = sanitizeFileName(filename);
            updateFieldValue("topicmedia", filename, formik);
          }
          topicFilesList.push(filename);
        }
        setfileOptionsList(topicFilesList);
        updateFieldValue(
          "formTopicMediaPickerSelect_wizard",
          e.target.value,
          formik,
          topicFilesList
        );
      } else {
        let topicmedia_file_value = formik.values.topicmedia;
        let uploadedFileListValue =
          formik.values.formTopicMediaPickerSelect_wizard;
        let uploadedFilesList = "";
        console.log(uploadedFileListValue, "uploadedFileListValue?");
        if (
          uploadedFileListValue &&
          uploadedFileListValue !== "" &&
          uploadedFileListValue.includes("\\")
        ) {
          uploadedFilesList = uploadedFileListValue.split("\\").pop();
        } else if (
          uploadedFileListValue &&
          uploadedFileListValue !== "" &&
          uploadedFileListValue.includes("/")
        ) {
          uploadedFilesList = uploadedFileListValue.split("/").pop();
        }
        let notMatchingFilesFlag = false;
        let notMatchingFilesFlag2 = false;
        props.lessonFormData?.languageSelectField?.forEach((value) => {
          let element = localFilesVariable[value];
          if (value !== "English" && element) {
            let foundCount = 0;
            if (uploadedFilesList !== "") {
              for (let file of element) {
                if (uploadedFilesList && uploadedFilesList === file.name) {
                  foundCount += 1;
                }
              }
              if (foundCount === 0 && element.length !== 0) {
                notMatchingFilesFlag = true;
              }
            } else if (topicmedia_file_value !== "") {
              for (let file of element) {
                if (
                  topicmedia_file_value &&
                  topicmedia_file_value === file.name
                ) {
                  foundCount += 1;
                }
              }
              if (foundCount === 0 && element.length !== 0) {
                notMatchingFilesFlag2 = true;
              }
            }
          }
        });
        if (notMatchingFilesFlag2 === true) {
          props.toast.current.show({
            severity: "info",
            summary: "Topic Media file",
            detail: `Topic Media file should be : ${topicmedia_file_value}`,
          });
        }
        if (notMatchingFilesFlag) {
          props.toast.current.show({
            severity: "info",
            summary: "File Names not matching for Topic",
            detail: `Uploaded File names should be same for all languages of single topic.`,
          });
        }
      }
    }
  };

  const updateFieldValue = (fieldName, newValue, formik, List) => {
    const updatedValue = List?.includes("story.html") ? "story.html" : newValue;
    formik.setFieldValue(fieldName, updatedValue);
  };

  const handleTopicMediaTypeChange = (value) => {
    setFolderTopicToggle(value);
    let localFilesVariable = {};
    document.querySelectorAll(".custom-file-label").forEach((element) => {
      element.textContent = value ? "Choose folder" : "Choose File";
    });
    document.querySelectorAll(".custom-file-input").forEach((element) => {
      element.value = "";
    });
    props.lessonFormData?.languageSelectField?.forEach((value) => {
      localFilesVariable[value] = null;
    });
    setLanguageFiles(localFilesVariable);
    setfileOptionsList([]);
  };

  const handleTopicIdChange = (e, formik) => {
    updateFieldValue(
      "topicfolder",
      props.lessonFormData.formLessonId + "-" + e.target.value,
      formik
    );
    updateFieldValue("formAddTopicIDDummy_wizard", e.target.value, formik);
    updateFieldValue(
      "topicid",
      props.lessonFormData.formLessonId + "-" + e.target.value,
      formik
    );
  };

  const validateForm = (values) => {
    const errors = {};
    if (props.topics) {
      const topicIds = props.topics.map((topic) =>
        topic?.topicid.replace("topicid-", "")
      );
      if (
        topicIds.includes(values?.topicid) &&
        values?.topicid !== props.editTopicData?.topicid.replace("topicid-", "")
      ) {
        errors.formAddTopicIDDummy_wizard =
          "TopicId should be unique. This TopicId already exists.";
      }
    }
    if (values.formAddTopicIDDummy_wizard === "") {
      errors.formAddTopicIDDummy_wizard = "TopicId is required.";
    }
    if (values.topicname === "") {
      errors.topicname = " Topic name is required.";
    }
    if (values.topicorder === "" || values.topicorder < 1) {
      errors.topicorder = "Topic Order is not valid.";
    }
    if (values.topicduration === "" || values.topicduration < 1) {
      errors.topicduration = "Topic duration is not valid.";
    }
    let localFilesError = {};
    props.lessonFormData?.languageSelectField?.forEach((value) => {
      let files = languageFiles[value];
      let language = value.substring(0, 3);
      if (!props.editTopicData && (!files || files.length === 0)) {
        errors[`formAddTopicFileInput${language}_wizard`] =
          "Topic Files are required.";
        localFilesError[`formAddTopicFileInput${language}_wizard`] =
          "Topic Files are required.";
      }
    });
    setFilesError(localFilesError);
    // console.log(errors)
    return errors;
  };

  function sanitizeFileName(fileName) {
    const forbiddenChars = /[<>?:;"'{}[\]|=+_\-\@#\$%\^&\*~`]/g;
    let folderPath = fileName.split("/");
    let sanitizedFileName = folderPath[folderPath.length - 1].replace(
      forbiddenChars,
      ""
    );
    sanitizedFileName = sanitizedFileName.replace(/\s/g, "");
    sanitizedFileName =
      folderPath.length > 1
        ? folderPath.slice(0, folderPath.length - 1).join("/") +
          "/" +
          sanitizedFileName
        : sanitizedFileName;
    return sanitizedFileName;
  }
  const handleSubmit = (values, { setSubmitting }) => {
    setIsSubmitting(false);

    if (props.submitDetect) {
      let topicObj = {};
      let topicFiles = [];
      var topicFilesOrg = [];
      for (let language of Object.keys(languageFiles)) {
        var tmpFileArray = [];
        var tmpFileArrayOrg = [];
        if (languageFiles[language] && languageFiles[language].length > 0) {
          var fileCount = 0;
          for (let file of languageFiles[language]) {
            if (file != undefined) {
              var filename =
                file.webkitRelativePath != ""
                  ? file.webkitRelativePath.substring(
                      file.webkitRelativePath.indexOf("/") + 1
                    )
                  : file.name;
              if (values.formTopicMediaTypeGroup == "FileTopicType") {
                filename = sanitizeFileName(filename);
              }
              if (filename != ".DS_Store") {
                const filePathArray = filename.split(/[\\/]/);
                const extractedFilename = filePathArray.pop();
                tmpFileArray.push({
                  filename: extractedFilename,
                  filetype: file.type,
                  fileOrder: fileCount,
                });
                tmpFileArrayOrg.push({
                  filename: extractedFilename,
                  filetype: file.type,
                  file: file,
                  fileOrder: fileCount,
                });
              }
              fileCount += 1;
            }
          }
          if (tmpFileArray.length > 0) {
            topicFiles.push({ language: language, files: tmpFileArray });
            topicFilesOrg.push({ language: language, files: tmpFileArrayOrg });
            // topicObj['topicfiles_' + language] = languageFiles[language]
          }
        }
      }

      topicObj["topicorder"] = values.topicorder;
      topicObj["lessonid"] = props.lessonFormData.formLessonId;
      topicObj["topicid"] = "topicid-" + values?.topicid;
      topicObj["topicname"] = values.topicname;
      topicObj["topicduration"] = values.topicduration;
      topicObj["topicmedia"] = values.topicmedia;
      topicObj["topictype"] = values.topictype;
      topicObj["topicversion"] = values.topicversion;
      topicObj["topicfolder"] = values.topicfolder;
      topicObj["status"] = topicStatus ? "active" : "inactive";
      topicObj["topicFiles"] = topicFiles;
      topicObj["topicFilesOrg"] = topicFilesOrg;
      // props.submitDetect("save", topicObj);
      // props.setVisible(false);
      setConfirmDialogVisible(true);
      setFormValue(topicObj);
    }
    setSubmitting(false);
  };

  return (
    <div>
      <Formik
        initialValues={initialValues}
        validate={validateForm}
        onSubmit={handleSubmit}
        enableReinitialize
      >
        {(formik) => (
          <Form>
            <div className="p-field mt-2">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="formAddTopicIDDummy_wizard">Topic ID</label>
                <Field
                  type="text"
                  id="formAddTopicIDDummy_wizard"
                  name="formAddTopicIDDummy_wizard"
                  as={InputText}
                  onChange={(e) => {
                    handleTopicIdChange(e, formik);
                  }}
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="formAddTopicIDDummy_wizard"
                component="div"
                className="p-error"
              />
            </div>

            <div
              className="p-field mt-2 d-none"
              id="formAddTopicIDGroup"
              hidden={props.editTopicData ? false : true}
            >
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="topicid">Old Topic ID</label>
                <Field
                  type="text"
                  as={InputText}
                  id="topicid"
                  name="topicid"
                  required
                  disabled
                  className={`form-control forminput ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="topicid"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-2">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="topicname">Topic Name</label>
                <Field
                  type="text"
                  id="topicname"
                  name="topicname"
                  as={InputText}
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="topicname"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-2">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="topicorder">Topic Order</label>
                <Field
                  type="text"
                  id="topicorder"
                  name="topicorder"
                  as={InputText}
                  required
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="topicorder"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-2">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="topicduration">Topic Duration</label>
                <Field
                  type="text"
                  id="topicduration"
                  name="topicduration"
                  as={InputText}
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="topicduration"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-2 d-none">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <Field
                  type="text"
                  id="topictype"
                  name="topictype"
                  as={InputText}
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
                <label htmlFor="topictype">Topic Type</label>
              </span>
              <ErrorMessage
                name="topictype"
                component="div"
                className="p-error"
              />
            </div>

            <div className="form-group mt-3">
              <label className="d-block">Topic Media Type</label>
              <div className="custom-control custom-control-inline custom-radio smi-green">
                <Field
                  type="radio"
                  name="formTopicMediaTypeGroup"
                  id="FolderTopicType"
                  value="FolderTopicType"
                  onClick={() => {
                    handleTopicMediaTypeChange(true);
                  }}
                  className="custom-control-input"
                />
                <label
                  className="custom-control-label"
                  htmlFor="FolderTopicType"
                >
                  Folder
                </label>
              </div>
              <div className="custom-control custom-control-inline custom-radio smi-green">
                <Field
                  type="radio"
                  name="formTopicMediaTypeGroup"
                  id="FileTopicType"
                  value="FileTopicType"
                  onClick={() => {
                    handleTopicMediaTypeChange(false);
                  }}
                  className="custom-control-input"
                />
                <label className="custom-control-label" htmlFor="FileTopicType">
                  Single File
                </label>
              </div>
              <br />
              <small id="topicFileTypeMessage" className="ml-1">
                Note: Topic media file name for all the languages should be the
                same.
              </small>

              {props.lessonFormData.languageSelectField &&
                props.lessonFormData.languageSelectField.map((language) => {
                  let langaugeFull = language;
                  language = language.substring(0, 3);
                  return (
                    <div
                      className="mt-3"
                      key={`divAddTopicFileInput${language}_wizard`}
                    >
                      <div
                        className="form-group"
                        id={`divAddTopicFileInput${language}_wizard`}
                      >
                        <label>
                          Upload Topic Files for {langaugeFull} <abbr>*</abbr>
                        </label>
                        <div className="custom-file">
                          <Field
                            type="file"
                            className="custom-file-input"
                            id={`formAddTopicFileInputID${language}_wizard`}
                            name={`formAddTopicFileInput${language}_wizard`}
                            onChange={(e) => {
                              handleFileChange(e, langaugeFull, formik);
                            }}
                            {...(folderTopicToggle
                              ? { webkitdirectory: "", mozdirectory: "" }
                              : {})}
                          />
                          <label
                            className="custom-file-label"
                            htmlFor={`formAddTopicFileInputID${language}_wizard`}
                          >
                            {folderTopicToggle
                              ? "Choose folder"
                              : "Choose File"}
                          </label>
                        </div>
                        {/* <ErrorMessage
                                            name={`formAddTopicFileInput${language}_wizard`}
                                            component="div"
                                            className="p-error"
                                        /> */}
                        {!props.editTopicData &&
                        isSubmitting &&
                        filesError[
                          `formAddTopicFileInput${language}_wizard`
                        ] ? (
                          <div className="p-error">
                            Topic Files are required
                          </div>
                        ) : (
                          <div></div>
                        )}
                      </div>
                      {langaugeFull === "English" &&
                      fileOptionsList.length > 0 ? (
                        <div id="formTopicMediaPicker" className="d-block">
                          <div className="form-group">
                            <label htmlFor="formTopicMediaPickerSelect_wizard">
                              Topic Media File<abbr>*</abbr>
                            </label>
                            <Field
                              as="select"
                              initialValue={
                                fileOptionsList.includes("story.html")
                                  ? "story.html"
                                  : ""
                              }
                              className="custom-select form-control"
                              name="formTopicMediaPickerSelect_wizard"
                              id="formTopicMediaPickerSelect_wizard"
                              onChange={(e) => {
                                updateFieldValue(
                                  "topicmedia",
                                  e.target.value,
                                  formik
                                );
                                updateFieldValue(
                                  "formTopicMediaPickerSelect_wizard",
                                  e.target.value,
                                  formik
                                );
                              }}
                              required
                            >
                              {fileOptionsList.map((file, index) => {
                                return (
                                  <option
                                    key={`topicMediaPickerFilesOption_${index}`}
                                    value={file}
                                  >
                                    {file}
                                  </option>
                                );
                              })}
                            </Field>
                            <ErrorMessage
                              name="formTopicMediaPickerSelect_wizard"
                              component="div"
                              className="p-error"
                            />
                          </div>
                        </div>
                      ) : (
                        <div></div>
                      )}
                    </div>
                  );
                })}
            </div>

            <div className="p-field mt-3">
              <label htmlFor="topicfolder">Topic Media Folder</label>
              <Field
                type="text"
                id="topicfolder"
                name="topicfolder"
                as={InputText}
                className={`form-control ${
                  formik.isSubmitting ? "p-disabled" : ""
                }`}
              />

              <ErrorMessage
                name="topicfolder"
                component="div"
                className="p-error"
              />
            </div>

            <div
              className={`form-group ${
                !props.editTopicData ? "d-none" : "mt-3"
              }`}
              id="formAddTopicMedia_wizardDiv"
            >
              <label htmlFor="topicmedia">
                Topic Media File (e.g. story.html)
              </label>
              <Field
                className="form-control"
                type="text"
                id="topicmedia"
                name="topicmedia"
                required
                disabled
              />
              <ErrorMessage
                name="topicmedia"
                component="div"
                className="invalid-feedback"
              >
                Topic Media is required.
              </ErrorMessage>
            </div>

            <div className="p-field mt-2">
              <span className={` ${formik.isSubmitting ? "p-disabled" : ""}`}>
                <label htmlFor="topicversion">Topic Version</label>
                <Field
                  type="text"
                  id="topicversion"
                  name="topicversion"
                  as={InputText}
                  className={`form-control ${
                    formik.isSubmitting ? "p-disabled" : ""
                  }`}
                />
              </span>
              <ErrorMessage
                name="topicversion"
                component="div"
                className="p-error"
              />
            </div>

            <div className="mt-3 custom-control-inline w-100">
              <div>Topic Status</div>
              <div className="d-flex justify-content-center align-items-center ml-4">
                <div>
                  <span className="d-none"></span>
                  <div className="d-flex requiredCheckbox">
                    <label
                      className={`switcher-control ${
                        topicStatus ? "switcher-control-success" : ""
                      }`}
                    >
                      <input
                        type="checkbox"
                        className="switcher-input StatusCheckBox"
                        name="topicStatus"
                        checked={topicStatus ? true : false}
                        onChange={() => {
                          setTopicStatus(!topicStatus);
                        }}
                      />
                      <span className="switcher-indicator"></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              label={`Save`}
              onClick={() => {
                setIsSubmitting(true);
              }}
              style={{
                background: "#4d4d4d",
                textAlign: "left",
                padding: "6px 12px",
                borderRadius: "0.25rem",
                fontStyle: "inherit",
                border: "none",
              }}
              disabled={formik.isSubmitting}
              className={`btn btn-primary float-right wizardtopicbtn ${
                formik.isSubmitting ? "disabled" : ""
              } mt-4 mb-2 float-right`}
            />
          </Form>
        )}
      </Formik>
      <LessonConfirmDialog
        modalTitle={"Confirm the changes"}
        confirmDialogVisible={confirmDialogVisible}
        setConfirmDialogVisible={setConfirmDialogVisible}
        submitDetect={(value) => {
          if (value === "confirm") {
            props.submitDetect("save", formValue);
            props.setVisible(false);
          }
        }}
      />
    </div>
  );
};
export default TopicForm;
