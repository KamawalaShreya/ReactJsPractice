import React, { useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Header from "../Header/Header";
import { Card, Container, Row } from "react-bootstrap";
import { useRef } from "react";
import { useState } from "react";
import config from "../../config/config.json";
import axios from "axios";
import { get, post } from "../../utils/HttpRequest";
import { Toast } from "primereact/toast";
import { Steps } from "primereact/steps";
import LessonDetailsForm from "./LessonDetailsForm";
import AdditionalLessonDetailsForm from "./AdditionalLessonDetailsForm";
import TopicsPage from "./TopicsPage";
import LessonConfirmDialog from "./LessonConfirmDialog";

const Lessonwizard = () => {
  const toast = useRef(null);
  const [searchParams] = useSearchParams();

  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const items = [
    {
      label: "Lesson Details",
    },
    {
      label: "Additional lesson details",
    },
    {
      label: "Topics",
    },
  ];
  const [stepperItems, setStepperItems] = useState(items);
  const [lessonFormData, setLessonFormData] = useState(null);
 
  const [oldLessonFormData, setOldLessonFormData] = useState(null);
  const [uiLoadFlag, setUiLoadFlag] = useState(false);
  // const [addLessonFormData, setAddLessonFormData] = useState(null);
  const [lessonIds, setLessonIds] = useState([]);

  const [confirmDialogVisible, setConfirmDialogVisible] = useState(false);
  const [editFlag, setEditFlag] = useState(null);
  const [topics, setTopics] = useState([]);
 

  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");
  const navigate = useNavigate();
  const lessonWizardReload = localStorage.getItem("lessonWizardReload");

  useEffect(() => {
    let url = config.api.url + "getLessons";
    let getLessonUrl =
      config.api.url + "getLessonandTopics/" + lessonid + "/all?edit=true";
    get(url)
      .then((response) => {
        setLessonIds(
          response.data
            .map((value) => {
              if (value.status != "review") {
                if (lessonid && lessonid === value.lessonid) {
                  return;
                }
                return { label: value.lessonid, value: value.lessonid };
              }
            })
            .filter((x) => x) 
        );
        if (lessonid) {
          setEditFlag(true);
          get(getLessonUrl)
            .then((result) => {
              let lessonData = result.data.lessondetails;
              let lessonObj = {
                formLessonId: lessonData.lessonid,
                formLessonType: lessonData.lessontype,
                formVersion: lessonData.version
                  ? lessonData.version
                  : lessonData.lessonversion
                  ? lessonData.lessonversion
                  : 1,
                formLessonName: lessonData.lessonname,
                formLessonDescription: lessonData.lessondescription,
                formLessonUrl: lessonData.lessonurl,
                formLessonStatus: lessonData.status === "active" ? true : false,
                formAcknowledgementRequired:
                  lessonData.acknowledgementRequired === "yes" ? true : false,
                nestedlessonList: [],
                lessoncardheader: lessonData.lessoncardheader
                  ? lessonData.lessoncardheader
                  : "",
                lessoncardfooter: lessonData.lessoncardfooter
                  ? lessonData.lessoncardfooter
                  : "",
                lessoncardtype: lessonData.lessoncardtype
                  ? lessonData.lessoncardtype
                  : "",
                lessoncarddescription: lessonData.lessoncarddescription
                  ? lessonData.lessoncarddescription
                  : "",
              };
              if (lessonData.lessontype === "nestedcard") {
                lessonObj["nestedlessonList"] =
                  lessonData.childlessonids && lessonData.childlessonids !== ""
                    ? lessonData.childlessonids.split(",")
                    : [];
              }
              if (
                lessonData.lessonlanguages &&
                lessonData.lessonlanguages !== ""
              ) {
                lessonObj["languageSelectField"] = lessonData.lessonlanguages
                  .split(",")
                  .map((x) => x.trim());
              }
              let allLessonLanguages = [];
              get(config.api.url + "getTrialConfig/lessonLanguages").then(
                (langResult) => {
                  let languages = JSON.parse(langResult.data.value);
                  languages.map((o) => {
                    allLessonLanguages.push({
                      label: o.languageName,
                      value: o.languageName,
                    });
                  });
                }
              );
              lessonObj["allLessonLanguages"] = allLessonLanguages;
              setLessonFormData(lessonObj);
              setOldLessonFormData(lessonObj);
              setTopics(result.data.topics);
              setUiLoadFlag(true);
            })
            .catch((err) => {
              console.log("Error getting lesson data", err);
            });
        }
      })
      .catch((err) => {
        console.log("Error ", err);
      });

    if (!lessonid) {
      let allLessonLanguages = [];
      get(config.api.url + "getTrialConfig/lessonLanguages").then(
        (langResult) => {
          let languages = JSON.parse(langResult.data.value);
          languages.map((o) => {
            allLessonLanguages.push({
              label: o.languageName,
              value: o.languageName,
            });
          });
        }
      );
      setUiLoadFlag(true);
      setEditFlag(false);
      setActiveStepIndex(0);
      setLessonFormData({
        formLessonId: "",
        formLessonType: "regularlesson",
        formVersion: 1,
        formLessonName: "",
        formLessonDescription: "",
        formLessonUrl: "",
        allLessonLanguages: allLessonLanguages,
      });
      setTopics([]);
    }
    if (lessonWizardReload) {
      localStorage.removeItem("lessonWizardReload");
    }
  }, [searchParams, lessonid, lessonWizardReload]);

  const createLessonSubmitMethod = (lessonObject, lessonFormData) => {
    const s3UploadInstance = axios.create();
    var jsonFormData = JSON.stringify(lessonObject);
    var url = config.api.url + "createLesson";

    if (
      lessonObject.givenLessonType === "regularlesson" ||
      lessonObject.givenLessonType === "survey" ||
      lessonObject.givenLessonType === "assessment"
    ) {
      toast.current.show({
        severity: "success",
        summary: "Lesson update",
        detail: "Lesson Created Successfully",
      });
      setActiveStepIndex(2);
    }

    // Create lesson Method here
    post(url, jsonFormData)
      .then(async (response) => {
        let createLessonResponse = response.data;
        const uploadPromises = [];
        var dataurltofilefunc;
        if (
          createLessonResponse.lessonImageUrl !== undefined &&
          createLessonResponse.lessonImageUrl !== null
        ) {
          dataurltofilefunc = function dataURLtoFile(dataurl, filename) {
            var arr = dataurl.split(","),
              mime = arr[0].match(/:(.*?);/)[1],
              bstr = atob(arr[1]),
              n = bstr.length,
              u8arr = new Uint8Array(n);
            while (n--) {
              u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
          };
          var resizedfile = dataurltofilefunc(
            lessonFormData.previewLessonImage,
            lessonFormData.lessonImageFile.name
          );
          const headers = {
            "Content-Type": resizedfile.type,
          };

          // Uploading preview / thumbnail lesson image here
          uploadPromises.push(
            s3UploadInstance
              .put(createLessonResponse.lessonImageUrl, resizedfile, {
                headers,
              })
              .then((result) => {
                let uploadFileData = result.data;
                var newFileUrl = uploadFileData.split("?")[0].substr(6);
                console.info("s3-upload done: ", newFileUrl);
              })
              .catch((err) => {
                console.log("Error in uploading preview image ", err);
              })
          );
        }
        if (
          createLessonResponse.lessonImageUrlOrig !== undefined &&
          createLessonResponse.lessonImageUrlOrig !== null
        ) {
          const headers = {
            "Content-Type": resizedfile.type,
          };

          // Uploading original lesson image here
          uploadPromises.push(
            s3UploadInstance
              .put(
                createLessonResponse.lessonImageUrlOrig,
                lessonFormData.lessonImageFile,
                { headers }
              )
              .then((result) => {
                let uploadFileData = result.data;
                var newFileUrl = uploadFileData.split("?")[0].substr(6);
                console.info("s3-upload done: ", newFileUrl);
              })
              .catch((err) => {
                console.log("Error in uploading original image ", err);
              })
          );
        }

        // let uploadRequests = uploadPromises
        //   ? await Promise.all(uploadPromises)
        //   : null;
        if (
          lessonObject.givenLessonType !== "regularlesson" &&
          lessonObject.givenLessonType !== "survey" &&
          lessonObject.givenLessonType !== "assessment"
        ) {
          toast.current.show({
            severity: "success",
            summary: "Lesson update",
            detail: "Lesson Created Successfully",
          });
          setTimeout(() => {
            navigate(`/lessonreviewmanager`);
          }, 2000);
        }
      })
      .catch((err) => {
        console.log("Error calling createlesson ", err);
      });
  };

  const generateLessonObject = (lessonFormData) => {
    var lessonObject = {
      givenLessonid: lessonFormData.formLessonId,
      givenVersion: lessonFormData.formVersion,
      givenLessonname: lessonFormData.formLessonName,
      givenLessondescription: lessonFormData.formLessonDescription,
      givenLessonurl: lessonFormData.formLessonUrl,
      givenLessonType: lessonFormData.formLessonType,
      givenLessonStatus: lessonFormData.formLessonStatus,
      givenAcknowledgement: lessonFormData.formAcknowledgementRequired
        ? "yes"
        : "no",
      givenLessonlanguages: lessonFormData?.languageSelectField?.join(", "),
      editLanguagesOld: oldLessonFormData?.lessonlanguages,
      lessoncardheader: lessonFormData.lessoncardheader,
      lessoncardfooter: lessonFormData.lessoncardfooter,
      lessoncardtype: lessonFormData.lessoncardtype,
      lessoncarddescription: lessonFormData.lessoncarddescription,
    };
    if (lessonObject.givenLessonType === "nestedcard") {
      lessonObject["editLanguagesOld"] = "";
      lessonObject["givenLessonlanguages"] = "";
      lessonObject["childlessonids"] =
        lessonFormData.nestedlessonList.join(",");
    }

    if (
      lessonFormData.lessonImageFile !== undefined &&
      lessonFormData.lessonImageFile !== null
    ) {
      var imgname = lessonFormData.lessonImageFile.name;
      var ext = imgname.substr(imgname.lastIndexOf(".") + 1);
      lessonObject["image"] = null;
      lessonObject["imagetype"] = ext;
    } else {
      lessonObject["image"] = null;
      lessonObject["imagetype"] = null;
    }
    lessonObject["lessonImage"] = lessonObject["imagetype"]
      ? lessonObject.givenLessonid + "." + lessonObject["imagetype"]
      : null;
  
    return lessonObject;
  };

  const updateLessonInServer = (formObject) => {
    // navigating to Topics page (3rd page)
    if (
      formObject.formLessonType === "regularlesson" ||
      formObject.formLessonType === "survey" ||
      formObject.formLessonType === "assessment"
    ) {
      setActiveStepIndex(2);
    } // else {
    // toast.current.show({ severity: 'info', summary: 'Lesson update', detail: "Lesson Updated Successfully" });
    // }

    var url = config.api.url + "updateAsset?all=true";

    var ext = null;
    var updateImage = "false";
    if (formObject.lessonImageFile) {
      updateImage = "true";
      var imgname = formObject.lessonImageFile.name;
      ext = imgname.substr(imgname.lastIndexOf(".") + 1);
    }
    var bodyObj = {
      givenLessonname: formObject.formLessonName,
      givenVersion: formObject.formVersion,
      givenLessondescription: formObject.formLessonDescription,
      lessonid: formObject.formLessonId,
      topicid: "lessonid-" + formObject.formLessonId,
      givenLessonType: formObject.formLessonType,
      givenAcknowledgement: formObject.formAcknowledgementRequired
        ? "yes"
        : "no",
      givenLessonStatus: formObject.formLessonStatus ? "active" : "inactive",
      givenLessonlanguages: formObject.languageSelectField.join(", "),
      givenLessonurl: formObject.formLessonUrl,
      updateImage: updateImage,
      languagesOld: formObject.languageSelectField.join(", "),
      imagetype: ext,
      lessoncardheader: lessonFormData.lessoncardheader,
      lessoncardfooter: lessonFormData.lessoncardfooter,
      lessoncardtype: lessonFormData.lessoncardtype,
      lessoncarddescription: lessonFormData.lessoncarddescription,
    };
    if (formObject.formLessonType === "nestedcard") {
      bodyObj["languagesOld"] = "";
      bodyObj["givenLessonlanguages"] = "";
      bodyObj["childlessonids"] = formObject.nestedlessonList.join(",");
    }
    if (
      formObject.formLessonType === "survey" ||
      formObject.formLessonType === "assessment"
    ) {
      bodyObj["languagesOld"] = bodyObj["givenLessonlanguages"];
    }
    if (["externallink", "nestedcard"].includes(formObject.formLessonType)) {
      bodyObj["languagesOld"] = bodyObj["givenLessonlanguages"];
    }
    if (
      formObject.formLessonType === "regularlesson" ||
      formObject.formLessonType === "assessment"
    ) {
      bodyObj["lessonRetakeConfiguration"] =
        formObject.lessonRetakeConfiguration;
    }
   

    const s3UploadInstance = axios.create();

    post(url, JSON.stringify(bodyObj))
      .then((result) => {
        let topicData = JSON.parse(result.data);
        var dataURLtoFilefunctionCall;
        if (topicData.signedURL != null) {
          dataURLtoFilefunctionCall = function dataURLtoFile(
            dataurl,
            filename
          ) {
            var arr = dataurl.split(","),
              mime = arr[0].match(/:(.*?);/)[1],
              bstr = atob(arr[1]),
              n = bstr.length,
              u8arr = new Uint8Array(n);
            while (n--) {
              u8arr[n] = bstr.charCodeAt(n);
            }
            return new File([u8arr], filename, { type: mime });
          };
          var resizedfile = dataURLtoFilefunctionCall(
            formObject.previewLessonImage,
            formObject.lessonImageFile.name
          );
          const headers = {
            "Content-Type": resizedfile.type,
          };

          // Uploading preview / thumbnail lesson image here
          s3UploadInstance
            .put(topicData.signedURL, resizedfile, { headers })
            .then((result) => {
              let uploadFileData = result.data;
              var newFileUrl = uploadFileData.split("?")[0].substr(6);
              console.info("s3-upload done: ", newFileUrl);
            })
            .catch((err) => {
              console.log("Error in uploading preview image ", err);
            });
        }

        if (topicData.signedURLOrig != null) {
          const headers = {
            "Content-Type": resizedfile.type,
          };
          // Uploading original lesson image here
          s3UploadInstance
            .put(topicData.signedURLOrig, formObject.lessonImageFile, {
              headers,
            })
            .then((result) => {
              let uploadFileData = result.data;
              var newFileUrl = uploadFileData.split("?")[0].substr(6);
              console.info("s3-upload done: ", newFileUrl);
            })
            .catch((err) => {
              console.log("Error in uploading original image ", err);
            });
        }

        toast.current.show({
          severity: "success",
          summary: "Lesson update",
          detail: "Lesson Updated Successfully",
        });
        if (
          formObject.formLessonType === "externallink" ||
          formObject.formLessonType === "nestedcard"
        ) {
          navigate("/lessonreviewmanager");
        }
      })
      .catch((err) => {
        console.log("Error updating lesson data", err);
      });
  };

  return (
    <div className="lessonWizardPage app">
      <Toast ref={toast}></Toast>
      <Header />
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card className="mt-3 ml-2 mr-2" style={{ width: "100%" }}>
            <Card.Body>
              <div className="card-title ml-2" style={{ textAlign: "Left" }}>
                New Lesson
              </div>
              <Row>
                <Container className="w-100">
                  {/* make it readonly at last */}
                  <Steps
                    model={stepperItems}
                    activeIndex={activeStepIndex}
                    onSelect={(e) => setActiveStepIndex(e.index)}
                    readOnly={true}
                    className="steps-lesson"
                  />
                </Container>
              </Row>
              <Row className={uiLoadFlag ? "" : "d-none"}>
                {activeStepIndex === 0 ? (
                  <Container
                    className="my-4 "
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      width: "100%",
                      position: "relative",
                    }}
                  >
                    <div
                      id="StepsContainer"
                      className="w-100"
                      style={{ paddingBottom: "40px" }}
                    >
                      <LessonDetailsForm
                        editFlag={editFlag}
                        initialValues={lessonFormData}
                        lessonIds={lessonIds}
                        setLessonFormData={setLessonFormData}
                        lessonTypeChangeDetector={(lessontype) => {
                          let obj = lessonFormData;
                          if (
                            !["regularlesson", "survey", "assessment"].includes(
                              lessontype
                            )
                          ) {
                            setStepperItems(
                              items.filter((x) => x.label !== "Topics")
                            );
                            if (lessontype === "nestedcard") {
                              obj["formLessonUrl"] = "";
                            } else if (lessontype === "externallink") {
                              obj["nestedlessonList"] = [];
                            }
                            setLessonFormData(obj);
                          } else {
                            obj["nestedlessonList"] = [];
                            obj["formLessonUrl"] = "";
                            setLessonFormData(obj);
                            setStepperItems(items);
                          }
                        }}
                        submitDetect={(eventValue, formData) => {
                          // console.log("SubmitEvent Detected", eventValue, formData);
                          setLessonFormData(formData);
                          setActiveStepIndex(1);
                        }}
                        toast={toast}
                      />
                    </div>
                  </Container>
                ) : activeStepIndex === 1 ? (
                  <Container
                    className="mt-4 "
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      width: "100%",
                    }}
                  >
                    <div id="StepsContainer" className="w-100">
                      <AdditionalLessonDetailsForm
                        editFlag={editFlag}
                        lessonFormData={lessonFormData}
                        setLessonFormData={setLessonFormData}
                        submitDetect={(eventValue, formData) => {
                          
                          setLessonFormData(formData);
                          if (eventValue && eventValue === "next") {
                            let lessonObj = generateLessonObject(formData);
                            if (editFlag === false) {
                              if (
                                formData.formLessonType === "externallink" ||
                                formData.formLessonType === "nestedcard"
                              ) {
                                setConfirmDialogVisible(true);
                              } else {
                                createLessonSubmitMethod(lessonObj, formData);
                              }
                            } else {
                              // This will trigger the confirmation dialog
                              setConfirmDialogVisible(true);
                            }
                          } else if (eventValue && eventValue === "previous") {
                            setActiveStepIndex(0);
                          }
                        }}
                        toast={toast}
                      />
                    </div>
                  </Container>
                ) : activeStepIndex === 2 ? (
                  <Container
                    className="mt-4 "
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      width: "100%",
                    }}
                  >
                    <div id="StepsContainer" className="w-75">
                      <TopicsPage
                        editFlag={editFlag}
                        lessonFormData={lessonFormData}
                        setLessonFormData={setLessonFormData}
                        topics={topics}
                        toast={toast}
                        setActiveStepIndex={setActiveStepIndex}
                      />
                    </div>
                  </Container>
                ) : (
                  <div></div>
                )}
              </Row>
            </Card.Body>
          </Card>
        </Row>
      </Container>
      <LessonConfirmDialog
        modalSubTitle={
          editFlag === true
            ? "Note: Removing a language will remove any associated topics and they are not recoverable."
            : " "
        }
        confirmDialogVisible={confirmDialogVisible}
        setConfirmDialogVisible={setConfirmDialogVisible}
        submitDetect={(value) => {
          
          if (value === "confirm") {
            if (editFlag === true) {
              let lessonObj = generateLessonObject(lessonFormData);
              
              updateLessonInServer(lessonFormData);
            } else {
              let lessonObj = generateLessonObject(lessonFormData);
              createLessonSubmitMethod(lessonObj, lessonFormData);
            }
          }
        }}
      />
    </div>
  );
};
export default Lessonwizard;
