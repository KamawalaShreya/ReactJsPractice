import React, { useState, useEffect } from "react";
import axios from "axios";
import config from "../../../config/config.json";
import { Chart } from "primereact/chart";
import Header from "../../Header/Header";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Row } from "react-bootstrap";
import { useRef } from "react";
import { get, post } from "../../../utils/HttpRequest";

const Sitereports = () => {
  const toast = useRef(null);

  const search = window.location.search;
  const params = new URLSearchParams(search);
  const siteid = params.get("siteid");

  const s3FetchInstance = axios.create();

  const [siteData, setSiteData] = useState({});
  const [siteReportData, setSiteReportData] = useState(null);

  const [barChartData, setBarChartData] = useState({});
  const [barChartOptions, setBarChartOptions] = useState({});

  const [pieChartData, setPieChartData] = useState({});
  const [pieChartOptions, setPieChartOptions] = useState({});

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  useEffect(() => {
    function displaySiteReportData(lessonCompletionDataJSON) {
      // console.log('lessonCompletionDataJSON', lessonCompletionDataJSON)
      s3FetchInstance
        .get(lessonCompletionDataJSON.s3url)
        .then((lessonCompletionDataResponse) => {
          let lessonCompletionData = lessonCompletionDataResponse.data;
          setSiteReportData(lessonCompletionData);
          var xdata = [];
          var percentcompletedData = [];
          var percentincompleteData = [];
          var percentcompletedPieData = 0;
          var percentincompletePieData = 0;
          // console.log(lessonCompletionData)
          lessonCompletionData.summary.forEach((o, i) => {
            xdata[i] = o.name;
            percentcompletedData[i] = o.percentagecompleted.toFixed(2);
            percentincompleteData[i] = o.percentageincomplete.toFixed(2);
          });
          let lessonTotCount = 0;
          let lessonComCount = 0;
          let lessonIncomCount = 0;
          lessonCompletionData.summary.forEach((o) => {
            lessonTotCount += o.requiredLessonCount;
            lessonComCount += Math.round(
              (o.percentagecompleted * o.requiredLessonCount) / 100
            );
            lessonIncomCount += Math.round(
              (o.percentageincomplete * o.requiredLessonCount) / 100
            );
          });
          // console.log(lessonTotCount)
          // console.log(lessonIncomCount)
        
          percentincompletePieData = Math.round(
            (lessonIncomCount * 100) / lessonTotCount
          );
          percentcompletedPieData = 100 - percentincompletePieData;

          const bardata = {
            labels: xdata,
            datasets: [
              {
                type: "bar",
                label: "Completed",
                backgroundColor: window.chartColors.green,
                stack: "Stack 0",
                data: percentcompletedData,
                borderColor: "white",
                borderWidth: 2,
                maxBarThickness: 40,
              },
              {
                type: "bar",
                label: "Incomplete",
                backgroundColor: window.chartColors.red,
                stack: "Stack 0",
                data: percentincompleteData,
                borderColor: "white",
                borderWidth: 2,
                maxBarThickness: 40,
              },
            ],
          };
          const baroptions = {
            responsive: true,
            plugins: {
              title: {
                display: false,
                text: "Lesson Completion for all users.",
              },
              legend: {
                onClick: null,
                display: true,
                position: "right",
                labels: {
                  fontColor: "rgb(255, 99, 132)",
                },
              },
              tooltips: {
                mode: "index",
                intersect: true,
                callbacks: {
                  title: function (tooltipItems, data) {
                    var idx = tooltipItems[0].index;
                    return "Title:" + data.labels[idx]; //do something with title
                  },
                },
              },
            },
            scales: {
              x: {
                stacked: true,
                ticks: {
                  autoSkip: false,
                  maxRotation: 45,
                  minRotation: 45,
                  callback: function (value) {
                    if (xdata[value].length > 15) {
                      return xdata[value].substr(0, 15) + "..."; //truncate
                    } else {
                      return xdata[value];
                    }
                  },
                },
              },
              y: {
                ticks: {
                  max: 100,
                  min: 0,
                },
              },
            },
          };
          setBarChartData(bardata);
          setBarChartOptions(baroptions);

          const data = {
            datasets: [
              {
                data: [percentcompletedPieData, percentincompletePieData],
                backgroundColor: [
                  window.chartColors.green,
                  window.chartColors.red,
                ],
                label: "Dataset 1",
              },
            ],
            labels: ["Completed", "Incomplete"],
          };
          const options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: false,
                text: "",
              },
              legend: {
                onClick: null,
                display: true,
                position: "bottom",
                labels: {
                  fontColor: "rgb(255, 99, 132)",
                },
              },
              tooltips: {
                mode: "index",
                intersect: true,
              },
            },
          };
          setPieChartData(data);
          setPieChartOptions(options);
        });
    }

    function CheckSiteReportFile(fileName) {
      var url = config.api.url + "runCheckReportFile";
      post(url, JSON.stringify({ fileName: fileName }))
        .then((reportStatusData) => {
          displaySiteReportData(reportStatusData.data);
        })
        .catch(async () => {
          await new Promise((r) => setTimeout(r, 30000));
          CheckSiteReportFile(fileName);
        });
    }

    // get site info
    let siteInfoUrl = config.api.url + "getOneSite/" + siteid;
    var fileName = Date.now().toString();
    let siteDataUrl =
      config.api.url +
      "getLessonsCompletionDetailsBySite/" +
      siteid +
      "?fileName=" +
      fileName;
    get(siteInfoUrl).then((response) => {
      setSiteData(response.data);
    });

    get(siteDataUrl)
      .then((lessonCompletionData) => {
        console.log(
          "displayLessonCompletionDetailsForSite:- " +
            JSON.stringify(lessonCompletionData)
        );
        CheckSiteReportFile(fileName);
      })
      .catch(() => {
        CheckSiteReportFile(fileName);
      });
  }, []);

  return (
    <div className="siteManagerPage app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          {/* <div className="page-inner" style={{ width: '100%' }}> */}
          <Card style={{ width: "100%" }}>
            {siteReportData ? (
              <Card.Body className="bar-chart" style={{ width: "100%" }}>
                <h6 className="card-title float-left ml-2">
                  {siteData ? (
                    <div>
                      <span id="siteReportName">
                        Site Completion Report for {siteData.sitename}{" "}
                      </span>
                      <span id="siteReportUserCount">
                        : {siteReportData ? siteReportData.userCount : ""} Total
                        Users
                      </span>
                    </div>
                  ) : (
                    ""
                  )}
                </h6>
                <Row style={{ width: "100%" }} className="ml-2 mt-2">
                  <Col xl={8} md={8} lg={8} sm={6}>
                    <div className="piechartheight">
                      <span className="d-block float-left mb-3">
                        Status by Required Lesson
                      </span>
                      <Chart
                        type="bar"
                        className="ml-2"
                        data={barChartData}
                        options={barChartOptions}
                      />
                    </div>
                  </Col>

                  <Col xl={4} md={4} lg={4} sm={6}>
                    <div className="pieChart">
                      <span className="d-flex justify-content-center mb-4">
                        Required Curriculum Completion
                      </span>
                      <Chart
                        type="pie"
                        className="ml-2"
                        data={pieChartData}
                        options={pieChartOptions}
                      />
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            ) : (
              <Card.Body style={{ width: "100%", height: "450px" }}>
                <Row className="p-3" style={{ width: "100%" }}>
                  <h6 className="card-title">
                    {" "}
                    Site report data is being processed. It will take some time.
                  </h6>
                </Row>
                <Row className="p-3" style={{ width: "100%" }}>
                  <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                    <i
                      className="pi pi-spin pi-spinner"
                      style={{ fontSize: "3rem" }}
                    ></i>
                  </Col>
                </Row>
              </Card.Body>
            )}
          </Card>
          {/* </div> */}
        </Row>
      </Container>
    </div>
  );
};
export default Sitereports;
