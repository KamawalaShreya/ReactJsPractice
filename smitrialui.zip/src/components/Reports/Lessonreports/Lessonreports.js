import React, { useEffect, useRef, useState } from "react";
import Header from "../../Header/Header";
import Chart from "chart.js/auto";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import TrainingRecord from "./TrainingRecordSub";
import "./Lessonreports.css";
import Footerview from "../../Footer/Footer";
import axios from "axios";

const Lessonreports = ({ flag }) => {
  const pieChartRef = useRef(null);
  const barChartRef = useRef(null);

  // const [fileName, setFileName] = useState("");
  const [data, setData] = useState("");
  const [xdata, setXData] = useState([]);
  const [percentcompletedData, setPercentcompletedData] = useState([]);
  const [percentincompleteData, setPercentincompleteData] = useState([]);
  const [percentcompletedPieData, setPercentcompletedPieData] = useState(0);
  // console.log(percentcompletedPieData);
  const [percentincompletePieData, setPercentincompletePieData] = useState(0);
  // console.log(percentincompletePieData);

  const [isLoading, setIsLoading] = useState(true);
  const [selectedLabel, setSelectedLabel] = useState("");
  // console.log(selectedLabel);
  const [selectedBar, setSelectedBar] = useState("");

  const CheckReportFile = (fileName, flag) => {
    var url = config.api.url + "runCheckReportFile";
    post(url, JSON.stringify({ fileName: fileName }))
      .then(async (reportStatusData) => {
        if (reportStatusData && reportStatusData.status && reportStatusData.status === 200) {
          displayLessonCompletionReport(reportStatusData.data, flag);
        } else {
          await new Promise((r) => setTimeout(r, 30000));
          CheckReportFile(fileName, flag);
        }
      })
      .catch(async (error) => {
        console.log('error', error)
        await new Promise((r) => setTimeout(r, 30000));
        CheckReportFile(fileName, flag);
      });
  }

  const displayLessonCompletionReport = async (reportData, flag) => {
    try {
      const s3FetchInstance = axios.create();
      s3FetchInstance.get(reportData.s3url).then((reportData) => {
        let response = reportData.data;
        if (response) {
          response = {
            ...response,
            details: response?.details?.map((item, index) => {
              const tempLessonData = {};

              item.lessondata.forEach((detail) => {
                const lessonId = detail.lI;
                const lPValue = detail.lP;

                tempLessonData[lessonId] = lPValue;
              });
              return {
                ...item,
                id: index + 1,
                status:
                  item.status === "enabled" || item.status === undefined
                    ? "Enabled"
                    : "Disabled",
                siteName:
                  typeof item.siteName === "undefined"
                    ? "No site assigned"
                    : item.siteName,
                ...tempLessonData,
              };
            }),
          };
          const tempXdata = [...xdata];
          const tempPercentcompletedData = [...percentcompletedData];
          const tempPercentincompleteData = [...percentincompleteData];
          let tempPercentcompletedPieData = percentcompletedPieData;
          let tempPercentincompletePieData = percentincompletePieData;

          if (flag === false) {
            let xdataCount = 0;
            response.summary.forEach((summaryData) => {
              if (summaryData.requiredCount > 0) {
                tempXdata[xdataCount] = summaryData.name;
                tempPercentincompleteData[xdataCount] = Math.round(
                  (summaryData.incomplete2 / summaryData.requiredCount) * 100
                );
                tempPercentcompletedData[xdataCount] =
                  100 - tempPercentincompleteData[xdataCount];
                xdataCount++;
              }
            });

            tempXdata?.map((item, index) => {
              tempPercentcompletedPieData += tempPercentcompletedData[index];
              tempPercentincompletePieData += tempPercentincompleteData[index];
              return item;
            });

            tempPercentincompletePieData = Math.round(
              tempPercentincompletePieData / xdataCount,
              2
            );
            tempPercentcompletedPieData = 100 - tempPercentincompletePieData;
            setXData(tempXdata);
            setPercentcompletedData(tempPercentcompletedData);
            setPercentincompleteData(tempPercentincompleteData);
            setPercentcompletedPieData(tempPercentcompletedPieData);
            setData(response);
            setPercentincompletePieData(tempPercentincompletePieData);
            setIsLoading(false);
          }
        } else {
          throw new Error(`HTTP error! Status: ${reportData.status}`);
        }
      })
      // let response = await fetch(reportData.s3url, {
      //   method: "GET",
      //   headers: {
      //     "Content-Type": "application/json",
      //   },
      // }).then((res) => res.json());

    } catch (error) {
      console.error("Error fetching report data:", error);
    }
  };

  const displayLessonCompletionDetailsForAllUsersAsync = async () => {
    const newFileName = Date.now().toString();
    // setFileName(newFileName);
    try {

      const GetData =
        config.api.url + "getLessonCompletionReportV2?fileName=" + newFileName;
      const PostData = config.api.url + "runLessonsCompletionReport";

      if (flag) {
        get(GetData, "").then((reportData) => {
          displayLessonCompletionReport(reportData.data, flag);
        });
      } else {
        post(PostData, JSON.stringify({ fileName: newFileName })).then(
          () => {
            // displayLessonCompletionReport(reportData.data, flag);
            CheckReportFile(newFileName, flag);
          }
        );
      }
    } catch (error) {
      console.error("Error getting user data for site...", error);
      CheckReportFile(newFileName, flag);
    }
  };

  useEffect(() => {
    displayLessonCompletionDetailsForAllUsersAsync();
  }, []);

  useEffect(() => {
    const pieChartCanvas = pieChartRef.current;
    const barChartCanvas = barChartRef.current;

    if (pieChartCanvas && barChartCanvas) {
      const pieChartData = {
        labels: ["Completed (%)", "Incomplete (%)"],
        datasets: [
          {
            data: [percentcompletedPieData, percentincompletePieData],
            backgroundColor: ["rgb(75, 192, 192)", "rgb(255, 99, 132)"],
            label: "Dataset 1",
          },
        ],
      };

      const pieChartOptions = {
        onClick: (event, chartElements) => {
          if (chartElements.length > 0) {
            const clickedElement = chartElements[0];
            const label = pieChartData.labels[clickedElement.index].replace(
              " (%)",
              ""
            );
            console.log(label);
            // setSelectedLabel(label);
          }
        },
        responsive: true,
        maintainAspectRatio: false,
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        plugins: {
          legend: {
            onClick: null,
            display: true,
            position: "bottom",
            labels: {
              fontColor: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label}: ${percentage}`;
              },
            },
          },
        },
      };

      // Bar chart data and options
      const barChartData = {
        labels: xdata,
        datasets: [
          {
            type: "bar",
            label: "Completed (%)",
            backgroundColor: "rgb(75, 192, 192)",
            stack: "Stack 0",
            data: percentcompletedData,
            maxBarThickness: 40,
            borderColor: "white",
            borderWidth: 2,
            xAxisID: "x-axis-0",
          },

          {
            type: "bar",
            label: "Incomplete (%)",
            backgroundColor: "rgb(255, 99, 132)",
            stack: "Stack 0",
            maxBarThickness: 40,
            data: percentincompleteData,
            borderColor: "white",
            borderWidth: 2,
            xAxisID: "x-axis-0",
          },
        ],
      };

      const barChartOptions = {
        onClick: (event, chartElements) => {
          if (chartElements.length > 0) {
            const clickedElement = chartElements[0];
            const datasetIndex = clickedElement.datasetIndex;
            const datasetLabel = barChartData.datasets[datasetIndex].label;

            const label = barChartData.labels[clickedElement.index].replace(
              " (%)",
              ""
            );
            const cleanLabel = datasetLabel.replace(" (%)", "");
            setSelectedLabel(cleanLabel);
            setSelectedBar(label);
          }
        },
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: "bottom",
            labels: {
              fontColor: "rgb(255, 99, 132)",
            },
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              const idx = tooltipItems?.[0]?.index;
              return "Title:" + data?.labels?.[idx];
            },
          },
        },
        scales: {
          x: {
            stacked: true,
            grid: {
              display: false,
            },
            ticks: {
              display: false,
              autoSkip: false,
              maxRotation: 45,
              minRotation: 45,
              callback: function (value) {
                if (value.length > 15) {
                  return value.substr(0, 15) + "...";
                } else {
                  return value;
                }
              },
            },
            maxBarThickness: 40,
            beginAtZero: true,
          },

          y: {
            ticks: {
              max: 100,
              min: 0,
            },
            beginAtZero: true, //
          },
        },
      };

      // Create the pie chart
      const pieChart = new Chart(pieChartRef.current, {
        type: "pie",
        data: pieChartData,
        options: pieChartOptions,
      });

      // Create the bar chart
      const barChart = new Chart(barChartRef.current, {
        type: "bar",
        data: barChartData,
        options: barChartOptions,
      });

      return () => {
        pieChart.destroy();
        barChart.destroy();
      };
    }
  }, [
    xdata,
    percentcompletedData,
    percentincompleteData,
    percentcompletedPieData,
    percentincompletePieData,
  ]);

  return (
    <div className="wrapper">
      <div className="page">
        <Header />
        <div className="page-inner">
          {isLoading ? (
            <div
              className="card card-fluid p-3 "
              id="lessonCompletionReportLoaderCard"
            >
              <div className="card-body ">
                <h6 className="card-title">
                  Lesson Completion Report is being processed. It will take few
                  minutes for the report to be ready.
                </h6>
                <div className="row">
                  <div className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                    <div
                      className="spinner-border"
                      style={{ color: "#398041" }}
                    // role="status"
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div
              className="card card-fluid p-3"
              id="lessonCompletionReportCard"
            >
              {/* <!-- .card-body --> */}
              <div className="card-body ">
                <h6 className="card-title">
                  Lesson Completion Reports:{" "}
                  <span>{data?.details?.length} + Total Users</span>
                  <span id="lessonReportUserCount"></span>
                </h6>
                <div className="row">
                  <div className="col-xl-4 col-md-4 col-lg-4 col-sm-6 pb-5 pr-0 ">
                    <h6 className="d-flex justify-content-center mb-4">
                      Required Curriculum Completion
                    </h6>
                    <div style={{ height: "310px" }}>
                      <canvas
                        id="lessonReportPieChart"
                        ref={pieChartRef}
                        style={{ cursor: "default", margin: "auto" }}
                      ></canvas>
                    </div>
                  </div>
                  <div className="col-xl-8 col-md-8 col-lg-8 col-sm-6 border border-secondary border-left-1 border-right-0 border-top-0 border-bottom-0">
                    <h6 className="d-flex justify-content-center ml-2">
                      Status by Required Lesson
                    </h6>
                    <div style={{ height: "450px", width: "100%" }}>
                      <canvas
                        id="lessonReportChart"
                        style={{ cursor: "default", width: "100%" }}
                        className="mt-4  d-md-block"
                        ref={barChartRef}
                      ></canvas>
                    </div>
                  </div>
                </div>
              </div>

              {/* <!-- /.card-body -->  */}
              <TrainingRecord
                data={data}
                selectedLabel={selectedLabel}
                selectedBar={selectedBar}
                setSelectedBar={setSelectedBar}
              />
            </div>
          )}
        </div>
        <Footerview />
      </div>
    </div>
  );
};
export default Lessonreports;
