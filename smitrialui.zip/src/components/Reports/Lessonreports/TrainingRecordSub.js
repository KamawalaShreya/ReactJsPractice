import React, { useEffect, useRef } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import "./Lessonreports.css";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { useState } from "react";
import { Button, Dialog, Editor } from "primereact";
import { Form } from "react-bootstrap";
import { get, post } from "../../../utils/HttpRequest";
import { Toast } from "primereact/toast";
import TableToExcel from "@linways/table-to-excel";
import BootstrapTable from "react-bootstrap-table-next";
import { useNavigate } from "react-router-dom";

const TrainingRecord = (props) => {
  const [visible, setVisible] = useState(false);
  const [text, setText] = useState("");
  const toast = useRef(null);
  const navigate = useNavigate();
  const [validated, setValidated] = useState(false);

  

  const TrainingRecorddata = props?.data;
  const modifiedData = TrainingRecorddata.details.map((user) => ({
    ...user,
    fullName: `${user.givenName} ${user.familyName}`,
  }));
  // console.log(modifiedData);

  const [searchText, setSearchText] = useState("");
  const [data, setData] = useState(modifiedData);
  const [filteredData, setFilteredData] = useState(modifiedData);
  const [lessonReportDownload, setLessonReportDownload] = useState(false);

  const getLessonReportDownload = async () => {
    try {
      const url = config.api.url + "getTrialConfig/lessonReportDownload";
      get(url).then((response) => {
        setLessonReportDownload(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.current.show({
        severity: "error",
        summary: "something want wrong",
        detail: "Error getting download metadata file.",
      });
    }
  };

  useEffect(() => {
    getLessonReportDownload();
  }, []);

  const handleShowAllRequiredLesson = () => {
    props.setSelectedBar("");
    const requiredLessons = modifiedData.filter((e) =>
      e.lessondata.some((k) => k.lR === "required")
    );
    setFilteredData(requiredLessons);
  };

  const handleShowRequiredLesson = () => {
    const requiredLessons = [...filteredData].filter((item) => {
      return item.lessondata.some((k) => {
        return (
          k.lI ===
            [...TrainingRecorddata.lessons].filter(
              (item) => item.lessonname === props.selectedBar
            )[0].lessonid && k.lR === "required"
        );
      });
    });
    setFilteredData(requiredLessons);
  };

  const handleShowOriginalData = () => {
    props.setSelectedBar("");
    setFilteredData(modifiedData);
    setData(modifiedData);
  };

  const handleSearchChange = (e, key) => {
    setData(modifiedData);

    const searchText = key === "input" ? e.target.value : e;
    const filtered = searchText
      ? [...modifiedData].filter((item) => {
          return props.selectedBar
            ? String(
                item?.[
                  [...TrainingRecorddata.lessons].filter(
                    (item) => item.lessonname === props.selectedBar
                  )[0].lessonid
                ]
              )
                .toLowerCase()
                .includes(searchText.toLowerCase())
            : Object.values(item).some((value) =>
                String(value).toLowerCase().includes(searchText.toLowerCase())
              );
        })
      : data;
    const groupValues = filtered.map((item) => item.group);
    setconcatenatedString(groupValues.join("; "));
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const siteColumns = [
    {
      dataField: "fullName",
      text: "Name",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
      formatter: (cell, row) => {
        return (
          <a
            href={"/userreports?user=" + row.group}
            onClick={(e) => {
              e.preventDefault();
              navigate("/userreports?user=" + encodeURIComponent(row.group));
            }}
          >
            {cell}
          </a>
        );
      },
    },
    {
      dataField: "siteName",
      text: "SiteName",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    ...[
      ...(props.selectedBar
        ? [...TrainingRecorddata.lessons].filter(
            (item) => item.lessonname === props.selectedBar
          )
        : TrainingRecorddata.lessons),
    ].map((lesson) => {
      return {
        dataField: lesson.lessonid,
        text: lesson.lessonname,
        sort: true,
        filterValue: (cell) => cell.includes(searchText),
        formatter: (cell, row) => {
          const detail = row.lessondata.find(
            (detail) => detail.lI === lesson.lessonid
          );
          let colorAttrib = "";
          if (
            detail["lR"] === "required" &&
            detail["lP"].includes("Completed")
          ) {
            colorAttrib = "colorGreen";
          } else {
            if (
              detail["lR"] === "required" &&
              detail["lP"].includes("Incomplete")
            ) {
              colorAttrib = "colorRed";
            } else {
              colorAttrib = "#fff2f3f3";
            }
          }

          return <div className={colorAttrib}>{cell}</div>;
        },
      };
    }),
    {
      dataField: "subrole",
      text: "Subrole",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "status",
      text: "Disabled",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "group",
      text: "Group",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
  ];

  useEffect(() => {
    handleSearchChange(props.selectedLabel);
  }, [props.selectedLabel]);

  const groupValues = data.map((item) => item.group);
  const [concatenatedString, setconcatenatedString] = useState(
    groupValues.join("; ")
  );

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        body: text,
        priority: "normal",
      };
      var url = config.api.url + "sendMultipleMessages";
      post(url, formData)
        .then((response) => {
          if (
            response.data.messageData &&
            response.data.messageData !== "" &&
            response.data.messageData.includes("disabled")
          ) {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data.messageData,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: "Message Sent!",
            });
          }
        })
        .catch(() => {
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];
  const csvFormatter = (cell) => {
    return cell;
  };

  const exportToCSV = () => {
    const csvColumns = siteColumns?.map((col) => ({
      dataField: col.dataField,
      text: col.text,
      formatter: csvFormatter,
    }));

    const csvData = filteredData?.map((item) =>
      csvColumns.map((col) => csvFormatter(item[col.dataField]))
    );

    const csvContent =
      csvColumns.map((col) => col.text).join(",") +
      "\n" +
      csvData.map((row) => row.join(",")).join("\n");

    const blob = new Blob([csvContent], {
      type: "text/csv",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "lessonReport_" + Date.now().toString() + ".CSV";
    link.click();
  };

  const exportToxlsx = () => {
    const tableElement = document.getElementById(
      "lessonCompletionReportTableBody"
    );
   

    let filename = "lessonReport_" + Date.now().toString() + ".xlsx";
    let data = TableToExcel.convert(tableElement, {
      name: filename,
    });
    return data;
  };

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <div className="card-body m-4 d-md-block">
        <h6 className="card-title d-sm-inline-block"> Training Record</h6>
        {lessonReportDownload ? (
          <div id="lessonReportTableExportFunctionsDiv">
            <Button
              id="exportToxlsx"
              className="btn btn-secondary mr-2 excel-btn"
              onClick={exportToxlsx}
            >
              Export table to Excel
            </Button>
            <Button
              id="exportToCSV"
              className="btn btn-secondary excel-btn"
              onClick={exportToCSV}
            >
              Export table to CSV
            </Button>
          </div>
        ) : (
          <>
            <div className="lessonReportBtn">
              <Button
                className="btn btn-secondary"
                onClick={() => setVisible(true)}
              >
                <FontAwesomeIcon icon={faEnvelope} />
              </Button>
              <Button
                type="button"
                onClick={handleShowOriginalData}
                className="btn btn-secondary"
              >
                Show All
              </Button>
              <Button
                type="button"
                onClick={handleShowAllRequiredLesson}
                className="btn btn-secondary"
              >
                All Required Lesson
              </Button>
              {props.selectedBar && (
                <Button
                  style={{ pointerEvents: "auto" }}
                  type="button"
                  title="Select any lesson first by clicking on the bar chart"
                  className="btn btn-secondary"
                  // disabled={!props.selectedBar}
                  onClick={handleShowRequiredLesson}
                >
                  Required Lesson
                </Button>
              )}
            </div>

            {TrainingRecorddata && (
              <Datatable
                keyField={"id"}
                columns={siteColumns}
                data={data}
                className="tableScroll"
                filteredData={filteredData}
                defaultSorted={defaultSorted}
                searchText={searchText}
                handleSearchChange={(e) => handleSearchChange(e, "input")}
              />
            )}
          </>
        )}
        <div className="d-none">
          <BootstrapTable
            keyField="id"
            id="lessonCompletionReportTableBody"
            data={filteredData}
            defaultSorted={defaultSorted}
            columns={siteColumns}
            striped
          />
        </div>
        <Dialog
          header="Send Email"
          visible={visible}
          className="mail-box"
          onHide={() => setVisible(false)}
          dismissableMask={true}
        >
          <Form
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            validated={validated}
          >
            <div className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Control
                  value={concatenatedString}
                  type="text"
                  name="to"
                  className="form-control input-group"
                />
              </Form.Group>
            </div>
            <div className="mb-3">
              <Form.Group>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  placeholder="subject"
                  name="subject"
                  required
                />
                {validated && (
                  <Form.Control.Feedback type="invalid">
                    Enter email subject.
                  </Form.Control.Feedback>
                )}
              </Form.Group>
            </div>
            <Editor
              type="text"
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
              required
            />
            <div className="py-3">
              <button type="submit" className="btn btn-primary mr-2">
                Send
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setVisible(false)}
                data-dismiss="modal"
              >
                Cancel
              </button>
            </div>
          </Form>
        </Dialog>
      </div>
    </div>
  );
};
export default TrainingRecord;
