import React, { useEffect, useRef, useState } from "react";
import { Toast, Dialog, Editor } from "primereact";
import { Card, Col, Container, Row, Form } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { post } from "../../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
const Usersummaryreports = () => {
  const toast = useRef(null);
  const navigate = useNavigate();

  const [userCountReportData, setUserCountReportData] = useState(null);
  const [userSummaryReportData, setUserSummaryReportData] = useState([]);
  const [validated, setValidated] = useState(false);
  const [visible, setVisible] = useState(false);
  const [text, setText] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(userSummaryReportData);

  useEffect(() => {
    let userSummaryReportsUrl = config.api.url + "userSummaryReport";
    var fileName = Date.now().toString();
    post(userSummaryReportsUrl, JSON.stringify({ fileName: fileName })).then(
      (reportData) => {
        const modifiedData = reportData.data.details.map((user) => ({
          ...user,
          fullName: `${user.givenName} ${user.familyName}`,
        }));
      
        setUserSummaryReportData(modifiedData);
        setUserCountReportData(reportData.data.usercount);
        setFilteredData(modifiedData);
      }
    );
  }, []);

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? userSummaryReportData.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : userSummaryReportData;
    const groupValuesOne = filtered?.map((item) => item.group);
    setSelectedEmail(groupValuesOne.join("; "));
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const groupValues = userSummaryReportData?.map((item) => item.group);

  const [concatenatedString, setConcatenatedString] = useState("");

  useEffect(() => {
    setConcatenatedString(groupValues.join("; "));
  }, [groupValues]);

  const userSummaryReportColumn = [
    {
      dataField: "fullName",
      text: "Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <a
            href={"/userreports?user=" + row.group}
            onClick={(e) => {
              e.preventDefault();
              navigate("/userreports?user=" + encodeURIComponent(row.group));
            }}
          >
            {row.fullName}
          </a>
        );
      },
    },
    {
      dataField: "siteName",
      text: "Site",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.siteName
          ? typeof row.siteName == "object" && row.siteName.length > 0
            ? row.siteName.join("   ")
            : row.siteName
          : "No site assigned";
      },
    },
    {
      dataField: "role",
      text: "Role",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "subrole",
      text: "Subrole",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "group",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "percentage",
      text: "Required Lesson Completed",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];
  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];

  const handleSubmit = async (event) => {
  
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        body: text,
        priority: "normal",
      };
    
      var url = config.api.url + "sendMultipleMessages";
      post(url, formData)
        .then((response) => {
          if (response.data && response.data !== "") {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: response.data,
            });
          }
        })
        .catch((error) => {
          console.log(error);
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  return (
    <div className="sitesReportsPage app" style={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card className="p-3" style={{ width: "100%", margin: "10px" }}>
            {userSummaryReportData && userSummaryReportData.length ? (
              <Card.Body className="p-3" style={{ width: "100%" }}>
                <Row style={{ width: "100%" }}>
                  <h6 className="card-title float-left">
                    User Summary Reports:
                    <span>{userCountReportData} Total Users</span>
                  </h6>
                </Row>
                <button
                  className="btn btn-secondary"
                  onClick={() => setVisible(true)}
                >
                  <FontAwesomeIcon icon={faEnvelope} />
                </button>
                <div className="mt-2" style={{ width: "100%" }}>
                  <Datatable
                    keyField="group"
                    defaultSorted={defaultSorted}
                    data={userSummaryReportData}
                    handleSearchChange={handleSearchChange}
                    columns={userSummaryReportColumn}
                    filteredData={filteredData}
                    searchText={searchText}
                  />
                </div>
              </Card.Body>
            ) : (
              <Card.Body style={{ width: "100%", height: "450px" }}>
                <Row className="p-3" style={{ width: "100%" }}>
                  <h6 className="card-title">
                    {" "}
                    User Summary Report is being processed.
                  </h6>
                </Row>
                <Row className="p-3" style={{ width: "100%" }}>
                  <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                    <i
                      className="pi pi-spin pi-spinner"
                      style={{ fontSize: "3rem" }}
                    ></i>
                  </Col>
                </Row>
              </Card.Body>
            )}
          </Card>
        </Row>
        <Dialog
          header="Send Email"
          visible={visible}
          // style={{ width: "35vw" }}
          className="mail-box"
          onHide={() => setVisible(false)}
          dismissableMask={true}
        >
          <Form
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            validated={validated}
          >
            <div className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Control
                  value={selectedEmail || concatenatedString}
                  type="text"
                  name="to"
                  className="form-control input-group"
                />
              </Form.Group>
            </div>
            <div className="mb-3">
              <Form.Group>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  placeholder="subject"
                  name="subject"
                />
              </Form.Group>
            </div>
            <Editor
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="py-3">
              <button type="submit" className="btn btn-primary mr-2">
                Send
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setVisible(false)}
                data-dismiss="modal"
              >
                Cancel
              </button>
            </div>
          </Form>
        </Dialog>
      </Container>
    </div>
  );
};
export default Usersummaryreports;
