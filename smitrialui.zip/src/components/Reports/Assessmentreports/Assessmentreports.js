import React, { useEffect, useRef, useState } from "react";

// import { findDOMNode } from "react-dom";
import { Toast, Dialog, Editor } from "primereact";
import { Card, Col, Container, Row, Form } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { get } from "../../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";
import { Chart } from "primereact/chart";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { post } from "../../../utils/HttpRequest";

const Assessmentreports = () => {
  const toast = useRef(null);
  const navigate = useNavigate();

  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");
  const topicid = params.get("topicid");

  const [visible, setVisible] = useState(false);
  const [validated, setValidated] = useState(false);
  const [text, setText] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");
 

  const [totalUsers, setTotalUsers] = useState(null);
  const [barChartdata, setBarChartData] = useState(null);
  const [tableRows, setTableRows] = useState([]);
  const [assessmentTableRows, setAssessmentTableRows] = useState([]);

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
 
  const [filteredData, setFilteredData] = useState(assessmentTableRows);

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);
 

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 991);
  };
  useEffect(() => {
    window.addEventListener("resize", handleResize);
    var url = config.api.url + "getAllMyReportees";
    let assessmentUrl =
      config.api.url +
      "getAssessmentCompletionDetailsAllUsers?lessonid=" +
      lessonid +
      "&topicid=" +
      topicid;
    var chartLinks = {};

    get(url)
      .then((userResponse) => {
        get(assessmentUrl).then((assessmentResponse) => {
          let userData = userResponse.data;
        

          let assessmentCompletionData = assessmentResponse.data;
          userData.forEach((u) => {
            assessmentCompletionData.result.forEach((a) => {
              if (u.group === a.email) {
                if (typeof u.subrole === "undefined") {
                  a["subrole"] = "";
                } else {
                  a["subrole"] = u.subrole;
                }
              }
            });
          });
          let chartClickLinks = [];
          let tableRowsArray = [];
          assessmentCompletionData.summary.forEach((e) => {
            assessmentCompletionData.topic.Items.forEach((item) => {
              if (e.topicorder === item.topicorder) {
                tableRowsArray.push(item);
                chartLinks["Question " + e.topicorder] =
                  "/assessmentquestionreports?lessonid=" +
                  item.lessonid +
                  "&topicid=" +
                  item.topic_id;
                chartClickLinks.push(
                  "/assessmentquestionreports?lessonid=" +
                    item.lessonid +
                    "&topicid=" +
                    item.topic_id
                );
              }
            });
          });
          setTableRows(tableRowsArray);
          setTotalUsers(assessmentCompletionData.userCount);
          var xdata = [];
          var xlabel = [];

          assessmentCompletionData.summary.forEach((o, i) => {
            assessmentCompletionData.topic.Items.map((item) => {
              if (o.topicorder === item.topicorder) {
                xdata[i] = o.value;
                xlabel[i] = "Question " + o.topicorder;
              }
            });
          });

          let chartdata = {
            labels: xlabel,
            datasets: [
              {
                type: "bar",
                label: "Percent Correct (%)",
                backgroundColor: window.chartColors.green,
                data: xdata,
                borderColor: "white",
                borderWidth: 2,
                maxBarThickness: 40,
              },
            ],
          };
          function graphClickEvent(event, array) {
            navigate(chartClickLinks[array[0].index]);
          }
          let chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: false,
                text: "Assessment Completion for all users.",
              },
              legend: {
                onClick: null,
                display: true,
                position: "top",
                align: "start",
              },
              tooltips: {
                mode: "index",
                intersect: true,
              },
            },
            onClick: graphClickEvent,
            scales: {
              x: {
                stacked: true,
                ticks: {
                  autoSkip: false,
                  maxRotation: 45,
                  minRotation: 45,
                },
              },
              y: {
                ticks: {
                  max: 100,
                  min: 0,
                },
              },
            },
          };
          const modifieddata = assessmentCompletionData.result.map((user) => ({
            ...user,
            assessmentScore: `${user.assessmentScore}%`,
          }));
          setBarChartData({ data: chartdata, options: chartOptions });
          setAssessmentTableRows(modifieddata);
          setFilteredData(modifieddata);
        });
      })
      .catch((err) => {
        console.log("Error ", err);
      });
  }, []);

  const dialogRef = useRef(null);
  

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? assessmentTableRows.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : assessmentTableRows;
    const emailpValues = filtered?.map((item) => item.email);
    const searchEmail = [...new Set(emailpValues)];
    setSelectedEmail(searchEmail.join("; "));
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const groupValues = assessmentTableRows?.map((item) => item.email);
  const uniqueEmails = [...new Set(groupValues)];
  const [concatenatedString, setConcatenatedString] = useState("");

  useEffect(() => {
    setConcatenatedString(uniqueEmails.join("; "));
  }, [uniqueEmails]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        // body: text,
        priority: "normal",
      };
 
      var url =
        config.api.url +
        "getAssessmentCompletionDetailsAllUsers?lessonid=" +
        lessonid +
        "&topicid=" +
        topicid;
      post(url, formData)
        .then((response) => {
          if (response.data && response.data !== "") {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: response.data,
            });
          }
        })
        .catch((error) => {
          
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const defaultSorted = [
    {
      dataField: "name",
      order: "asc",
    },
  ];
  const trainingRecordsColumns = [
    {
      dataField: "name",
      text: "Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <a
            href={"/userreports?user=" + row.email}
            onClick={(e) => {
              e.preventDefault();
              navigate("/userreports?user=" + encodeURIComponent(row.email));
            }}
          >
            {row.name}
          </a>
        );
      },
    },
    {
      dataField: "siteName",
      text: "Site",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        let links = [];
        if (Array.isArray(row.siteName)) {
          row.siteName.forEach((siteName, index) => {
            const siteId = row.site[index];
            const link = (
              <a
                key={`site-link-${index}`}
                href={`/sitereports?siteid=${siteId}`}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(`/sitereports?siteid=${siteId}`);
                }}
              >
                {siteName}
              </a>
            );
            links.push(link);
          });
        } else {
          if (
            typeof row.siteName === "undefined" ||
            row.siteName === "no record"
          ) {
            links.push("No site assigned");
          } else {
            if (
              localStorage.getItem("userRole") === "kp" ||
              localStorage.getItem("userRole") === "crc" ||
              localStorage.getItem("userRole") === "sitepi"
            ) {
              links.push(row.siteName);
            } else {
              const link = (
                <a
                  href={`/sitereports?siteid=${row.site}`}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(`/sitereports?siteid=${row.site}`);
                  }}
                >
                  {row.siteName}
                </a>
              );
              links.push(link);
            }
          }
        }
        return (
          <div>
            {links.map((link, index) => (
              <div key={`site-link-div-${index}`}>{link}</div>
            ))}
          </div>
        );
      },
    },
    {
      dataField: "assessmentResult",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "assessmentScore",
      text: "Score",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "missedQuestions",
      text: "Missed Questions",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        const missedQuestionElements = row.missedQuestions.map((mq, index) => (
          <div key={`missed-question-${index}`}>
            <a
              href={`/assessmentquestionreports?lessonid=${row.lessonid}&topicid=${mq.topicid}`}
              onClick={(e) => {
                e.preventDefault();
                navigate(
                  `/assessmentquestionreports?lessonid=${row.lessonid}&topicid=${mq.topicid}`
                );
              }}
            >
              {mq.topicid}
            </a>
            <br />
          </div>
        ));
        return (
          <div key={`missed-question-user-${row.email}`}>
            {missedQuestionElements}
          </div>
        );
      },
    },
    {
      dataField: "role",
      text: "Role",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "subrole",
      text: "Subrole",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "email",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];

  return (
    <div className="assessmentReportsPage  app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card className="p-3" style={{ width: "100%", margin: "10px" }}>
            <Card.Body className="p-3" style={{ width: "100%" }}>
              <h6 className="card-title float-left">
                {" "}
                Comprehension Reports: &nbsp;
                {totalUsers ? totalUsers + " Total Users" : ""}
              </h6>
              <Row style={{ width: "100%" }}>
                <Col xl={6} md={6} lg={6} sm={12} style={{ height: "500px" }}>
                  <h6 className="ml-2">Comprehension Results</h6>
                  {barChartdata ? (
                    <Chart
                      type="bar"
                      className="ml-2 w-full h-full p-5"
                      data={barChartdata.data}
                      options={barChartdata.options}
                    />
                  ) : (
                    <div></div>
                  )}
                </Col>
                <Col xl={6} md={6} lg={6} sm={12}>
                  <div style={{ height: "420px", overflowY: "auto" }}>
                    <table className="table">
                      <thead>
                        <tr>
                          <th>Category</th>
                          <th>Question</th>
                        </tr>
                      </thead>
                      <tbody>
                        {tableRows ? (
                          tableRows.map((row) => (
                            <tr key={row.topic_id}>
                              <td>
                                <a
                                  href={
                                    "/assessmentquestionreports?lessonid=" +
                                    row.lessonid +
                                    "&topicid=" +
                                    row.topic_id
                                  }
                                  onClick={(e) => {
                                    e.preventDefault();
                                    navigate(
                                      "/assessmentquestionreports?lessonid=" +
                                        row.lessonid +
                                        "&topicid=" +
                                        row.topic_id
                                    );
                                  }}
                                >
                                  Question {row.topicorder}
                                </a>
                              </td>
                              <td>{row.question}</td>
                            </tr>
                          ))
                        ) : (
                          <tr></tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </Col>
              </Row>
              <Row style={{ width: "100%" }}>
                <div className="d-none d-md-block text-center justify-content-center w-100 pt-4">
                  <p className="font-weight-bold">
                    Click on the graphs column of the left or the questions on
                    the right to see the detailed report about each question
                  </p>
                </div>
              </Row>
            
              {!isMobile ? (
                <Row style={{ width: "100%" }}>
                  <h6 className="card-title d-sm-inline-block">
                    Training Record
                  </h6>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setVisible(true)}
                  >
                    <FontAwesomeIcon icon={faEnvelope} />
                  </button>
                  <div className="mt-2" style={{ width: "100%" }}>
                    <Datatable
                      keyField="email"
                      defaultSorted={defaultSorted}
                      data={assessmentTableRows}
                      handleSearchChange={handleSearchChange}
                      columns={trainingRecordsColumns}
                      filteredData={filteredData}
                      searchText={searchText}
                    />
                  </div>
                </Row>
              ) : (
                <div className={`alert alert-dark mt-2 ml-2 mr-2 text-center`}>
                  <p> Desktop access is required to view Training Record</p>
                </div>
              )}
            </Card.Body>
          </Card>
        </Row>
        <Dialog
          header="Send Email"
          visible={visible}
          className="mail-box"
          // style={{ width: "35vw" }}
          onHide={() => setVisible(false)}
          dismissableMask={true}
        >
          <Form
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            validated={validated}
          >
            <div className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Control
                  value={selectedEmail || concatenatedString}
                  type="text"
                  name="to"
                  className="form-control input-group"
                />
              </Form.Group>
            </div>
            <div className="mb-3">
              <Form.Group>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  placeholder="subject"
                  name="subject"
                />
              </Form.Group>
            </div>
            <Editor
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="py-3">
              <button type="submit" className="btn btn-primary mr-2">
                Send
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setVisible(false)}
                data-dismiss="modal"
              >
                Cancel
              </button>
            </div>
          </Form>
        </Dialog>
      </Container>
    </div>
  );
};
export default Assessmentreports;
