import React, { useEffect, useRef, useState } from "react";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import { get } from "../../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";
import { Chart } from "primereact/chart";

const Allassessmentreports = () => {
  const toast = useRef(null);
  const navigate = useNavigate();

  const [barChartdata, setBarChartData] = useState(null);
  const [tableRows, setTableRows] = useState([]);

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  useEffect(() => {
    var url = config.api.url + "getLessonsCompletionDetailsAllUsers";
    var getAssessmentUrl = config.api.url + "getAssessments";
    get(url)
      .then((lessonCompletionDataResponse) => {
        let lessonCompletionData = lessonCompletionDataResponse.data;
        get(getAssessmentUrl).then((displayAllAssessmentsResponse) => {
          let displayAllAssessments = displayAllAssessmentsResponse.data;
          let xdata = [];
          let percentcompletedData = [];
          let percentincompleteData = [];
          let xdataCount = 0;
          let assessmentLinksArray = [];
          lessonCompletionData.summary.map(function (l) {
            displayAllAssessments.map(function (d) {
              if (l.id === d.lessonid && l.requiredCount > 0) {
                xdata[xdataCount] = l.name;
                assessmentLinksArray.push(
                  "/assessmentreports?lessonid=" +
                    d.lessonid +
                    "&topicid=" +
                    d.topicid
                );
                percentincompleteData[xdataCount] = Math.round(
                  (l.incomplete2 / l.requiredCount) * 100
                );
                percentcompletedData[xdataCount] =
                  100 - percentincompleteData[xdataCount];
                xdataCount++;
              }
            });
          });
          let assessmentLinks = [];
          displayAllAssessments.map((e) => {
            assessmentLinks[e.lessonname] =
              "/assessmentreports?lessonid=" +
              e.lessonid +
              "&topicid=" +
              e.topicid;
          });
          let assessmentTableRows = [];
          displayAllAssessments.map((item) => {
            if (item.status == "active") {
              assessmentTableRows.push(item);
            }
          });
        
          setTableRows(assessmentTableRows);
          let chartdata = {
            labels: xdata,
            datasets: [
              {
                type: "bar",
                label: "Completed (%)",
                backgroundColor: window.chartColors.green,
                stack: "Stack 0",
                data: percentcompletedData,
                borderColor: "white",
                borderWidth: 2,
                maxBarThickness: 40,
              },
              {
                type: "bar",
                label: "Incomplete (%)",
                backgroundColor: window.chartColors.red,
                stack: "Stack 0",
                data: percentincompleteData,
                borderColor: "white",
                borderWidth: 2,
                maxBarThickness: 40,
              },
            ],
          };
          function assessmentGraphClick(event, array) {
            navigate(assessmentLinksArray[array[0].index]);
          }
          let chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: false,
                text: "Lesson Completion for all users.",
              },
              legend: {
                onClick: null,
                display: true,
                position: "top",
                align: "start",
              },
              tooltips: {
                mode: "index",
                intersect: true,
              },
            },
            onClick: assessmentGraphClick,
            scales: {
              x: {
                stacked: true,
                ticks: {
                  autoSkip: false,
                  maxRotation: 45,
                  minRotation: 45,
                },
              },
              y: {
                ticks: {
                  max: 100,
                  min: 0,
                },
              },
            },
          };
          setBarChartData({ data: chartdata, options: chartOptions });
        });
      })
      .catch((err) => {
        console.log("Error ", err);
      });
  }, []);

  return (
    <div className="allassessmentReportsPage  app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card className="p-3" style={{ width: "100%", margin: "10px" }}>
            <Card.Body className="p-3" style={{ width: "100%" }}>
              <h6 className="card-title float-left"> Comprehension Reports </h6>
              <Row style={{ width: "100%" }}>
                <Col xl={6} md={6} lg={6} sm={12} style={{ height: "500px" }}>
                  {barChartdata ? (
                    <Chart
                      type="bar"
                      className="ml-2 w-full h-full"
                      data={barChartdata.data}
                      options={barChartdata.options}
                    />
                  ) : (
                    <div></div>
                  )}
                </Col>
                <Col xl={6} md={6} lg={6} sm={12}>
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Comprehension Name</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tableRows ? (
                        tableRows.map((row) => (
                          <tr key={row.lessonid}>
                            <td>
                              <a
                                key={row.lessonid}
                                href={
                                  "/assessmentreports?lessonid=" +
                                  row.lessonid +
                                  "&topicid=" +
                                  row.topicid
                                }
                                onClick={(e) => {
                                  e.preventDefault();
                                  navigate(
                                    "/assessmentreports?lessonid=" +
                                      row.lessonid +
                                      "&topicid=" +
                                      row.topicid
                                  );
                                }}
                              >
                                {row.lessonname}
                              </a>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr></tr>
                      )}
                    </tbody>
                  </table>
                </Col>
              </Row>
              <Row style={{ width: "100%" }}>
                <div className="text-center justify-content-center w-100 pt-4">
                  <p className="font-weight-bold">
                    Click on the bar or the comprehension name to see report
                    about each comprehension.
                  </p>
                </div>
              </Row>
            </Card.Body>
          </Card>
        </Row>
      </Container>
    </div>
  );
};
export default Allassessmentreports;
