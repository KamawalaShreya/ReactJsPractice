import React, { useEffect, useRef, useState } from "react";
import axios from "axios";
import { Toast, Dialog, Editor } from "primereact";
import { Card, Col, Container, Form, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { post } from "../../../utils/HttpRequest";
import { Chart } from "primereact/chart";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEnvelope,
  faFaceFrown,
  faFaceMeh,
  faFaceSmile,
} from "@fortawesome/free-solid-svg-icons";

const Surveyreports = () => {
  const toast = useRef(null);

  const s3FetchInstance = axios.create();

  const [surveyReportData, setSurveyReportData] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState("");
  const [text, setText] = useState("");
  const [visible, setVisible] = useState(false);
  const [validated, setValidated] = useState(false);

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(surveyReportData);

  const [pieChartData, setPieChartData] = useState({});

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  const displayPieChartData = (responseData) => {
    s3FetchInstance
      .get(responseData.s3url)
      .then((surveyDataResponse) => {
        let surveyData = surveyDataResponse.data;
        const modifiedData = surveyData.surveyTableData.map((user, id) => ({
          ...user,
          id: id,
          fullName: `${user.givenName} ${user.familyName}`,
        }));
        const piechartdata = {
          datasets: [
            {
              data: [
                surveyData.sentimentReport.percentageOfPositive,
                surveyData.sentimentReport.percentageOfNegative,
                surveyData.sentimentReport.percentageOfMixed,
              ],
              backgroundColor: [
                window.chartColors.green,
                window.chartColors.red,
                window.chartColors.blue,
              ],
              label: "Dataset 1",
            },
          ],
          labels: ["Positive (%)", "Negative (%)", "Mixed (%)"],
        };
        const piechartoptions = {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: false,
              text: "Sentiment report.",
            },
            legend: {
              onClick: null,
              display: true,
              position: "bottom",
              labels: {
                fontColor: "rgb(255, 99, 132)",
              },
            },
            tooltip: {
              mode: "index",
              intersect: true,
              callbacks: {
                label: function (tooltipItem) {
                  const label = tooltipItem.label;
                  // console.log(label);
                  const percentage =
                    tooltipItem.dataset.data[tooltipItem.dataIndex];
                  // console.log(percentage);
                  return `${label}: ${percentage}`;
                },
              },
            },
          },
        };
        setPieChartData({ data: piechartdata, options: piechartoptions });
        setSurveyReportData(modifiedData);
        setFilteredData(modifiedData);
      })
      .catch((err) => {
        console.log("Error ", err);
      });
  };

  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? surveyReportData.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : surveyReportData;
    const emailpValues = filtered?.map((item) => item.email);
    const searchEmail = [...new Set(emailpValues)];
    setSelectedEmail(searchEmail.join("; "));
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const groupValues = surveyReportData?.map((item) => item.email);
  const uniqueEmails = [...new Set(groupValues)];
  const [concatenatedString, setConcatenatedString] = useState("");

  useEffect(() => {
    setConcatenatedString(uniqueEmails.join("; "));
  }, [uniqueEmails]);

  useEffect(() => {
    var url = config.api.url + "createSurveyReport";
    var fileName = Date.now().toString();
    post(url, JSON.stringify({ fileName: fileName }))
      .then((reportStatusDataResponse) => {
        let reportStatusData = reportStatusDataResponse.data;
        displayPieChartData(reportStatusData);
      })
      .catch((err) => {
        console.log("Error ", err);
      });
  }, []);

  // Datatable search helper function

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        body: text,
        priority: "normal",
      };
     
      var url = config.api.url + "sendMultipleMessages";
      post(url, formData)
        .then((response) => {
          if (response.data && response.data !== "") {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: response.data,
            });
          }
        })
        .catch((error) => {
          console.log(error);
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];
  const surveyTableColumns = [
    {
      dataField: "fullName",
      text: "name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "siteName",
      text: "Site",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "lessonname",
      text: "Lessonname",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.lessonname + "(" + row.lessonid + ")";
      },
    },
    {
      dataField: "question",
      text: "Question",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "answer",
      text: "Answer",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "sentiment",
      text: "Sentiment",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        if (row.sentiment === "NEGATIVE") {
          return (
            <div>
              {row.sentiment} <FontAwesomeIcon icon={faFaceFrown} size="lg" />
            </div>
          );
        } else if (row.sentiment === "POSITIVE") {
          return (
            <div>
              {row.sentiment} <FontAwesomeIcon icon={faFaceSmile} size="lg" />
            </div>
          );
        } else if (row.sentiment === "MIXED") {
          return (
            <div>
              {row.sentiment} <FontAwesomeIcon icon={faFaceMeh} size="lg" />
            </div>
          );
        }
      },
    },
    {
      dataField: "role",
      text: "Role",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "email",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];

  return (
    <div className="surveyReportsPageAsync app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <div className="page-inner">
          <Row style={{ width: "100%", margin: "auto" }}>
            {/* <div className="page-inner" style={{ width: '100%' }}> */}
            <Card style={{ width: "100%" }}>
              {surveyReportData ? (
                <Card.Body style={{ width: "100%" }}>
                  <h6 className="d-flex justify-content-center mb-4 mt-3">
                    Sentiment report
                  </h6>
                  <Row
                    style={{ width: "100%" }}
                    className="ml-2 mt-2 mb-4 mr-2"
                  >
                    <Col xl={12} md={12} lg={12} sm={12}>
                      <div style={{ height: "250px" }}>
                        <Chart
                          type="pie"
                          className="mb-2"
                          data={pieChartData.data}
                          options={pieChartData.options}
                        />
                      </div>
                    </Col>
                  </Row>
                  <div style={{ width: "100%" }} className="ml-2 mt-7 mr-2">
                    <h6 className="card-title">Survey Record</h6>
                    <button
                      className="btn btn-secondary"
                      onClick={() => setVisible(true)}
                    >
                      <FontAwesomeIcon icon={faEnvelope} />
                    </button>
                  </div>
                  <Row className="m-2">
                    <div className="mt-2 ml-2 mr-2" style={{ width: "100%" }}>
                      <Datatable
                        keyField="id"
                        defaultSorted={defaultSorted}
                        data={filteredData}
                        handleSearchChange={handleSearchChange}
                        columns={surveyTableColumns}
                        filteredData={filteredData}
                        searchText={searchText}
                      />
                    </div>
                  </Row>
                </Card.Body>
              ) : (
                <Card.Body style={{ width: "100%", height: "450px" }}>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <h6 className="card-title">
                      {" "}
                      Survey Report is being processed. It will take few minutes
                      for the report to be ready.
                    </h6>
                  </Row>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                      <i
                        className="pi pi-spin pi-spinner"
                        style={{ fontSize: "3rem" }}
                      ></i>
                    </Col>
                  </Row>
                </Card.Body>
              )}
            </Card>
            {/* </div> */}
          </Row>
        </div>
        <Dialog
          header="Send Email"
          visible={visible}
          className="mail-box"
          // style={{ width: "35vw" }}
          onHide={() => setVisible(false)}
          dismissableMask={true}
        >
          <Form
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            validated={validated}
          >
            <div className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Control
                  value={selectedEmail || concatenatedString}
                  type="text"
                  name="to"
                  className="form-control input-group"
                />
              </Form.Group>
            </div>
            <div className="mb-3">
              <Form.Group>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  placeholder="subject"
                  name="subject"
                />
              </Form.Group>
            </div>
            <Editor
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="py-3">
              <button type="submit" className="btn btn-primary mr-2">
                Send
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setVisible(false)}
                data-dismiss="modal"
              >
                Cancel
              </button>
            </div>
          </Form>
        </Dialog>
      </Container>
    </div>
  );
};
export default Surveyreports;
