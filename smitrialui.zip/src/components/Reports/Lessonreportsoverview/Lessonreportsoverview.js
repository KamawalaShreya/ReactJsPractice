import React, { useEffect, useRef, useState } from "react";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import axios from "axios";
import { Chart } from "primereact/chart";
import "../Lessonreports/Lessonreports.css";

const Lessonreportsoverview = () => {
  const toast = useRef(null);

  const s3FetchInstance = axios.create();

  const [lessonReportData, setLessonReportdata] = useState(null);
  const [aggregateReportData, setAggregateReportData] = useState(null);
  const [reportGenTime, setReportGenTime] = useState(null);

  const [mainBarChartData, setmainBarChartData] = useState({});
  const [sitesBarChartData, setSitesBarChartData] = useState({});
  const [rolesBarChartData, setRolesBarChartData] = useState({});
  const [lessonsBarChartData, setLessonssBarChartData] = useState({});

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  const initializeMainBarChart = (lessonCompletionData) => {
    var xdata = [];
    var percentcompletedData = [];
    var percentincompleteData = [];
    var percentcompletedPieData = 0;
    var percentincompletePieData = 0;
    var mostCompletedLessons = [];
    let xdataCount = 0;
    lessonCompletionData.summary.forEach((o) => {
      if (o.requiredCount > 0) {
        xdata[xdataCount] = o.name;
        percentincompleteData[xdataCount] = Math.round(
          (o.incomplete2 / o.requiredCount) * 100
        );
        percentcompletedData[xdataCount] =
          100 - percentincompleteData[xdataCount];
        mostCompletedLessons.push({
          name: o.name,
          percentincompleteData: percentincompleteData[xdataCount],
          percentcompletedData: percentcompletedData[xdataCount],
        });
        xdataCount++;
      }
    });
    mostCompletedLessons.sort(function (a, b) {
      return b.percentcompletedData - a.percentcompletedData;
    });
    xdata.map((o, index) => {
      percentcompletedPieData += percentcompletedData[index];
      percentincompletePieData += percentincompleteData[index];
    });
    percentincompletePieData = Math.round(
      percentincompletePieData / xdataCount,
      2
    );

    percentcompletedPieData = 100 - percentincompletePieData;
    console.log(percentcompletedPieData);

    const bardata = {
      labels: xdata,
      datasets: [
        {
          type: "bar",
          label: "Completed (%)",
          backgroundColor: window.chartColors.green,
          stack: "Stack 0",
          data: percentcompletedData,
          borderColor: "white",
          borderWidth: 2,
          maxBarThickness: 40,
        },
      ],
    };
    const baroptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "bottom",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Title:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            autoSkip: false,
            maxRotation: 45,
            minRotation: 45,
            callback: function (value) {
              if (xdata[value].length > 40) {
                return xdata[value].substr(0, 40) + "..."; //truncate
              } else {
                return xdata[value];
              }
            },
          },
        },
        y: {
          ticks: {
            min: 0,
            max: 100,
          },
        },
      },
    };
    setmainBarChartData({ data: bardata, options: baroptions });
  };
  const initializeSitesBarChart = (lessonCompletionData) => {
    var siteWiseCompleteCount = lessonCompletionData.siteWiseCompleteCount;
    var roleWiseCompleteCount = lessonCompletionData.roleWiseCompleteCount;
    delete roleWiseCompleteCount.admin;
    delete roleWiseCompleteCount.smiadmin;

    roleWiseCompleteCount = Object.entries(roleWiseCompleteCount)
      .sort(([, a], [, b]) => b - a)
      .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

    var siteWiseCompleteCountMain = [];
    var siteLabels = [];
    var threshold = 1;
    let siteCount = 5;
    for (let key in siteWiseCompleteCount) {
      let obj = {};
      var total = 0;
      for (let role of ["sitepi", "crc", "kp"]) {
        if (siteWiseCompleteCount[key][role] == undefined) {
          siteWiseCompleteCount[key][role] = 0;
        }
        obj[role] = siteWiseCompleteCount[key][role];
        total = total + obj[role];
      }

      if (total > threshold && siteWiseCompleteCountMain.length < siteCount) {
        obj["total"] = total;
        obj["label"] = key;
        siteWiseCompleteCountMain.push(obj);
      }
    }
    siteWiseCompleteCountMain.sort(function (a, b) {
      return b.total - a.total;
    });
    siteLabels = siteWiseCompleteCountMain.map((a) => a.label);

    const sitesChartData = {
      labels: siteLabels,
      datasets: [
        {
          label: "SitePi Total Complete: ",
          backgroundColor: window.chartColors.purple,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.sitepi),
          borderColor: "white",
          maxBarThickness: 25,
        },
        {
          label: "CRC Total Complete: ",
          backgroundColor: window.chartColors.green,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.crc),
          borderColor: "white",
          maxBarThickness: 25,
        },
        {
          label: "KP Total Complete: ",
          backgroundColor: window.chartColors.orange,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.kp),
          borderColor: "white",
          maxBarThickness: 25,
        },
      ],
    };
    const sitesChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Site:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
        },
        y: {
          ticks: {
            stacked: true,
            callback: function (value) {
              if (siteLabels[value].length > 15) {
                return siteLabels[value].substr(0, 15) + "..."; //truncate
              } else {
                return siteLabels[value];
              }
            },
          },
        },
      },
    };
    setSitesBarChartData({ data: sitesChartData, options: sitesChartOptions });
  };
  const initializeRolesBarChart = (lessonCompletionData) => {
    var roleWiseCompleteCount = lessonCompletionData.roleWiseCompleteCount;
    delete roleWiseCompleteCount.admin;
    delete roleWiseCompleteCount.smiadmin;

    roleWiseCompleteCount = Object.entries(roleWiseCompleteCount)
      .sort(([, a], [, b]) => b - a)
      .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

    const rolesChartData = {
      labels: Object.keys(roleWiseCompleteCount).map(
        (x) => x.charAt(0).toUpperCase() + "" + x.substr(1)
      ),
      datasets: [
        {
          label: "Total Complete: ",
          backgroundColor: window.chartColors.blue,
          stack: "Stack 1",
          data: Object.keys(roleWiseCompleteCount).map(
            (x) => roleWiseCompleteCount[x]
          ),
          borderColor: "white",
        },
      ],
    };
    const rolesChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Role:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
        },
        y: {
          ticks: {
            stacked: true,
          },
        },
      },
    };
    setRolesBarChartData({ data: rolesChartData, options: rolesChartOptions });
  };
  const initializeLessonsBarChart = (lessonCompletionData) => {
    var xdata = [];
    var percentcompletedData = [];
    var percentincompleteData = [];
    var mostCompletedLessons = [];
    let xdataCount = 0;
    lessonCompletionData.summary.forEach((o) => {
      if (o.requiredCount > 0) {
        xdata[xdataCount] = o.name;
        percentincompleteData[xdataCount] = Math.round(
          (o.incomplete2 / o.requiredCount) * 100
        );
        percentcompletedData[xdataCount] =
          100 - percentincompleteData[xdataCount];
        mostCompletedLessons.push({
          name: o.name,
          percentincompleteData: percentincompleteData[xdataCount],
          percentcompletedData: percentcompletedData[xdataCount],
        });
        xdataCount++;
      }
    });
    mostCompletedLessons.sort(function (a, b) {
      return b.percentcompletedData - a.percentcompletedData;
    });
    let labels = mostCompletedLessons.slice(0, 5).map((x) => x.name);
    let values = mostCompletedLessons
      .slice(0, 5)
      .map((x) => x.percentcompletedData);
    const lessonsChartData = {
      labels: labels,
      datasets: [
        {
          label: "Completed (%)",
          backgroundColor: window.chartColors.blue,
          stack: "Stack 1",
          data: values,
          borderColor: "white",
        },
      ],
    };
    const lessonsChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Role:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            max: 100,
            min: 0,
          },
        },
        y: {
          ticks: {
            stacked: true,
            callback: function (value, index) {
              if (labels[index].length > 15) {
                return labels[index].substr(0, 15) + "..."; //truncate
              } else {
                return labels[index];
              }
            },
          },
        },
      },
    };
    setLessonssBarChartData({
      data: lessonsChartData,
      options: lessonsChartOptions,
    });
  };

  useEffect(() => {
    var completionReportUrl =
      config.content.url + "lessonReport/lessonCompletionReport.json";
    s3FetchInstance.get(completionReportUrl).then((reportData) => {
      const lessonCompletionData = reportData.data;
      var reportGenTime = Math.round(
        (parseInt(Date.now().toString()) -
          parseInt(lessonCompletionData.addedEpoch)) /
          1000 /
          60
      );
      if (reportGenTime > 60) {
        reportGenTime = Math.round(reportGenTime / 60) + " hours ago";
      } else {
        reportGenTime = Math.round(reportGenTime) + " minutes ago";
      }
      setReportGenTime(reportGenTime);
      initializeMainBarChart(lessonCompletionData);
      initializeSitesBarChart(lessonCompletionData);
      initializeRolesBarChart(lessonCompletionData);
      initializeLessonsBarChart(lessonCompletionData);
      setLessonReportdata(lessonCompletionData);
    });

    var aggregateReportUrl =
      config.content.url + "lessonReport/aggregateReport.json";
    s3FetchInstance.get(aggregateReportUrl).then((reportData) => {
      setAggregateReportData(reportData.data);
    });
  }, []);

  return (
    <div
      className="lessonReportsOverviewPageAsync app"
      tyle={{ width: "100%" }}
    >
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <div className="page-inner">
          <Row style={{ width: "100%", margin: "auto" }}>
            <Card style={{ width: "100%" }}>
              {lessonReportData ? (
                <Card.Body
                  className="m-2 p-3"
                  style={{ width: "100%", height: "450px" }}
                >
                  <h6 className="card-title">
                    {" "}
                    Completion reports
                    <div className="flotRight">
                      Last report generated{" "}
                      <span id="lessonReportGeneratedTime">
                        {reportGenTime}
                      </span>
                    </div>
                  </h6>
                  {mainBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pl-3 pr-3 pr-3 pb-5"
                      data={mainBarChartData.data}
                      options={mainBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              ) : (
                <Card.Body style={{ width: "100%", height: "450px" }}>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <h6 className="card-title">
                      {" "}
                      Lesson Completion Report is being processed. It will take
                      few minutes for the report to be ready.
                    </h6>
                  </Row>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                      <i
                        className="pi pi-spin pi-spinner"
                        style={{ fontSize: "3rem" }}
                      ></i>
                    </Col>
                  </Row>
                </Card.Body>
              )}
            </Card>
          </Row>
          <Row style={{ width: "100%" }}>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title">
                    {" "}
                    Sites with most lesson completion
                  </h6>
                  {sitesBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={sitesBarChartData.data}
                      options={sitesBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title">
                    {" "}
                    Roles with most lesson completion
                  </h6>
                  {rolesBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={rolesBarChartData.data}
                      options={rolesBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title">
                    {" "}
                    Roles with most lesson completion
                  </h6>
                  {lessonsBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={lessonsBarChartData.data}
                      options={lessonsBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
          <Row style={{ width: "100%" }}>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body
                  className="m-2"
                  style={{ width: "100%", height: "290px" }}
                >
                  <h6 className="card-title"> Summary Report </h6>
                  {aggregateReportData ? (
                    <div>
                      <Row className="ml-2 mt-3">
                        <span>
                          Total Users:{" "}
                          {aggregateReportData.reportSummary.totalUsersCount}
                        </span>{" "}
                        <br />
                      </Row>
                      <Row className="ml-2 mt-4">
                        <span>
                          Total Sites:{" "}
                          {aggregateReportData.reportSummary.totalSiteCount}
                        </span>
                        <br />
                      </Row>
                      <Row className="ml-2 mt-4">
                        <span>
                          Total Lessons:{" "}
                          {aggregateReportData.reportSummary.totalLessonsCount}
                        </span>{" "}
                        <br />
                      </Row>
                    </div>
                  ) : (
                    <div></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default Lessonreportsoverview;
