import React, { useEffect, useRef, useState } from "react";
import { Toast, Dialog, Editor } from "primereact";
import { Card, Col, Container, Row, Form } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { get } from "../../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";
import { Chart } from "primereact/chart";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleLeft, faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { post } from "../../../utils/HttpRequest";

const Assessmentquestionreports = () => {
  const toast = useRef(null);
  const navigate = useNavigate();

  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");
  const topicid = params.get("topicid");

  const [visible, setVisible] = useState(false);
  const [validated, setValidated] = useState(false);
  const [text, setText] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");

  const [barChartdata, setBarChartData] = useState(null);
  const [tableRows, setTableRows] = useState([]);
  const [titleText, setTitleText] = useState("");

  const [questionData, setQuestionData] = useState(null);

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(tableRows);

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  const processBarChartData = (assessmentQuestionData, allUsers) => {
    var xdata = [];
    var xlabel = [];
    for (
      let i = 0;
      i < Object.keys(assessmentQuestionData.summary).length;
      i++
    ) {
      if (assessmentQuestionData.topicData.Items[0]["answer" + String(i + 1)]) {
        xdata.push(
          Math.round(
            (assessmentQuestionData.summary["answer" + String(i + 1)] /
              allUsers) *
              100
          )
        );
        xlabel.push((i + 10).toString(36).toUpperCase());
      }
    }
    let chartdata = {
      labels: xlabel,
      datasets: [
        {
          type: "bar",
          label: "Response Percentage",
          backgroundColor: window.chartColors.green,
          stack: "Stack 0",
          data: xdata,
          borderColor: "white",
          borderWidth: 2,
          maxBarThickness: 40,
        },
      ],
    };
    let chartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false,
          text: "Assessment Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "bottom",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
        },
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            autoSkip: false,
            maxRotation: 0,
            minRotation: 0,
          },
        },
        y: {
          ticks: {
            max: 100,
            min: 0,
          },
        },
      },
    };
    setBarChartData({ data: chartdata, options: chartOptions });
  };

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 575);


  const handleResize = () => {
    setIsMobile(window.innerWidth <= 575);
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);
    var url =
      config.api.url +
      "getAssessmentQuestionDetailsAllUsers" +
      "?lessonid=" +
      lessonid +
      "&topicid=" +
      topicid;
    // let assessmentQuestionData = assessmentresponse;
    get(url)
      .then((assessmentQuestionDataResponse) => {
        let assessmentQuestionData = assessmentQuestionDataResponse.data;
        let allUsers = assessmentQuestionData.details.length;
        let assessmentData = assessmentQuestionData.details;
       
        const modifiedData = assessmentData.map((user) => ({
          ...user,
          fullName: `${user.givenName} ${user.familyName}`,
        }));
        

        assessmentQuestionData.details = assessmentQuestionData.details.filter(
          function (d) {
            return d.score != " ";
          }
        );
        let object = {};
        object["question"] = assessmentQuestionData.topicData.Items[0].question;
        object["answer"] = assessmentQuestionData.topicData.Items[0].answer;
        object["answers"] = [];
        for (let i = 1; i <= 10; i++) {
          const key = `answer${i}`;
          if (
            Object.prototype.hasOwnProperty.call(
              assessmentQuestionData.topicData.Items[0],
              key
            )
          ) {
            object["answers"].push(
              assessmentQuestionData.topicData.Items[0][key]
            );
          }
        }
        for (let i = 0; i < assessmentQuestionData.details.length; i++) {
          for (let j = 0; j < 10; j++) {
            if (
              assessmentQuestionData.details[i].answerbyuser ==
              assessmentQuestionData.details[i]["answer" + String(j + 1)]
            ) {
              assessmentQuestionData.details[i].answerCategory = (j + 10)
                .toString(36)
                .toUpperCase();
            }
          }
          const jj = (assessmentQuestionData.details[i].isCorrect =
            assessmentQuestionData.details[i].answerbyuser ===
            assessmentQuestionData.details[i].correctanswer
              ? "TRUE"
              : "FALSE");
         
        }
        let topicorder = assessmentQuestionData.topicData.Items[0].topicorder;
        setTitleText(`Question ${topicorder} : ${allUsers} Total Users`);
        setTableRows(modifiedData);
        setFilteredData(modifiedData);
        processBarChartData(assessmentQuestionData, allUsers);
        setQuestionData(object);
      })
      .catch((err) => {
        console.log("Error ", err);
      });
  }, []);

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? tableRows.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : tableRows;
    const emailpValues = filtered?.map((item) => item.email);
    const searchEmail = [...new Set(emailpValues)];
    setSelectedEmail(searchEmail.join("; "));
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const groupValues = tableRows?.map((item) => item.email);
  const uniqueEmails = [...new Set(groupValues)];
  const [concatenatedString, setConcatenatedString] = useState("");

  useEffect(() => {
    setConcatenatedString(uniqueEmails.join("; "));
  }, [uniqueEmails]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        body: text,
        priority: "normal",
      };
     
      var url =
        config.api.url +
        "getAssessmentQuestionDetailsAllUsers" +
        "?lessonid=" +
        lessonid +
        "&topicid=" +
        topicid;
      post(url, formData)
        .then((response) => {
          if (response.data && response.data !== "") {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: response.data,
            });
          }
        })
        .catch((error) => {
          console.log(error);
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const defaultSorted = [
    {
      dataField: "givenName",
      order: "asc",
    },
  ];
  const trainingRecordsColumns = [
    {
      dataField: "givenName",
      text: "name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.givenName + " " + row.familyName;
      },
    },
    {
      dataField: "siteName",
      text: "Site",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.siteName != "" && row.siteName != "NA" ? row.siteName : "";
      },
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        if (row.status.includes("Failed")) {
          return <div className="colorRed">{row.status}</div>;
        } else {
          return <div className="colorGreen">{row.status}</div>;
        }
      },
    },
    {
      dataField: "score",
      text: "score",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "answerCategory",
      text: "Response",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        if (row.isCorrect === "TRUE") {
          return <div className="colorGreen">{row.answerCategory}</div>;
        } else {
          return <div className="colorRed">{row.answerCategory}</div>;
        }
      },
    },
    {
      dataField: "email",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];

  return (
    <div
      className="assessmentQuestionReportsPage  app"
      tyle={{ width: "100%" }}
    >
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%", marginLeft: "10px" }}>
        <Row style={{ width: "100%" }}>
          <Card className="p-3" style={{ width: "100%", margin: "10px" }}>
            <Card.Body className="p-3" style={{ width: "100%" }}>
              <ol className="breadcrumb">
                <li className="breadcrumb-item active">
                  <a
                    id="assessmentReportBreadCrumb"
                    href={"/assessmentreports?lessonid=" + lessonid}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/assessmentreports?lessonid=" + lessonid);
                    }}
                  >
                    {/* <i className="breadcrumb-icon fa fa-angle-left mr-2" aria-hidden="true"></i> */}
                    <FontAwesomeIcon
                      icon={faAngleLeft}
                      className="breadcrumb-icon mr-2"
                    />
                    Comprehension Report
                  </a>
                </li>
              </ol>
              <h6 className="card-title"> {titleText} </h6>
              <Row style={{ width: "100%" }}>
                <Col xl={6} md={6} lg={6} sm={12}>
                  <p className="pl-2">
                    <strong>Question</strong>
                  </p>
                  <p id="assessmentQuestionReportQuestionText" className="pl-2">
                    {questionData?.question}
                  </p>
                  <p className="pl-2">
                    <strong>Answers</strong>
                  </p>
                  {questionData ? (
                    <div>
                      {questionData.answers.map((item, index) => {
                        if (item != "") {
                          let flag = false;
                          if (item == questionData.answer) {
                            flag = true;
                          }
                          return (
                            <p
                              className="pl-2"
                              key={"answer" + index}
                              id={"answer" + index}
                            >
                              <strong>
                                {" "}
                                {String.fromCharCode(65 + index)}{" "}
                              </strong>
                              &nbsp;
                              <span
                                id="assessmentQuestionReportAnswer1"
                                className={flag ? "font-weight-bold" : ""}
                              >
                                {item}
                              </span>
                            </p>
                          );
                        }
                      })}
                    </div>
                  ) : (
                    <div></div>
                  )}
                </Col>
                <Col xl={6} md={6} lg={6} sm={12} style={{ height: "400px" }}>
                  <h6 className="ml-2">Question Responses</h6>
                  {barChartdata ? (
                    <Chart
                      type="bar"
                      className="ml-2 w-full h-full p-5"
                      data={barChartdata.data}
                      options={barChartdata.options}
                    />
                  ) : (
                    <div></div>
                  )}
                </Col>
              </Row>
              {!isMobile ? (
                <Row className="mt-2" style={{ width: "100%" }}>
                  <h6 className="card-title d-sm-inline-block">
                    Training Record
                  </h6>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setVisible(true)}
                  >
                    <FontAwesomeIcon icon={faEnvelope} />
                  </button>
                  <div className="mt-2" style={{ width: "100%" }}>
                    <Datatable
                      keyField="email"
                      data={tableRows}
                      defaultSorted={defaultSorted}
                      handleSearchChange={handleSearchChange}
                      columns={trainingRecordsColumns}
                      filteredData={filteredData}
                      searchText={searchText}
                    />
                  </div>
                </Row>
              ) : (
                <div className={`alert alert-dark mt-2 ml-2 mr-2 text-center`}>
                  <p> Desktop access is required to view Training Record</p>
                </div>
              )}
            </Card.Body>
          </Card>
        </Row>
        <Dialog
          header="Send Email"
          visible={visible}
          className="mail-box"
          // style={{ width: "35vw" }}
          onHide={() => setVisible(false)}
          dismissableMask={true}
        >
          <Form
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            validated={validated}
          >
            <div className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Control
                  value={selectedEmail || concatenatedString}
                  type="text"
                  name="to"
                  className="form-control input-group"
                />
              </Form.Group>
            </div>
            <div className="mb-3">
              <Form.Group>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  placeholder="subject"
                  name="subject"
                />
              </Form.Group>
            </div>
            <Editor
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="py-3">
              <button type="submit" className="btn btn-primary mr-2">
                Send
              </button>
              <button
                type="button"
                className="btn btn-primary"
                onClick={() => setVisible(false)}
                data-dismiss="modal"
              >
                Cancel
              </button>
            </div>
          </Form>
        </Dialog>
      </Container>
    </div>
  );
};
export default Assessmentquestionreports;
