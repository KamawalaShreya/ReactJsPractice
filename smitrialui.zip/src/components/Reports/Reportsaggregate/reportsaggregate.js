import React, { useEffect, useRef, useState } from "react";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import axios from "axios";
import { Chart } from "primereact/chart";
import "../Lessonreports/Lessonreports.css";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import { Button } from "primereact/button";

const Reportsaggregate = () => {
  const toast = useRef(null);

  const s3FetchInstance = axios.create();

  const [lessonReportData, setLessonReportdata] = useState(null);
  const [aggregateReportData, setAggregateReportData] = useState(null);
  const [reportGenTime, setReportGenTime] = useState(null);

  const [mainBarChartData, setmainBarChartData] = useState({});
  const [sitesBarChartData, setSitesBarChartData] = useState({});
  const [rolesBarChartData, setRolesBarChartData] = useState({});
  const [lessonsBarChartData, setLessonssBarChartData] = useState({});

  const [trainedUsers, setTrainedUsers] = useState({});
  const [trainedUsersOptions, setTrainedUsersOptions] = useState({});

  const [sentimentData, setSentimentData] = useState({});
  const [sentimentOptions, setSentimentOptions] = useState({});

  const [lessoncompletionData, setLessoncompletionData] = useState({});
  const [lessoncompletionDataOptions, setLessoncompletionDataOptions] =
    useState({});

  const [trainedusersperroleData, setTrainedUsersperroleData] = useState({});
  const [userstrainedperroleOptions, setTrainedUsersperroleOptions] = useState(
    {}
  );

  const [usersperroleData, setUsersperroleData] = useState({});
  const [usersperroleOptions, setUsersperroleOptions] = useState({});

  const [fullyTrainedUsersData, setFullyTrainedUsersData] = useState({});
  const [fullyTrainedUsersOptions, setFullyTrainedUsersOptions] = useState({});

  const [percentageFullyTrainedData, setPercentageFullyTrainedData] = useState(
    {}
  );
  const [percentageFullyTrainedOptions, setPercentageFullyTrainedOptions] =
    useState({});

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
    lightgreen: "rgb(155, 235, 52)",
    musterdYellow: "rgb(255, 205, 86)",
    darkpink: "rgb(235, 52, 110)",
    // orange: "rgb(255, 159, 64)",
  };

  // const handleExportCSV = async () => {
  //   try {
  //     // Fetch JSON data from the provided URL
  //     const response = await fetch(
  //       config.content.url + "lessonReport/aggregateReport.json"
  //     );

  //     if (!response.ok) {
  //       throw new Error("Failed to fetch data");
  //     }

  //     const jsonData = await response.json();

  //     // if (!Array.isArray(jsonData) || jsonData.length === 0) {
  //     //   throw new Error("Invalid JSON data");
  //     // }

  //     const csvContent = convertJsonToCsv(jsonData);

  //     const blob = new Blob([csvContent], { type: "text/csv" });

  //     const url = URL.createObjectURL(blob);
  //     const link = document.createElement("a");
  //     link.href = url;
  //     link.download = "data.csv";
  //     link.click();
  //   } catch (error) {
  //     console.error("Error exporting CSV:", error);
  //   }
  // };

  // const convertJsonToCsv = (jsonData, xlsxData) => {
  //   const csvRows = [];
  //   const headers = [];
  //   const valuesz = [];
  //   let tempXlsxData = [];
  //   // Recursive function to flatten nested objects
  //   const flattenObject = (obj, parentKey = "") => {
  //     for (const key in obj) {
  //       const keyWithParent = parentKey ? `${parentKey}_${key}` : key;

  //       if (typeof obj[key] === "object" && obj[key] !== null) {
  //         flattenObject(obj[key], keyWithParent);
  //       } else {
  //         headers.push(keyWithParent);
  //         valuesz.push(obj[key]);
  //         const resultObject = headers.reduce((result, key, index) => {
  //           result[key] = valuesz[index];
  //           return result;
  //         }, {});
  //         tempXlsxData = resultObject;
  //       }
  //     }
  //   };

  //   flattenObject(jsonData);

  //   csvRows.push(headers.join(","));

  //   const addDataRows = () => {
  //     csvRows.push(valuesz.join(","));
  //   };

  //   addDataRows();

  //   return !xlsxData ? csvRows.join("\n") : tempXlsxData;
  // };

  const handleExportExcel = async () => {
    try {
      const response = await fetch(
        config.content.url + "lessonReport/aggregateReport.json"
      );

      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }

      const workbook = XLSX.utils.book_new();
      const sheetObjects = [
        {
          name: "Completion reports",
          columns: ["Lesson Name", "Completed (%)"],
        },
        {
          name: "Sites with most lesson",
          columns: [
            "Site ID",
            "SitePi Total Complete",
            "CRC Total Complete",
            "KP Total Complete",
          ],
        },
        { name: "Roles with most lesson", columns: ["Role", "Complete (%)"] },
        { name: "Most completed lessons", columns: ["Lesson", "Complete (%)"] },
        {
          name: "Fully trained Users",
          columns: ["Fully trained Users", "Value (%)"],
        },
        {
          name: "Required Lesson completion",
          columns: ["Required Lesson completion by Users", "Value (%)"],
        },
        {
          name: "Cumulative user sentiment",
          columns: ["Sentiment", "Value (%)"],
        },
        {
          name: "Fully trained Users per role",
          columns: ["Role", "No of users (%)"],
        },
        { name: "Users per role", columns: ["Role", "No of users (%)"] },
        {
          name: "Fully Trained Users 12 month",
          columns: ["Month", "Total (%)"],
        },
        {
          name: "Percentage Of Fully Trained",
          columns: ["Month", "Total (%)"],
        },
      ];
      [
        mainBarChartData.data,
        sitesBarChartData.data,
        rolesBarChartData.data,
        lessonsBarChartData.data,
        trainedUsers,
        lessoncompletionData,
        sentimentData,
        trainedusersperroleData,
        usersperroleData,
        fullyTrainedUsersData,
        percentageFullyTrainedData,
      ].map((item, i) => {
        let data = [];
        [...item.labels].map((ele, j) => {
          try {
            let obj = {};
            sheetObjects[i].columns.map((col, colindex) => {
              if (colindex == 0) {
                obj[col] = ele;
              } else {
                obj[col] = item.datasets[colindex - 1].data[j];
              }
            });
            data.push(obj);
          } catch (err) {
            console.log(err);
          }
        });
       
        const worksheet = XLSX.utils.json_to_sheet(data);

        XLSX.utils.book_append_sheet(
          workbook,
          worksheet,
          sheetObjects[i].name,
          true
        );
      });

      const excelBuffer = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "array",
      });
      const blob = new Blob([excelBuffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8",
      });

      saveAs(blob, "data.xlsx");
    } catch (error) {
      console.error("Error exporting Excel:", error);
    }
  };

  const initializeMainBarChart = (lessonCompletionData) => {
    var xdata = [];
    var percentcompletedData = [];
    var percentincompleteData = [];
    var percentcompletedPieData = 0;
    var percentincompletePieData = 0;
    var mostCompletedLessons = [];
    let xdataCount = 0;
    lessonCompletionData.summary.forEach((o) => {
      if (o.requiredCount > 0) {
        xdata[xdataCount] = o.name;
        percentincompleteData[xdataCount] = Math.round(
          (o.incomplete2 / o.requiredCount) * 100
        );
        percentcompletedData[xdataCount] =
          100 - percentincompleteData[xdataCount];
        mostCompletedLessons.push({
          name: o.name,
          percentincompleteData: percentincompleteData[xdataCount],
          percentcompletedData: percentcompletedData[xdataCount],
        });
        xdataCount++;
      }
    });
    mostCompletedLessons.sort(function (a, b) {
      return b.percentcompletedData - a.percentcompletedData;
    });
    xdata.map((o, index) => {
      percentcompletedPieData += percentcompletedData[index];
      percentincompletePieData += percentincompleteData[index];
    });
    percentincompletePieData = Math.round(
      percentincompletePieData / xdataCount,
      2
    );
    percentcompletedPieData = 100 - percentincompletePieData;
    

    const bardata = {
      labels: xdata,
      datasets: [
        {
          type: "bar",
          label: "Completed (%)",
          backgroundColor: window.chartColors.green,
          stack: "Stack 0",
          data: percentcompletedData,
          borderColor: "white",
          borderWidth: 2,
          maxBarThickness: 40,
        },
      ],
    };
    const baroptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "bottom",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Title:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          ticks: {
            autoSkip: false,
            maxRotation: 45,
            minRotation: 45,

            callback: function (value) {
              if (xdata[value].length > 40) {
                return xdata[value].substr(0, 40) + "..."; //truncate
              } else {
                return xdata[value];
              }
            },
          },
        },
        y: {
          min: 0,
          max: 100,
        },
      },
    };
    setmainBarChartData({ data: bardata, options: baroptions });
  };
  const initializeSitesBarChart = (lessonCompletionData) => {
    var siteWiseCompleteCount = lessonCompletionData.siteWiseCompleteCount;
    var roleWiseCompleteCount = lessonCompletionData.roleWiseCompleteCount;
    delete roleWiseCompleteCount.admin;
    delete roleWiseCompleteCount.smiadmin;

    roleWiseCompleteCount = Object.entries(roleWiseCompleteCount)
      .sort(([, a], [, b]) => b - a)
      .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

    var siteWiseCompleteCountMain = [];
    var siteLabels = [];
    var threshold = 1;
    let siteCount = 5;
    for (let key in siteWiseCompleteCount) {
      let obj = {};
      var total = 0;
      for (let role of ["sitepi", "crc", "kp"]) {
        if (siteWiseCompleteCount[key][role] == undefined) {
          siteWiseCompleteCount[key][role] = 0;
        }
        obj[role] = siteWiseCompleteCount[key][role];
        total = total + obj[role];
      }

      if (total > threshold && siteWiseCompleteCountMain.length < siteCount) {
        obj["total"] = total;
        obj["label"] = key;
        siteWiseCompleteCountMain.push(obj);
      }
    }
    siteWiseCompleteCountMain.sort(function (a, b) {
      return b.total - a.total;
    });
    siteLabels = siteWiseCompleteCountMain.map((a) => a.label);

    const sitesChartData = {
      labels: siteLabels,
      datasets: [
        {
          label: "SitePi Total Complete: ",
          backgroundColor: window.chartColors.purple,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.sitepi),
          borderColor: "white",
          maxBarThickness: 25,
        },
        {
          label: "CRC Total Complete: ",
          backgroundColor: window.chartColors.green,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.crc),
          borderColor: "white",
          maxBarThickness: 25,
        },
        {
          label: "KP Total Complete: ",
          backgroundColor: window.chartColors.orange,
          stack: "Stack 1",
          data: siteWiseCompleteCountMain.map((x) => x.kp),
          borderColor: "white",
          maxBarThickness: 25,
        },
      ],
    };
    const sitesChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Site:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
        },
        y: {
          ticks: {
            stacked: true,
            callback: function (value) {
              if (siteLabels[value].length > 15) {
                return siteLabels[value].substr(0, 15) + "..."; //truncate
              } else {
                return siteLabels[value];
              }
            },
          },
        },
      },
    };
    setSitesBarChartData({ data: sitesChartData, options: sitesChartOptions });
  };
  const initializeRolesBarChart = (lessonCompletionData) => {
    var roleWiseCompleteCount = lessonCompletionData.roleWiseCompleteCount;
    delete roleWiseCompleteCount.admin;
    delete roleWiseCompleteCount.smiadmin;

    roleWiseCompleteCount = Object.entries(roleWiseCompleteCount)
      .sort(([, a], [, b]) => b - a)
      .reduce((r, [k, v]) => ({ ...r, [k]: v }), {});

    const rolesChartData = {
      labels: Object.keys(roleWiseCompleteCount).map(
        (x) => x.charAt(0).toUpperCase() + "" + x.substr(1)
      ),
      datasets: [
        {
          label: "Total Complete: ",
          backgroundColor: window.chartColors.blue,
          stack: "Stack 1",
          data: Object.keys(roleWiseCompleteCount).map(
            (x) => roleWiseCompleteCount[x]
          ),
          borderColor: "white",
        },
      ],
    };
    const rolesChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Role:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          ticks: {
            max: 100,
          },
        },
        y: {
          ticks: {
            stacked: true,
            max: 100,
          },
        },
      },
    };
    setRolesBarChartData({ data: rolesChartData, options: rolesChartOptions });
  };
  const initializeLessonsBarChart = (lessonCompletionData) => {
    var xdata = [];
    var percentcompletedData = [];
    var percentincompleteData = [];
    var mostCompletedLessons = [];
    let xdataCount = 0;
    lessonCompletionData.summary.forEach((o) => {
      if (o.requiredCount > 0) {
        xdata[xdataCount] = o.name;
        percentincompleteData[xdataCount] = Math.round(
          (o.incomplete2 / o.requiredCount) * 100
        );
        percentcompletedData[xdataCount] =
          100 - percentincompleteData[xdataCount];
        mostCompletedLessons.push({
          name: o.name,
          percentincompleteData: percentincompleteData[xdataCount],
          percentcompletedData: percentcompletedData[xdataCount],
        });
        xdataCount++;
      }
    });
    mostCompletedLessons.sort(function (a, b) {
      return b.percentcompletedData - a.percentcompletedData;
    });
    let labels = mostCompletedLessons.slice(0, 5).map((x) => x.name);
    let values = mostCompletedLessons
      .slice(0, 5)
      .map((x) => x.percentcompletedData);
    const lessonsChartData = {
      labels: labels,
      datasets: [
        {
          label: "Completed (%)",
          backgroundColor: window.chartColors.blue,
          stack: "Stack 1",
          data: values,
          borderColor: "white",
        },
      ],
    };
    const lessonsChartOptions = {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: "y",
      plugins: {
        title: {
          display: false,
          text: "Lesson Completion for all users.",
        },
        legend: {
          onClick: null,
          display: true,
          position: "top",
          labels: {
            color: "rgb(255, 99, 132)",
          },
        },
        tooltips: {
          mode: "index",
          intersect: true,
          callbacks: {
            title: function (tooltipItems, data) {
              var idx = tooltipItems[0].index;
              return "Role:" + data.labels[idx]; //do something with title
            },
          },
        },
      },
      scales: {
        x: {
          stacked: true,
          max: 100,
          min: 0,
        },
        y: {
          ticks: {
            stacked: true,

            callback: function (value, index) {
              if (labels[index].length > 15) {
                return labels[index].substr(0, 15) + "..."; //truncate
              } else {
                return labels[index];
              }
            },
          },
        },
      },
    };
    setLessonssBarChartData({
      data: lessonsChartData,
      options: lessonsChartOptions,
    });
  };

  useEffect(() => {
    var completionReportUrl =
      config.content.url + "lessonReport/lessonCompletionReport.json";
    s3FetchInstance.get(completionReportUrl).then((reportData) => {
      const lessonCompletionData = reportData.data;
      var reportGenTime = Math.round(
        (parseInt(Date.now().toString()) -
          parseInt(lessonCompletionData.addedEpoch)) /
          1000 /
          60
      );
      if (reportGenTime > 60) {
        reportGenTime = Math.round(reportGenTime / 60) + " hours ago";
      } else {
        reportGenTime = Math.round(reportGenTime) + " minutes ago";
      }
      setReportGenTime(reportGenTime);
      initializeMainBarChart(lessonCompletionData);
      initializeSitesBarChart(lessonCompletionData);
      initializeRolesBarChart(lessonCompletionData);
      initializeLessonsBarChart(lessonCompletionData);
      setLessonReportdata(lessonCompletionData);
    });

    var aggregateReportUrl =
      config.content.url + "lessonReport/aggregateReport.json";
    s3FetchInstance.get(aggregateReportUrl).then((reportData) => {
      const TrainedUserspercentage =
        reportData.data.percentOfTotalUsersWith100PTraining;

      const trainedUsersdata = {
        labels: ["% of Users 100%  Trained", "%  of Users 100% Not Trained"],
        datasets: [
          {
            data: [TrainedUserspercentage, 100 - TrainedUserspercentage],
            backgroundColor: [
              window.chartColors.lightgreen,
              window.chartColors.grey,
            ],
            label: "% of users 100% Trained",
          },
        ],
      };

      const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "top",
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label} (%): ${percentage}`;
              },
            },
          },
        },
      };

      const sentimentcomplete = reportData.data.sentimentReport;
      const sentimentdata = {
        labels: ["Positive (%)", "Negative (%)", "Mixed (%)"],
        datasets: [
          {
            data: [
              sentimentcomplete.percentageOfPositive,
              sentimentcomplete.percentageOfNegative,
              sentimentcomplete.percentageOfMixed,
            ],
            backgroundColor: [
              window.chartColors.lightgreen,
              window.chartColors.red,
              window.chartColors.blue,
            ],
            label: "% of users 100% Trained",
          },
        ],
      };

      const semtimentoptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "top",
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label} (%): ${percentage}`;
              },
            },
          },
        },
      };

      const Lessoncompletionpercentage =
        reportData.data.PercentOfReqLessonsCompByAllUsers;

      const Lessoncompletion = {
        labels: [
          "% of Required lesson completed by all users",
          "% of Required lesson not completed by all users",
        ],
        datasets: [
          {
            data: [
              Lessoncompletionpercentage,
              100 - Lessoncompletionpercentage,
            ],
            backgroundColor: [
              window.chartColors.purple,
              window.chartColors.grey,
            ],
            label: "% of users 100% Trained",
          },
        ],
      };

      const lessoncomplitionoptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "top",
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label} (%): ${percentage}`;
              },
            },
          },
        },
      };

      const traineduserpercentage =
        reportData.data.percentageOfRoleWiseTotalusers;

      const userPerRole = {
        labels: [
          "kp",
          "admin",
          "monitor",
          "crc",
          "sitepi",
          "smiadmin",
          "cro",
          "sponser",
        ],
        datasets: [
          {
            data: [
              traineduserpercentage.kp,
              traineduserpercentage.admin,
              traineduserpercentage.monitor,
              traineduserpercentage.crc,
              traineduserpercentage.sitepi,
              traineduserpercentage.smiadmin,
              traineduserpercentage.cro,
              traineduserpercentage.sponser,
            ],
            backgroundColor: [
              window.chartColors.green,
              window.chartColors.blue,
              window.chartColors.purple,
              window.chartColors.grey,
              window.chartColors.musterdYellow,
              window.chartColors.orange,
              window.chartColors.lightgreen,
              window.chartColors.darkpink,
            ],
            label: "% of users 100% Trained",
          },
        ],
      };

      const userPerRoleoptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "top",
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label} (%): ${percentage}`;
              },
            },
          },
        },
      };

      const fullytraineduserpercentage =
        reportData.data.roleWiseFullyTrainedUsersCount;

      const fullytraineduserPerRole = {
        labels: [
          "kp",
          "admin",
          "monitor",
          "crc",
          "sitepi",
          "smiadmin",
          "cro",
          "sponser",
        ],
        datasets: [
          {
            data: [
              fullytraineduserpercentage.kp,
              fullytraineduserpercentage.admin,
              fullytraineduserpercentage.monitor,
              fullytraineduserpercentage.crc,
              fullytraineduserpercentage.sitepi,
              fullytraineduserpercentage.smiadmin,
              fullytraineduserpercentage.cro,
              fullytraineduserpercentage.sponser,
            ],
            backgroundColor: [
              window.chartColors.green,
              window.chartColors.blue,
              window.chartColors.purple,
              window.chartColors.grey,
              window.chartColors.musterdYellow,
              window.chartColors.orange,
              window.chartColors.lightgreen,
              window.chartColors.darkpink,
            ],
            label: "% of users 100% Trained",
          },
        ],
      };

      const fullyTrainedUserPerRoleoptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "top",
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
          tooltip: {
            mode: "index",
            intersect: true,
            callbacks: {
              label: function (tooltipItem) {
                const label = tooltipItem.label;
                const percentage =
                  tooltipItem.dataset.data[tooltipItem.dataIndex];
                return `${label} (%): ${percentage}`;
              },
            },
          },
        },
      };

      const dataArray = Object.values(
        reportData.data.totalUsersWith100PTrainingFor12Months
      );

      const TrainedUsers12 = {
        labels: [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "september",
          "october",
          "november",
          "december",
        ],
        datasets: [
          {
            label: "Total",
            data: dataArray,
            fill: false,
            borderColor: window.chartColors.blue,
            backgroundColor: window.chartColors.blue,
            tension: 0.4,
          },
        ],
      };

      const TrainedUsers12options = {
        stacked: false,
        maintainAspectRatio: false,
        aspectRatio: 0.6,
        plugins: {
          legend: {
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
        },
        scales: {
          x: {
            // grid: {
            //   color: 'red',
            // },
          },
          y: {
            type: "linear",
            display: true,
            position: "left",
          },
        },
      };

      const totaluserper = Object.values(
        reportData.data.percentageOfTotalUsersWith100PTrainingFor12Months
      );

      const PertrainedUsers12 = {
        labels: [
          "January",
          "February",
          "March",
          "April",
          "May",
          "June",
          "July",
          "August",
          "september",
          "october",
          "november",
          "december",
        ],
        datasets: [
          {
            label: "Total(%)",
            data: totaluserper,
            fill: false,
            borderColor: window.chartColors.blue,
            backgroundColor: window.chartColors.blue,

            tension: 0.4,
          },
        ],
      };

      const PertrainedUsers12options = {
        stacked: false,
        maintainAspectRatio: false,
        aspectRatio: 0.6,
        plugins: {
          legend: {
            labels: {
              color: "rgb(255, 99, 132)",
            },
          },
        },
        scales: {
          x: {
            // grid: {
            //   color: 'red',
            // },
          },
          y: {
            type: "linear",
            display: true,
            position: "left",
          },
        },
      };

      setTrainedUsers(trainedUsersdata);
      setTrainedUsersOptions(options);

      setSentimentData(sentimentdata);
      setSentimentOptions(semtimentoptions);

      setLessoncompletionData(Lessoncompletion);
      setLessoncompletionDataOptions(lessoncomplitionoptions);

      setUsersperroleData(userPerRole);
      setUsersperroleOptions(userPerRoleoptions);

      setTrainedUsersperroleData(fullytraineduserPerRole);
      setTrainedUsersperroleOptions(fullyTrainedUserPerRoleoptions);

      setFullyTrainedUsersData(TrainedUsers12);
      setFullyTrainedUsersOptions(TrainedUsers12options);

      setPercentageFullyTrainedData(PertrainedUsers12);
      setPercentageFullyTrainedOptions(PertrainedUsers12options);

      setAggregateReportData(reportData.data);
    });
  }, []);

  return (
    <div
      className="lessonReportsOverviewPageAsync app"
      tyle={{ width: "100%" }}
    >
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <div className="page-inner">
          <Button
            icon="pi pi-download"
            rounded
            severity="secondary"
            style={{ background: "#4d4d4d", margin: "10px" }}
            onClick={() => handleExportExcel()}
          />
          {/* <button
            className="btn btn-secondary buttons-copy buttons-html5 mr-2 mb-3"
            onClick={handleExportExcel}
          >
            EXCEL
          </button> */}
          <Row style={{ width: "100%", margin: "auto", marginRight: "10px" }}>
            <Card style={{ width: "100%" }}>
              {lessonReportData ? (
                <Card.Body
                  className="m-2 p-3"
                  style={{ width: "100%", height: "450px" }}
                >
                  <h6 className="card-title">
                    {" "}
                    Completion Reports
                    <div className="flotRight" style={{ fontSize: "12px" }}>
                      Last report generated{" "}
                      <span id="lessonReportGeneratedTime">
                        {reportGenTime}
                      </span>
                    </div>
                  </h6>
                  {mainBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pl-3 pr-3 pr-3 pb-5"
                      data={mainBarChartData.data}
                      options={mainBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              ) : (
                <Card.Body style={{ width: "100%", height: "450px" }}>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <h6 className="card-title">
                      {" "}
                      Lesson Completion Report is being processed. It will take
                      few minutes for the report to be ready.
                    </h6>
                  </Row>
                  <Row className="p-3" style={{ width: "100%" }}>
                    <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                      <i
                        className="pi pi-spin pi-spinner"
                        style={{ fontSize: "3rem" }}
                      ></i>
                    </Col>
                  </Row>
                </Card.Body>
              )}
            </Card>
          </Row>
          <Row style={{ width: "100%" }}>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title">
                    {" "}
                    Sites With Most Lesson Completion
                  </h6>
                  {sitesBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={sitesBarChartData.data}
                      options={sitesBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title">
                    {" "}
                    Roles With Most Lesson Completion
                  </h6>
                  {rolesBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={rolesBarChartData.data}
                      options={rolesBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
            <Col lg={4} xl={4}>
              <Card style={{ width: "100%" }}>
                <Card.Body style={{ width: "100%", height: "350px" }}>
                  <h6 className="card-title"> Most Completed Lessons</h6>
                  {lessonsBarChartData ? (
                    <Chart
                      type="bar"
                      className="w-full h-full pt-5 pb-7 pr-2 pl-2"
                      data={lessonsBarChartData.data}
                      options={lessonsBarChartData.options}
                    />
                  ) : (
                    <div style={{ width: "100%", height: "250px" }}></div>
                  )}
                </Card.Body>
              </Card>
            </Col>
          </Row>
          <Row style={{ width: "100%" }}>
            <Card style={{ width: "100%" }}>
              <Card.Body className="m-2" style={{ width: "100%" }}>
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <h6 className="card-title"> Summary Report </h6>
                  {aggregateReportData ? (
                    <div style={{ display: "flex", padding: "0 40px" }}>
                      <Row className="ml-2 m-3">
                        <span>
                          Total Users:{" "}
                          {aggregateReportData.reportSummary.totalUsersCount}
                        </span>{" "}
                        <br />
                      </Row>
                      <Row className="ml-2 m-3">
                        <span>
                          Total Sites:{" "}
                          {aggregateReportData.reportSummary.totalSiteCount}
                        </span>
                        <br />
                      </Row>
                      <Row className="ml-2 m-3">
                        <span>
                          Total Lessons:{" "}
                          {aggregateReportData.reportSummary.totalLessonsCount}
                        </span>{" "}
                        <br />
                      </Row>
                    </div>
                  ) : (
                    <div></div>
                  )}
                </div>
                <Row style={{ marginRight: "10px" }}>
                  <Col lg={4} xl={4}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title"> Fully Trained Users</h6>
                        {trainedUsers ? (
                          <Chart
                            type="pie"
                            className="ml-2 piechartreportview"
                            data={trainedUsers}
                            options={trainedUsersOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col lg={4} xl={4}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">
                          {" "}
                          Required Lesson Completion By All Users
                        </h6>
                        {lessoncompletionData ? (
                          <Chart
                            type="pie"
                            className="ml-2 piechartreportview"
                            data={lessoncompletionData}
                            options={lessoncompletionDataOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col lg={4} xl={4}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">
                          {" "}
                          Cumulative User Sentiment
                        </h6>
                        {sentimentData ? (
                          <Chart
                            type="pie"
                            className="ml-2 piechartreportview"
                            data={sentimentData}
                            options={sentimentOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row style={{ marginRight: "10px" }}>
                  <Col lg={6} xl={6}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">
                          Fully Trained Users Per Role
                        </h6>
                        {usersperroleData ? (
                          <Chart
                            type="pie"
                            className="ml-2 piechartreportview"
                            data={trainedusersperroleData}
                            options={userstrainedperroleOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col lg={6} xl={6}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">Users Per Role</h6>
                        {usersperroleData ? (
                          <Chart
                            type="pie"
                            className="ml-2 piechartreportview"
                            data={usersperroleData}
                            options={usersperroleOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
                <Row style={{ marginRight: "10px" }}>
                  <Col lg={5} xl={6}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">
                          Fully Trained Users For 12 Months (Last Year)
                        </h6>
                        {fullyTrainedUsersData ? (
                          <Chart
                            type="line"
                            className="ml-2 piechartreportview"
                            data={fullyTrainedUsersData}
                            options={fullyTrainedUsersOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col lg={5} xl={6}>
                    <Card style={{ width: "100%" }}>
                      <Card.Body style={{ width: "100%", height: "350px" }}>
                        <h6 className="card-title">
                          Percentage Of Fully Trained Users For 12 Months (Last
                          Year)
                        </h6>
                        {fullyTrainedUsersData ? (
                          <Chart
                            type="line"
                            className="ml-2 piechartreportview"
                            data={percentageFullyTrainedData}
                            options={percentageFullyTrainedOptions}
                          />
                        ) : (
                          <div style={{ width: "100%", height: "250px" }}></div>
                        )}
                      </Card.Body>
                    </Card>
                  </Col>
                </Row>
              </Card.Body>
            </Card>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default Reportsaggregate;
