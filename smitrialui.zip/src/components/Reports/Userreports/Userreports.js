import { Card, Col, Container, Row } from "react-bootstrap";
import React, { useEffect, useState } from "react";

import { Chart } from "primereact/chart";
import Header from "../../Header/Header";
import { Toast } from "primereact/toast";
import config from "../../../config/config.json";
import { get } from "../../../utils/HttpRequest";
import { useRef } from "react";

const Userreports = () => {
  const toast = useRef(null);

  const search = window.location.search;
  const params = new URLSearchParams(search);
  const user = params.get("user");

  const [userDetails, setUserDetails] = useState({});
  const [completionReportData, setCompletionReportData] = useState(null);

  const [barChartData, setBarChartData] = useState({});
  const [barChartOptions, setBarChartOptions] = useState({});

  const [pieChartData, setPieChartData] = useState({});
  const [pieChartOptions, setPieChartOptions] = useState({});

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  useEffect(() => {
    function displayUserReportData(lessonCompletionDataResponse) {
      let lessonCompletionData = lessonCompletionDataResponse;
      var xdata = [];
      var percentcompletedData = [];
      var percentincompleteData = [];
      var percentcompletedPieData = 0;
      var percentincompletePieData = 0;
      let requiredLessonCount = 0;
      lessonCompletionData.forEach((o, i) => {
        if (o.lessonRequired === "required") {
          xdata[i] = o.name;
          if (o.status === "completed") {
            percentcompletedData[i] = 100;
          } else if (o.status === "incomplete") {
            percentincompleteData[i] = 100;
          }
        }
      });

      lessonCompletionData.forEach((o) => {
        if (o.status === "completed" && o.lessonRequired === "required") {
          percentcompletedPieData++;
          requiredLessonCount++;
        } else if (
          o.status === "incomplete" &&
          o.lessonRequired === "required"
        ) {
          percentincompletePieData++;
          requiredLessonCount++;
        }
      });
      percentcompletedPieData = Math.round(
        (percentcompletedPieData * 100) / requiredLessonCount
      );
      percentincompletePieData = Math.round(
        (percentincompletePieData * 100) / requiredLessonCount
      );

      const bardata = {
        labels: xdata,
        datasets: [
          {
            type: "bar",
            label: "Completed",
            backgroundColor: window.chartColors.green,
            stack: "Stack 0",
            data: percentcompletedData,
            borderColor: "white",
            borderWidth: 2,
            maxBarThickness: 40,
          },
          {
            type: "bar",
            label: "Incomplete",
            backgroundColor: window.chartColors.red,
            stack: "Stack 0",
            data: percentincompleteData,
            borderColor: "white",
            borderWidth: 2,
            maxBarThickness: 40,
          },
        ],
      };
      const baroptions = {
        responsive: true,
        plugins: {
          title: {
            display: false,
            text: "Lesson Completion for all users.",
          },
          legend: {
            onClick: null,
            display: true,
            position: "right",
            labels: {
              fontColor: "rgb(255, 99, 132)",
            },
          },
          tooltips: {
            mode: "index",
            intersect: true,
            callbacks: {
              title: function (tooltipItems, data) {
                var idx = tooltipItems[0].index;
                return "Title:" + data.labels[idx]; //do something with title
              },
            },
          },
        },
        scales: {
          x: {
            stacked: true,
            ticks: {
              autoSkip: false,
              maxRotation: 45,
              minRotation: 45,
              callback: function (value) {
                if (xdata[value].length > 15) {
                  return xdata[value].substr(0, 15) + "..."; //truncate
                } else {
                  return xdata[value];
                }
              },
            },
          },
          y: {
            ticks: {
              max: 100,
              min: 0,
            },
          },
        },
      };
      setBarChartData(bardata);
      setBarChartOptions(baroptions);

      const data = {
        datasets: [
          {
            data: [percentcompletedPieData, percentincompletePieData],
            backgroundColor: [window.chartColors.green, window.chartColors.red],
            label: "Dataset 1",
          },
        ],
        labels: ["Completed", "Incomplete"],
      };
      const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          title: {
            display: false,
            text: "",
          },
          legend: {
            onClick: null,
            display: true,
            position: "bottom",
            labels: {
              fontColor: "rgb(255, 99, 132)",
            },
          },
          tooltips: {
            mode: "index",
            intersect: true,
          },
        },
      };
      setPieChartData(data);
      setPieChartOptions(options);
    }
   

    // get site info
    let getUserDetailsUrl = config.api.url + "getUserDetails/" + user;
    let getCompletionDataurl =
      config.api.url + "getLessonsCompletionDetailsOneUser/" + user;
    get(getUserDetailsUrl).then((response) => {
      setUserDetails(response.data);
    });

    get(getCompletionDataurl)
      .then((reportData) => {
        setCompletionReportData(reportData.data);
        displayUserReportData(reportData.data);
      })
      .catch((error) => {
        console.log("Error ", error);
      });
  }, []);

  return (
    <div className="userReportsPage app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%", marginLeft: "10px" }}>
        <Row style={{ width: "100%" }}>
          {/* <div className="page-inner" style={{ width: '100%' }}> */}
          <Card style={{ width: "100%", margin: "10px" }}>
            {completionReportData ? (
              <Card.Body style={{ width: "100%" }}>
                <h6 className="card-title float-left ml-2">
                  {userDetails && completionReportData ? (
                    <div>
                      <h6 className="card-title">
                        User Completion Report for{" "}
                        {userDetails.givenName + " " + userDetails.familyName}
                      </h6>
                    </div>
                  ) : (
                    ""
                  )}
                </h6>
                <Row style={{ width: "100%" }} className="ml-2 mt-2">
                  <Col xl={8} md={8} lg={8} sm={6}>
                    <div>
                      <span className="d-block float-left mb-3">
                        Status by Required Lesson
                      </span>
                      <Chart
                        type="bar"
                        className="ml-2"
                        data={barChartData}
                        options={barChartOptions}
                      />
                    </div>
                  </Col>

                  <Col xl={4} md={4} lg={4} sm={6}>
                    <div style={{ height: "250px" }}>
                      <span className="d-flex justify-content-center mb-4">
                        Required Curriculum Completion
                      </span>
                      <Chart
                        type="pie"
                        className="ml-2"
                        data={pieChartData}
                        options={pieChartOptions}
                      />
                    </div>
                  </Col>
                </Row>
              </Card.Body>
            ) : (
              <Card.Body style={{ width: "100%", height: "450px" }}>
                <Row className="p-3" style={{ width: "100%" }}>
                  <h6 className="card-title"> {/* Loading Message */}</h6>
                </Row>
                <Row className="p-3" style={{ width: "100%" }}>
                  <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                    <i
                      className="pi pi-spin pi-spinner"
                      style={{ fontSize: "3rem" }}
                    ></i>
                  </Col>
                </Row>
              </Card.Body>
            )}
          </Card>
          {/* </div> */}
        </Row>
      </Container>
    </div>
  );
};
export default Userreports;
