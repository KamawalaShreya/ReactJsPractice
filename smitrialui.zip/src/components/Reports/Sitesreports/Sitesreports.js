import React, { useEffect, useRef, useState } from "react";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import Datatable from "../../Common/Datatable";
import { post } from "../../../utils/HttpRequest";
import { useNavigate } from "react-router-dom";

const Sitesreports = () => {
  const toast = useRef(null);
  const navigate = useNavigate();

  const [sitesReportData, setSitesReportData] = useState([]);

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(sitesReportData);

  useEffect(() => {
    let sitesReportsUrl = config.api.url + "sitesReport";
    var fileName = Date.now().toString();
    post(sitesReportsUrl, JSON.stringify({ fileName: fileName })).then(
      (reportData) => {
        setSitesReportData(reportData.data);
        setFilteredData(reportData.data);
      }
    );
  }, []);

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? sitesReportData.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : sitesReportData;
    setFilteredData(filtered);
    setSearchText(searchText);
  };
  const sitesReportColumn = [
    {
      dataField: "sitename",
      text: "Site Code",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <a
            href={"/sitedetails?siteid=" + row.siteid}
            onClick={(e) => {
              e.preventDefault();
              navigate("/sitedetails?siteid=" + row.siteid);
            }}
          >
            {row.sitename}
          </a>
        );
      },
    },
    {
      dataField: "description",
      text: "Site Description",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "address",
      text: "Address",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "country",
      text: "Country",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "userCount",
      text: "No. Of Users",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
  ];
  const defaultSorted = [
    {
      dataField: "sitename",
      order: "asc",
    },
  ];

  return (
    <div className="sitesReportsPage app" tyle={{ width: "100%" }}>
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }}>
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card className="p-3" style={{ width: "100%", margin: "10px" }}>
            {sitesReportData && sitesReportData.length ? (
              <Card.Body className="p-3" style={{ width: "100%" }}>
                <Row style={{ width: "100%" }}>
                  <h6 className="card-title float-left">Sites Reports:</h6>
                </Row>
                <div className="mt-2" style={{ width: "100%" }}>
                  <Datatable
                    keyField="siteid"
                    data={sitesReportData}
                    defaultSorted={defaultSorted}
                    handleSearchChange={handleSearchChange}
                    columns={sitesReportColumn}
                    filteredData={filteredData}
                    searchText={searchText}
                  />
                </div>
              </Card.Body>
            ) : (
              <Card.Body style={{ width: "100%", height: "450px" }}>
                <Row className="p-3" style={{ width: "100%" }}>
                  <h6 className="card-title">
                    {" "}
                    Site Report is being processed.
                  </h6>
                </Row>
                <Row className="p-3" style={{ width: "100%" }}>
                  <Col className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                    <i
                      className="pi pi-spin pi-spinner"
                      style={{ fontSize: "3rem" }}
                    ></i>
                  </Col>
                </Row>
              </Card.Body>
            )}
          </Card>
        </Row>
      </Container>
    </div>
  );
};
export default Sitesreports;
