const resizeImage = (imgEl) => {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  const MAX_WIDTH = 700;
  // var MAX_HEIGHT = 400;
  var width = imgEl.width;
  var height = imgEl.height;
  const ratio = height / width;
  const MAX_HEIGHT = MAX_WIDTH * ratio;
  if (width > MAX_WIDTH) {
    width = MAX_WIDTH;
  }

  if (height > MAX_HEIGHT) {
    height = MAX_HEIGHT;
  }
  canvas.width = width;
  canvas.height = height;

  ctx.drawImage(imgEl, 0, 0, canvas.width, canvas.height);
  return canvas.toDataURL();
};
export default resizeImage;
