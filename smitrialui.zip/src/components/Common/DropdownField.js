import React from "react";
import { ErrorMessage } from "formik";
import { Dropdown } from "primereact/dropdown";

const DropdownField = ({
  field,
  form,
  options,
  label,
  changeDetector,
  ...rest
}) => {
  return (
    <div className="p-field">
      <label htmlFor={field.name}>{label}</label>
      <Dropdown
        {...field}
        {...rest}
        options={options}
        style={{ width: "100%" }}
        onChange={(e) => {
          if (changeDetector) {
            changeDetector(e.value);
          }
          form.setFieldValue(field.name, e.value);
        }}
      />
      <ErrorMessage name={field.name} component="div" className="p-error" />
    </div>
  );
};

export default DropdownField;
