// /* eslint-disable jsx-a11y/anchor-is-valid */
import React from "react";
import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory, {
  PaginationProvider,
  PaginationTotalStandalone,
  PaginationListStandalone,
  SizePerPageDropdownStandalone,
} from "react-bootstrap-table2-paginator";
import copy from "copy-to-clipboard";
import "./Datatable.css";
import { Col, Form, Row } from "react-bootstrap";
import { renderToStaticMarkup } from "react-dom/server";

const CustomPaginationTotal = ({ from, to, size, totalSize, isFiltered }) => {
  return (
    <>
      <p className="pl-3 text-left">
        Showing {from} to {to} of {size} entries{" "}
        {isFiltered &&
          `(filtered from ${totalSize}
        total entries)`}
      </p>
    </>
  );
};

function Datatable(props) {
  const {
    isActionEnable = true,
    isVisibleText = true,
    showrow = true,
    Pagination = true,
    sizePerPage = 10,
  } = props;
  const options = {
    custom: true,
    totalSize: props?.filteredData?.length || 0,
    // showTotal: true,
    sizePerPage: sizePerPage,
    sizePerPageList: [
      {
        text: "10",
        value: 10,
      },
      {
        text: "25",
        value: 25,
      },
      {
        text: "50",
        value: 50,
      },
      {
        text: "100",
        value: 100,
      },
    ],
  };

  const csvFormatter = (cell) => {
    return cell;
  };

  const csvColumns = props?.columns?.map((col) => ({
    dataField: col.dataField,
    text: col.text,
    formatter: csvFormatter,
  }));
  const printContentId = "print-content";

  const exportAndPrintData = () => {
    var win = window.open("", "");

    const htmlContent = `
      <html>
        <head>
          <title>Print Page</title>
          <link rel="stylesheet" href="link-to-your-styles.css" type="text/css">
          <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
          <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.20.0/bootstrap-table.min.css" rel="stylesheet">
        </head>
        <body>
          <div id="${printContentId}">
          <h3>SMi Trial</h3>
            <!-- Include the content you want to print here -->
          </div>
          <script>
            // Trigger the print action after the content is loaded
            window.onload = function () {
              window.print();
              window.close();
            };
          </script>
          <!-- Bootstrap and Bootstrap Table JavaScript CDN links -->
          <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-table/1.20.0/bootstrap-table.min.js"></script>
        </body>
        
      </html>
    `;

    win.document.write(htmlContent);
    win.document.close();

    const printContent = win.document.getElementById(printContentId);
    if (printContent) {
      const componentHtml = renderToStaticMarkup(
        <BootstrapTable
          keyField="id"
          data={props?.filteredData}
          defaultSorted={props.defaultSorted ? props.defaultSorted : {}}
          columns={props?.columns?.slice(0, -1)}
          striped
        />
      );
      printContent.innerHTML = componentHtml;
    }
  };

  return (
    <Row>
      <Col lg={12}>
        <div className="main_datatable">
          <PaginationProvider pagination={paginationFactory({ ...options })}>
            {({ paginationProps, paginationTableProps }) => {
              // console.log({ paginationTableProps });
              return (
                <div className="datatable" key={"i"}>
                  <Row className="m-auto justify-content-between pb-3">
                    {showrow && (
                      <Col md={3} className="custom-dropdown pl-0">
                        <span className="d-flex align-items-center py-3 pl-3">
                          Show{" "}
                          <SizePerPageDropdownStandalone {...paginationProps} />
                          entries
                        </span>
                      </Col>
                    )}
                    <Col md={3}>
                      {isActionEnable && (
                        <div className="dt-buttons btn-group">
                          <button
                            className="btn btn-secondary buttons-copy buttons-html5"
                            onClick={() =>
                              copy(JSON.stringify(props?.filteredData))
                            }
                          >
                            Copy
                          </button>
                          <button
                            className="btn btn-secondary buttons-copy buttons-html5"
                            onClick={() => {
                              const csvData = props?.filteredData?.map((item) =>
                                csvColumns.map((col) =>
                                  csvFormatter(item[col.dataField])
                                )
                              );

                              const csvContent =
                                csvColumns.map((col) => col.text).join(",") +
                                "\n" +
                                csvData.map((row) => row.join(",")).join("\n");

                              const blob = new Blob([csvContent], {
                                type: "text/csv",
                              });
                              const url = URL.createObjectURL(blob);
                              const link = document.createElement("a");
                              link.href = url;
                              link.download = "data.csv";
                              link.click();
                            }}
                          >
                            CSV
                          </button>

                          <button
                            className="btn btn-secondary buttons-copy buttons-html5"
                            onClick={exportAndPrintData}
                          >
                            Print
                          </button>
                        </div>
                      )}
                    </Col>
                    {isVisibleText && (
                      <Col md={3}>
                        <div className="dataTables_filter d-flex align-items-center">
                          <Form.Label className="mb-0 mr-2">
                            Search:{" "}
                          </Form.Label>
                          <Form.Control
                            type="search"
                            placeholder="Search"
                            aria-controls="newsiteListTable"
                            onChange={(data) => {
                              props?.handleSearchChange(data);
                            }}
                            value={props?.searchText}
                            className="form-control mr-sm-2"
                          />
                        </div>
                      </Col>
                    )}
                  </Row>
                  <div id={printContentId}>
                    {props?.Pagination == false ? (
                      <BootstrapTable
                        keyField={props?.keyField ? props?.keyField : "id"}
                        data={props?.filteredData}
                        columns={props?.columns}
                        striped
                        defaultSorted={
                          props.defaultSorted ? props.defaultSorted : undefined
                        }
                        search={{ searchText: props?.searchText }}
                        bordered={true}
                        noDataIndication={
                          !props?.filteredData.length && (
                            <p
                              style={{
                                textAlign: "center",
                              }}
                            >
                              {props?.searchText
                                ? "No matching records found"
                                : "No data available in table"}
                            </p>
                          )
                        }
                        pagination={paginationProps}
                        {...paginationTableProps}
                      />
                    ) : (
                      <BootstrapTable
                        keyField={props?.keyField ? props?.keyField : "id"}
                        data={props?.filteredData}
                        columns={props?.columns}
                        striped
                        defaultSorted={
                          props.defaultSorted ? props.defaultSorted : undefined
                        }
                        noDataIndication={
                          !props?.filteredData.length && (
                            <p
                              style={{
                                textAlign: "center",
                              }}
                            >
                              {props?.searchText
                                ? "No matching records found"
                                : "No data available in table"}
                            </p>
                          )
                        }
                        search={{ searchText: props?.searchText }}
                        bordered={true}
                        pagination={paginationProps}
                        {...paginationTableProps}
                      />
                    )}
                    {Pagination && (
                      <PaginationTotalStandalone
                        {...{
                          ...paginationProps,
                          paginationTotalRenderer: (from, to, size) => (
                            <>
                              <CustomPaginationTotal
                                from={from}
                                to={to}
                                size={size}
                                totalSize={props.data?.length}
                                isFiltered={props?.searchText}
                              />
                            </>
                          ),
                        }}
                      />
                    )}
                    {Pagination && (
                      <PaginationListStandalone {...paginationProps} />
                    )}
                  </div>
                </div>
              );
            }}
          </PaginationProvider>
        </div>
      </Col>
    </Row>
  );
}

export default Datatable;
