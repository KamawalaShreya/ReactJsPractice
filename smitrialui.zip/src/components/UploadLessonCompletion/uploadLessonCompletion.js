import { useEffect, useRef, useState } from "react";
import Header from "../Header/Header";
import { Card, Row, Col, Container, Form } from "react-bootstrap";
import { MultiSelect } from "primereact/multiselect";
import { Button } from "primereact/button";
import axios from "axios";
// import { read, utils } from "xlsx";
import { post } from "../../utils/HttpRequest";
import { Toast } from "primereact/toast";
import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import "./uploadLessonCompletion.css";
import { CsvFileTableUploadLessonCompletion } from "../Exceluploadview/SampleTableFiles/SampleTables";
import ExcelErrorDialog from "../Exceluploadview/ExcelErrorDialog";
import HelpDialog from "../Exceluploadview/HelpDialog";

const UploadLessonCompletion = () => {
  const toast = useRef(null);

  const [lessonIdData, setlessonIdData] = useState([]);
  const [selectedLessonId, setSelectedLessonId] = useState(null);
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [visibleHelpDialog, setVisibleHelpDialog] = useState(false);
  const [fileChooserLabel, setFileChooserLabel] = useState(
    "Choose XLS/XLSX file"
  );

  const [visibleExcelErrorDialog, setVisibleExcelErrorDialog] = useState(false);

  const [dialogTitle, setDialogTitle] = useState(
    "Following records require user attention"
  );
  const [errorExcelData, setErrorExcelData] = useState({});
  const [uploadLessonModal] = useState(true);

  const getLessonsData = async () => {
    try {
      const url = config.api.url + "getLessons";
      get(url).then((response) => {
        let lessonIds = [];
        response.data.forEach((lesson) => {
          if (
            lesson.status !== "review" &&
            lesson.lessontype === "regularlesson"
          ) {
            lessonIds.push(lesson.lessonid);
          
          }
        });
        setlessonIdData(response.data);
      });
    } catch (error) {
      toast.current.show({
        severity: "error",
        summary: "something want wrong",
        detail: "something want wrong.",
      });
    }
  };

  useEffect(() => {
    getLessonsData();
  }, []);

  const resetFileInput = () => {
    setFile(null);
    setFileChooserLabel("Choose XLS/XLSX file");
    setIsUploading(false);
  };

  const handleFileChange = (e) => {
  
    if (e.target.files && e.target.files.length) {
      setFile(e.target.files[0]);
      setFileChooserLabel(e.target.files[0].name);
    } else {
      resetFileInput();
    }
  };

  const createExcelErrorTable = async (data) => {
    setVisibleExcelErrorDialog(true);
    setErrorExcelData(data);
    var sheet_data = data.errorRecords;
    if (sheet_data.length === 0) {
      setDialogTitle("All Valid records found");
    } else {
      setDialogTitle("Following records requires user attention");
    }
    if (data.successRecordsLength === 0) {
      setDialogTitle("No Valid records found");
    }
  };

  const CheckExcelFile = async (fileName) => {
    const s3UploadInstance = axios.create();
    var url = config.api.url + "checkExcelProcessStatus";
    post(url, JSON.stringify({ fileName: fileName }))
      .then((response) => {
        s3UploadInstance.get(response.data.s3url).then((response) => {
          createExcelErrorTable(response.data);
          resetFileInput();
          // props.excelDialogOnClose(false);
        });
      })
      .catch(async (error) => {
        console.log(
          "Error in CheckExcelFile ",
          error,
          "status ",
          error.response.status
        );
        await new Promise((r) => setTimeout(r, 20000));
        CheckExcelFile(fileName);
      });
  };

  const processAndUploadFile = async () => {
    function get_file_name() {
      return Date.now().toString() + ".csv";
    }
    var excelFileName = "uploadLessonCompletion_" + get_file_name();
    var jsonBody = {
      lessonids: selectedLessonId,
      fileName: excelFileName,
      fileType: file.type,
      userEmail: localStorage.getItem("email"),
    };

    function errorAction(errorDesc, error) {
    
      toast.current.show({
        severity: "error",
        summary: "File Upload",
        detail: "Something went Wrong!",
      });
    }

    let uploadUrl = config.api.url + "uploadLessonCompletion";
    const s3UploadInstance = axios.create();

    // Passing file details to get the signedUrl
    post(uploadUrl + "?upload=true", JSON.stringify(jsonBody))
      .then(async (firstUploadResponse) => {
        if (
          firstUploadResponse.data.signedURL !== undefined &&
          firstUploadResponse.data.signedURL !== ""
        ) {
          let lessonids = firstUploadResponse.data.lessonIdsFoundArray;
          jsonBody["lessonids"] = lessonids;
          // Uploading file to the signedUrl
          s3UploadInstance
            .put(firstUploadResponse.data.signedURL, file, {
              headers: { "Content-Type": jsonBody.fileType },
            })
            .then(async () => {
              var newFileUrl = firstUploadResponse.data.signedURL
                .split("?")[0]
                .substr(6);
              console.info("s3-upload done: ", newFileUrl);

              // Processing the uploaded file from here
              post(uploadUrl + "?process=true", JSON.stringify(jsonBody))
                .then(async (thirdUploadResponse) => {
                  console.info("s3-upload done: ", thirdUploadResponse.data);
                  await CheckExcelFile(excelFileName.replace(".csv", ".json"));
                })
                .catch(async (error3) => {
                  console.log("Error3 ", error3);
                  await CheckExcelFile(excelFileName.replace(".csv", ".json"));
                });
            })
            .catch((error2) => {
              errorAction("error 2nd Upload", error2);
            });
        } else {
         
          toast.current.show({
            severity: "error",
            summary: "File Upload",
            detail: "Something went Wrong!",
          });
        }
      })
      .catch((error) => {
        errorAction("error 1st Upload", error);
        if (error.response.status === 401 || error.response.status === 0) {
          // window.location.href = '';
          // redirect to localhost:3000/ or login route
        }
      });
  };

  const uploadFileOnConfirm = (fileName, lessonids) => {
    var jsonBody = {
      fileName: fileName,
      userEmail: localStorage.getItem("email"),
      lessonids: lessonids,
    };
    let url = config.api.url + "uploadLessonCompletion?confirm=true";
    post(url, jsonBody)
      .then(() => {
        toast.current.show({
          severity: "success",
          summary: "File Upload Lesson Completion",
          detail: "Lessons marked completed successfully.",
        });
      })
      .catch((error) => {
        console.log(error);
        toast.current.show({
          severity: "error",
          summary: "File Upload Lesson Completion",
          detail: "Something went Wrong!",
        });
      });
  };
  const uploadExcelFile = () => {
    if (!file) {
      toast.current.show({
        severity: "info",
        summary: "File Upload Lesson Completion",
        detail: "Please select file to upload",
      });
    } else {
      if (
        ![
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
        ].includes(file.type)
      ) {
        toast.current.show({
          severity: "error",
          summary: "File Upload Lesson Completion",
          detail: "Please upload a valid excel (.xsl/.XLSX) file.",
        });
        resetFileInput();
      } else {
        processAndUploadFile();
        setIsUploading(true);
      }
    }
  };

  return (
    <div className="page-section app">
      <Toast ref={toast}></Toast>`{" "}
      <HelpDialog
        visibleHelpDialog={visibleHelpDialog}
        setVisibleHelpDialog={setVisibleHelpDialog}
        uploadLessonModal={uploadLessonModal}
      />
      `
      <Header />
      <Container fluid style={{ width: "100%" }}>
        <div className="page-inner">
          <Row>
            <Col lg={12}>
              <div className="page-section">
                <Card>
                  <Card.Header style={{ border: "none" }}>
                    <Card.Title style={{ textAlign: "Left" }}>
                      <div className="manager_bar">
                        <span className="card-title p-0">
                          {" "}
                          Upload Lesson Completion{" "}
                          <span
                            className="pi pi-question-circle"
                            title="Help for CSV file"
                            onClick={() => setVisibleHelpDialog(true)}
                          />
                        </span>
                      </div>
                      <Row>
                        <Col lg={5}>
                          <Form>
                            <div className="mb-3">
                              <label
                                className="control-label"
                                htmlFor="settingsPageLanguageSelect"
                                style={{ fontSize: "14px" }}
                              >
                                Select lessons*
                              </label>
                              <MultiSelect
                                value={selectedLessonId}
                                onChange={(e) => setSelectedLessonId(e.value)}
                                options={
                                  lessonIdData &&
                                  lessonIdData
                                    .filter(
                                      (id) =>
                                        id.status !== "review" &&
                                        id.lessontype === "regularlesson"
                                    )
                                    .map((id) => ({
                                      name: `${id.lessonid} (${id.lessonname})`,
                                      value: id.lessonid,
                                    }))
                                }
                                optionLabel="name"
                                className="w-full forminput"
                                display="chip"
                                style={{ width: "100%" }}
                                id="nestedlessonList"
                                filter
                              />
                            </div>
                            <div className="input-grou mb-3">
                              <div className="custom-file ">
                                <label
                                  className="custom-file-label"
                                  htmlFor="excel_file"
                                  style={{ fontSize: "14px" }}
                                >
                                  {fileChooserLabel}
                                </label>
                                <input
                                  type="file"
                                  className="custom-file-input "
                                  accept=".xlsx,.xls"
                                  id="excel_file"
                                  onChange={handleFileChange}
                                />
                              </div>
                            </div>

                            <Button
                              name="fileUploadButton"
                              label={isUploading ? "Submitting..." : "Submit"}
                              icon={
                                isUploading
                                  ? "pi pi-spin pi-spinner"
                                  : "pi pi-upload"
                              }
                              style={{ background: "#4d4d4d" }}
                              onClick={() => {
                                uploadExcelFile();
                              }}
                              disabled={isUploading}
                              className="mt-2 ml-2"
                            />
                          </Form>
                        </Col>
                      </Row>
                    </Card.Title>
                  </Card.Header>
                </Card>
              </div>
            </Col>
          </Row>
        </div>
        <ExcelErrorDialog
          dialogTitle={dialogTitle}
          visibleExcelErrorDialog={visibleExcelErrorDialog}
          setVisibleExcelErrorDialog={setVisibleExcelErrorDialog}
          setSelectedLessonId={setSelectedLessonId}
          errorExcelData={errorExcelData}
          submitExcelConfirmation={(confirmationValue) => {
            if (confirmationValue) {
              uploadFileOnConfirm(
                errorExcelData.uploadedFilename,
                errorExcelData.lessonids
              );
            } else {
              toast.current.show({
                severity: "info",
                summary: "File Upload Lesson Completion",
                detail: "Upload aborted",
              });
            }
            setVisibleExcelErrorDialog(false);
          }}
        />
      </Container>
      <div className="d-none">
        <CsvFileTableUploadLessonCompletion />
      </div>
    </div>
  );
};

export default UploadLessonCompletion;
