import React from "react";
import { Dialog } from "primereact/dialog";
import {
  CsvFileTableAssignSite,
  CsvFileTableCreateSites,
  CsvFileTableDisableUsers,
  CsvFileTableRole,
  CsvFileTableUsers,
} from "./uploadLessonSampleTable.js";
import TableToExcel from "@linways/table-to-excel";

const HelpDialog = (props) => {
  const exportSampleTable = (tableName) => {
    let filename = tableName + "_" + Date.now().toString() + ".xlsx";
    let data = TableToExcel.convert(
      document.getElementById("csvFileTable" + tableName),
      {
        name: filename,
      }
    );
    return data;
  };


  return (
    <div>
      <Dialog
        header="Steps to upload CSV / Excel file"
        position="top"
        visible={props.visibleHelpDialog}
        onHide={() => props.setVisibleHelpDialog(false)}
        draggable={false}
        resizable={false}
        dismissableMask={true}
        style={{ width: "50vw" }}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
      >
        <p>
          You can bulk create users by uploading an XLS/XLSX file. <br />
          You can assign one site each to KP, CRC, SitePI, Monitor. You can not
          assign site to CRO and Sponsor.
          <br />
          Here is an &nbsp;
          <a
            id="downloadUsers"
            href="#0"
            onClick={() => {
              exportSampleTable("Users");
            }}
          >
            example file &nbsp;
            <i className="pi pi-download" aria-hidden="true"></i>
          </a>
        </p>
        <p>
          You can bulk create sites by uploading a XLS/XLSX file. <br />
          Here is an &nbsp;
          <a
            href="#0"
            id="downloadCreateSites"
            onClick={() => {
              exportSampleTable("CreateSites");
            }}
          >
            example file &nbsp;
            <i className="pi pi-download" aria-hidden="true"></i>
          </a>
        </p>
        <p>
          You can bulk assign Monitor users to sites by uploading a XLS/XLSX
          file. <br />
          Here is an &nbsp;
          <a
            href="#0"
            id="downloadAssignSite"
            onClick={() => {
              exportSampleTable("AssignSite");
            }}
          >
            example file &nbsp;
            <i className="pi pi-download" aria-hidden="true"></i>
          </a>
        </p>
        <p>
          You can disable multiple users by uploading a XLS/XLSX file. <br />
          Here is an &nbsp;
          <a
            href="#0"
            id="downloadDisableUsers"
            onClick={() => {
              exportSampleTable("DisableUsers");
            }}
          >
            example file &nbsp;
            <i className="pi pi-download" aria-hidden="true"></i>
          </a>
        </p>
        Here is a file that contains all the roles in the system &nbsp;
        <a
          href="#0"
          id="downloadRole"
          onClick={() => {
            exportSampleTable("Role");
          }}
        >
          <i className="pi pi-download" aria-hidden="true"></i>
        </a>
        <br></br>
      </Dialog>
      <div className="d-none">
        <CsvFileTableAssignSite />
        <CsvFileTableCreateSites />
        <CsvFileTableDisableUsers />
        <CsvFileTableRole />
        <CsvFileTableUsers />
      </div>
    </div>
  );
};
export default HelpDialog;
