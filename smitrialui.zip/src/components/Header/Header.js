import {} from "@fortawesome/fontawesome-svg-core";
import "./Header.css";

import { Link, useNavigate } from "react-router-dom";
import React, { useEffect, useState } from "react";
import {
  faChartPie,
  faClinicMedical,
  faComment,
  faCubes,
  faEnvelope,
  faFileInvoice,
  faFileLines,
  faFileMedical,
  faGear,
  faGears,
  faHome,
  faHomeLg,
  faListCheck,
  faMagnifyingGlass,
  faPlus,
  faPoll,
  faQuestionCircle,
  faShare,
  faSignOut,
  faSquarePollVertical,
  faTable,
  faTableColumns,
  faTasks,
  faTimesCircle,
  faUser,
  faUserFriends,
  faUsers,
} from "@fortawesome/free-solid-svg-icons";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Dropdown, NavDropdown } from "react-bootstrap";
import UserPool from "../../utils/UserPool";
// import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import nestedcardIcon from "../../asset/image/icons/lesson_nested_icon.svg";
import assessmentIcon from "../../asset/image/icons/assesment_icon.svg";
import lessonRegIcon from "../../asset/image/icons/lesson_reg_icon.svg";
import externallinkIcon from "../../asset/image/icons/lesson_reg_icon.svg";
import config from "../../config/config.json";

const Header = (props) => {
  const [isLargeLessonView, setIsLargeLessonView] = useState(false);
  const navigate = useNavigate();
  const [trialDuser, setTrialUser] = useState(null);
  const [isTrialDUser, setIsTrialDUser] = useState(false);
  const [trialdEnabled, setTrialdEnabled] = useState(false);
  const [enableNavBarItems, setEnableNavBarItems] = useState(false);
  const [isLoading, setIsloading] = useState(true);
  const [unread, setUnread] = useState(false);
  const [isDashboardPage, setIsDashboardPage] = useState(false);
  const [toggleState, setToggleState] = useState({
    isDropdownOpen: false,
    isSidebarOpen: false,
    isProfileMenuOpen: false,
    isReportMenuOpen: false,
    isUserSiteMenuOpen: false,
  });
  const [searchList, setSearchList] = useState([]);
  const [topMessages, setTopMessages] = useState([]);

  const [isPageInitialized, setIsPageInitialized] = useState(false);

  const [searchInputValue, setSearchInputValue] = useState("");

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 575);

  const setNavItemsVisibility = () => {
    const userRole = localStorage.getItem("userRole");

    const userMenus = document.querySelectorAll(".userMenu");
    const reportMenus = document.querySelectorAll(".reportMenu");
    const userSiteMenus = document.querySelectorAll(".userSiteMenu");
    const smiAdminMenus = document.querySelectorAll(".smiAdminMenu");
    const lessonReviewMainMenus = document.querySelectorAll(
      ".lessonReviewMainMenuItem"
    );
    const sidebarTrainingRecord = document.querySelectorAll(
      ".sidebarTrainingRecord"
    );
    const sideBarHomeMenu = document.querySelectorAll(".sideBarHomeMenu");

    const showBlock = (elements, breakpoint = "", noneBlockFlag) => {
      elements.forEach((element) => {
        if (breakpoint) {
          element.classList.add(`d-${breakpoint}-block`);
        } else {
          element.classList.add("d-block");
        }
        if (!noneBlockFlag) {
          element.classList.remove("d-none");
        }
      });
    };

    if (userRole === "crc" || userRole === "sitepi") {
      showBlock(userMenus);
      window.innerWidth >= 575 && showBlock(reportMenus);
    }

    if (["monitor", "cro", "sponsor", "smiadmin"].includes(userRole)) {
      showBlock(userSiteMenus, "md", true);
      window.innerWidth >= 575 && showBlock(reportMenus);
    }

    if (userRole === "smiadmin") {
      showBlock(smiAdminMenus, "lg", true);
      showBlock(lessonReviewMainMenus);
    }
    showBlock(sidebarTrainingRecord);
    showBlock(sideBarHomeMenu);
  };

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 575);
    setNavItemsVisibility();
  };

  useEffect(() => {
    if (props.isLargeLessonView && props.isLargeLessonView == true) {
      setIsLargeLessonView(true);
    } else {
      setIsLargeLessonView(false);
    }
  }, [props.isLargeLessonView]);

  const displayMessagesTopBar = async () => {
    try {
      const url = config.api.url + "getMyTopMessages/5";
      get(url).then((response) => {
        if (response?.data?.messages) {
          setTopMessages(response.data.messages);
          if (JSON.stringify(response.data.messages).includes("unread")) {
            setUnread(true);
          }
        }
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);
  });

  setTimeout(setNavItemsVisibility, 350);

  useEffect(() => {
    get(config.api.url + "isTrialDUser")
      .then((response) => {
        setTrialUser(response.data);
        setIsloading(false);
        if (response.data) {
          setIsTrialDUser(response.data.isTrialDUser);
          setTrialdEnabled(response.data.trialdEnabled);
          setEnableNavBarItems(response.data.enableNavBarItems);
        }
        // setNavItemsVisibility();
        const userRole = localStorage.getItem("userRole");
        if (userRole != null && userRole === "cro") {
          get(config.api.url + "getTrialConfig/croLessonReview").then(
            (result) => {
              if (result.data.value === true) {
                const lessonReviewMainMenus = document.querySelectorAll(
                  ".lessonReviewMainMenuItem"
                );
                lessonReviewMainMenus.forEach((element) => {
                  element.classList.add("d-block");
                  element.classList.remove("d-none");
                });
              }
            }
          );
        }
        if (userRole != null && userRole === "sponsor") {
          get(config.api.url + "getTrialConfig/sponsorLessonReview").then(
            (result) => {
              if (result.data.value === true) {
                const lessonReviewMainMenus = document.querySelectorAll(
                  ".lessonReviewMainMenuItem"
                );
                lessonReviewMainMenus.forEach((element) => {
                  element.classList.add("d-block");
                  element.classList.remove("d-none");
                });
              }
            }
          );
        }
        setIsPageInitialized(true);
      })
      .finally(() => {
        // setIsloading(false);
      });
    displayMessagesTopBar();
  }, []);

  useEffect(() => {
    if (
      window.location.href.split("/")[3].split("?")[0] === "dashboard" ||
      window.location.href
        .split("/")[3]
        .split("?")[0]
        ?.toLowerCase()
        .includes("lessonview")
    ) {
      setIsDashboardPage(true);
      if (props.searchDashboardData) {
        setSearchList(props.searchDashboardData);
      }
    }
  }, [props.searchDashboardData]);

  const toggleStateFn = (key) => {
    const setStyleForApp = document.querySelectorAll(".App");
    setStyleForApp.forEach((menu) => {
      menu.style.overflow = "scroll";
    });
    setToggleState((prevState) => ({
      ...prevState,
      [key]: !prevState[key],
    }));
  };

  const handleLogout = async () => {
    try {
      const cognitoUser = UserPool.getCurrentUser();
      if (cognitoUser) {
        cognitoUser.signOut();
      }
      localStorage.clear();
      localStorage.setItem("logout", "1");
      navigate("/");
    } catch (error) {
      console.error("Error during logout:", error);
    }
  };

  document.addEventListener("mouseup", (e) => {
    var container = document.getElementById("user-menu");
    // if the target of the click isn't the container nor a descendant of the container
    if (container && !container?.contains(e.target)) {
      toggleStateFn("isDropdownOpen");
    }
  });

  return (
    <div className="">
      {toggleState.isSidebarOpen && (
        <div
          className="overlay"
          onClick={() => toggleStateFn("isSidebarOpen")}
        ></div>
      )}
      <header className="app-header app-header-light">
        <div className="top-bar">
          <div className="top-bar-brand">
            {isLoading ? (
              " "
            ) : trialdEnabled && isTrialDUser ? (
              <a href="dashboard" className="smiTrialDLogo">
                <img
                  src={require("../../asset/image/logos/SMiTrialD_logo.png")}
                  alt=""
                  style={{ height: "10%", width: "70%", padding: "10px" }}
                />
              </a>
            ) : (
              <a href="dashboard" className="smiTrialLogo">
                <img
                  src={require("../../asset/image/logos/SMiTrial_logo-02.png")}
                  alt=""
                  style={{ height: "10%", width: "70%", padding: "10px" }}
                />
              </a>
            )}
          </div>
          {isPageInitialized && (
            <div className="top-bar-list">
              <div className="top-bar-item px-2  d-md-none d-md-none d-lg-none d-xl-none  ">
                <button
                  className="hamburger hamburger-squeeze d-sm-none"
                  type="button"
                  data-toggle="aside"
                  aria-label="toggle menu"
                  onClick={() => {
                    toggleStateFn("isSidebarOpen");
                  }}
                >
                  <span className="hamburger-box">
                    {" "}
                    <span className="hamburger-inner"></span>
                  </span>
                </button>

                {trialdEnabled && isTrialDUser ? (
                  <div className="smiTrialDMobileLogo">
                    <a href="dashboard">
                      <img
                        src={require("../../asset/image/logos/SMiTrialD_logo.png")}
                        alt=""
                        style={{ maxWidth: "100px" }}
                      />
                    </a>
                  </div>
                ) : (
                  <div className="smiTrialMobileLogo">
                    <a href="dashboard">
                      <img
                        src={require("../../asset/image/logos/SMiTrial_logo-02.png")}
                        alt=""
                        style={{ maxWidth: "100px" }}
                      />
                    </a>
                  </div>
                )}
                <div
                  className="d-block d-xs-none logohatchery"
                  style={{ position: "fixed", right: " 10px" }}
                >
                  <img
                    className="img-fluid"
                    src={require(`../../asset/image/logos/${config.site.logo}`)}
                    alt=""
                    style={{ maxWidth: "117px" }}
                  />
                </div>
              </div>

              {!isTrialDUser && (
                <div className="top-bar-item px-2 d-none d-md-block  ">
                  <div
                    id="searchDiv"
                    className={`input-group smi-radius has-clearable searchBarDiv ${
                      isDashboardPage ? "" : "d-none"
                    }`} // add condition here fo search
                  >
                    <div
                      className={`list-group list-group-bordered mt-5 bg-white ${
                        searchInputValue !== "" ? "" : "d-none"
                      }`}
                      id="contentList"
                      style={{
                        position: "absolute",
                        boxShadow: "none",
                        width: "20vw",
                      }}
                    >
                      {searchList.length > 0 &&
                        searchInputValue !== "" &&
                        searchInputValue.length > 1 &&
                        searchList.map((item, index) => {
                          let lessonIcon;
                          let dest = "/lessonview?lessonid=" + item.id;
                          if (item.lessontype === "nestedcard") {
                            dest = `/dashboard?lessonid=${item.id}&parentids=${item.id}&parentNames=${item.name}`;
                            lessonIcon = nestedcardIcon;
                          } else if (item.lessontype === "assessment") {
                            lessonIcon = assessmentIcon;
                          } else if (
                            item.lessontype === "lesson" &&
                            item.topicid
                          ) {
                            dest =
                              "/lessonview?lessonid=" +
                              item.id +
                              "&topicid=" +
                              item.topicid;
                            lessonIcon = lessonRegIcon;
                          } else if (item.lessontype === "externallink") {
                            dest = item.lessonurl;
                            lessonIcon = externallinkIcon;
                          } else {
                            lessonIcon = lessonRegIcon;
                          }
                          const target =
                            item.lessontype === "externallink"
                              ? "_blank"
                              : "_self";
                          return (
                            (item.name
                              ?.toLowerCase()
                              .includes(searchInputValue?.toLowerCase()) ||
                              item.id
                                ?.toLowerCase()
                                .includes(searchInputValue?.toLowerCase())) && (
                              <a
                                key={"searchdropditem_" + index}
                                href={dest}
                                target={target}
                                onClick={(e) => {
                                  if (item.lessontype === "externallink") {
                                    setSearchInputValue("");
                                    return; // Don't prevent default for external links
                                  }
                                  e.preventDefault();

                                  setSearchInputValue("");
                                  navigate(dest);
                                }}
                                className="list-group-item list-group-item-action nav-link pt-2 pb-2 "
                                style={{
                                  border: "1px solid #ecedf1 !important",
                                }}
                              >
                                <div
                                  className="list-group-item-figure"
                                  style={{ color: "inherit" }}
                                >
                                  <div>
                                    <img
                                      src={lessonIcon}
                                      width="40"
                                      height="40"
                                      alt=""
                                    />
                                  </div>
                                </div>
                                <div className="list-group-item-body truncateText">
                                  {item.name}
                                </div>
                              </a>
                            )
                          );
                        })}
                    </div>
                    <button
                      type="button"
                      className={
                        searchInputValue === "" ? "close" : "close show"
                      }
                      aria-label="Close"
                      onClick={(e) => {
                        e.preventDefault();
                        setSearchInputValue("");
                      }}
                    >
                      <span aria-hidden="true">
                        {/* <i className="fa fa-times-circle"></i> */}
                        <FontAwesomeIcon icon={faTimesCircle} />
                      </span>
                    </button>
                    <>
                      <label
                        className="input-group-prepend"
                        htmlFor="contentFilter"
                      >
                        <span className="input-group-text">
                          {/* <span className="oi oi-magnifying-glass"></span> */}
                          <FontAwesomeIcon icon={faMagnifyingGlass} />
                        </span>
                      </label>
                      <input
                        className="form-control searchbar"
                        id="contentFilter"
                        onChange={(e) => {
                          setSearchInputValue(e.target.value);
                        }}
                        value={searchInputValue}
                        type="text"
                        placeholder="Search.."
                        // style={{ width: "20vw" }}
                      />
                    </>
                  </div>
                </div>
              )}
              <div className="d-none d-md-block">
                {trialdEnabled && isTrialDUser && !isLargeLessonView ? (
                  ""
                ) : !isMobile && isLargeLessonView && !props.hideNavbar ? (
                  <nav className="d-none d-sm-block" id="secondNav">
                    <ul className="nav">
                      {isLoading && trialdEnabled && isTrialDUser ? (
                        ""
                      ) : (
                        <li className="nav-item dropdown header-nav-dropdown pl-0 sidebarTrainingRecord d-none">
                          <Link to="/trainingrecord" className="nav-link">
                            <i className="fas fa-file-spreadsheet"></i>
                            <FontAwesomeIcon icon={faFileLines} />
                            {/* <span className="texts d-none d-xl-inline-flex">
                          Records
                        </span> */}
                          </Link>
                        </li>
                      )}
                      <div className="reportMenu d-none">
                        <NavDropdown
                          title={
                            <span className="NavDropdown_style">
                              <FontAwesomeIcon icon={faChartPie} />
                              {/* <span className="texts d-none d-xl-inline-flex">
                            Reports
                          </span> */}
                            </span>
                          }
                          id="basic-nav-dropdown"
                          className="dropdown_style reportMenu"
                        >
                          <NavDropdown.Item
                            as={Link}
                            to="/lessonreports"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faListCheck} />
                            </span>{" "}
                            <span className="tile-peek">
                              Lesson Completion Reports
                            </span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/lessonreportsoverview"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faListCheck} />
                            </span>{" "}
                            <span className="tile-peek">
                              Lesson Completion Reports Overview
                            </span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/usersummaryreports"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faListCheck} />
                            </span>{" "}
                            <span className="tile-peek">
                              User Summary Reports
                            </span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/sitesreports"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faListCheck} />
                            </span>
                            <span className="tile-peek"> Sites Reports</span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/allassessmentreports"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faSquarePollVertical} />
                            </span>
                            <span className="tile-peek">
                              {" "}
                              Comprehension Reports
                            </span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/surveyreports"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faSquarePollVertical} />
                            </span>
                            <span className="tile-peek"> Survey Reports</span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/reportsaggregate"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faSquarePollVertical} />
                            </span>
                            <span className="tile-peek">
                              {" "}
                              Aggregate Report{" "}
                            </span>
                          </NavDropdown.Item>
                        </NavDropdown>
                      </div>

                      <li className="nav-item pl-0 userMenu d-none">
                        <Link to="/usermanager" className="nav-link">
                          <FontAwesomeIcon icon={faUsers} />
                          {/* <span className="texts d-none d-xl-inline-flex">
                        User Management
                      </span> */}
                        </Link>
                      </li>

                      <div className="userSiteMenu d-none d-sm-none">
                        <NavDropdown
                          title={
                            <span className="NavDropdown_style">
                              <FontAwesomeIcon icon={faUsers} />
                              {/* <span className="texts d-none d-xl-inline-flex">
                            User/Site
                          </span> */}
                            </span>
                          }
                          id="basic-nav-dropdown"
                          className="dropdown_style "
                        >
                          <NavDropdown.Item
                            as={Link}
                            to="/sitemanager"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faHomeLg} />
                            </span>
                            <span className="tile-peek">Sites</span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/usermanager"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faUsers} />
                            </span>
                            <span className="tile-peek">Users</span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/Triaidshare"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faShare} />
                            </span>
                            <span className="tile-peek"> Trial Share</span>
                          </NavDropdown.Item>
                          <NavDropdown.Item
                            as={Link}
                            to="/uploadlessoncompletion"
                            className="tile-wrapper"
                          >
                            <span className="tile tile-lg bg-smi-green">
                              <FontAwesomeIcon icon={faHomeLg} />
                            </span>
                            <span className="tile-peek">Lesson Completion</span>
                          </NavDropdown.Item>
                        </NavDropdown>
                      </div>
                      <li className="nav-item pl-0 lessonReviewMainMenuItem d-none">
                        <Link to="/lessonreviewmanager" className="nav-link">
                          <FontAwesomeIcon icon={faFileInvoice} />
                          {/* <span className="texts d-none d-xl-inline-flex">Review</span> */}
                        </Link>
                      </li>
                    </ul>
                    <div
                      id="errorMessageNav"
                      className=" toast fade hide float-right"
                      role="alert"
                      aria-live="assertive"
                      aria-atomic="true"
                      data-delay="10000"
                    >
                      <div className="toast-body"> </div>
                    </div>
                  </nav>
                ) : (
                  <></>
                )}
              </div>
              <div
                className={`top-bar-item top-bar-item-right px-0 d-none d-sm-flex ${
                  ["sitepi", "crc", "kp"].includes(
                    localStorage.getItem("userRole")
                  )
                    ? "marginbar"
                    : ""
                }`}
              >
                {(!trialDuser?.enableNavBarItems ||
                  !trialDuser?.isTrialDUser) && (
                  <ul className="header-nav nav responsive-header">
                    <li className="mt-2">
                      <div
                        className={`${
                          ["sitepi", "crc", "kp"].includes(
                            localStorage.getItem("userRole")
                          )
                            ? ""
                            : "d-none"
                        } myMonitorDiv`}
                      >
                        <button
                          className="btn btn-primary myMonitor"
                          style={{ padding: "0.375rem 0.75rem;" }}
                          type="button"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/messages");
                          }}
                        >
                          <FontAwesomeIcon icon={faComment} className="mr-2" />
                          Contact my monitor
                        </button>
                      </div>
                    </li>
                    {isTrialDUser && enableNavBarItems ? (
                      ""
                    ) : (
                      <>
                        <li
                          className={
                            "nav-item dropdown header-nav-dropdown avatar has-badge mt-2" +
                            (unread ? " has-notified" : "")
                          }
                        >
                          <NavDropdown
                            title={<FontAwesomeIcon icon={faEnvelope} />}
                            id="basic-nav-dropdown"
                            className="dropdown_style"
                          >
                            <NavDropdown.Item className="p-0">
                              <h6 className="dropdown-header stop-propagation py-3">
                                <div>
                                  <a
                                    href="messages"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      navigate("/messages");
                                    }}
                                    className="writemessage"
                                  >
                                    View All
                                  </a>
                                </div>
                                <div>
                                  <a
                                    className="writemessage"
                                    onClick={(e) => {
                                      e.preventDefault();
                                      navigate(`/messages`);
                                    }}
                                    href="/messages"
                                  >
                                    <FontAwesomeIcon
                                      style={{
                                        padding: "0.25rem",
                                        verticalAlign: "bottom",
                                      }}
                                      icon={faPlus}
                                    />
                                    Write a Message
                                  </a>
                                </div>
                              </h6>

                              <div className="dropdown-scroll perfect-scrollbar hover-message">
                                <div className="messageTemplateWrapper">
                                  {topMessages.map((item, index) => (
                                    <a
                                      key={`message_element_` + index}
                                      href={`messages?messageid=${item?.timestamp_subject}&box=in`}
                                      onClick={(e) => {
                                        e.preventDefault();
                                        navigate(
                                          `/messages?messageid=${item?.timestamp_subject}&box=in`
                                        );
                                      }}
                                      className={`dropdown-item item-hover borderclass py-2.5  ${
                                        item?.status === "unread"
                                          ? "unread"
                                          : ""
                                      }`}
                                    >
                                      <div className="dropdown-item-body onclickMessage">
                                        <p className="subject">
                                          {item?.fromName}{" "}
                                        </p>
                                        <p className="text text-truncate">
                                          {item?.subject}
                                        </p>
                                        <p
                                          className="date"
                                          style={{ textAlign: "end" }}
                                        >
                                          {item?.addedString}
                                        </p>
                                      </div>
                                    </a>
                                  ))}
                                </div>
                              </div>
                            </NavDropdown.Item>
                          </NavDropdown>
                        </li>
                      </>
                    )}
                    {isTrialDUser && enableNavBarItems ? (
                      ""
                    ) : (
                      <li className="nav-item dropdown header-nav-dropdown mt-2 helpIcon">
                        <a
                          className="nav-link"
                          href="/help"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/help");
                          }}
                          aria-haspopup="true"
                          aria-expanded="false"
                        >
                          {/* <span className="fas fa-question-circle" title="Support" style={{ "fontSize": "1.1rem", "fontWeight": "800" }}></span> */}
                          <FontAwesomeIcon
                            icon={faQuestionCircle}
                            title="Support"
                            style={{
                              fontSize: "1.1rem",
                              fontWeight: "800",
                            }}
                          />
                        </a>
                      </li>
                    )}
                  </ul>
                )}
                <Dropdown className="userInfoDiv">
                  <Dropdown.Toggle
                    className="btn-account d-block d-sm-block d-md-flex"
                    variant="light"
                    id="dropdown-basic"
                  >
                    {enableNavBarItems && isTrialDUser && (
                      <span className="dropdown-icon oi oi-person"></span>
                    )}
                    {(!isTrialDUser || !enableNavBarItems) && (
                      <span className="">
                        <span
                          className="account-name text-center"
                          id="userName"
                          style={{ fontSize: "14px" }}
                        >
                          {localStorage.getItem("userName")}
                        </span>
                        <span
                          className="account-description text-center"
                          id="userRole"
                        >
                          {localStorage.getItem("userRole")}
                        </span>

                        <span
                          className="account-description text-center"
                          id="userSubRole"
                        >
                          {localStorage.getItem("userSubRole")}
                        </span>
                      </span>
                    )}
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    {!isTrialDUser && (
                      <Dropdown.Item
                        href="/profile"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/profile");
                        }}
                      >
                        <span className="dropdown-icon oi oi-person"></span>{" "}
                        Profile
                      </Dropdown.Item>
                    )}
                    <Dropdown.Item onClick={handleLogout} className="logout">
                      <span className="dropdown-icon oi oi-account-logout"></span>{" "}
                      Logout
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>

                <div className="top-bar-brand app-header-light btn-account">
                  <img
                    className="img-fluid mx-auto d-block p-1"
                    src={require(`../../asset/image/logos/${config.site.logo}`)}
                    alt=""
                    style={{ maxHeight: "48px", width: "auto", height: "auto" }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </header>
      <main className="app-main"></main>
      {isLoading ? (
        ""
      ) : trialdEnabled && isTrialDUser && !isLargeLessonView ? (
        ""
      ) : !isMobile && !isLargeLessonView ? (
        <nav
          className="page-navs shadow-sm pr-3 d-none d-sm-block"
          id="secondNav"
        >
          <ul className="header-nav nav">
            {trialdEnabled && isTrialDUser ? (
              ""
            ) : (
              <li className="nav-item dropdown header-nav-dropdown pl-0 sideBarHomeMenu d-none">
                <Link className="nav-link" to="/dashboard">
                  <FontAwesomeIcon icon={faHome} />
                  <span className="texts d-none d-xl-inline-flex">Home</span>
                </Link>
              </li>
            )}

            {isTrialDUser && trialdEnabled ? (
              ""
            ) : (
              <li className="nav-item dropdown header-nav-dropdown pl-0 sidebarTrainingRecord d-none">
                <Link to="/trainingrecord" className="nav-link">
                  <i className="fas fa-file-spreadsheet"></i>
                  <FontAwesomeIcon icon={faFileLines} />
                  <span className="texts d-none d-xl-inline-flex">
                    Training Records
                  </span>
                </Link>
              </li>
            )}
            <div className="reportMenu d-none">
              <NavDropdown
                title={
                  <span className="NavDropdown_style">
                    <FontAwesomeIcon icon={faChartPie} />
                    <span className="texts d-none d-xl-inline-flex">
                      Reports
                    </span>
                  </span>
                }
                id="basic-nav-dropdown"
                className="dropdown_style reportMenu"
              >
                <NavDropdown.Item
                  as={Link}
                  to="/lessonreports"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faListCheck} />
                  </span>{" "}
                  <span className="tile-peek">Lesson Completion Reports</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/lessonreportsoverview"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faListCheck} />
                  </span>{" "}
                  <span className="tile-peek">
                    Lesson Completion Reports Overview
                  </span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/usersummaryreports"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faListCheck} />
                  </span>{" "}
                  <span className="tile-peek">User Summary Reports</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/sitesreports"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faListCheck} />
                  </span>
                  <span className="tile-peek"> Sites Reports</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/allassessmentreports"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faSquarePollVertical} />
                  </span>
                  <span className="tile-peek"> Comprehension Reports</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/surveyreports"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faSquarePollVertical} />
                  </span>
                  <span className="tile-peek"> Survey Reports</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/reportsaggregate"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faSquarePollVertical} />
                  </span>
                  <span className="tile-peek"> Aggregate Report </span>
                </NavDropdown.Item>
              </NavDropdown>
            </div>

            <li className="nav-item pl-0 userMenu d-none">
              <Link to="/usermanager" className="nav-link">
                <FontAwesomeIcon icon={faUsers} />
                <span className="texts d-none d-xl-inline-flex">
                  User Management
                </span>
              </Link>
            </li>

            <div className="userSiteMenu d-none d-sm-none">
              <NavDropdown
                title={
                  <span className="NavDropdown_style">
                    <FontAwesomeIcon icon={faUsers} />
                    <span className="texts d-none d-xl-inline-flex">
                      User/Site Management
                    </span>
                  </span>
                }
                id="basic-nav-dropdown"
                className="dropdown_style "
              >
                <NavDropdown.Item
                  as={Link}
                  to="/sitemanager"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faHomeLg} />
                  </span>
                  <span className="tile-peek">Sites</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/usermanager"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faUsers} />
                  </span>
                  <span className="tile-peek">Users</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/Triaidshare"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faShare} />
                  </span>
                  <span className="tile-peek"> Trial Share</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/uploadlessoncompletion"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faHomeLg} />
                  </span>
                  <span className="tile-peek">Lesson Completion</span>
                </NavDropdown.Item>
              </NavDropdown>
            </div>
            <li className="nav-item pl-0 lessonReviewMainMenuItem d-none">
              <Link to="/lessonreviewmanager" className="nav-link">
                <FontAwesomeIcon icon={faFileInvoice} />
                <span className="texts d-none d-xl-inline-flex">Review</span>
              </Link>
            </li>

            <div className="d-none smiAdminMenu">
              <NavDropdown
                title={
                  <span className="NavDropdown_style">
                    <FontAwesomeIcon icon={faCubes} />
                    <span className="texts d-none d-xl-inline-flex">
                      Asset Management
                    </span>
                  </span>
                }
                id="basic-nav-dropdown"
                className="dropdown_style"
              >
                <NavDropdown.Item
                  as={Link}
                  to="/lessonmanager"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faFileInvoice} />
                  </span>
                  <span className="tile-peek texts">Lessons</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/lessonwizard"
                  onClick={() => {
                    localStorage.setItem("lessonWizardReload", "true");
                  }}
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faFileMedical} />
                  </span>
                  <span className="tile-peek">Create Lesson</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/lessonmanagertreeview"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faFileInvoice} />
                  </span>
                  <span className="tile-peek"> Lessons Tree</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/roles"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faUsers} />
                  </span>
                  <span className="tile-peek"> Roles</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/dashboardsettings"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faTableColumns} />
                  </span>
                  <span className="tile-peek"> Dashboard</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/lessonassignmentoverview"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faTable} />
                  </span>
                  <span className="tile-peek"> Lesson Assignment Overview</span>
                </NavDropdown.Item>
              </NavDropdown>
            </div>

            <div className="d-none smiAdminMenu">
              <NavDropdown
                title={
                  <span className="NavDropdown_style">
                    <FontAwesomeIcon icon={faGears} />
                    <span className="texts d-none d-xl-inline-flex">
                      Settings
                    </span>
                  </span>
                }
                id="basic-nav-dropdown"
                className="dropdown_style"
              >
                <NavDropdown.Item
                  as={Link}
                  to="/settings"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faGear} />
                  </span>
                  <span className="tile-peek">Settings</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/notificationsettings"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faGear} />
                  </span>
                  <span className="tile-peek">Notification Settings</span>
                </NavDropdown.Item>
                <NavDropdown.Item
                  as={Link}
                  to="/emailreminder"
                  className="tile-wrapper"
                >
                  <span className="tile tile-lg bg-smi-green">
                    <FontAwesomeIcon icon={faShare} />
                  </span>
                  <span className="tile-peek"> Email Reminders</span>
                </NavDropdown.Item>
              </NavDropdown>
            </div>
          </ul>
          <div
            id="errorMessageNav"
            className=" toast fade hide float-right"
            role="alert"
            aria-live="assertive"
            aria-atomic="true"
            data-delay="10000"
          >
            <div className="toast-body"> </div>
          </div>
        </nav>
      ) : (
        <aside
          className={`app-aside app-aside-expand-sm app-aside-light d-md-none ${
            toggleState.isSidebarOpen ? "show" : ""
          }`}
        >
          <div className="aside-content">
            <div className="aside-menu overflow-hidden ps">
              <nav
                className="stacked-menu stacked-menu-has-collapsible"
                id="stacked-menu"
              >
                <ul className="menu">
                  {isTrialDUser && enableNavBarItems ? (
                    ""
                  ) : (
                    <li
                      className={`menu-item has-child sidebarUsername d-block ${
                        toggleState.isProfileMenuOpen ? "has-open" : ""
                      }`}
                    >
                      <a
                        className="menu-link text-center"
                        id="userNameMobile"
                        onClick={() => toggleStateFn("isProfileMenuOpen")}
                      >
                        <span className="menu-text">
                          {localStorage.getItem("userName")}
                        </span>
                      </a>
                      <ul className="menu">
                        <li className="menu-item">
                          <a
                            href="/profile"
                            onClick={(e) => {
                              e.preventDefault();
                              navigate("/profile");
                            }}
                            className="menu-link"
                          >
                            <FontAwesomeIcon
                              icon={faUser}
                              title="Profile"
                              className="menu-icon"
                            />
                            <span className="menu-text">Profile</span>
                          </a>
                        </li>
                        <li className="menu-item">
                          <a className="menu-link" onClick={handleLogout}>
                            <FontAwesomeIcon
                              icon={faSignOut}
                              title="Logout"
                              className="menu-icon"
                            />
                            <span
                              className="menu-text"
                              style={{ color: "#888c9b" }}
                            >
                              Logout
                            </span>
                          </a>
                        </li>
                      </ul>
                    </li>
                  )}
                  {isTrialDUser && trialdEnabled ? (
                    ""
                  ) : (
                    <li className="menu-item sidebarHome sideBarHomeMenu d-none">
                      <a
                        href="/dashboard"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/dashboard");
                        }}
                        className="menu-link"
                      >
                        <FontAwesomeIcon icon={faHome} className="menu-icon" />
                        <span className="menu-text"> Home</span>
                      </a>
                    </li>
                  )}
                  <li className="menu-item sidebarTrainingRecord d-none">
                    <a
                      className="menu-link"
                      href="trainingrecord"
                      onClick={(e) => {
                        e.preventDefault();
                        navigate("/trainingrecord");
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faFileLines}
                        className="menu-icon"
                      />
                      <span className="menu-text">Training Records</span>
                    </a>
                  </li>

                  <li
                    className={`menu-item has-child reportMenu d-none d-sm-none ${
                      ["sitepi", "crc", "kp"].includes(
                        localStorage.getItem("userRole")
                      )
                        ? "d-none"
                        : ""
                    } ${toggleState.isReportMenuOpen ? "has-open" : ""}`}
                  >
                    <a
                      className="menu-link"
                      onClick={() => toggleStateFn("isReportMenuOpen")}
                    >
                      <FontAwesomeIcon
                        icon={faChartPie}
                        className="menu-icon"
                      />
                      <span className="menu-text">Reports</span>
                    </a>
                    <ul className="menu">
                      <li className="menu-item">
                        <a
                          href="/lessonreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/lessonreports");
                          }}
                          className="menu-link"
                        >
                          <FontAwesomeIcon
                            icon={faTasks}
                            className="menu-icon"
                          />
                          <span className="menu-text">
                            Lesson Completion Reports
                          </span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          href="/lessonreportsoverview"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/lessonreportsoverview");
                          }}
                          className="menu-link"
                        >
                          <FontAwesomeIcon
                            icon={faTasks}
                            className="menu-icon"
                          />
                          <span className="menu-text">
                            Lesson Completion Reports Overview
                          </span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          href="/Usersummaryreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/Usersummaryreports");
                          }}
                          className="menu-link"
                        >
                          <FontAwesomeIcon
                            icon={faTasks}
                            className="menu-icon"
                          />
                          <span className="menu-text">
                            {" "}
                            User Summary Reports
                          </span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          href="/sitesreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/sitesreports");
                          }}
                          className="menu-link"
                        >
                          <FontAwesomeIcon
                            icon={faTasks}
                            className="menu-icon"
                          />
                          <span className="menu-text">Sites Reports</span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          className="menu-link compreshensionReportsButton"
                          href="/allassessmentreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/allassessmentreports");
                          }}
                        >
                          <FontAwesomeIcon
                            icon={faPoll}
                            className="menu-icon"
                          />
                          <span className="menu-text">
                            Comprehension Reports
                          </span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          className="menu-link surveyReportsButton"
                          href="/surveyreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/surveyreports");
                          }}
                        >
                          <FontAwesomeIcon
                            icon={faPoll}
                            className="menu-icon"
                          />
                          <span className="menu-text">Survey Reports</span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          className="menu-link surveyReportsButton"
                          href="/surveyreports"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/reportsaggregate");
                          }}
                        >
                          <FontAwesomeIcon
                            icon={faPoll}
                            className="menu-icon"
                          />
                          <span className="menu-text">Aggregate Report</span>
                        </a>
                      </li>
                    </ul>
                  </li>

                  {/* <li
                    className={`${
                      ["sitepi", "crc", "kp"].includes(
                        localStorage.getItem("userRole")
                      )
                        ? "d-none"
                        : ""
                    } menu-item lessonReviewMainMenuItem`}
                  >
                    <a
                      className="menu-link"
                      href="/lessonreviewmanager"
                      onClick={(e) => {
                        e.preventDefault();
                        navigate("/lessonreviewmanager");
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faFileInvoice}
                        className="menu-icon"
                      />
                      <span className="menu-text">Reviewsdd</span>
                    </a>
                  </li> */}

                  <li
                    className={`menu-item has-child userSiteMenu d-none d-sm-none d-md-block ${
                      toggleState.isUserSiteMenuOpen ? "has-open" : ""
                    }`}
                  >
                    <a
                      onClick={() => toggleStateFn("isUserSiteMenuOpen")}
                      className="menu-link"
                    >
                      <FontAwesomeIcon icon={faUsers} className="menu-icon" />
                      <span className="menu-text">User/Site Management</span>
                    </a>
                    <ul className="menu">
                      <li className="menu-item">
                        <a
                          href="/Sitemanager"
                          className="menu-link"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/Sitemanager");
                          }}
                        >
                          <FontAwesomeIcon
                            icon={faClinicMedical}
                            className="menu-icon"
                          />
                          <span className="menu-text">Sites</span>
                        </a>
                      </li>
                      <li className="menu-item">
                        <a
                          href="/Usermanager"
                          className="menu-link"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/Usermanager");
                          }}
                        >
                          <FontAwesomeIcon
                            icon={faUserFriends}
                            className="menu-icon"
                          />
                          <span className="menu-text"> Users</span>
                        </a>
                      </li>
                    </ul>
                  </li>
                  {isTrialDUser && enableNavBarItems ? (
                    ""
                  ) : (
                    <li
                      className={`${
                        ["sitepi", "crc", "kp"].includes(
                          localStorage.getItem("userRole")
                        )
                          ? ""
                          : "d-none"
                      } menu-item myMonitorDiv`}
                    >
                      <a
                        className="menu-link"
                        href="/messages?newmessage=yes"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/messages?newmessage=yes");
                        }}
                      >
                        <FontAwesomeIcon
                          icon={faComment}
                          className="menu-icon"
                        />
                        <span className="menu-text">Contact my monitor</span>
                      </a>
                    </li>
                  )}
                  {isTrialDUser && enableNavBarItems ? (
                    ""
                  ) : (
                    <li className="menu-item sidebarMessages">
                      <a
                        className="menu-link"
                        href="/messages"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/messages");
                        }}
                      >
                        <FontAwesomeIcon
                          icon={faEnvelope}
                          className="menu-icon"
                        />
                        <span className="menu-text">Messages</span>
                      </a>
                    </li>
                  )}

                  {isTrialDUser && enableNavBarItems ? (
                    ""
                  ) : (
                    <li className="menu-item helpIcon">
                      <a
                        className="menu-link"
                        href="/help"
                        onClick={(e) => {
                          e.preventDefault();
                          navigate("/help");
                        }}
                      >
                        <FontAwesomeIcon
                          icon={faQuestionCircle}
                          className="menu-icon"
                        />
                        <span className="menu-text">Help</span>
                      </a>
                    </li>
                  )}

                  <li className="menu-item ">
                    <a className="menu-link" onClick={handleLogout}>
                      <FontAwesomeIcon icon={faSignOut} className="menu-icon" />
                      <span className="menu-text">Logout</span>
                    </a>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </aside>
      )}
      <div
        className="modal fade has-shown"
        id="surveyModal"
        tabIndex="-1"
        role="dialog"
        aria-labelledby="surveyModalLabel"
        style={{ display: "none" }}
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 id="surveyModalLabel" className="modal-title">
                {" "}
                Take a survey{" "}
              </h5>
            </div>
            <div className="modal-body" id="surveyBody"></div>
            <div className="modal-footer surveyFooter"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Header;
