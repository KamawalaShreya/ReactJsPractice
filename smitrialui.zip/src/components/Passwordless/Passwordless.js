import "./Passwordless.css";

import { AuthenticationDetails, CognitoUser } from "amazon-cognito-identity-js";
import React, { useEffect } from "react";

import UserPool from "../../utils/UserPool";
import config from "../../config/config.json";
import { useNavigate } from "react-router-dom";

const Passwordless = () => {
  const navigate = useNavigate();
  let authenticationToken;
  let userRole;
  let userName;

  const login = () => {
    const urlParams = new URLSearchParams(window.location.search);
    const encodedString = urlParams.get("l");
    const url = config.api.url + "decodeTrialDLink" + "?login=" + encodedString;

    // Use fetch or axios instead of jQuery.ajax in React
    fetch(url, {
      method: "GET",
      headers: {
        Authorization: authenticationToken,
        "Content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((decoded) => {
        // After the decoded username and password are passed back, authenticate it using handleSignin below
        handleSignin(decoded.email, decoded.password);
      })
      .catch((error) => {
        // TODO: fix error not showing
        console.log("Error getting dashboard data.", error);
      });
    //   .finally((xhr) => {
    //     console.log("Successfully", xhr);
    //     if (xhr.status === 401 || xhr.status === 0) {
    //       navigate("/login");
    //     }
    //   });
  };

  const handleSignin = (usernameInput, passwordInput) => {
    localStorage.clear();
    const email = usernameInput;
    const password = passwordInput;

    signin(
      email,
      password,
      (role) => {
        console.log("Successfully Logged In: " + role);
        navigate("/dashboard");
      },
      (err) => {
        console.log("JSON.stringify(err)" + JSON.stringify(err.message));
        // Handle other error cases here
      },
      () => {
        navigate("/newpassword?email=" + email);
      }
    );
  };

  const createCognitoUser = (email) => {
    return new CognitoUser({
      Username: email,
      Pool: UserPool,
    });
  };

  const signin = (email, password, onSuccess, onFailure, onResetPassword) => {
    let role = "";
    const authenticationDetails = new AuthenticationDetails({
      Username: email,
      Password: password,
    });

    const cognitoUser = createCognitoUser(email);
 
    let firstName;
    let lastName;

    cognitoUser.authenticateUser(authenticationDetails, {
      onSuccess: (result_token) => {
        authenticationToken = result_token.getIdToken().getJwtToken();
       
        cognitoUser.getUserAttributes((err, result) => {
          if (err) {
            console.log(err);
            return;
          } else {
            
            for (let i = 0; i < result.length; i++) {
              console.log(
                "attribute " +
                  result[i].getName() +
                  " has value " +
                  result[i].getValue()
              );
              if (result[i].getName() === "custom:role") {
                role = result[i].getValue();
                userRole = result[i].getValue();
              }
              if (result[i].getName() === "given_name") {
                firstName = result[i].getValue();
              }
              if (result[i].getName() === "family_name") {
                lastName = result[i].getValue();
              }
            }
            localStorage.setItem("userName", firstName + " " + lastName);
            localStorage.setItem("userRole", userRole);
            localStorage.setItem("email", email);
          }
        
          onSuccess(role);
        });
      },
      newPasswordRequired: onResetPassword,
      onFailure: onFailure,
    });
  };

  useEffect(() => {
    login();
  }, []);

  return (
    <div className="passwordless">
      <main>
        <div className="wrapper">
          <div className="page">
            <div className="page-inner">
              <div className="page-section">
                <div className="card card-fluid centerMsg">
                  <h2 className="text-center">Welcome to SMi Trial</h2>
                  <h5 className="font-weight-normal">
                    You are being authenticated using passwordless link.
                  </h5>
                  <img
                    className="img-fluid mx-auto d-block p-1"
                    src={require(`../../asset/image/logos/${config.site.logo}`)}
                    alt=""
                    style={{ maxHeight: "48px", width: "auto" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Passwordless;
