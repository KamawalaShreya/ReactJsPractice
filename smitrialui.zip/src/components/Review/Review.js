import React, { useRef } from "react";
import Header from "../Header/Header";
import Datatable from "../Common/Datatable";
import { useState } from "react";
import config from "../../config/config.json";
import { get, post } from "../../utils/HttpRequest";
import { useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import { SplitButton } from "primereact/splitbutton";
import Footerview from "../Footer/Footer";
import { Toast } from "primereact/toast";

const Review = () => {
  const toast = useRef(null);
  const [searchText, setSearchText] = useState("");
  const [data, setData] = useState([]);
  const searchTextRef = useRef(searchText);
  const [filteredData, setFilteredData] = useState(data);
  const lessonTypes = {
    regularlesson: "Regular Lesson",
    assessment: "Comprehension",
    externallink: "External Link",
    nestedcard: "Nested Lesson",
    survey: "Survey Lesson",
  };

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value;
    let dataAll = newData ? newData : data;
    const filtered = newsearchText
      ? [...dataAll].filter((item) =>
          Object.values(item).some((value) => {
            return String(value)
              .toLowerCase()
              .includes(newsearchText.toLowerCase());
          })
        )
      : dataAll;
    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getData = async () => {
    try {
      const url = config.api.url + "getLessons";
      const response = await get(url);
      const modifiedData = response.data.map((user) => ({
        ...user,
        fullName: `${user.lessonid} ${user.lessonname} ${user.lessondescription}`,
      }));

      setData(modifiedData.filter((item) => item.status === "review"));
      setFilteredData(modifiedData.filter((item) => item.status === "review"));
      data.length &&
        handleSearchChange(
          {
            target: {
              value: searchTextRef.current ? searchTextRef.current : "",
            },
          },
          [...modifiedData.filter((item) => item.status === "review")]
        );
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleStatusChange = async (row) => {
   
    try {
      const formData = {
        lessonid: row?.lessonid,
        status: row.status === "review" ? "active" : "inactive",
      };
      
      var url = config.api.url + "updateLessonStatus";
      post(url, formData)
        .then((response) => {
          
          if (response.status === 200 || response.status === 201) {
            setData((prev) =>
              prev
                .map((item) =>
                  item.lessonid === row?.lessonid
                    ? { ...item, status: "active" }
                    : { ...item }
                )
                .filter((item) => item.status === "review")
            );
            setFilteredData((prev) =>
              prev
                .map((item) =>
                  item.lessonid === row?.lessonid
                    ? { ...item, status: "active" }
                    : { ...item }
                )
                .filter((item) => item.status === "review")
            );
            toast.current.show({
              severity: "success",
              summary: "Successfully added",
              detail: "Success",
            });
          } else {
            console.error("Error fetching data:");
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch((err) => {
          console.log("Error in singup", err);
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];
  const siteColumn = [
    {
      dataField: "fullName",
      headerStyle: () => {
        return { width: "40%" };
      },
      text: (
        <>
          Lesson Id
          <br />
          Lesson Name
          <br />
          Description
        </>
      ),
      formatter: (cell, row) => {
        return (
          <a
            href={
              row.lessontype === "nestedcard"
                ? `/dashboard?lessonid=${row.lessonid}&parentids=${row.lessonid}&parentNames=${row.lessonname}`
                : row.lessontype === "externallink"
                ? row.lessonurl
                : `/lessonview?lessonid=${row.lessonid}&review=true`
            }
            style={{ cursor: "pointer" }}
            target={row.lessontype === "externallink" ? "_blank" : "_self"}
            rel="noreferrer"
          >
            <span>{row?.lessonid}</span>
            <br />
            <span>{row?.lessonname}</span>
            <br />
            <span>{row?.lessondescription}</span>
          </a>
        );
      },
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "lessonlanguages",
      text: "Language",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.lessonlanguages ? row.lessonlanguages : "N/A";
      },
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        const valueChange = (pre) => {
          const reviewStatus = pre?.map((item) =>
            item.addedEpoch === row.addedEpoch && item.lessonid === row.lessonid
              ? {
                  ...item,
                  status: row.status === "review" ? "active" : "inactive",
                }
              : item
          );
          return reviewStatus;
        };

        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "active" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "review" ? false : true}
                  onChange={() => {
                    setFilteredData(valueChange);
                    handleStatusChange(row);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "lessontype",
      text: "Lesson Type",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return lessonTypes[row.lessontype] || lessonTypes["regularlesson"];
      },
    },
    {
      dataField: "version",
      text: "version",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.version === undefined ? "" : row.version;
      },
    },
    {
      dataField: "Action",
      text: "Action",
      sort: true,
      formatter: (cell, row) => {
        const items = [
          {
            label: "Edit Lesson Wizard",
            icon: "pi pi-pencil",
            command: () => {
              window.location.href = `/lessonwizard?lessonid=${row?.lessonid}`;
            },
          },
        ];
        return (
          <div>
            <SplitButton icon="pi pi-cog" model={items} severity="success" />
          </div>
        );
      },
    },
  ];

  useEffect(() => {
    getData();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="SiteManagerPage">
          <Row>
            <Col lg={12}>
              <div className="manager_bar">
                <span className="card-title "> Lesson Review Manager </span>
              </div>
              <Datatable
                keyField={"addedEpoch"}
                data={data}
                defaultSorted={defaultSorted}
                handleSearchChange={handleSearchChange}
                columns={siteColumn}
                filteredData={filteredData}
                searchText={searchText}
                isActionEnable={false}
              />
            </Col>
          </Row>
        </div>
      </Container>
      <Footerview />
    </div>
  );
};
export default Review;
