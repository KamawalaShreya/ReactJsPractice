import React from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Col, Form, Row } from "react-bootstrap";
import { DragDropContext } from "react-beautiful-dnd";

const Table = ({
  data,
  columns,
  handleSearchChange,
  searchText,
  onRowReorder,
  activeSearchTable,
}) => {
  const rowReorderCursorClass = "cursor-move";

  return (
    <div className="app">
      <Row className="justify-content-end mb-3">
        <Col md={5}>
          {activeSearchTable === false && (
            <div className="dataTables_filter d-flex align-items-center">
              <Form.Label className="mb-0 mr-2">Search: </Form.Label>
              <Form.Control
                type="text"
                placeholder="Search"
                aria-controls="newsiteListTable"
                onChange={handleSearchChange}
                value={searchText}
                className="form-control mr-sm-2"
              />
            </div>
          )}
        </Col>
      </Row>
      <DragDropContext>
        <DataTable
          value={data}
          reorderableRows
          onRowReorder={(e) => {
            onRowReorder(e.value);
          }}
          tableStyle={{ minWidth: "50rem" }}
        >
          <Column rowReorder style={{ width: "3rem" }} />
          {columns.map((column) => (
            <Column
              sortable={column.sortable ? column.sortable : false}
              key={column.field}
              field={column.field}
              header={column.header}
              body={(rowData) => (
                <div
                  className={rowReorderCursorClass}
                  draggable={true}
                  onDragStart={(e) => {
                    e.dataTransfer.setData(
                      "text/plain",
                      JSON.stringify(rowData)
                    );
                  }}
                >
                  {rowData[column.field]}
                </div>
              )}
            ></Column>
          ))}
        </DataTable>
      </DragDropContext>
    </div>
  );
};

export default Table;
