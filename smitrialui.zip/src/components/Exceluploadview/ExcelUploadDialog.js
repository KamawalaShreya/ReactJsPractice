import React, { useState, useRef } from "react";
import { Button } from "primereact/button";
import axios from "axios";
import { read, utils } from "xlsx";
import { Dialog } from "primereact/dialog";
import { Toast } from "primereact/toast";
import HelpDialog from "./HelpDialog";
import { post } from "../../utils/HttpRequest";
import config from "../../config/config.json";
import ExcelErrorDialog from "./ExcelErrorDialog";

const ExcelUploadDialog = (props) => {
  const toast = useRef(null);
  const [file, setFile] = useState(null);
  const [fileChooserLabel, setFileChooserLabel] = useState(
    "Choose XLS/XLSX file"
  );
  const [visibleHelpDialog, setVisibleHelpDialog] = useState(false);
  const [visibleExcelErrorDialog, setVisibleExcelErrorDialog] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [dialogTitle, setDialogTitle] = useState(
    "Following records require user attention"
  );
  const [errorExcelData, setErrorExcelData] = useState({});

  const resetFileInput = () => {
    setFile(null);
    setFileChooserLabel("Choose XLS/XLSX file");
    setIsUploading(false);
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files.length) {
      setFile(e.target.files[0]);
      setFileChooserLabel(e.target.files[0].name);
    } else {
      resetFileInput();
    }
  };

  const createExcelErrorTable = async (data) => {
    setVisibleExcelErrorDialog(true);
    setErrorExcelData(data);
    var sheet_data = data.errorRecords;
    if (sheet_data.length === 0) {
      setDialogTitle("All Valid records found");
    } else {
      setDialogTitle("Following records requires user attention");
    }
    if (data.successRecordsLength === 0) {
      setDialogTitle("No Valid records found");
    }
  };

  const CheckExcelFile = async (fileName) => {
    const s3UploadInstance = axios.create();
    var url = config.api.url + "checkExcelProcessStatus";
    post(url, JSON.stringify({ fileName: fileName }))
      .then((response) => {
        s3UploadInstance.get(response.data.s3url).then((response) => {
          createExcelErrorTable(response.data);
          resetFileInput();
          props.excelDialogOnClose(false);
        });
      })
      .catch(async (error) => {
        console.log(
          "Error in CheckExcelFile ",
          error,
          "status ",
          error.response.status
        );
        await new Promise((r) => setTimeout(r, 20000));
        CheckExcelFile(fileName);
      });
  };

  const processAndUploadFile = async () => {
    function getfilecontent(file) {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsArrayBuffer(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
      });
    }
    function get_file_name() {
      // return new Date().toLocaleString().replace(/\//g,'_').replace(', ','_').replace(/:/g,'_').replace('pm','').trim() + '.csv';
      return Date.now().toString() + ".csv";
    }
    var filedata = await getfilecontent(file);
    var exceldata = new Uint8Array(filedata);
    var work_bookdata = read(exceldata, { type: "array" });
    var sheet_namedata = work_bookdata.SheetNames;
    var sheet_data = utils.sheet_to_json(
      work_bookdata.Sheets[sheet_namedata[0]],
      { header: 1 }
    );

    var header = sheet_data[0].map((data) => data.toLowerCase());
    var excelFileName = "";
    if (header.includes("family_name")) {
      excelFileName = "createUser_" + get_file_name();
    } else if (header.includes("address")) {
      excelFileName = "createDataSites_" + get_file_name();
    } else if (header.includes("email") && header.includes("name")) {
      excelFileName = "createAssignSite_" + get_file_name();
    } else if (header.includes("emails")) {
      excelFileName = "createDisableUsers_" + get_file_name();
    } else if (header.includes("email")) {
      excelFileName = "createUser_" + get_file_name();
    }
    var jsonBody = {
      fileName: excelFileName,
      fileType: file.type,
      userEmail: localStorage.getItem("email"),
      // "file": base64Excel
    };

    function errorAction(errorDesc, error) {
      toast.current.show({
        severity: "error",
        summary: "File Upload",
        detail: "Something went Wrong!",
      });
    }

    let uploadUrl = config.api.url + "uploadFile";
    const s3UploadInstance = axios.create();

    // Passing file details to get the signedUrl
    post(uploadUrl + "?upload=true", JSON.stringify(jsonBody))
      .then(async (firstUploadResponse) => {
        if (
          firstUploadResponse.data.signedURL !== undefined &&
          firstUploadResponse.data.signedURL !== ""
        ) {
          // Uploading file to the signedUrl
          s3UploadInstance
            .put(firstUploadResponse.data.signedURL, file, {
              headers: { "Content-Type": jsonBody.fileType },
            })
            .then(async () => {
              var newFileUrl = firstUploadResponse.data.signedURL
                .split("?")[0]
                .substr(6);
              console.info("s3-upload done: ", newFileUrl);

              // Processing the uploaded file from here
              post(uploadUrl, JSON.stringify(jsonBody))
                .then(async (thirdUploadResponse) => {
                  console.info("s3-upload done: ", thirdUploadResponse.data);
                  await CheckExcelFile(excelFileName.replace(".csv", ".json"));
                })
                .catch(async (error3) => {
                  console.log("Error3 ", error3);
                  await CheckExcelFile(excelFileName.replace(".csv", ".json"));
                });
            })
            .catch((error2) => {
              errorAction("error 2nd Upload", error2);
            });
        } else {
          toast.current.show({
            severity: "error",
            summary: "File Upload",
            detail: "Something went Wrong!",
          });
        }
      })
      .catch((error) => {
        errorAction("error 1st Upload", error);
        if (error.response.status === 401 || error.response.status === 0) {
          // window.location.href = '';
          // redirect to localhost:3000/ or login route
        }
      });
  };

  const uploadFileOnConfirm = (fileName) => {
    var jsonBody = {
      fileName: fileName,
      userEmail: localStorage.getItem("email"),
    };
    let url = config.api.url + "uploadFile?confirm=true";
    post(url, jsonBody)
      .then((response) => {
        if (fileName.includes("createDisableUsers_")) {
          toast.current.show({
            severity: "success",
            summary: "File Upload",
            detail: "Users have been disabled",
          });
        } else {
          toast.current.show({
            severity: "success",
            summary: "File Upload",
            detail: response.data.message,
          });
        }
      })
      .catch((error) => {
        console.log(error);
        toast.current.show({
          severity: "error",
          summary: "File Upload",
          detail: "Something went Wrong!",
        });
      });
  };

  const uploadExcelFile = () => {
    if (!file) {
      toast.current.show({
        severity: "info",
        summary: "File Upload",
        detail: "Please select file to upload",
      });
    } else {
      if (
        ![
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
        ].includes(file.type)
      ) {
        toast.current.show({
          severity: "error",
          summary: "File Upload",
          detail: "Please upload a valid excel (.xsl/.XLSX) file.",
        });
        resetFileInput();
      } else {
        processAndUploadFile();
        setIsUploading(true);
      }
    }
  };

  return (
    <div className="card flex justify-content-center">
      <Toast ref={toast}></Toast>
      <Dialog
        header={props.dialogTitle}
        position="top"
        visible={props.excelDialogVisible}
        onHide={() => props.excelDialogOnClose(false)}
        draggable={false}
        resizable={false}
        dismissableMask={true}
        style={{ width: "50vw" }}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
      >
        <p className="pl-2">
          Please click on the help icon to get details on how to use the upload
          feature &nbsp;
          <span
            className="pi pi-question-circle"
            title="Help for CSV file"
            onClick={() => setVisibleHelpDialog(true)}
          />
          <span className="sr-only">Help for CSV file</span>
        </p>

        <p className="pl-2">{props.dialogSubTitle}</p>

        <div className="ml-2 mb-3">
          <div className="input-group">
            <div className="custom-file ">
              <input
                type="file"
                className="custom-file-input "
                accept=".xlsx,.xls"
                id="excel_file"
                onChange={handleFileChange}
              />
              <label className="custom-file-label" htmlFor="excel_file">
                {fileChooserLabel}
              </label>
            </div>
          </div>
        </div>

        <Button
          name="fileUploadButton"
          icon={isUploading ? "pi pi-spin pi-spinner" : "pi pi-upload"}
          label={isUploading ? "Uploading..." : "Upload File"}
          style={{ background: "black" }}
          onClick={() => {
            uploadExcelFile();
          }}
          disabled={isUploading}
          className="mt-2 ml-2"
        />
      </Dialog>

      <HelpDialog
        visibleHelpDialog={visibleHelpDialog}
        setVisibleHelpDialog={setVisibleHelpDialog}
      />
      <ExcelErrorDialog
        dialogTitle={dialogTitle}
        visibleExcelErrorDialog={visibleExcelErrorDialog}
        setVisibleExcelErrorDialog={setVisibleExcelErrorDialog}
        errorExcelData={errorExcelData}
        submitExcelConfirmation={(confirmationValue) => {
          if (confirmationValue) {
            uploadFileOnConfirm(errorExcelData.uploadedFilename);
          } else {
            toast.current.show({
              severity: "info",
              summary: "File Upload",
              detail: "Upload aborted",
            });
          }
          setVisibleExcelErrorDialog(false);
        }}
      />
    </div>
  );
};
export default ExcelUploadDialog;
