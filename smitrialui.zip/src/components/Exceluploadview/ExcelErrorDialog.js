import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Dialog } from "primereact/dialog";
import React from "react";
import { useNavigate } from "react-router-dom";

const ExcelErrorDialog = (props) => {
  const navigate = useNavigate();

  const getTableHeader = (fileName) => {
    let columns = [];

    if (fileName && fileName.includes("createUser_")) {
      columns = [
        { field: "email", header: "Email" },
        { field: "family_name", header: "Last Name" },
        { field: "given_name", header: "First Name" },
        { field: "role", header: "Role" },
        { field: "site", header: "Site" },
        { field: "subrole", header: "Subrole" },
        { field: "language", header: "Language" },
        { field: "reason", header: "Reason" },
      ];
    } else if (fileName && fileName.includes("createDataSites_")) {
      columns = [
        { field: "siteName", header: "Name" },
        { field: "description", header: "Description" },
        { field: "address", header: "Address" },
        { field: "country", header: "Country" },
        { field: "reason", header: "Reason" },
      ];
    } else if (fileName && fileName.includes("createAssignSite_")) {
      columns = [
        { field: "email", header: "Email" },
        { field: "name", header: "Site name" },
        { field: "reason", header: "Reason" },
      ];
    } else if (fileName && fileName.includes("createDisableUsers_")) {
      columns = [
        { field: "email", header: "Email" },
        { field: "reason", header: "Reason" },
      ];
    } else if (fileName && fileName.includes("uploadLessonCompletion_")) {
      columns = [
        { field: "email", header: "Email" },
        { field: "reason", header: "Reason" },
      ];
    }
    return columns;
  };

  return (
    <Dialog
      header={props.dialogTitle}
      position="top"
      visible={props.visibleExcelErrorDialog}
      closable={false}
      onHide={() => props.setVisibleExcelErrorDialog(false)}
      draggable={false}
      resizable={false}
      // style={{ width: '55vw' }}
      breakpoints={{ "960px": "75vw", "641px": "100vw" }}
    >
      <div id="excel_data_errors" className="mt-2"></div>

      {props.errorExcelData.errorRecordsLength ? (
        <DataTable
          resizableColumns
          paginator
          rows={10}
          paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
          currentPageReportTemplate="{first} to {last} of {totalRecords}"
          value={props.errorExcelData.errorRecords}
        >
          {getTableHeader(props.errorExcelData.uploadedFilename).map((col) => (
            <Column key={col.field} field={col.field} header={col.header} />
          ))}
        </DataTable>
      ) : (
        ""
      )}

      <p
        className="text-muted ml-1"
        id="modalsubtitle_message"
        style={{
          display:
            props.errorExcelData.successRecordsLength === 0 ? "none" : "block",
        }}
      >
        Click confirm to proceed or cancel to abort the upload
      </p>

      <p className="text-muted ml-1" id="modalsubtitle_novalidrecordsmessage">
        {props.errorExcelData.successRecordsLength === 0
          ? "Click Cancel to exit"
          : ""}
      </p>

      <h5 id="validrecordcounts">
        {" "}
        Valid Records : {props.errorExcelData.successRecordsLength}
      </h5>

      <button
        type="button"
        id="submitExcelConfirmation"
        style={{
          display:
            props.errorExcelData.successRecordsLength === 0 ? "none" : "",
        }}
        onClick={() => {
          if (props.submitExcelConfirmation) {
            props.submitExcelConfirmation(true);
            if (props.setSelectedLessonId) {
              props.setSelectedLessonId(null);
              navigate("/uploadlessoncompletion");
            }
            // window.location.reload("/uploadlessoncompletion");
          }
        }}
        className="btn btn-primary mr-2"
      >
        Confirm
      </button>

      <button
        type="button"
        id="cancelExcelConfirmation"
        data-filename={props.errorExcelData.uploadedFilename}
        onClick={() => {
          if (props.submitExcelConfirmation) {
            props.submitExcelConfirmation(false);
          }
        }}
        className="btn btn-primary"
      >
        Cancel
      </button>
    </Dialog>
  );
};
export default ExcelErrorDialog;
