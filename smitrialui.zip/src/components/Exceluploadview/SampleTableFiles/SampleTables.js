export const CsvFileTableUsers = () => {
    return (
        <table id="csvFileTableUsers" style={{ display: "none" }}>
            <thead>
                <tr><th>email</th><th>family_name</th><th>given_name</th><th>role</th><th>site</th><th>language</th></tr>
            </thead>
            <tbody>
                <tr><td>John.doe@smitrial.com</td><td>Doe</td><td>John</td><td>kp</td><td>San Diego</td><td>English</td></tr>
                <tr><td>Jane.doe@smitrial.com</td><td>Doe</td><td>Jane</td><td>crc</td><td>San Franciso</td><td>Chinese</td></tr>
                <tr><td>don.lee@smitrial.com</td><td>Lee</td><td>Don</td><td>monitor</td><td></td><td>English</td></tr>
            </tbody>
        </table>
    )
}
export const CsvFileTableRole = () => {
    return (
        <table id="csvFileTableRole" style={{ display: "none" }}>
            <thead>
                <tr><th>Role</th></tr>
            </thead>
            <tbody>
                <tr><td>admin</td></tr>
                <tr><td>crc</td></tr>
                <tr><td>cro</td></tr>
                <tr><td>kp</td></tr>
                <tr><td>monitor</td></tr>
                <tr><td>sitepi</td></tr>
                <tr><td>smiadmin</td></tr>
                <tr><td>sponsor</td></tr>
            </tbody>
        </table>
    )
}
export const CsvFileTableAssignSite = () => {
    return (
        <table id="csvFileTableAssignSite" style={{ display: "none" }}>
            <thead>
                <tr><th>email</th><th>name</th></tr>
            </thead>
            <tbody>
                <tr><td>John.doe@smitrial.com</td><td>San Diego</td></tr>
                <tr><td>Jane.doe@smitrial.com</td><td>San Franciso</td></tr>
            </tbody>
        </table>
    )
}
export const CsvFileTableDisableUsers = () => {
    return (
        <table id="csvFileTableDisableUsers" style={{ display: "none" }}>
            <thead>
                <tr><th>emails</th></tr>
            </thead>
            <tbody>
                <tr><td>John.doe@smitrial.com</td></tr>
                <tr><td>Jane.doe@smitrial.com</td></tr>
            </tbody>
        </table>
    )
}
export const CsvFileTableCreateSites = () => {
    return (
        <table id="csvFileTableCreateSites" style={{ display: "none" }}>
            <thead>
                <tr><th>name</th><th>description</th><th>address</th><th>country</th></tr>
            </thead>
            <tbody>
                <tr><td>336889</td><td>St. Luke's Medical Center</td><td>3901 Main Street, New York</td><td>NY USA</td></tr>
                <tr><td>336890</td><td>Center for High Quality Health Care</td><td>1480 Beach St. San Diego</td><td>CA USA</td></tr>
            </tbody>
        </table>
    )
}
export const CsvFileTableUploadLessonCompletion = () => {
    return (
        <table id="csvFileTableUploadLessonCompletion" style={{ display: "none" }}>
            <thead>
                <tr><th>email</th></tr>
            </thead>
            <tbody>
                <tr><td>John.doe@smitrial.com</td></tr>
                <tr><td>Jane.doe@smitrial.com</td></tr>
            </tbody>
        </table>
    )
}
