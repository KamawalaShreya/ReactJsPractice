import { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import { faCheckCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

const Sidebar = (props) => {
  var [topics, setTopics] = useState(null);
  useEffect(() => {
    setTopics(props.topics);
  }, [props.topics]);

  if (
    topics !== undefined &&
    topics !== null &&
    props.toggle &&
    !props.isAssessment
  ) {
    return (
      <Card
        className="p-0 m-0"
        style={{ boxShadow: "none", borderRadius: "0px" }}
      >
        {topics.map((topic) => (
          // href={`lessonviewmobile?lessonid=${props.lessonid}&topicid=${topic.topic_id}`}
          <a
            style={{ border: "1px solid #ecedf1" }}
            onClick={props.onClickTopics}
            key={topic.topic_id}
            className={`p-0 list-group-item list-group-item-action smi-list-group-item smi-topic-${
              topic.topic_id
            } ${
              topic.topic_id === props.topicToLoad.topic_id
                ? "smi-list-group-item-action-hover text-white"
                : ""
            }`}
          >
            <div className="list-group-item-figure">
              <div className="">
                <FontAwesomeIcon
                  icon={faCheckCircle}
                  className="c-smi-green pl-3"
                />
              </div>
            </div>
            <div className="list-group-item-body pr-3 py-3" id={topic.topic_id}>
              {topic.topicname}{" "}
            </div>
          </a>
        ))}
      </Card>
    );
  } else {
    return null;
  }
};
export default Sidebar;
