import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAngleRight, faAngleLeft } from "@fortawesome/free-solid-svg-icons";

export const nextBtn = (props) => {
  let topics = JSON.parse(localStorage.getItem("topics"));
  let currentTopic = localStorage.getItem("topicid");
  let indexOfTopic = topics.findIndex((x) => x.topic_id === currentTopic);

  if (props.topics.length <= 1 || indexOfTopic === topics.length - 1) {
    return (
      <div
        className="col-md-2 col-sm-2 col-2 d-flex align-items-end justify-content-center"
        onClick={props.clickNextBtnFunc}
      >
        <div
          className="mt-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext align-items-center align-self-center d-none d-block"
          style={{ visibility: "hidden" }}
        >
          <FontAwesomeIcon icon={faAngleRight} className="fa-2x c-smi-green" />
        </span>
      </div>
    );
  } else {
    return (
      <div
        className="col-md-2 col-sm-2 col-2 d-flex align-items-end justify-content-center"
        onClick={props.clickNextBtnFunc}
      >
        <div
          className="mt-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext align-items-center align-self-center d-none d-block"
          style={{ visibility: "visible" }}
        >
          <FontAwesomeIcon icon={faAngleRight} className="fa-2x c-smi-green" />
        </span>
      </div>
    );
  }
};
export const prevBtn = (props) => {
  let topics = JSON.parse(localStorage.getItem("topics"));
  let currentTopic = localStorage.getItem("topicid");
  let indexOfTopic = topics.findIndex((x) => x.topic_id === currentTopic);
  if (props.topics.length <= 1 || indexOfTopic === 0) {
    return (
      <div className="col-md-2 col-sm-2 col-2 d-flex align-items-end justify-content-center">
        <div
          className="mt-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext align-items-center align-self-center d-none d-block"
          style={{ visibility: "hidden" }}
        >
          <FontAwesomeIcon icon={faAngleLeft} className="fa-2x c-smi-green" />
        </span>
      </div>
    );
  } else {
    return (
      <div
        className="col-md-2 col-sm-2 col-2 d-flex align-items-end justify-content-center"
        onClick={props.clickPrevBtnFunc}
      >
        <div
          className="mt-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext align-items-center align-self-center d-none d-block"
          style={{ visibility: "visible" }}
        >
          <FontAwesomeIcon icon={faAngleLeft} className="fa-2x c-smi-green" />
        </span>
      </div>
    );
  }
};
