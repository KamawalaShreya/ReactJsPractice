import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";

const LessonHeader = (props) => {
  const navigate = useNavigate();
  return (
    <div
      style={{ boxShadow: "none", background: "none" }}
      className="card card-fluid d-block m-0"
      id="lessonviewMobilePageLessonList"
    >
      {props.ackFlag && (
        <div
          className="text-center p-2"
          style={{
            backgroundColor: "#fff",
            marginBottom: "20px",
            boxShadow: " 0 0.5rem 1rem rgba(20, 20, 31, 0.15) !important;",
          }}
        >
          <div className=" ml-2 ">
            <button
              type="button"
              id="lessonComplete"
              onClick={() => {
                const url =
                  "/acknowledge?lessonid=" + props.lessondetails.lessonid;
                navigate(url);
              }}
              className={`lessonViewLessonComplete  btn btn-primary btn-xs ml-3 mt-2 ${props.ackFlag ? "" : "d-none"
                }`}
            >
              Acknowledge Completion
            </button>
          </div>
          <div className={`alert alert-dark m-4 text-center`}>
            <p>
              {" "}
              You have completed this lesson. Click the button "Acknowledge
              Completion" to update your training record.
            </p>
          </div>
        </div>
      )}

      {props?.isAssessment === false && (
        <div
          className="card-header"
          style={{ paddingLeft: "26px !important", backgroundColor: "#fff" }}
        >
          <div className="form-inline">
            <button
              className={`hamburger hamburger-squeeze mr-2 sidebarToggleMobile ${props.topicToLoad === "PDF.pdf" ? "d-none" : ""
                }`}
              type="button"
              aria-label="toggle menu"
              onClick={props.handleToggle}
            >
              <span className="hamburger-box">
                {" "}
                <span className="hamburger-inner"></span>
              </span>
            </button>
            <h5 className="mt-2 d-inline-block mr-1 ml-2" id="lessonName">
              {props.lessondetails.lessonname}
            </h5>
            <a
              id="lessonviewPageShare"
              // href={`messages.html?newmessage=yes&lessonlink=https://Fhatchery.smitrial.com/html/lessonviewmobile.htm/lessonid=${props.lessondetails.lessonid}&lessonname=${props.lessondetails.lessonname}#messagePageMessageCard`}
              href={`messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessondetails.lessonid}&lessonname=${props.lessondetails.lessonname}#messagePageMessageCard`}
              onClick={(e) => {
                e.preventDefault();
                navigate(
                  `/messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessondetails.lessonid}&lessonname=${props.lessondetails.lessonname}#messagePageMessageCard`
                );
              }}
            >
              <FontAwesomeIcon icon={faEnvelope} />
            </a>
          </div>
        </div>
      )}
      <div
        className={`col-md-3 col-md-3 pl-5 pr-5 pt-3 pb-3 
        ${props.lessondetails.languages &&
            props.lessondetails.languages.length > 1
            ? ""
            : "d-none"
          }`}
      >
        <div
          className={`${props.lessondetails.languages &&
            props.lessondetails.languages.length > 1
            ? ""
            : "d-none"
            }`}
          id="languageSelectDiv "
        >
          <select
            className="custom-select custom-select-sm "
            id="languageSelect"
            value={props.selectedLanguage ? props.selectedLanguage : ""}
            onChange={(e) => {
              if (props.languageChangeHandler) {
                props.languageChangeHandler(e.target.value);
              }
            }}
          >
            {props.lessondetails.languages &&
              props.lessondetails.languages?.length > 1 &&
              props.lessondetails.languages.map((value) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
          </select>
        </div>
      </div>
      {props.retakeFlag && (
        <div
          id="retakeAssessment"
          className={`alert alert-dark d-sm-none mt-2 ml-2 mr-2 text-center`}
          role="alert"
        >
          <button
            type="button"
            id="retakeAssessment"
            onClick={() => {
              if (props.retakeHandler) {
                props.retakeHandler();
              }
            }}
            className={`lessonViewLessonComplete btn btn-primary btn-xs mb-3 `}
            data-toggle="modal"
            data-target="#retakeAssessmentModel"
          >
            Retake Assessment
          </button>
          <p>
            You have already completed this assignment. Click the button "Retake
            Assessment" to erase your prior training record.
          </p>
        </div>
      )}
    </div>
  );
};
export default LessonHeader;
