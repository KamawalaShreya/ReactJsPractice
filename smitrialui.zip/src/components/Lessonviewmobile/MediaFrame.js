import React, { useEffect, useRef, useState } from "react";
import { Player } from "video-react";
import { Card } from "react-bootstrap";
import "video-react/dist/video-react.css";
import config from "../../config/config.json";
import { nextBtn, prevBtn } from "./FrameButtons";
import { post } from "../../utils/HttpRequest";
import { Button } from "primereact/button";
import { FullScreen, useFullScreenHandle } from "react-full-screen";
import "./MediaFrame.css";

// import { faUpRightAndDownLeftFromCenter } from "@fortawesome/free-solid-svg-icons";

import {
  faCompress,
  faUpRightAndDownLeftFromCenter,
} from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./MediaFrame.css";

const MediaFrame = (props) => {
  const playerRef = useRef(null);

  const handle = useFullScreenHandle();

  const [selectedValue, setSelectedValue] = useState(null);
  const [topicToLoad, setTopicToLoad] = useState(null);
  const [url, setUrl] = useState(null);
  const [iframeStyle, setIframeStyle] = useState(null);
  const [iframeStyleImage, setIframeStyleImage] = useState(null);
  const [isSubmittingAnswer, setIsSubmittingAnswer] = useState(false);

  const [isFullScreen, setIsFullScreen] = useState(false);

  const toggleFullScreen = (e) => {
    e.preventDefault();

    const iframe = document.getElementById("topicIframeDiv");

    if (iframe) {
      const isMobileDevice =
        /iPhone|iPad|iPod|Android|webOS|BlackBerry|Windows Phone/i.test(
          navigator.userAgent
        );
      const isSmallScreen = window.innerWidth < 480;

      if (isMobileDevice || isSmallScreen) {
        if (!isFullScreen) {
          if (iframe.webkitEnterFullScreen) {
            iframe.webkitEnterFullScreen();
          }
          if (iframe.requestFullscreen) {
            iframe.requestFullscreen();
          } else if (iframe.webkitRequestFullscreen) {
            iframe.webkitRequestFullscreen();
          } else if (iframe.mozRequestFullScreen) {
            iframe.mozRequestFullScreen();
          } else if (iframe.msRequestFullscreen) {
            iframe.msRequestFullscreen();
          } else {
            console.log("Fullscreen not supported");
          }
        } else {
          if (document.exitFullscreen) {
            document.exitFullscreen();
          } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
          } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
          } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
          } else if (iframe.webkitExitFullscreen) {
            iframe.webkitExitFullscreen();
          } else {
            console.log("Fullscreen not supported");
          }
        }
      }

      setIsFullScreen(!isFullScreen);
    }
  };

  const toggleFullScreenVideo = (e) => {
    e.preventDefault();
    const iframee = document.getElementById("videoPlayer");
    const videotag = document.getElementsByTagName("video")[0];

    if (iframee) {
      if (!isFullScreen) {
        if (videotag.fullscreenEnabled) {
          videotag.requestFullscreen();
          setIsFullScreen(false);
        } else if (videotag.webkitEnterFullscreen) {
          videotag.webkitEnterFullscreen();
          setIsFullScreen(false);
        } else if (videotag.mozRequestFullScreen) {
          videotag.mozRequestFullScreen();
          setIsFullScreen(false);
        } else if (videotag.webkitRequestFullscreen) {
          videotag.webkitRequestFullscreen();
          setIsFullScreen(false);
        } else if (videotag.msRequestFullscreen) {
          videotag.msRequestFullscreen();
          setIsFullScreen(false);
        } else {
          alert("Fullscreen not supported");
        }
      } else {
        if (document.exitFullscreen) {
          document.exitFullscreen();
        } else if (document.mozCancelFullScreen) {
          document.mozCancelFullScreen();
        } else if (document.webkitExitFullscreen) {
          document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
          document.msExitFullscreen();
        } else if (iframee.webkitExitFullscreen) {
          iframee.webkitExitFullscreen();
        } else {
          alert("Fullscreen not supported");
        }
      }
      // setIsFullScreen(!isFullScreen);
    }
  };

  useEffect(() => {
    setTopicToLoad(props.topicToLoad);
    if (props.topicToLoad) {
      if (props.selectedLanguage && props.selectedLanguage !== "English") {
        setUrl(
          config.content.url +
          props.lessonid +
          "/" +
          props.selectedLanguage +
          "/" +
          props.topicToLoad.topic_id +
          "/" +
          props.topicToLoad.topicmedia
        );
      } else {
        setUrl(
          config.content.url +
          props.lessonid +
          "/" +
          props.topicToLoad.topic_id +
          "/" +
          props.topicToLoad.topicmedia
        );
      }
    }

    setIframeStyle({
      width: "-webkit-fill-available",
      height:
        props?.notSetHeight === "true" &&
          props?.topicToLoad?.topicmedia?.includes("html")
          ? "40vh"
          : "25vh",
    });
    setIframeStyleImage({
      width: "-webkit-fill-available",
      height: props?.notSetHeight === "true" ? "auto" : "71vh",
      alignItems: "center",
    });
    setIsSubmittingAnswer(false);

    const fullscreenChangeHandler = () => {
      const isInFullScreen =
        document.fullscreenElement ||
        document.mozFullScreenElement ||
        document.webkitFullscreenElement ||
        document.msFullscreenElement;

      setIsFullScreen(isInFullScreen);
    };

    document.addEventListener("fullscreenchange", fullscreenChangeHandler);
    document.addEventListener("mozfullscreenchange", fullscreenChangeHandler);
    document.addEventListener(
      "webkitfullscreenchange",
      fullscreenChangeHandler
    );
    document.addEventListener("msfullscreenchange", fullscreenChangeHandler);

    return () => {
      document.removeEventListener("fullscreenchange", fullscreenChangeHandler);
      document.removeEventListener(
        "mozfullscreenchange",
        fullscreenChangeHandler
      );
      document.removeEventListener(
        "webkitfullscreenchange",
        fullscreenChangeHandler
      );
      document.removeEventListener(
        "msfullscreenchange",
        fullscreenChangeHandler
      );
    };
  }, [props.topicToLoad]);

  useEffect(() => {
    setIframeStyle({
      "max-width": isFullScreen ? "100%" : "-webkit-fill-available",
      width: isFullScreen ? "auto" : "-webkit-fill-available",
      height:
        props?.notSetHeight === "true" &&
          props?.topicToLoad?.topicmedia?.includes("html")
          ? "40vh"
          : isFullScreen
            ? "100vh"
            : "25vh",
    });
  }, [isFullScreen]);

  const handleAnswerSubmittion = () => {
    let obj = {};
    obj["answerbyuser"] = topicToLoad[selectedValue];
    obj["lessonid"] = topicToLoad.lessonid;
    obj["testid"] = topicToLoad.testid;
    obj["assessmentid"] = topicToLoad.testid;
    obj["username"] = localStorage.getItem("email");
    obj["questionid"] = topicToLoad.questionid;
    // console.log('submitted answer ', obj);
    setIsSubmittingAnswer(true);
    if (props.clickNextBtnFunc) {
      let url = config.api.url + "insertAnswerData";
      post(url, JSON.stringify(obj))
        .then((result) => {
          let topicData = result.data;
          props.clickNextBtnFunc();
        })
        .catch((err) => {
          console.log("err ", err);
        });
      setSelectedValue(null);
    }
  };

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  if (
    props &&
    props.isAssessment &&
    topicToLoad &&
    (!props.retakeFlag || props.retakeFlag !== true)
  ) {
    return (
      <div
        className={`topicViewer ${props.topics
          .map((topic) =>
            topic.questiontype === "Multiplechoice" ? "p-0" : ""
          )
          .join(" ")}`}
      >
        <div>
          <div className="row" style={{ width: "100%" }}>
            <div
              className={`col-md-8 col-sm-8 ${props.topics
                .map((topic) =>
                  topic.questiontype === "Multiplechoice" ? "p-0" : ""
                )
                .join(" ")}`}
            >
              <div
                id="assessmentData"
                className=" text-left embed-responsive-item"
                style={{ padding: "3rem" }}
              >
                <h6 id="assessmentDataQuestion" className="mt-2">
                  <span className="mb-1">
                    Question {topicToLoad.topicorder} of {props?.topics?.length}
                  </span>
                  <br /> <div className="mt-2" dangerouslySetInnerHTML={{ __html: topicToLoad["question"] }}>
                    {/* {topicToLoad["question"]}  */}
                  </div>
                </h6>
                {topicToLoad["questiontype"] === "text" && (
                  <div id="SurveyTextAnswer">
                    <textarea
                      className="form-control"
                      name="answerbyuser"
                      id="surveyTextAnswer"
                      onChange={handleChange}
                      rows="3"
                      cols="50"
                    ></textarea>
                  </div>
                )}
                {topicToLoad["questiontype"] === "Multiplechoice" &&
                  Array.from({ length: 10 }).map((_, index) => (
                    <div
                      className={`custom-control custom-radio mt-4 ${topicToLoad[`answer${index + 1}`] !== "" ? "" : "d-none"
                        }`}
                      key={`divAssessmentDataAnswer${index + 1}`}
                    >
                      <input
                        className="custom-control-input"
                        id={`a${index + 1}`}
                        type="radio"
                        value={`answer${index + 1}`}
                        onChange={handleChange}
                        checked={selectedValue === `answer${index + 1}`}
                        name="answerbyuser"
                        required=""
                      />
                      <label
                        className="custom-control-label"
                        htmlFor={`a${index + 1}`}
                        id={`assessmentDataAnswer${index + 1}`}
                      >
                        {topicToLoad[`answer${index + 1}`]}
                      </label>
                    </div>
                  ))}
                <Button
                  label={`Save Answer`}
                  style={{ background: "#0f7439", textAlign: "left" }}
                  disabled={!selectedValue}
                  icon={isSubmittingAnswer ? "pi pi-spinner pi-spin" : ""}
                  onClick={() => {
                    handleAnswerSubmittion();
                  }}
                  className={`btn btn-success mt-4`}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } else if (topicToLoad?.topicmedia?.includes(".mp4")) {
    return (
      <div className="topicViewer">
        {/* <Card> */}
        <div className="row" style={{ width: "100%" }}>
          {prevBtn(props)}
          <div className="col-md-8 col-sm-8 col-xs-10 col-8">
            <FullScreen handle={handle}>
              <div
                id="videoPlayer"
                style={{ display: "flex", alignItems: "center" }}
              >
                <Player
                  key={url}
                  autoPlay
                  playsInline
                  allowFullScreen
                  ref={playerRef}
                >
                  <source src={url} />
                </Player>
              </div>
            </FullScreen>
          </div>
          <Button
            // label={isFullScreen ? "Exit Full Screen" : "Full Screen"}
            icon={<FontAwesomeIcon icon={faUpRightAndDownLeftFromCenter} />}
            // icon={
            //   isFullScreen ? (
            //     <FontAwesomeIcon icon={faCompress} />
            //   ) : (
            //     <FontAwesomeIcon icon={faUpRightAndDownLeftFromCenter} />
            //   )
            // }

            onClick={toggleFullScreenVideo}
            className="p-button-rounded p-button-text p-button-plain"
            style={{
              position: "absolute",
              bottom: "32px",
              backgroundColor: "#4d4d4d",
              color: "#fff",
              borderRadius: "0.25rem",
              height: "38px",
              width: "40px",
              right: "20px",
              zIndex: "2",
            }}
          />

          {nextBtn(props)}
        </div>
        {/* </Card> */}
      </div>
    );
  } else if (topicToLoad?.topicmedia?.toLowerCase()?.includes(".pdf")) {
    var topicURL =
      "https://mozilla.github.io/pdf.js/web/viewer.html?file=" + url;
    return (
      <div className="topicViewer">
        <div className="row" style={{ width: "100%" }}>
          {prevBtn(props)}
          <div
            className={`col-md-8 col-sm-8 col-xs-8 col-8 p-0 ${isFullScreen ? "topicIframeDivstyle" : ""
              }`}
            id="topicIframeDiv"
            allowFullScreen
            webkitAllowFullScreen
          >
            {isFullScreen && (
              <Button
                icon={<FontAwesomeIcon icon={faCompress} />}
                onClick={toggleFullScreen}
                className="p-button-rounded p-button-text p-button-plain"
                style={{
                  position: "absolute",
                  top: "44px",
                  left: "20px",
                  backgroundColor: "#4d4d4d",
                  color: "#fff",
                  borderRadius: "0.25rem",
                  height: "38px",
                  width: "40px",
                  zIndex: "9999",
                }}
              />
            )}
            <Card style={iframeStyle} className="mb-2">
              <iframe
                className="embed-responsive-item mb-0"
                id="topicIframe"
                style={iframeStyle}
                src={topicURL}
                title="pdf_frame"
                allowFullScreen
                webkitAllowFullScreen
              ></iframe>
            </Card>
          </div>
          <div
            className="col-md-2 col-sm-2 col-xs-1 col-2 d-flex align-items-center justify-content-center"
            style={{ position: "relative" }}
          >
            <Button
              // label={isFullScreen ? "Exit Full Screen" : "Full Screen"}
              icon={<FontAwesomeIcon icon={faUpRightAndDownLeftFromCenter} />}
              onClick={toggleFullScreen}
              className="p-button-rounded p-button-text p-button-plain"
              style={{
                position: "absolute",
                bottom: "10px",
                backgroundColor: "#4d4d4d",
                color: "#fff",
                borderRadius: "0.25rem",
                height: "38px",
                width: "40px",
                right: "0",
                left: "15px",
                zIndex: "2",
              }}
            />
            {nextBtn(props)}
          </div>
        </div>
      </div>
    );
  } else if (topicToLoad?.topicmedia?.toLowerCase()?.includes(".html")) {
    return (
      <div className="topicViewer">
        <div className="row" style={{ width: "100%" }}>
          {prevBtn(props)}
          <div className="col-md-8 col-sm-8 col-xs-10 col-8">
            <Card style={iframeStyle} className="shadow-none">
              <iframe
                className="embed-responsive-item"
                id="topicIframe"
                src={url}
                style={iframeStyle}
                allowFullScreen
                title="html_frame"
                frameBorder="0"
              ></iframe>
            </Card>
            <Button
              icon={<FontAwesomeIcon icon={faUpRightAndDownLeftFromCenter} />}
              onClick={toggleFullScreen}
              className="p-button-rounded p-button-text p-button-plain"
              style={{
                position: "absolute",
                bottom: "0",
                backgroundColor: "#4d4d4d",
                color: "#fff",
                borderRadius: "0.25rem",
                height: "38px",
                width: "40px",
                right: "-40px",
                zIndex: "2",
              }}
            />
          </div>
          {nextBtn(props)}
        </div>
      </div>
    );
  } else if (
    topicToLoad?.topicmedia?.toLowerCase()?.includes(".png") ||
    topicToLoad?.topicmedia?.toLowerCase()?.includes(".jpg")
  ) {
    return (
      <div className="topicViewer">
        <div className="row" style={{ width: "100%" }}>
          {prevBtn(props)}
          <div className="col-md-8 col-sm-8 col-xs-10 col-8">
            <Card style={iframeStyleImage} className="mb-0">
              <div id="topicIframeDiv">
                <img
                  className=""
                  style={{ maxWidth: "100%", maxHeight: "100%" }}
                  title="image_frame"
                  alt="image_frame"
                  src={url}
                ></img>
              </div>
            </Card>
            <Button
              icon={<FontAwesomeIcon icon={faUpRightAndDownLeftFromCenter} />}
              onClick={toggleFullScreen}
              className="p-button-rounded p-button-text p-button-plain"
              style={{
                position: "absolute",
                bottom: "0",
                backgroundColor: "#4d4d4d",
                color: "#fff",
                borderRadius: "0.25rem",
                height: "38px",
                width: "40px",
                right: "-40px",
                zIndex: "2",
              }}
            />
          </div>
          {nextBtn(props)}
        </div>
      </div>
    );
  }
};

export default MediaFrame;
