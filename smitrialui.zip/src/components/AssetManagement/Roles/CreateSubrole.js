import React, { useRef, useState } from "react";
import { Button, Col, Form, Row } from "react-bootstrap";
import config from "../../../config/config.json";
import { post } from "../../../utils/HttpRequest";
import { Toast } from "primereact/toast";
import { useNavigate } from "react-router-dom";

const CreateSubrole = ({ closeSubRuleModel }) => {
  const navigate = useNavigate();
  const toast = useRef(null);
  const [validated, setValidated] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.target;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        name: form.name.value,
        description: form.description.value,
        role: form.subrole.value,
      };
     
      var url = config.api.url + "createSubRole";
      post(url, formData)
        .then((response) => {
          if (response.status === 200 || response.status === 201) {
            toast.current.show({
              severity: "success",
              summary: "Successfully added",
              detail: "Success",
            });
            setTimeout(() => {
              closeSubRuleModel();
              navigate("/roles");
            }, 1000);
          } else {
            console.error("Error fetching fffff data:");
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            console.log(error);
            toast.current.show({
              severity: "error",
              summary: error.response.data.message,
              detail: error.response.data.message,
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error fetching lesson data:", error);
    }
  };

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <div className="formData">
        <Form
          className="needs-validation"
          onSubmit={handleSubmit}
          noValidate
          validated={validated}
        >
          <span className="card-title d-block">Create Subrole</span>
          <Row className="m-auto">
            <Col lg={12} className="mb-3">
              <Form.Group controlId="validationCustom01">
                <Form.Label>
                  Subrole name <abbr>*</abbr>
                </Form.Label>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  name="name"
                  placeholder="Subrole name "
                  required
                />
                {validated && (
                  <Form.Control.Feedback type="invalid">
                    Valid name is required.
                  </Form.Control.Feedback>
                )}
              </Form.Group>
            </Col>

            <Col lg={12} className="mb-3">
              <Form.Group>
                <Form.Label>
                  Description <abbr>*</abbr>
                </Form.Label>
                <Form.Control
                  type="text"
                  className="form-control input-group"
                  name="description"
                  placeholder="Description"
                  required
                />
                {validated && (
                  <Form.Control.Feedback type="invalid">
                    Valid description is required.
                  </Form.Control.Feedback>
                )}
              </Form.Group>
            </Col>
            <Col lg={12} className="mb-3">
              <Form.Group controlId="validationCustom02">
                <Form.Label>
                  {" "}
                  Role<abbr>*</abbr>
                </Form.Label>
                <Form.Select
                  className="form-control"
                  aria-label="Select Subrole"
                  name="subrole"
                  required
                >
                  <option value=""> Select Role </option>
                  <option value="admin">Admin</option>
                  <option value="crc">CRC</option>
                  <option value="cro">CRO</option>
                  <option value="kp">KP</option>
                  <option value="monitor">Monitor</option>
                  <option value="sitepi">Site PI</option>
                  <option value="smiadmin">SMiTrial Admin</option>
                  <option value="sponsor">Sponsor</option>
                </Form.Select>
                {validated && (
                  <Form.Control.Feedback type="invalid">
                    Please select a subrole.
                  </Form.Control.Feedback>
                )}
              </Form.Group>
            </Col>
          </Row>
          <div className="ml-3 pb-3 pt-3">
            <Button type="submit" className="btn btn-primary">
              Create Subrole
            </Button>
          </div>
        </Form>
      </div>
    </div>
  );
};
export default CreateSubrole;
