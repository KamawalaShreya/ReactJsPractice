import React, { useEffect, useState } from "react";
import { Dialog } from "primereact/dialog";
import { Card, Col, Container, Row } from "react-bootstrap";
import { faAward } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import config from "../../../config/config.json";

const DashboardPreview = (props) => {
  const [clickedLessonId, setClickLessonId] = useState("");
  const [childLessonsData, setChildLessonsData] = useState([]);

  const getFormattedLessonObject = function (lesson) {
    const lessonObj = {};
    lessonObj["id"] = lesson["topicid"]
      ? lesson["topicid"].replace("lessonid-", "")
      : lesson["id"]
        ? lesson["id"]
        : "";
    lessonObj["name"] = lesson["lessonname"];
    lessonObj["order"] = lesson["dashboardvisibleOrder"];
    lessonObj["lessontype"] = lesson["lessontype"]
      ? lesson["lessontype"]
      : "regular";
    lessonObj["lessoncardtype"] = lesson["lessoncardtype"]
      ? lesson["lessoncardtype"]
      : "";
    lessonObj["lessoncardheader"] = lesson["lessoncardheader"]
      ? lesson["lessoncardheader"]
      : "";
    lessonObj["lessoncardfooter"] = lesson["lessoncardfooter"]
      ? lesson["lessoncardfooter"]
      : "";
    lessonObj["lessonDuration"] = "0 min";
    lessonObj["lessonurl"] = lesson["lessonurl"];
    lessonObj["lessondescription"] = lesson["lessondescription"];
    lessonObj["lessonAdded"] = "01/01/2021"; // TO-DO
    lessonObj["status"] = lesson["status"];
    lessonObj["display"] = lesson["dashboardvisible"];
    lessonObj["lessonRequired"] = lesson["lessonassigned"];
    lessonObj["version"] = lesson["version"];
    lessonObj["childlessonids"] = lesson["childlessonids"];
    return lessonObj;
  };

  const getChildData = () => {
    let childLessons = [];
    for (let lesson of props.lessonData) {
      if (lesson.lessonid === clickedLessonId) {

        let childids = lesson.childlessonids.split(",").map((x) => x.trim());

        [...props.lessonData].map((childlesson) => {
          if (childids.includes(childlesson.lessonid)) {
            childLessons.push(getFormattedLessonObject(childlesson));
          }
        });
        break;
      }
    }
    childLessons.sort(function (a, b) {
      var x = isNaN(parseInt(a.order)) ? 0 : parseInt(a.order);
      var y = isNaN(parseInt(b.order)) ? 0 : parseInt(b.order);
      return x - y;
    });
    setChildLessonsData(childLessons);
  };
  useEffect(() => {
    clickedLessonId && getChildData();
  }, [clickedLessonId]);

  return (
    <div className="app">
      <div className="card">
        <Dialog
          header={
            <>
              <span
                style={{
                  marginRight: "5rem !important",
                }}
              >
                Dashboard preview for role {props.Dashboardfor}{" "}
              </span>
              {clickedLessonId && (
                <button
                  type="button"
                  className="btn btn-primary "
                  onClick={() => setClickLessonId("")}
                  id="dashboardSimulatorReturn"
                >
                  Return to Dashboard
                </button>
              )}
            </>
          }
          visible={true}
          position="center"
          style={{ width: "50vw" }}
          draggable={false}
          resizable={false}
          onHide={() => props.onClose(false)}
          dismissableMask={true}
        >
          <div className="smi-page-inner">
            <Container fluid>
              <Row style={{ width: "100%" }}>
                {(clickedLessonId
                  ? childLessonsData
                  : props.DashboardPreviewdata
                ).map((lesson, k) => (
                  <Col key={k} xs={12} md={4} lg={3} className="smi-card-outer">
                    <Card
                      className={`smi-card card-hover-shadow 
                      ${lesson.lessoncardtype} ${lesson.lessoncardtype === "pinkCard"
                          ? "card-border"
                          : ""
                        } ${lesson.lessoncardtype === "blackCard"
                          ? "card-border"
                          : ""
                        } ${lesson.lessoncardtype === "greenCard"
                          ? "card-border"
                          : ""
                        } ${lesson.lessoncardtype === "lightblueCard"
                          ? "card-border"
                          : ""
                        } ${lesson.lessoncardtype === "blueCard"
                          ? "card-border"
                          : ""
                        }
                      `}
                      onClick={() => {
                        lesson.lessontype === "nestedcard" &&
                          setClickLessonId(lesson.id);
                      }}
                    >
                      <Card.Header>
                        <div className="row ">
                          <h6 className="  col-9  truncateText text-left float-left">
                            {lesson.name}
                          </h6>
                          {lesson.status === "completed" ? (
                            <FontAwesomeIcon
                              icon={faAward}
                              color="green"
                              className="col-2 downloadCertificate  c-smi-green smi-btn text-right float-right mt-1"
                            />
                          ) : (
                            ""
                          )}
                        </div>
                      </Card.Header>
                      <Card.Body
                        className="smi-card-body onclickLesson"
                        data-id={lesson.id}
                      >
                        {lesson.lessoncardheader && (
                          <div
                            className={` ${lesson.lessoncardtype === "whiteCard"
                              ? "cardOptionalText1"
                              : ""
                              } ${lesson.lessoncardtype === "blueCard"
                                ? "blueHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "greenCard"
                                ? "greenHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "pinkCard"
                                ? "pinkHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "blackCard"
                                ? "blackHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "lightblueCard"
                                ? "lightblueHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "yellowCard"
                                ? "yellowHeaderBg"
                                : ""
                              } ${lesson.lessoncardtype === "lightgrayCard"
                                ? "lightgrayHeaderCard"
                                : ""
                              }`}
                          >
                            <h6 className="font-weight-300 truncateText">
                              {lesson.lessoncardheader}
                            </h6>
                          </div>
                        )}
                        <div>
                          <a
                            // href={`lessonview?lessonid=${lesson.id}`}
                            href="#"
                            // onClick={(e) => {
                            //   e.preventDefault();
                            //   navigate(`/lessonview?lessonid=${lesson.id}`);
                            // }}
                            className="img-link h-100 d-none d-sm-block d-md-block d-lg-block d-xl-block"
                          >
                            <div>
                              <Card.Img
                                className={`img-fluid d-flex align-items-center justify-content-center cardImg  ${lesson.status === "completed"
                                  ? "completeLesson"
                                  : ""
                                  }`}
                                loading="lazy"
                                src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                                alt={lesson.id}
                              />
                            </div>
                          </a>
                          <a
                            // href={`lessonviewmobile?lessonid=${lesson.id}`}
                            href="#"
                            className="img-link h-100 d-block d-sm-none"
                          >
                            {" "}
                            {/* Mobile view tag */}
                            <div>
                              <Card.Img
                                className={`img-fluid d-flex align-items-center justify-content-center cardImg  ${lesson.status === "completed"
                                  ? "completeLesson"
                                  : ""
                                  }`}
                                loading="lazy"
                                src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                                alt={lesson.id}
                              />
                            </div>
                          </a>
                        </div>
                        {lesson.lessoncardfooter && (
                          <div
                            className={`${lesson.lessoncardtype === "whiteCard"
                              ? "cardFooterOptional1"
                              : ""
                              } ${lesson.lessoncardtype === "blueCard"
                                ? "blueFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "greenCard"
                                ? "greenFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "pinkCard"
                                ? "pinkFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "blackCard"
                                ? "blackFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "lightblueCard"
                                ? "lightblueFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "yellowCard"
                                ? "yellowFooterBg"
                                : ""
                              } ${lesson.lessoncardtype === "lightgrayCard"
                                ? "lightgrayFooterBg"
                                : ""
                              } footer-border`}
                          >
                            <h6 className="font-weight-100 truncateText">
                              {lesson.lessoncardfooter}
                            </h6>
                          </div>
                        )}
                      </Card.Body>
                      <div className="smi-card-footer">
                        <div className="smi-lessoncard-header">
                          <div className="task-title mr-auto w-100">
                            <div className="row">
                              <div className="small p-0 text-left float-left">
                                {" "}
                                {lesson.lessonRequired === "true"
                                  ? "REQUIRED"
                                  : "OPTIONAL"}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </Col>
                ))}
              </Row>
            </Container>
          </div>
        </Dialog>
      </div>
    </div>
  );
};
export default DashboardPreview;
