import React, { useEffect, useState } from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import { Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCircleCheck,
  faDesktop,
  faGear,
  faPlus,
  faUserGear,
} from "@fortawesome/free-solid-svg-icons";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import Datatable from "../../Common/Datatable";
import { useRef } from "react";
import { Toast } from "primereact/toast";
import CreateSubrole from "./CreateSubrole";
import DashboardPreview from "./DashboardPreview";
import BootstrapTable from "react-bootstrap-table-next";

const Roles = () => {
  const toast = useRef(null);
  const [data, setData] = useState([]);
  const [lessonData, setlessonData] = useState([]);
  const [showsRoleTable, setshowsRoleTable] = useState(false);
  const [showLessonTable, setShowLessonTable] = useState(false);
  const [showSubroleTable, setShowSubroleTable] = useState(false);
  const [lessonAssignmentTitle, setLessonAssignmentTitle] = useState("");
  const [AssignmentSubrole, setAssignmentSubrole] = useState("");
  const [selectRoleData, setselectRoleData] = useState({});
  const [SubroleRoleData, setSubroleRoleData] = useState({});
  const [roleUserdata, setRoleUserdata] = useState([]);
  const [subrole, setsubrole] = useState([]);
  const [showCreateSubrole, setShowCreateSubrole] = useState(false);
  const [filteredAndMappedData, setFilteredAndMappedData] = useState([]);
  const [FilteredAndMappedDataSecond, setFilteredAndMappedDataSecond] =
    useState([]);

  const [filteredData, setFilteredData] = useState(lessonData);
  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);

  const [isDashboardPreviewVisible, setIsDashboardPreviewVisible] =
    useState(false);

  const [isDashboardPreviewVisiblesecond, setIsDashboardPreviewVisiblesecond] =
    useState(false);

  const openDashboardPreview = () => {
    setIsDashboardPreviewVisible(true);
  };

  const openDashboardPreviewSecond = () => {
    setIsDashboardPreviewVisiblesecond(true);
  };

  const toggleCreateSubrole = () => {
    setShowCreateSubrole(!showCreateSubrole);
  };
  const getData = async () => {
    try {
      const url = config.api.url + "getAllRoles";
      get(url).then((response) => {
        setData(response.data ? response.data : []);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const handleSearchChange = (e) => {
    const newsearchText = e.target.value;

    let dataAll = [...lessonData];

    const filtered = newsearchText
      ? [...dataAll].filter((item) => {
        const data = ["lessonid", "lessonname"].some((key) =>
          String(item[key])
            .toLowerCase()
            .includes(newsearchText.toLowerCase())
        );
        return data;
      })
      : dataAll;


    // const groupValuesOne = filtered?.map((item) => item.group);
    // setSelectedEmail(groupValuesOne.join("; "));
    setFilteredData(filtered);

    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getFormattedLessonObject = function (lesson) {
    let lessonObj = {};
    lessonObj["id"] = lesson["topicid"]
      ? lesson["topicid"].replace("lessonid-", "")
      : lesson["id"]
        ? lesson["id"]
        : "";
    lessonObj["name"] = lesson["lessonname"];
    lessonObj["order"] = lesson["dashboardvisibleOrder"];
    lessonObj["lessontype"] = lesson["lessontype"]
      ? lesson["lessontype"]
      : "regular";
    lessonObj["lessoncardtype"] = lesson["lessoncardtype"]
      ? lesson["lessoncardtype"]
      : "";
    lessonObj["lessoncardheader"] = lesson["lessoncardheader"]
      ? lesson["lessoncardheader"]
      : "";
    lessonObj["lessoncardfooter"] = lesson["lessoncardfooter"]
      ? lesson["lessoncardfooter"]
      : "";
    lessonObj["lessonDuration"] = "0 min";
    lessonObj["lessonurl"] = lesson["lessonurl"];
    lessonObj["lessondescription"] = lesson["lessondescription"];
    lessonObj["lessonAdded"] = "01/01/2021"; // TO-DO
    lessonObj["status"] = lesson["status"];
    lessonObj["display"] = lesson["dashboardvisible"];
    lessonObj["lessonRequired"] = lesson["lessonassigned"];
    lessonObj["version"] = lesson["version"];
    lessonObj["childlessonids"] = lesson["childlessonids"];
    return lessonObj;
  };

  const getLessonsAssignedForRole = (role, description) => {
    const url = `${config.api.url}getLessonAssigedForRoleOrUser?role=${role}&userRole=role`;
    get(url)
      .then((response) => {
        response.data.sort(function (a, b) {
          var x = parseInt(a.dashboardvisibleOrder);
          var y = parseInt(b.dashboardvisibleOrder);
          if (x === y) {
            return 0;
          }
          if (isNaN(x)) {
            return 1;
          }
          if (isNaN(y)) {
            return -1;
          }
          return x < y ? -1 : 1;
        });

        const filteredData = response.data.filter(
          (word) =>
            word.dashboardvisible === "true" &&
            word.dashboardvisibleOrder !== undefined &&
            word.dashboardvisibleOrder !== ""
        );



        const filteredDataaa =
          filteredData.length === 0
            ? response.data.filter(
              (word) =>
                word.companyDashboardVisibility !== undefined &&
                word.companyDashboardVisibility === "visible"
            )
            : [];

        const mappedData = [...filteredData, ...filteredDataaa].map((x) =>
          getFormattedLessonObject(x)
        );
        // const mappedData = filteredData.map((x) => getFormattedLessonObject(x));

        setFilteredAndMappedData(mappedData);
        setlessonData(response.data);
        setFilteredData(response.data);
        setShowLessonTable(true);
        setLessonAssignmentTitle(description);
      })
      .catch((error) => {
        console.error("Error fetching lesson data:", error);
      });
  };

  const displaySubRole = (role, description) => {
    const url = config.api.url + "getSubRole/" + role;
    get(url)
      .then((response) => {
        setsubrole(response.data);
        setshowsRoleTable(true);
        setLessonAssignmentTitle(description);
      })
      .catch((error) => {
        console.error("Error fetching lesson data:", error);
      });
  };

  const getLessonAssigedForRoleOrUser = (row) => {
    const url = `${config.api.url}getLessonAssigedForRoleOrUser?role=${SubroleRoleData.group}&userRole=role`;
    get(url)
      .then((response) => {

        const filteredData = [...response.data].filter(
          (word) =>
            word.dashboardvisible === "true" &&
            word.dashboardvisibleOrder !== undefined &&
            word.dashboardvisibleOrder !== ""
        );

        const mappedData = [...filteredData].map((x) =>
          getFormattedLessonObject(x)
        );
        setFilteredAndMappedDataSecond(mappedData);
        setRoleUserdata(response.data);
        setShowSubroleTable(true);
        setAssignmentSubrole(row.subrolename);
      })
      .catch((error) => {
        console.error("Error fetching lesson data:", error);
      });
  };

  const displaySubRoleUserColumn = (row) => {
    const url = `${config.api.url}getLessonAssigedForSubRoleOrUser?role=${SubroleRoleData.group}&subrole=${row.subrolename}`;
    get(url)
      .then((response) => {

        const filteredData = [...response.data].filter(
          (word) =>
            word.dashboardvisible === "true" &&
            word.dashboardvisibleOrder !== undefined &&
            word.dashboardvisibleOrder !== ""
        );
        if (filteredData.length === 0) {
          getLessonAssigedForRoleOrUser(row);
        } else {
          const mappedData = [...filteredData].map((x) =>
            getFormattedLessonObject(x)
          );
          setlessonData(response.data);
          setFilteredAndMappedDataSecond(mappedData);
          setRoleUserdata(response.data);
          setShowSubroleTable(true);
          setAssignmentSubrole(row.subrolename);
        }
      })
      .catch((error) => {
        console.error("Error fetching lesson data:", error);
      });
  };

  const handleStatusChange = async (lessonid, dashboardvisible) => {
    try {
      const newDashboardVisible =
        dashboardvisible === "true" ? "false" : "true";
      const formData = {
        lessonid: lessonid,
        display: newDashboardVisible,
        role: selectRoleData.group,
      };
      var url = config.api.url + "updateLessonVisibilityOnDashboard";
      post(url, formData).then(async (response) => {
        if (response.status === 200) {
          toast.current.show({
            severity: "success",
            summary: "Successfully updated",
            detail: "Success",
          });
        } else {
          toast.current.show({
            severity: "error",
            summary: "something want wrong",
            detail: "Error getting handling lesson assignment.",
          });
        }
      });
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    }
  };

  const handlerequiredClick = async (lessonid, lessonassigned) => {
    try {
      let apiEndpoint = lessonassigned
        ? "assignLesson"
        : "unassignLessonForRole";

      const url = `${config.api.url}${apiEndpoint}`;
      const requestData = {
        lessonid: lessonid,
        entity: "role",
        name: selectRoleData.group,
      };
      const response = await post(url, requestData);
      if (response.status === 200) {
        toast.current.show({
          severity: "success",
          summary: "Successfully updated",
          detail: "Success",
        });
      } else {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    }
  };

  const handlerequiredClickAssignLessonForSubRole = async (
    lessonid,
    isAssigned
  ) => {
    try {
      const apiEndpoint = isAssigned
        ? "assignLessonForSubRole"
        : "unassignLessonForSubRole";

      const url = `${config.api.url}${apiEndpoint}`;
      const requestData = {
        lessonid: lessonid,
        subrole: "subrole",
        role: SubroleRoleData.group,
        subrolename: AssignmentSubrole,
      };
      const response = await post(url, requestData);
      if (response.status === 200) {
        toast.current.show({
          severity: "success",
          summary: "Successfully updated",
          detail: "Success",
        });
      } else {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    }
  };

  const handleupdateLessonVisibilityOnDashboardForSubRole = async (
    lessonid,
    isAssigned
  ) => {
    try {
      const newDashboardVisible =
        isAssigned === "true" ? "visible" : "invisible";
      const formData = {
        display: newDashboardVisible,
        lessonid: lessonid,
        subrole: "subrole",
        role: SubroleRoleData.group,
        subrolename: AssignmentSubrole,
      };
      var url = config.api.url + "updateLessonVisibilityOnDashboardForSubRole";
      post(url, formData).then(async (response) => {
        if (response.status === 200) {
          toast.current.show({
            severity: "success",
            summary: "Successfully updated",
            detail: "Success",
          });
        } else {
          toast.current.show({
            severity: "error",
            summary: "something want wrong",
            detail: "Error getting handling lesson assignment.",
          });
        }
      });
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting handling lesson assignment.",
        });
      }
    }
  };

  const siteColumn = [
    {
      dataField: "description",
      text: "Role Name",
    },
    {
      dataField: "group",
      text: "Edit lesson assignment",
      formatter: (cell, row, index) => {
        return (
          <div className="text-center" key={index}>
            <div
              style={{ cursor: "pointer" }}
              className="btn btn-sm btn-icon btn-secondary "
              onClick={() => {
                setShowCreateSubrole(false);
                setshowsRoleTable(false);
                setShowLessonTable(false);
                setShowSubroleTable(false);
                setselectRoleData({
                  group: row.group,
                  description: row.description,
                });
                getLessonsAssignedForRole(row.group, row.description);
              }}
            >
              <FontAwesomeIcon className="text-teal" icon={faGear} />
            </div>
          </div>
        );
      },
    },
    {
      dataField: "name",
      text: "Subrole details",
      formatter: (cell, row) => {
        return (
          <div className="text-center">
            <div
              style={{ cursor: "pointer" }}
              className="btn btn-sm btn-icon btn-secondary "
              onClick={() => {
                setShowCreateSubrole(false);
                setshowsRoleTable(false);
                setShowLessonTable(false);
                setShowSubroleTable(false);
                setSubroleRoleData({ group: row.group });
                displaySubRole(row.group, row.description, row);
              }}
            >
              <FontAwesomeIcon className="text-teal" icon={faUserGear} />
            </div>
          </div>
        );
      },
    },
  ];

  const LessonAssignmentColumn = [
    {
      dataField: "lessonid",
      text: "Lesson Id",
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "lessonname",
      text: "Lesson Name",
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "companyDashboardVisibility",
      text: "Company Dashboard Visibility",
      formatter: (cell, row) => {
        return row?.companyDashboardVisibility ? (
          <FontAwesomeIcon icon={faCircleCheck} />
        ) : (
          ""
        );
      },
    },
    {
      dataField: "companyDashboardVisibilityOrder",
      text: " Company Dashboard Visibility Order No",
    },
    {
      dataField: "lessonassigned",
      text: "Required",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${row?.lessonassigned === "true"
                  ? "switcher-control-success"
                  : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  defaultChecked={row?.lessonassigned === "true" ? true : false}
                  onClick={() => {
                    setlessonData((prev) => [
                      ...prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            lessonassigned:
                              row?.lessonassigned === "true" ? "false" : "true",
                          };
                        } else {
                          return role;
                        }
                      }),
                    ]);
                    setFilteredData((prev) => [
                      ...prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            lessonassigned:
                              row?.lessonassigned === "true" ? "false" : "true",
                          };
                        } else {
                          return role;
                        }
                      }),
                    ]);
                    handlerequiredClick(
                      row.lessonid,
                      row?.lessonassigned === "true" ? false : true
                    );
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "dashboardvisible",
      text: "Visible on Dashboard",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${row?.dashboardvisible === "true"
                  ? "switcher-control-success"
                  : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  defaultChecked={
                    row?.dashboardvisible === "true" ? true : false
                  }
                  onChange={() => {
                    setlessonData((prev) =>
                      prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            dashboardvisible:
                              row?.dashboardvisible === "true"
                                ? "false"
                                : "true",
                          };
                        } else {
                          return role;
                        }
                      })
                    );
                    setFilteredData((prev) =>
                      prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            dashboardvisible:
                              row?.dashboardvisible === "true"
                                ? "false"
                                : "true",
                          };
                        } else {
                          return role;
                        }
                      })
                    );
                    handleStatusChange(
                      row?.lessonid,
                      row?.dashboardvisible === "true" ? "false" : "true"
                    );
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "dashboardvisibleOrder",
      text: "Visible on Dashboard Order No",
    },
  ];

  const subroleColumn = [
    {
      dataField: "subrolename",
      text: "Role Name",
    },
    {
      dataField: "",
      text: "Edit lesson assignment",
      formatter: (cell, row) => {
        return (
          <div className="text-center">
            <div
              style={{ cursor: "pointer" }}
              className="btn btn-sm btn-icon btn-secondary "
              onClick={() => {
                displaySubRoleUserColumn(row);
              }}
            >
              <FontAwesomeIcon className="text-teal" icon={faGear} />
            </div>
          </div>
        );
      },
    },
  ];

  const SubRoleOrUserColumn = [
    {
      dataField: "lessonid",
      text: "Lesson Id",
    },
    {
      dataField: "lessonname",
      text: "Lesson Name",
    },
    {
      dataField: "companyDashboardVisibility",
      text: "Company Dashboard Visibility",
      formatter: (cell, row) => {
        return row?.companyDashboardVisibility ? (
          <FontAwesomeIcon icon={faCircleCheck} />
        ) : (
          ""
        );
      },
    },
    {
      dataField: "companyDashboardVisibilityOrder",
      text: " Company Dashboard Visibility Order No",
    },
    {
      dataField: "lessonassigned",
      text: "Required",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${row?.lessonassigned === "true"
                  ? "switcher-control-success"
                  : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  defaultChecked={row?.lessonassigned === "true" ? true : false}
                  onClick={() => {
                    setRoleUserdata((prev) =>
                      prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            lessonassigned:
                              row?.lessonassigned === "true" ? "false" : "true",
                          };
                        } else {
                          return role;
                        }
                      })
                    );
                    handlerequiredClickAssignLessonForSubRole(
                      row?.lessonid,
                      row?.lessonassigned === "true" ? false : true
                    );
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "dashboardvisible",
      text: "Visible on Dashboard",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${row?.dashboardvisible === "true"
                  ? "switcher-control-success"
                  : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  defaultChecked={
                    row?.dashboardvisible === "true" ? true : false
                  }
                  onChange={() => {
                    setRoleUserdata((prev) =>
                      prev.map((role) => {
                        if (role.lessonid === row.lessonid) {
                          return {
                            ...role,
                            dashboardvisible:
                              row?.dashboardvisible === "true"
                                ? "false"
                                : "true",
                          };
                        } else {
                          return role;
                        }
                      })
                    );
                    handleupdateLessonVisibilityOnDashboardForSubRole(
                      row.lessonid,
                      row?.dashboardvisible === "true" ? "false" : "true"
                    );
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "dashboardvisibleOrder",
      text: "Visible on Dashboard Order No",
    },
  ];

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="SiteManagerPage">
          <Row>
            <Col lg={3}>
              <div className="page-inner siteManagerClass">
                <Card style={{ width: "100%" }}>
                  <div className="d-flex justify-content-between">
                    <span className="card-title ">Role</span>
                    <div className="d-flex align-items-center">
                      <span className="card-title ">Create Subrole</span>
                      <Link
                        to=""
                        onClick={() => {
                          setShowSubroleTable(false);
                          setshowsRoleTable(false);
                          setShowLessonTable(false);
                          toggleCreateSubrole();
                        }}
                      >
                        <span className="tile tile-circle tile-md text-white smi-tile-primary createLesson smi-btn">
                          <FontAwesomeIcon icon={faPlus} />
                        </span>
                      </Link>
                    </div>
                  </div>
                  <BootstrapTable
                    keyField={"group"}
                    data={data}
                    columns={siteColumn}
                    striped
                    bordered={true}
                  />
                </Card>
              </div>
            </Col>
            {showLessonTable && data.length !== 0 && (
              <Col lg={7}>
                <div className="page-inner siteManagerClass">
                  <Card style={{ width: "100%" }}>
                    <div className="d-flex justify-content-between align-items-center px-3">
                      <span className="card-title ">
                        Lesson assignment for role {lessonAssignmentTitle}
                      </span>
                      <span onClick={openDashboardPreview}>
                        <FontAwesomeIcon
                          className="text-teal"
                          icon={faDesktop}
                        />
                      </span>
                    </div>
                    <Datatable
                      keyField={"lessonid"}
                      data={filteredData}
                      columns={LessonAssignmentColumn}
                      filteredData={filteredData}
                      Pagination={true}
                      Paginationnumber={true}
                      sizePerPage={50}
                      showrow={false}
                      // isVisibleText={false}
                      isActionEnable={false}
                      handleSearchChange={handleSearchChange}
                      searchText={searchText}
                    />
                  </Card>
                </div>
              </Col>
            )}

            {showsRoleTable && subrole.length !== 0 && (
              <Col lg={3}>
                <div className="page-inner siteManagerClass">
                  <Card style={{ width: "100%" }}>
                    <div className="d-flex justify-content-between">
                      <span className="card-title ">
                        Sub Role for {lessonAssignmentTitle}
                      </span>
                    </div>
                    <Datatable
                      keyField={"group"}
                      data={subrole}
                      columns={subroleColumn}
                      filteredData={subrole}
                      Pagination={true}
                      Paginationnumber={true}
                      sizePerPage={50}
                      showrow={false}
                      isVisibleText={false}
                      isActionEnable={false}
                    />
                  </Card>
                </div>
              </Col>
            )}

            {showSubroleTable && roleUserdata.length !== 0 && (
              <Col lg={6}>
                <div className="page-inner siteManagerClass">
                  <Card style={{ width: "100%" }}>
                    <div className="d-flex justify-content-between align-items-center px-3">
                      <span className="card-title ">
                        Lesson assignment for subrole {AssignmentSubrole}
                      </span>
                      <span onClick={openDashboardPreviewSecond}>
                        <FontAwesomeIcon
                          className="text-teal"
                          icon={faDesktop}
                        />
                      </span>
                    </div>
                    <Datatable
                      keyField={"topicid"}
                      data={roleUserdata}
                      columns={SubRoleOrUserColumn}
                      filteredData={roleUserdata}
                      Pagination={true}
                      sizePerPage={50}
                      Paginationnumber={true}
                      showrow={false}
                      isVisibleText={false}
                      isActionEnable={false}
                    />
                  </Card>
                </div>
              </Col>
            )}
            {showCreateSubrole && (
              <Col lg={3}>
                <CreateSubrole
                  closeSubRuleModel={() => setShowCreateSubrole(false)}
                />
              </Col>
            )}
          </Row>
          {isDashboardPreviewVisible && (
            <DashboardPreview
              lessonData={lessonData}
              Dashboardfor={selectRoleData.group}
              DashboardPreviewdata={filteredAndMappedData}
              onClose={() => setIsDashboardPreviewVisible(false)}
            />
          )}

          {isDashboardPreviewVisiblesecond && (
            <DashboardPreview
              lessonData={lessonData}
              Dashboardfor={AssignmentSubrole}
              DashboardPreviewdata={FilteredAndMappedDataSecond}
              onClose={() => setIsDashboardPreviewVisiblesecond(false)}
            />
          )}
        </div>
      </Container>
    </div>
  );
};
export default Roles;
