import React from "react";
import { Card, Col, Modal, Row } from "react-bootstrap";

const ModelPopUp = (show) => {
  return (
    <div className="app">
      <Modal show={show}>
        <Card.Body
          style={{ height: "200px" }}
          className="d-flex justify-content-center align-items-center"
        >
          <Row>
            <Col lg={12}>
              <div className="text-center">
                <h6 className="card-title">
                  Please wait while dashboard is updated
                </h6>
                <div className="mb-3">
                  <i
                    className="pi pi-spin pi-spinner"
                    style={{ fontSize: "3rem" }}
                  ></i>
                </div>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Modal>
    </div>
  );
};
export default ModelPopUp;
