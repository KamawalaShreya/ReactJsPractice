import React, { useRef } from "react";
import { useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import { useEffect } from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import config from "../../../config/config.json";
import ModelPopUp from "./ModelPopUp";
import { ReactSortable } from "react-sortablejs";
import "./DashboardSettings.css";

const DashboardSettings = () => {
  const [modalShow, setModalShow] = useState(false);
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState(data);
  const [filteredUnSortedData, setFiltereUnSorteddData] = useState(data);
  const [orderedDashboardData, setOrderedDashboardData] = useState([]);
  const [searchTextDash, setSearchTextDash] = useState("");
  const [searchTextLessons, setSearchTextLessons] = useState("");
  const inputRefDash = useRef(null);
  const inputRefLessons = useRef(null);

  const [sortToggleLessonId, setSortToggleLessonId] = useState(0);
  const [sortToggleLessonName, setSortToggleLessonName] = useState(0);
  const [sortToggleLessonVersion, setSortToggleLessonVersion] = useState(0);

  const getData = async () => {
    try {
      const url = config.api.url + "getTrialDashbaord";
      // commenting for skipping api call while implementation
      get(url).then((response) => {
        let dashboardData;
        dashboardData = response.data.dashboard.sort(function (a, b) {
          var x = parseInt(a.order);
          var y = parseInt(b.order);
          // equal items sort equally
          if (x === y) {
            return 0;
          }
          if (isNaN(x)) {
            return 1;
          }
          if (isNaN(y)) {
            return -1;
          }
          return x < y ? -1 : 1;
        });
        let orderedLessonIds = [];
        let unorderedLessonIds = [];
        let tempOrderedDashboardData = [];
        let unOrderedDashboardData = [];
        dashboardData.map((d) => {
          if (d.order !== undefined && d.order !== "") {
            orderedLessonIds.push(d.id);
            tempOrderedDashboardData.push(d);
          } else {
            unorderedLessonIds.push(d.id);
            unOrderedDashboardData.push(d);
          }
        });
        setData(unOrderedDashboardData);
        setFilteredData(unOrderedDashboardData);
        setFiltereUnSorteddData(unOrderedDashboardData);
        setOrderedDashboardData(tempOrderedDashboardData);
        resetSortToggles();
        if (searchTextDash !== "") {
          handleDashSearch(searchTextDash);
        }
        if (searchTextLessons) {
          handleLessonsSearch(searchTextLessons);
        }
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const onRowDashboardReorderApi = (value) => {
    const payload = {
      name: "companyDashboard",
      value: JSON.stringify({ dashboard: value }),
    };

    try {
      const url = config.api.url + "updateTrialConfig";
      post(url, payload).then(() => {
        setModalShow(false);
        getData();
      });
    } catch (error) {
      setModalShow(false);
      console.error("Error updating data:", error);
    }
  };

  useEffect(() => {
    getData();
  }, []);

  // Search handler function - dashboard list
  const handleDashSearch = (value) => {
    setSearchTextDash(value);
    let searchValue = value.toLowerCase();
    let tempDashData = orderedDashboardData;
    tempDashData.forEach((lesson) => {
      if (
        lesson.id?.toLowerCase().includes(searchValue) ||
        lesson.name?.toLowerCase().includes(searchValue) ||
        lesson.lessondescription?.toLowerCase().includes(searchValue)
      ) {
        lesson.hidden = false;
      } else {
        lesson.hidden = true;
      }
    });
    setOrderedDashboardData(tempDashData);
  };
  // Search handler function - lessons list
  const handleLessonsSearch = (value) => {
    setSearchTextLessons(value);
    let searchValue = value.toLowerCase();
    let tempLessonsData = filteredData;
    tempLessonsData.forEach((lesson) => {
      if (
        lesson.id?.toLowerCase().includes(searchValue) ||
        lesson.name?.toLowerCase().includes(searchValue) ||
        lesson.lessondescription?.toLowerCase().includes(searchValue)
      ) {
        lesson.hidden = false;
      } else {
        lesson.hidden = true;
      }
    });
    setFilteredData(tempLessonsData);
  };

  // search field reset lessons
  const clearLessonsSearch = () => {
    handleLessonsSearch("");
    inputRefLessons.current.focus();
  };
  // search field reset dashboard
  const clearDashSearch = () => {
    handleDashSearch("");
    inputRefDash.current.focus();
  };

  // event handler for list item add - dashboard
  const handleDashboardAdd = (e) => {
    setModalShow(true);
    let unorderedLessonsData = filteredData;
    let dashData = [...orderedDashboardData];
    const [movedItem] = unorderedLessonsData.splice(e.oldIndex, 1);
    dashData.splice(e.newIndex, 0, movedItem);
    let dashValueToPass = [];
    dashData.forEach((item, index) => {
      item.order = index + 1;
      delete item["selected"];
      delete item["chosen"];
      delete item["status"];
      delete item["lessondescription"];
      delete item["version"];
      item.display = "visible";
      let lessondate = new Date(item["lessonAdded"]);
      item["lessonAdded"] = !isNaN(lessondate.getDate())
        ? lessondate.getDate() +
        "/" +
        (lessondate.getMonth() + 1) +
        "/" +
        lessondate.getFullYear()
        : item["lessonAdded"];
      item["lessonDuration"] =
        isNaN(item["lessonDuration"]) || item["lessonDuration"] == "NAN"
          ? "0 min"
          : item["lessonDuration"];
      dashValueToPass.push({ ...item });
    });
    // console.log(dashValueToPass)
    setOrderedDashboardData(dashData);
    // call API to update the dashboard data
    onRowDashboardReorderApi(dashValueToPass);
  };

  // event handler for list item remove - dashboard
  const handleDashboardRemove = (e) => {
    setModalShow(true);
    let dashData = orderedDashboardData;
    dashData.splice(e.oldIndex, 1);
    let dashValueToPass = [];
    dashData.forEach((item, index) => {
      item.order = index + 1;
      delete item["selected"];
      delete item["chosen"];
      dashValueToPass.push({ ...item });
    });
    // console.log(dashData)
    setOrderedDashboardData(dashData);
    // call API to update the dashboard data
    onRowDashboardReorderApi(dashValueToPass);
  };

  const handleDashboardSort = (e) => {
    setModalShow(true);
    let dashData = [...orderedDashboardData];
    const [movedItem] = dashData.splice(e.oldIndex, 1);
    dashData.splice(e.newIndex, 0, movedItem);
    let dashValueToPass = [];
    dashData.forEach((item, index) => {
      item.order = index + 1;
      delete item["selected"];
      delete item["chosen"];
      dashValueToPass.push({ ...item });
    });
    // console.log(dashValueToPass)
    setOrderedDashboardData(dashData);
    // call API to update the dashboard data
    onRowDashboardReorderApi(dashValueToPass);
  };

  const resetSortToggles = () => {
    setSortToggleLessonId(0);
    setSortToggleLessonName(0);
    setSortToggleLessonVersion(0);
  };

  const getNextSortValue = (currentValue, arrayData, fieldName, fieldName1) => {
    let nextValue = 0;
    if (currentValue === 0) {
      nextValue = -1;
    } else if (currentValue === -1) {
      nextValue = 1;
    }
    let sortedArray;
    if (nextValue === 0) {
      sortedArray = [...filteredUnSortedData];
    } else {
      sortedArray = [...arrayData];
      sortedArray.sort((a, b) => {
        const fieldA =
          `${a[fieldName]}`.toLowerCase() +
          (fieldName1 && b[fieldName1]
            ? ` ${a[fieldName1]}`.toLowerCase()
            : "");
        const fieldB =
          `${b[fieldName]}`.toLowerCase() +
          (fieldName1 && b[fieldName1]
            ? ` ${b[fieldName1]}`.toLowerCase()
            : "");
        if (nextValue === -1) {
          return fieldA.localeCompare(fieldB);
        } else if (nextValue === 1) {
          return fieldB.localeCompare(fieldA);
        }
      });
    }
    // console.log(sortedArray);
    return { sortValue: nextValue, arrayData: sortedArray };
  };

  const toggleSortField = (fieldName) => {
    if (fieldName === "name") {
      let result = getNextSortValue(
        sortToggleLessonName,
        [...filteredData],
        fieldName,
        "lessondescription"
      );
      setFilteredData(result.arrayData);
      setSortToggleLessonName(result.sortValue);
      setSortToggleLessonId(0);
      setSortToggleLessonVersion(0);
    } else if (fieldName === "id") {
      // let { sortValue, sortedArrayData } = getNextSortValue(sortToggleLessonId, [...filteredData], fieldName);
      let result = getNextSortValue(
        sortToggleLessonId,
        [...filteredData],
        fieldName
      );
      setFilteredData(result.arrayData);
      setSortToggleLessonId(result.sortValue);
      setSortToggleLessonName(0);
      setSortToggleLessonVersion(0);
    } else if (fieldName === "version") {
      let result = getNextSortValue(
        sortToggleLessonVersion,
        [...filteredData],
        fieldName
      );
      setFilteredData(result.arrayData);
      setSortToggleLessonVersion(result.sortValue);
      setSortToggleLessonName(0);
      setSortToggleLessonId(0);
    }
  };

  return (
    <div className="app">
      <Container fluid>
        <Header />
        <Container fluid>
          <div className="page-inner">
            <Row>
              <Col lg={6}>
                <Card style={{ width: "100%" }}>
                  <span className="card-title ">Dashboard</span>
                  <div className="w-100 col align-self-end">
                    <div className="input-group">
                      <input
                        type="text"
                        placeholder="Search Dashboard"
                        className="form-control"
                        onChange={(e) => handleDashSearch(e.target.value)}
                        value={searchTextDash}
                        ref={inputRefDash}
                      />
                      {searchTextDash && (
                        <span
                          className="input-group-text"
                          onClick={clearDashSearch}
                        >
                          X
                        </span>
                      )}
                    </div>
                  </div>
                  <Card.Body>
                    <table className="table table-responsive">
                      <thead className="w-100 headCls">
                        <tr className="w-100">
                          <th className="text-left w-20"></th>
                          <th className="text-left w-20"></th>
                          <th className="text-left w-25">Lesson Id</th>
                          <th className="text-left w-25">
                            {" "}
                            Lesson Name <br />
                            Description
                          </th>
                          <th className="text-left">Version</th>
                        </tr>
                      </thead>
                      <ReactSortable
                        list={orderedDashboardData}
                        setList={setOrderedDashboardData}
                        group="dashboard"
                        animation={200}
                        className="w-100"
                        filter={".headCls"}
                        onSort={(e) => {
                          if (e.to === e.from) {
                            handleDashboardSort(e);
                          }
                        }}
                        onAdd={(e) => {
                          handleDashboardAdd(e);
                        }}
                        onRemove={(e) => {
                          handleDashboardRemove(e);
                        }}
                        swap
                      >
                        {orderedDashboardData.map((item, index) => (
                          <tbody key={item.id} className="w-100">
                            <tr
                              className={`dashboardTableDataRow w-100 ${item.hidden ? "d-none" : ""
                                }`}
                              role="row"
                              data-id={item.id}
                            >
                              <td className="text-left drag-handle w-20">
                                <span className="drag-indicator"></span>
                              </td>
                              <td className="text-left w-20">{index + 1}</td>
                              <td className="text-left text-break w-25">
                                {item.id}
                              </td>
                              <td className="text-left text-break w-25">
                                {item.name} <br />{" "}
                                {item.lessondescription || ""}
                              </td>
                              <td className="text-left">{item.version}</td>
                            </tr>
                          </tbody>
                        ))}
                      </ReactSortable>
                    </table>
                  </Card.Body>
                </Card>
              </Col>
              <Col lg={6}>
                <Card style={{ width: "100%" }}>
                  <span className="card-title">Lessons</span>
                  <div className="w-100 col align-self-end">
                    <div className="input-group">
                      <input
                        type="text"
                        placeholder="Search Lessons"
                        className="form-control"
                        onChange={(e) => handleLessonsSearch(e.target.value)}
                        value={searchTextLessons}
                        ref={inputRefLessons}
                      />
                      {searchTextLessons && (
                        <span
                          className="input-group-text"
                          onClick={clearLessonsSearch}
                        >
                          X
                        </span>
                      )}
                    </div>
                  </div>

                  <Card.Body>
                    <table className="table table-responsive">
                      <thead className="w-100 headCls">
                        <tr className="w-100">
                          <th className="text-left w-20"></th>
                          <th className="text-left w-20 d-none"></th>
                          <th
                            className="text-left w-25"
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              toggleSortField("id");
                            }}
                          >
                            Lesson Id
                            {sortToggleLessonId === 0 ? (
                              <i className="pi pi-sort"></i>
                            ) : sortToggleLessonId === -1 ? (
                              <i className="pi pi-sort-up"></i>
                            ) : (
                              <i className="pi pi-sort-down"></i>
                            )}
                          </th>
                          <th
                            className="text-left w-25"
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              toggleSortField("name");
                            }}
                          >
                            Lesson Name <br />
                            Description{" "}
                            {sortToggleLessonName === 0 ? (
                              <i className="pi pi-sort"></i>
                            ) : sortToggleLessonName === -1 ? (
                              <i className="pi pi-sort-up"></i>
                            ) : (
                              <i className="pi pi-sort-down"></i>
                            )}
                          </th>

                          <th
                            className="text-left"
                            style={{ cursor: "pointer" }}
                            onClick={() => {
                              toggleSortField("version");
                            }}
                          >
                            Version
                            {sortToggleLessonVersion === 0 ? (
                              <i className="pi pi-sort"></i>
                            ) : sortToggleLessonVersion === -1 ? (
                              <i className="pi pi-sort-up"></i>
                            ) : (
                              <i className="pi pi-sort-down"></i>
                            )}
                          </th>
                        </tr>
                      </thead>
                      <ReactSortable
                        list={filteredData}
                        setList={setFilteredData}
                        group="dashboard"
                        animation={200}
                        className="w-100"
                        filter={".headCls"}
                        swap
                      >
                        {filteredData.map((item, index) => (
                          <tbody key={item.id}>
                            <tr
                              className={`dashboardTableDataRow drag-handle ${item.hidden ? "d-none" : ""
                                }`}
                              role="row"
                            >
                              <td className="text-left drag-handle w-20">
                                <span className="drag-indicator"></span>
                              </td>
                              <td className="text-left w-20 d-none">
                                {index + 1}
                              </td>
                              <td className="text-left text-break w-25">
                                {item.id}
                              </td>
                              <td className="text-left text-break w-25">
                                {item.name} <br />{" "}
                                {item.lessondescription || ""}
                              </td>
                              <td className="text-left">{item.version}</td>
                            </tr>
                          </tbody>
                        ))}
                      </ReactSortable>
                    </table>
                  </Card.Body>
                </Card>
              </Col>
            </Row>
          </div>
        </Container>
      </Container>
      {modalShow && (
        <ModelPopUp show={modalShow} onHide={() => setModalShow(false)} />
      )}
    </div>
  );
};
export default DashboardSettings;
