import { Col, Container, OverlayTrigger, Row, Tooltip } from "react-bootstrap";
import React, { useRef } from "react";
import { faEye, faSquareCheck } from "@fortawesome/free-solid-svg-icons";
import { get, post } from "../../../utils/HttpRequest";

import Datatable from "../../Common/Datatable";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import Header from "../../Header/Header";
import { Toast } from "primereact/toast";
import config from "../../../config/config.json";
import { useEffect } from "react";
import { useState } from "react";

const LessonAssignmentOverview = () => {
  const toast = useRef(null);
  const [searchText, setSearchText] = useState("");
  const [data, setData] = useState([]);
  const [columndata, setColumndataData] = useState([]);
  const [filteredData, setFilteredData] = useState(data);
  const [isLoading, setIsLoading] = useState(true);

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 991);
  };

  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? data.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : data;
    setFilteredData(filtered);
    setSearchText(searchText);
  };

  const getData = async () => {
    try {
      const url = config.api.url + "getLessonAssignmentOverview";
      get(url).then((response) => {
        setData(response.data.result);
        setColumndataData(response.data.result[0].roles);
        setFilteredData(response.data.result);
        setIsLoading(false);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
      setIsLoading(false);
    }
  };

  const handleEyeClick = async (row, role, visible, roleData) => {
    try {
      const newValue = visible ? "invisible" : "visible";
      role = role === "SMiTrial Admin" ? "smiadmin" : role;
      let url, data;
      if (roleData.group) {
        let subrolename = roleData.rolename
          .match(/\(.*\)/g)[0]
          .replace("(", "")
          .replace(")", "");
        data = {
          display: newValue,
          lessonid: row.lessonid,
          role: roleData.group.toLowerCase(),
          subrole: "subrole",
          subrolename,
        };
        url = config.api.url + "updateLessonVisibilityOnDashboardForSubRole";
      } else {
        data = {
          display: newValue,
          lessonid: row.lessonid,
          role: role.toLowerCase().replace(" ", ""),
        };
        url = config.api.url + "updateLessonVisibilityOnDashboard";
      }

      const response = await post(url, data);
      if (response.status === 201 || response.status === 200) {
        getData();
        toast.current.show({
          severity: "success",
          summary: "successfully updated",
          detail: "Success",
        });
      } else {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting download metadata file.",
        });
      }
    } catch (error) {
      console.error("Error making API call:", error);
      if (error.response.status === 400 || error.response.status === 401) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting download metadata file.",
        });
      }
    }
  };

  const handlerequiredClick = async (row, role, required, roleData) => {
    try {
      let url, data;
      role = role === "SMiTrial Admin" ? "smiadmin" : role;
      data = {
        lessonid: row.lessonid,
        entity: "role",
        name: role.toLowerCase().replace(" ", ""),
      };
      if (roleData.group) {
        let subrolename = roleData.rolename
          .match(/\(.*\)/g)[0]
          .replace("(", "")
          .replace(")", "");
        data = {
          lessonid: row.lessonid,
          role: roleData.group.toLowerCase(),
          subrole: "subrole",
          subrolename,
        };
        if (required) {
          url = config.api.url + "unassignLessonForSubRole";
        } else {
          url = config.api.url + "assignLessonForSubRole";
        }
      } else {
        if (required) {
          url = config.api.url + "unassignLessonForRole";
        } else {
          url = config.api.url + "assignLesson";
        }
      }

      const response = await post(url, data);
      if (response.status === 201 || response.status === 200) {
        getData();
        toast.current.show({
          severity: "success",
          summary: "successfully updated",
          detail: "Success",
        });
      } else {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "Error getting download metadata file.",
        });
      }
    } catch (error) {
      console.error("Error making API call:", error);
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: error.message,
        });
      }
    }
  };

  useEffect(() => {
    window.addEventListener("resize", handleResize);

    getData();
  }, []);

  const siteColumn = [
    {
      dataField: "lessonid",
      text: "Lesson Id",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "lessonname",
      text: "Lesson Name\n (Description)",
      formatter: (cell, row) => {
        return (
          <div>
            <span>{row?.lessonname}</span>
            <br />
            <span>{row?.lessondescription}</span>
          </div>
        );
      },
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    ...[...columndata].map((item) => {
      return {
        dataField: item.rolename,
        text: item.rolename,
        sort: true,
        filterValue: (cell) => cell.includes(searchText),
        formatter: (cell, row) => {
          const roleData = row.roles.find(
            (role) => role.rolename === item.rolename
          );
          const visible =
            roleData.visible === "no" || roleData.visible === undefined
              ? false
              : true;
          const required =
            roleData.required === "no" || roleData.required === undefined
              ? false
              : true;
          return (
            <div>
              <OverlayTrigger
                placement={"bottom"}
                overlay={
                  <Tooltip id={`tooltip-bottom`}>Toggle Required</Tooltip>
                }
              >
                <FontAwesomeIcon
                  color={required ? "green" : "rgb(202, 202, 202)"}
                  icon={faSquareCheck}
                  className="pr-1"
                  onClick={() => {
                    handlerequiredClick(row, item.rolename, required, roleData);
                  }}
                />
              </OverlayTrigger>
              <OverlayTrigger
                placement={"bottom"}
                overlay={
                  <Tooltip id={`tooltip-bottom`}>
                    Toggle Dashboard Visibility
                  </Tooltip>
                }
              >
                <FontAwesomeIcon
                  onClick={() =>
                    handleEyeClick(row, item.rolename, visible, roleData)
                  }
                  color={visible ? "green" : "rgb(202, 202, 202)"}
                  icon={faEye}
                />
              </OverlayTrigger>
            </div>
          );
        },
      };
    }),
  ];

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="SiteManagerPage">
          <Row>
            <Col lg={12}>
              <div className="manager_bar">
                <span className="card-title ">
                  {" "}
                  Lesson Assignment Overview{" "}
                </span>
              </div>
              {!isMobile ? (
                <div style={{ textAlign: "center" }}>
                  {isLoading ? (
                    <p>Loading...</p>
                  ) : (
                    <Datatable
                      keyField={"lessonid"}
                      data={filteredData}
                      handleSearchChange={handleSearchChange}
                      columns={siteColumn}
                      filteredData={filteredData}
                      searchText={searchText}
                      isActionEnable={false}
                    />
                  )}
                </div>
              ) : (
                ""
              )}
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default LessonAssignmentOverview;
