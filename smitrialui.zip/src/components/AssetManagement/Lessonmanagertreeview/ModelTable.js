import React from "react";
import { Col, Modal, Row } from "react-bootstrap";
import Datatable from "../../Common/Datatable";
import "./ModelTable.css";
import { SplitButton } from "primereact/splitbutton";

const ModelTable = (props) => {
  const userColumns = [
    {
      dataField: "lessonid",
      text: (
        <div>
          Lesson Id
          <br />
          Lesson Name
          <br />
          Description
        </div>
      ),
      formatter: (cell, row) => {
        return (
          <div>
            <span>{row?.id}</span>
            <br />
            <span>{row?.name}</span>
            <br />
            <span>{row?.lessondescription}</span>
          </div>
        );
      },
    },
    {
      dataField: "lessonlanguages",
      text: "Language",
    },
    {
      dataField: "status",
      text: "Status",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "active" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "active" ? true : false}
                  onChange={() => props.handleStatusChange(row)}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "version",
      text: "Version",
    },
    {
      dataField: "order",
      text: "Order",
    },
    {
      dataField: "display",
      text: " Visible on Dashboard",
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.display === "visible" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input"
                  name="userStatus"
                  disabled
                  checked={row.display === "visible" ? true : false}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "",
      text: "Action",
      formatter: (cell, row) => {
        const items = [
          {
            label: "Edit Lesson Wizard",
            icon: "pi pi-pencil",
            command: () => {
              window.location.href = `/lessonwizard?lessonid=${row?.lessonid}`;
            },
          },
          {
            label: "Download Lesson Metadata File",
            icon: "pi pi-download",
            command: () => {
              props.DownloadMetadataFile(row?.lessonid);
            },
          },
        ];
        return (
          <div>
            <SplitButton
              style={{ zIndex: "9999" }}
              icon="pi pi-cog"
              model={items}
              severity="success"
            />
          </div>
        );
      },
    },
  ];
  return (
    <div className="app">
      <Modal show={props.show} onHide={() => props.onHide()}>
        <Modal.Header closeButton>
          <Modal.Title style={{ fontSize: "1.25rem" }}>
            Lesson details
          </Modal.Title>
        </Modal.Header>
        <Row>
          <Col lg={12}>
            <Datatable
              showrow={false}
              isVisibleText={false}
              isActionEnable={false}
              columns={userColumns}
              data={props.filteredData}
              filteredData={props.data}
              searchText={props.searchText}
              defaultSorted={false}
              Pagination={false}
              Paginationnumber={false}
            />
          </Col>
        </Row>
      </Modal>
    </div>
  );
};
export default ModelTable;
