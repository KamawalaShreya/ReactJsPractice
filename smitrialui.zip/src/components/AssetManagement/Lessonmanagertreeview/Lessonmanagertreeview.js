import React, { useRef } from "react";
import { Card, Col, Container, Row, Form } from "react-bootstrap";
import Header from "../../Header/Header";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { Tree } from "primereact/tree";
import { useEffect } from "react";
import { get, post } from "../../../utils/HttpRequest";
import { useState } from "react";
import config from "../../../config/config.json";
import ModelTable from "./ModelTable";
import { Link } from "react-router-dom";
import { Toast } from "primereact/toast";

const LessonsTreeView = () => {
  const toast = useRef(null);
  const [searchText, setSearchText] = useState();
  const [dashboardResponseData, setDashboardResponseData] = useState([]);
  const [PerIddata, setPerIddata] = useState([]);

  const [data, setData] = useState([]);
  const [show, setShow] = useState(false);

  const handleShow = () => setShow(true);
  const [selectedLessonId, setSelectedLessonId] = useState(null);

  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    setSearchText(searchText ? searchText : null);
  };

  const getData = async () => {
    try {
      const url = config.api.url + "getLessons";
      get(url).then(async (response) => {
        const dashboardUrl = config.api.url + "getTrialDashbaord";
        const dashboardData = await get(dashboardUrl);
        setDashboardResponseData(dashboardData.data);
        const sortedLessonData = response.data.sort((a, b) =>
          a?.lessonname?.localeCompare(b?.lessonname)
        );
        const updatedLessonData = sortedLessonData.filter((lesson) => {
          const iter = dashboardData.data.dashboard.findIndex((dashboard) => {
            return dashboard.id === lesson.lessonid;
          });
          if (iter !== -1) {
            return true;
          } else {
            return false;
          }
        });
        setData(updatedLessonData);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleStatusChange = async (row) => {
    try {
      setPerIddata([
        { ...row, status: row?.status === "active" ? "inactive" : "active" },
      ]);
      const formData = {
        lessonid: row?.lessonid,
        status: row?.status === "active" ? "inactive" : "active",
      };
      var url = config.api.url + "updateLessonStatus";
      post(url, formData).then(async () => {
        await getData();
      });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  useEffect(() => {
    getData();
  }, []);

  const DownloadMetadataFile = (lessonid) => {
    try {
      const url = config.api.url + "getMetadataFile?lessonid=" + lessonid;
      get(url)
        .then((response) => new Blob([response.data]))
        .then((Blob) => {
          const fileName = `lesson_metadata_${lessonid}.txt`;
          const a = document.createElement("a");
          a.href = window.URL.createObjectURL(Blob);
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          toast.current.show({
            severity: "success",
            summary: "download metadata file.",
            detail: "Success",
          });
        });
    } catch (error) {
      console.error("Error downloading lesson metadata:", error);
      toast.current.show({
        severity: "error",
        summary: "download metadata file.",
        detail: "Error getting download metadata file.",
      });
    }
  };

  const createTreeNodes = (data) => {
    const generateTreeNode = (lesson) => {
      const node = {
        key: lesson.lessonid,
        label: (
          <div
            style={{
              color: lesson.lessonname
                ?.toLowerCase()
                .includes(searchText?.toLowerCase())
                ? "#8b0000"
                : "black",
              fontWeight: lesson.lessonname
                ?.toLowerCase()
                .includes(searchText?.toLowerCase())
                ? "bold"
                : "normal",
            }}
          >
            {lesson.lessonname}
          </div>
        ),
        icon: "pi pi-fw pi-file",
      };

      if (lesson.childlessonids && lesson.childlessonids.length) {
        const childIds = lesson.childlessonids
          .split(",")
          .map((id) => id.trim());
        const childLessons = data.filter((childLesson) =>
          childIds.includes(childLesson.lessonid)
        );

        if (childLessons.length > 0) {
          node.children = childLessons.map((childLesson) =>
            generateTreeNode(childLesson)
          );
        }
      }

      return node;
    };

    if (!data) return [];

    return data.map((lesson) => generateTreeNode(lesson));
  };

  const onTreeNodeSelect = (e) => {
    const selectedNode = e.value;

    if (selectedNode) {
      const selecteddashboard = dashboardResponseData.dashboard?.filter(
        (dashboardItem) => dashboardItem.id === selectedNode
      );

      const selectedLessonData = data?.filter(
        (lessonDataItem) => lessonDataItem.lessonid === selectedNode
      );
      const AllData = { ...selecteddashboard[0], ...selectedLessonData[0] };

      setPerIddata([AllData]);
      setSelectedLessonId(selectedNode);
      handleShow();
    }
  };
  const treeData = createTreeNodes(data);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <Container fluid>
          <div className="page-inner">
            <Row>
              <Col lg={7}>
                <Card style={{ width: "100%" }}>
                  <div className="d-flex justify-content-between">
                    <span className="card-title ">Lesson Manager</span>
                    <div className="d-flex align-items-center">
                      <span className="card-title ">Create Lesson</span>
                      <Link to="/lessonwizard">
                        <span className="tile tile-circle tile-md text-white smi-tile-primary createLesson smi-btn">
                          <FontAwesomeIcon icon={faPlus} />
                        </span>
                      </Link>
                    </div>
                  </div>
                  <div className="p-0 my-2 smi-perfect-scrollbar111">
                    <header className="page-navs-tree bg-light shadow-sm">
                      <div className="form-row pt-1">
                        <div className="col-md-10 pt-1">
                          <Form className="d-flex">
                            <Form.Control
                              type="search"
                              placeholder="Search..."
                              className="me-2"
                              aria-label="Search..."
                              onChange={handleSearchChange}
                              value={searchText}
                            />
                          </Form>
                        </div>
                      </div>
                    </header>
                  </div>
                  <div className="table-responsive">
                    <div className="card flex justify-content-center">
                      <Tree
                        className="w-full"
                        value={treeData}
                        selectionMode="single"
                        onSelectionChange={onTreeNodeSelect}
                      />
                    </div>
                  </div>
                </Card>
              </Col>
            </Row>
          </div>
        </Container>

        {selectedLessonId && (
          <ModelTable
            filteredData={[]}
            searchText={searchText}
            data={PerIddata}
            DownloadMetadataFile={DownloadMetadataFile}
            handleStatusChange={handleStatusChange}
            show={show}
            onHide={() => {
              setShow(false);
              setSelectedLessonId(null);
            }}
          />
        )}
      </Container>
    </div>
  );
};
export default LessonsTreeView;
