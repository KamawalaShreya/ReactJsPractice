import React, { useRef } from "react";
import Header from "../../Header/Header";
import Datatable from "../../Common/Datatable";
import { useState } from "react";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import { useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import { SplitButton } from "primereact/splitbutton";
import { Toast } from "primereact/toast";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPlus } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";

const lessonTypes = {
  regularlesson: "Regular Lesson",
  assessment: "Comprehension",
  externallink: "External Link",
  nestedcard: "Nested Lesson",
  survey: "Survey Lesson",
};

const LessonManager = () => {
  const toast = useRef(null);
  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);
  const [data, setData] = useState([]);

  const [filteredData, setFilteredData] = useState(data);
  const [dashboardResponseData, setDashboardResponseData] = useState([]);

  const navigate = useNavigate();

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value;
    let dataAll = newData ? newData : data;

    const filtered = newsearchText
      ? [...dataAll].filter((item) =>
        Object.values(item).some((value) => {
          return String(value)
            .toLowerCase()
            .includes(newsearchText.toLowerCase());
        })
      )
      : dataAll;
    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getData = async () => {
    try {
      const url = config.api.url + "getLessons";
      get(url).then(async (response) => {
        const dashboardUrl = config.api.url + "getTrialDashbaord";
        const dashboardData = await get(dashboardUrl);
        setDashboardResponseData(dashboardData.data);
        const modifiedData = response.data.map((user) => ({
          ...user,
          fullName: `${user.lessonid} ${user.lessonname} ${user.lessondescription}`,
        }));
        setData(
          modifiedData
            .sort((a, b) => a?.lessonname?.localeCompare(b?.lessonname))
            .filter((item) => item.status !== "review")
        );

        setFilteredData(
          modifiedData
            .sort((a, b) => a?.lessonname?.localeCompare(b?.lessonname))
            .filter((item) => item.status !== "review")
        );
        data.length &&
          handleSearchChange(
            {
              target: {
                value: searchTextRef.current ? searchTextRef.current : "",
              },
            },
            [
              ...modifiedData
                .sort((a, b) => a?.lessonname?.localeCompare(b?.lessonname))
                .filter((item) => item.status !== "review"),
            ]
          );
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleStatusChange = async (row) => {
    try {
      const formData = {
        lessonid: row?.lessonid,
        status: row?.status === "active" ? "inactive" : "active",
      };
      var url = config.api.url + "updateLessonStatus";
      post(url, formData).then(() => {
        getData();
      });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const DownloadMetadataFile = (lessonid) => {
    try {
      const url = config.api.url + "getMetadataFile?lessonid=" + lessonid;
      get(url)
        .then((response) => new Blob([response.data]))
        .then((Blob) => {
          const fileName = `lesson_metadata_${lessonid}.txt`;
          const a = document.createElement("a");
          a.href = window.URL.createObjectURL(Blob);
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          toast.current.show({
            severity: "success",
            summary: "download metadata file.",
            detail: "Success",
          });
        });
    } catch (error) {
      toast.current.show({
        severity: "error",
        summary: "download metadata file.",
        detail: "Error getting download metadata file.",
      });
    }
  };

  useEffect(() => {
    getData();
  }, []);

  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];
  const siteColumn = [
    {
      dataField: "fullName",
      text: "Lesson Id\nLesson Name\nDescription",
      formatter: (cell, row) => {
        return (
          <div>
            <span>{row?.lessonid}</span>
            <br />
            <span>{row?.lessonname}</span>
            <br />
            <span>{row?.lessondescription}</span>
          </div>
        );
      },
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "lessonlanguages",
      text: "Language",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.lessonlanguages ? row.lessonlanguages : "N/A";
      },
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        const valueChange = (pre) => {
          const reviewStatus = pre?.map((item) =>
            item.addedEpoch === row.addedEpoch && item.lessonid === row.lessonid
              ? {
                ...item,
                status: row.status === "active" ? "inactive" : "active",
              }
              : item
          );
          return reviewStatus;
        };
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${row.status === "active" ? "switcher-control-success" : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "active" ? true : false}
                  onChange={() => {
                    setFilteredData(valueChange);
                    handleStatusChange(row);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "lessontype",
      text: "Lesson Type",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return lessonTypes[row.lessontype] || lessonTypes["regularlesson"];
      },
    },
    {
      dataField: "version",
      text: "Version",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "order",
      text: "Order",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return dashboardResponseData.dashboard.find(
          (i) => i.id === row.lessonid
        )?.order === undefined
          ? ""
          : dashboardResponseData.dashboard.find((i) => i.id === row.lessonid)
            ?.order;
      },
    },

    {
      dataField: "display",
      text: " Visible on Dashboard",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${dashboardResponseData.dashboard.find(
                  (i) => i.id === row.lessonid
                )?.order !== undefined
                    ? "switcher-control-success"
                    : ""
                  }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input"
                  name="userStatus"
                  disabled
                  checked={
                    dashboardResponseData.dashboard.find(
                      (i) => i.id === row.lessonid
                    )?.order !== undefined
                      ? true
                      : false
                  }
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "Action",
      text: "Action",
      sort: true,
      formatter: (cell, row) => {
        const items = [
          {
            label: "Edit Lesson Wizard",
            icon: "pi pi-pencil",
            command: () => {
              window.location.href = `/lessonwizard?lessonid=${row?.lessonid}`;
            },
          },
          {
            label: "Download Lesson Metadata File",
            icon: "pi pi-download",
            command: () => {
              DownloadMetadataFile(row?.lessonid);
            },
          },
        ];
        return (
          <div>
            <SplitButton icon="pi pi-cog" model={items} severity="success" />
          </div>
        );
      },
    },
  ];

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="SiteManagerPage">
          <Row>
            <Col lg={12}>
              <div className="manager_bar">
                <span className="card-title "> Lesson Manager </span>
                <div className="d-flex align-items-center card-title">
                  <span className="card-title ">Create Lesson</span>
                  <span
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/lessonwizard");
                    }}
                  >
                    <span className="tile tile-circle tile-md text-white smi-tile-primary">
                      <FontAwesomeIcon icon={faPlus} />
                    </span>
                  </span>
                </div>
              </div>
              <Datatable
                keyField={"lessonid"}
                data={filteredData}
                defaultSorted={defaultSorted}
                handleSearchChange={handleSearchChange}
                columns={siteColumn}
                filteredData={filteredData}
                searchText={searchText}
                isActionEnable={false}
              />
            </Col>
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default LessonManager;
