import React, { useEffect, useState, useRef } from "react";
import Header from "../Header/Header";
import config from "../../config/config.json";
import { get, post } from "../../utils/HttpRequest";
import { Card, Row, Col, Container, Form } from "react-bootstrap";
import Datatable from "../Common/Datatable";
import { SplitButton } from "primereact/splitbutton";
import { Button } from "primereact/button";
import { Toast } from "primereact/toast";
import { Dialog } from "primereact/dialog";
import UserCreateForm from "./UserCreateForm";
import ExcelUploadDialog from "../Exceluploadview/ExcelUploadDialog";
import ResetPasswordDialog from "./ResetPasswordDialog";
import DashboardSimulator from "./DashboardSimulator";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";

const Usermanager = () => {
  // userRef variables
  // const dt = useRef(null);
  const toast = useRef(null);

  // state variables
  const [usersData, setUsersData] = useState([]);
  const [edituserData, setedituserData] = useState(null);
  const [resetPassUserData, setResetPassUserData] = useState(null);
  const [edituserEmail, setedituserEmail] = useState([]);
  const [languagesData, setLanguagesData] = useState([]);
  const [roleOptions, setRoleOptions] = useState([]);
  const [sitesOptions, setSitesOptions] = useState([]);
  const [validated, setValidated] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState("");

  const [visible, setVisible] = useState(false);
  const [VisibleForm, setVisibleForm] = useState(false);
  const [position, setPosition] = useState("top");

  const [isMobile, setIsMobile] = useState(window.innerWidth <= 991);

  const handleResize = () => {
    setIsMobile(window.innerWidth <= 991);
  };

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);
  const [filteredData, setFilteredData] = useState(usersData);

  // excel upload dialog state variable
  const [dialogVisible, setDialogVisible] = useState(false);

  // for edit user functionality
  const [fetchDataFlag, setFetchDataFlag] = useState(null);

  // for reset password dialog
  const [resetPasswordDialogVisible, setResetPasswordDialogVisible] =
    useState(false);

  // for dashboard simulator dialog
  const [dashboardSimulatorDialogVisible, setDashboardSimulatorDialogVisible] =
    useState(false);
  const [userDataForDashboardSimulator, setUserDataForDashboardSimulator] =
    useState(null);

  const navigate = useNavigate();

  // useEffect block
  useEffect(() => {
    // variables
    window.addEventListener("resize", handleResize);

    var url = config.api.url + "getAllMyReportees";
    var sitesUrl = config.api.url + "getMySitesV2";
    var rolesUrl = config.api.url + "getMyReporteeRoles";
    var subRolesUrl = config.api.url + "getMyReporteeSubRoles";
    var languagesUrl = config.api.url + "getTrialConfig/language";

    if (fetchDataFlag === null) {
      get(url)
        .then((response) => {
          const modifiedData = response.data.map((user) => ({
            ...user,
            fullName: `${user.givenName} ${user.familyName}`,
          }));
          setUsersData(modifiedData);

          setFilteredData(modifiedData);
        })
        .catch((error) => {
          console.log("Error getting users :", error.response.status);
        });
    }
    if (fetchDataFlag === null || fetchDataFlag === true) {
      get(rolesUrl).then((rolesResponse) => {
        get(subRolesUrl).then((subRolesResponse) => {
          var roleandsubroles = {};
          var rolesArray = [];
          rolesResponse.data.map((role) => {
            rolesArray.push({ label: role.description, value: role.group });
            roleandsubroles[role.group] = [];
            subRolesResponse.data.map((subrole) => {
              if (role.group === subrole.group.split("-")[0]) {
                roleandsubroles[role.group].push(subrole.subrolename);
                rolesArray.push({
                  label: "   " + subrole.subrolename,
                  value: role.group + ";" + subrole.subrolename,
                });
              }
              return subrole;
            });
            return role;
          });
          setRoleOptions(rolesArray);
        });
      });
      get(languagesUrl).then((response) => {
        let languages = JSON.parse(response.data.value);
        let langData = [];
        languages.map((o) => {
          langData.push({ label: o.languageName, value: o.languageName });
          return 0;
        });
        setLanguagesData(langData);
      });
      get(sitesUrl).then((siteResponse) => {
        var siteData = [];
        siteResponse.data.map((site) => {
          siteData.push({ label: site.sitename, value: site.siteid });
          return site;
        });
        setSitesOptions(siteData);
      });
    }

    if (fetchDataFlag) {
      const editUserUrl = config.api.url + "getUserDetails/" + edituserEmail;
      get(editUserUrl).then((editUserResponse) => {
        let userdata = editUserResponse.data;
        userdata.email = userdata.group;
        setedituserData(userdata);
        setFetchDataFlag(false);
        show("top");
      });
    }
  }, [fetchDataFlag]);

  const openExcelDialog = () => {
    setDialogVisible(true);
  };

  const closeExcelDialog = () => {
    setDialogVisible(false);
  };

  const resetPasswordDialogOnOpen = () => {
    setResetPasswordDialogVisible(true);
  };

  const resetPasswordDialogOnClose = () => {
    setResetPasswordDialogVisible(false);
  };

  const dashboardSimulatorDialogOnOpen = () => {
    setDashboardSimulatorDialogVisible(true);
  };

  const dashboardSimulatorDialogOnClose = () => {
    setDashboardSimulatorDialogVisible(false);
  };

  // Datatable search helper function

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value;
    let dataAll = newData ? newData : usersData;
    const filtered = newsearchText
      ? [...dataAll].filter((item) => {
          return [
            ...Object.keys(item).filter((ele) => ele !== "createdBy"),
          ].some((key) => {
            const value = String(item[key]).toLowerCase();
            return value.includes(newsearchText.toLowerCase());
          });
        })
      : dataAll;
    const groupValuesOne = filtered?.map((item) => item.group);
    setSelectedEmail(groupValuesOne.join("; "));
    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const groupValues = usersData?.map((item) => item.group);

  const [concatenatedString, setConcatenatedString] = useState("");

  useEffect(() => {
    setConcatenatedString(groupValues.join("; "));
  }, [groupValues]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        to: form.to.value.split(";"),
        subject: form.subject.value,
        priority: "normal",
        body: form.body.value,
      };
      var url = config.api.url + "sendMultipleMessages";
      post(url, formData)
        .then((response) => {
          if (response.data && response.data !== "") {
            toast.current.show({
              severity: "warn",
              summary: "Message",
              detail: response.data,
            });
          } else {
            toast.current.show({
              severity: "success",
              summary: "Message",
              detail: response.data,
            });
          }
        })
        .catch(() => {
          toast.current.show({
            severity: "warn",
            summary: "Message error",
            detail: "Something went wrong.",
          });
        });
      setTimeout(() => {
        setVisibleForm(false);
      }, 4000);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const changeUserStatus = (email, currentStatus) => {
    let url = config.api.url + "changeUserStatus";
    let status = currentStatus === "enabled" ? "disabled" : "enabled";
    let jsonBody = {
      Username: email,
      status: status,
    };
    post(url, JSON.stringify(jsonBody))
      .then(async () => {
        // refreshing the users table for the new data
        await get(config.api.url + "getAllMyReportees").then((response) => {
          const modifiedData = response.data.map((user) => ({
            ...user,
            fullName: `${user.givenName} ${user.familyName}`,
          }));
          setUsersData([...modifiedData]);
          setFilteredData([...modifiedData]);

          handleSearchChange(
            {
              target: {
                value: searchTextRef.current ? searchTextRef.current : "",
              },
            },
            [...modifiedData]
          );

          toast.current.show({
            severity: "success",
            summary: "Updated",
            detail: "Status changed for " + email,
          });
        });
        setTimeout(() => {
          setFetchDataFlag(null);
        }, 2000);
      })
      .catch((error) => {
        console.log("Error :", error);
      });
  };

  const getDataForResetPassword = (email) => {
    const editUserUrl = config.api.url + "getUserDetails/" + email;
    get(editUserUrl).then((editUserResponse) => {
      let userdata = editUserResponse.data;
      userdata.email = userdata.group;
      setResetPassUserData(userdata);
      resetPasswordDialogOnOpen(true);
    });
  };

  const defaultSorted = [
    {
      dataField: "fullName",
      order: "asc",
    },
  ];
  const userColumns = [
    {
      dataField: "fullName",
      text: "Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <a
            href={`/trainingrecord?user=${encodeURIComponent(
              row?.group
            )}&username=${row.fullName}`}
            onClick={(e) => {
              e.preventDefault();
              navigate(
                `/trainingrecord?user=${encodeURIComponent(
                  row?.group
                )}&username=${row.fullName}`
              );
            }}
          >
            {row.fullName}
          </a>
        );
      },
    },
    {
      dataField: "group",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "subrole",
      text: "Role / Subrole",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row?.subrole ? row?.subrole : row?.role;
      },
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,

      formatter: (cell, row) => {
        const valueChange = (pre) =>
          pre.map((item) =>
            item.addedEpoch === row.addedEpoch && item.group === row.group
              ? {
                  ...item,
                  status: row?.status === "enabled" ? "disabled" : "enabled",
                }
              : item
          );
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "enabled" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "enabled" ? true : false}
                  onChange={() => {
                    setFilteredData(valueChange);
                    changeUserStatus(row.group, row.status);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "siteName",
      text: "Site",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.siteName
          ? typeof row?.siteName == "object" && row?.siteName.length > 0
            ? row?.siteName.join("   ")
            : row?.siteName
          : "No site assigned";
      },
    },
    {
      dataField: "country",
      text: "Country",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.country
          ? typeof row.country == "object" && row.country.length > 0
            ? row.country.join(", ")
            : row.country
          : "No site assigned";
      },
    },
    {
      dataField: "languagePreference",
      text: "language",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "",
      text: "",
      sort: true,
      formatter: (cell, row) => {
        const items = [
          {
            label: "Edit User",
            icon: "pi pi-pencil",
            command: () => {
              setedituserEmail(row.group);
              setFetchDataFlag(true);
            },
          },
          {
            label: "Resend Password",
            icon: "pi pi-user-edit",
            command: () => {
              getDataForResetPassword(row.group);
            },
          },
          {
            label: "Dashboard View",
            icon: "pi pi-desktop",
            command: () => {
              setUserDataForDashboardSimulator(row);
              dashboardSimulatorDialogOnOpen();
            },
          },
        ];
        return (
          <div>
            <SplitButton icon="pi pi-cog" model={items} severity="success" />
          </div>
        );
      },
    },
  ];

  const show = (position) => {
    setPosition(position);
    setVisible(true);
  };

  const createUserLinkAction = (position) => {
    setedituserEmail(null);
    setedituserData(null);
    show(position);
  };

  const requestResetPassword = (userData) => {
    let editUserData = {};
    editUserData.givenName = userData.givenName;
    editUserData.familyName = userData.familyName;
    editUserData.email = userData.email;
    editUserData.role = userData.role;
    var jsonFormData = JSON.stringify(editUserData);
    var url = config.api.url + "adminResetUserPassword";

    post(url, jsonFormData)
      .then(() => {
        resetPasswordDialogOnClose();
        toast.current.show({
          severity: "success",
          summary: "Reset Password",
          detail: "Success",
        });
      })
      .catch(() => {
        resetPasswordDialogOnClose();
        toast.current.show({
          severity: "error",
          summary: "Reset Password",
          detail:
            "This user has logged in and reset this password. Please ask the user to click Forgot password link.",
        });
      });
  };

  // main return block
  return (
    <div className="userManagerPage app">
      <Header />

      {!isMobile ? (
        <Container fluid style={{ width: "100%" }}>
          <div className="page-inner">
            <Row>
              <Col lg={12}>
                <Card>
                  <Card.Header style={{ borderBottom: "none" }}>
                    <Card.Title style={{ textAlign: "Left" }}>
                      <Row>
                        <Col md={4} lg={4}>
                          <span>My users</span>
                          <button
                            className="btn btn-secondary"
                            onClick={() => setVisibleForm(true)}
                          >
                            <FontAwesomeIcon icon={faEnvelope} />
                          </button>
                        </Col>
                        <Col
                          md={8}
                          lg={8}
                          style={{
                            textAlign: "right",
                            display: "flex",
                            justifyContent: "flex-end",
                            alignItems: "center",
                          }}
                        >
                          Create User &nbsp;
                          <Button
                            icon="pi pi-plus"
                            rounded
                            severity="secondary"
                            onClick={() => createUserLinkAction("top")}
                            style={{ background: "#4d4d4d" }}
                            aria-label="Create User"
                          />
                          &nbsp; &nbsp; Add Multiple Users using XLSX file
                          &nbsp;
                          <Button
                            icon="pi pi-upload"
                            rounded
                            severity="secondary"
                            style={{ background: "#4d4d4d" }}
                            onClick={() => openExcelDialog()}
                            aria-label="Add Multiple Users using XLSX file"
                          />
                        </Col>
                      </Row>
                    </Card.Title>
                  </Card.Header>
                  <Card.Body>
                    <div className="mt-2">
                      <Datatable
                        keyField="group"
                        defaultSorted={defaultSorted}
                        data={usersData}
                        handleSearchChange={handleSearchChange}
                        columns={userColumns}
                        filteredData={filteredData}
                        searchText={searchText}
                      />
                    </div>
                  </Card.Body>
                  <Toast ref={toast}></Toast>
                  <Dialog
                    header={`${edituserData ? "Edit User" : "Create user"}`}
                    visible={visible}
                    position={position}
                    style={{ width: "37vw" }}
                    onHide={() => setVisible(false)}
                    dismissableMask={true}
                    draggable={false}
                    resizable={false}
                  >
                    <UserCreateForm
                      setVisible={setVisible}
                      initialValues={edituserData}
                      roleOptions={roleOptions}
                      languagesData={languagesData}
                      sitesOptions={sitesOptions}
                      submitDetect={() => {
                        setTimeout(() => {
                          setFetchDataFlag(null);
                        }, 2000);
                      }}
                      toast={toast}
                    />
                  </Dialog>
                  <ExcelUploadDialog
                    dialogTitle={"Add Multiple Users using XLSX file"}
                    dialogSubTitle={
                      "For better performance upload less than 500 users per file."
                    }
                    excelDialogVisible={dialogVisible}
                    excelDialogOnClose={closeExcelDialog}
                  ></ExcelUploadDialog>

                  <ResetPasswordDialog
                    initialValues={resetPassUserData}
                    submitDetect={(value) => {
                      if (value) {
                        requestResetPassword(resetPassUserData);
                      }
                    }}
                    resetPasswordDialogVisible={resetPasswordDialogVisible}
                    resetPasswordDialogOnClose={resetPasswordDialogOnClose}
                  ></ResetPasswordDialog>

                  <DashboardSimulator
                    userData={userDataForDashboardSimulator}
                    setUserDataForDashboardSimulator={
                      setUserDataForDashboardSimulator
                    }
                    dashboardSimulatorDialogVisible={
                      dashboardSimulatorDialogVisible
                    }
                    dashboardSimulatorDialogOnClose={
                      dashboardSimulatorDialogOnClose
                    }
                  ></DashboardSimulator>
                </Card>
              </Col>
            </Row>
          </div>
          <Dialog
            header="Send Email"
            visible={VisibleForm}
            position={position}
            style={{ width: "35vw" }}
            onHide={() => setVisibleForm(false)}
            // onMaskClick={() => setVisibleForm(false)}
            dismissableMask={true}
          >
            <Form
              className="needs-validation"
              onSubmit={handleSubmit}
              noValidate
              validated={validated}
            >
              <div className="mb-3">
                <Form.Group controlId="validationCustom01">
                  <Form.Control
                    value={selectedEmail || concatenatedString}
                    type="text"
                    name="to"
                    className="form-control input-group"
                    required
                  />
                </Form.Group>
              </div>
              <div className="mb-3">
                <Form.Group>
                  <Form.Control
                    type="text"
                    className="form-control input-group"
                    placeholder="subject"
                    name="subject"
                    required
                  />
                  {validated && (
                    <Form.Control.Feedback type="invalid">
                      Enter email subject.
                    </Form.Control.Feedback>
                  )}
                </Form.Group>
              </div>
              <div className="mb-3">
                <Form.Group>
                  <Form.Control as="textarea" name="body" required rows={2} />
                  {validated && (
                    <Form.Control.Feedback type="invalid">
                      Enter email body.
                    </Form.Control.Feedback>
                  )}
                </Form.Group>
              </div>
              <div className="py-3">
                <button type="submit" className="btn btn-primary mr-2">
                  Send
                </button>
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={() => setVisibleForm(false)}
                  data-dismiss="modal"
                >
                  Cancel
                </button>
              </div>
            </Form>
          </Dialog>
        </Container>
      ) : (
        <div className={`alert alert-dark mt-2 ml-2 mr-2 text-center`}>
          <p> Desktop access is required to view User Manager</p>
        </div>
      )}
    </div>
  );
};
export default Usermanager;
