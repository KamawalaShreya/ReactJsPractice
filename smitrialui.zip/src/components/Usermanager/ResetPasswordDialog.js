import React from "react";
import "./UserCreateForm.css";
import { Dialog } from "primereact/dialog";
import { InputText } from "primereact/inputtext";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { Button } from "primereact/button";

const ResetPasswordDialog = (props) => {
  var initialValues = {
    givenName: "",
    familyName: "",
    email: "",
    role: "",
  };

  const handleSubmit = () => {
    if (props.submitDetect) {
      props.submitDetect(true);
    }
  };

  if (props.initialValues) {
    initialValues = props.initialValues;
  } else {
    initialValues = {
      givenName: "",
      familyName: "",
      email: "",
      role: "",
    };
  }

  return (
    <Dialog
      header={`Reset Password`}
      visible={props.resetPasswordDialogVisible}
      position="top"
      style={{ width: "37vw" }}
      onHide={() => props.resetPasswordDialogOnClose(false)}
      draggable={false}
      resizable={false}
      dismissableMask={true}
    >
      <Formik initialValues={initialValues} onSubmit={handleSubmit}>
        {({ isSubmitting }) => (
          <Form>
            <div className="p-field mt-5">
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="givenName"
                  name="givenName"
                  as={InputText}
                  disabled={true}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
                <label htmlFor="givenName">First Name</label>
              </span>
              <ErrorMessage
                name="givenName"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-4">
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="text"
                  id="familyName"
                  name="familyName"
                  as={InputText}
                  disabled={true}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
                <label htmlFor="familyName">Last Name</label>
              </span>
              <ErrorMessage
                name="familyName"
                component="div"
                className="p-error"
              />
            </div>

            <div className="p-field mt-4">
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="email"
                  id="email"
                  name="email"
                  as={InputText}
                  disabled={true}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
                <label htmlFor="email">Email</label>
              </span>
              <ErrorMessage name="email" component="div" className="p-error" />
            </div>
            <div className="p-field mt-4">
              <span
                className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
              >
                <Field
                  type="role"
                  id="role"
                  name="role"
                  as={InputText}
                  disabled={true}
                  className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
                />
                <label htmlFor="role">Role</label>
              </span>
              <ErrorMessage name="role" component="div" className="p-error" />
            </div>
            <Button
              type="submit"
              label="Reset Password"
              style={{ background: "black", textAlign: "left" }}
              disabled={isSubmitting}
              className={`p-button-primary mt-4`}
            />
          </Form>
        )}
      </Formik>
    </Dialog>
  );
};
export default ResetPasswordDialog;
