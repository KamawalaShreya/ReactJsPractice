import React, { useState, useEffect } from "react";
import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import { Card, Row, Col, Container } from "react-bootstrap";
import { Dialog } from "primereact/dialog";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAward } from "@fortawesome/free-solid-svg-icons";
import { Button } from "primereact/button";

const DashboardSimulator = (props) => {
  const [dashboardData, setDashboardData] = useState([]);
  const [userEmail, setUserEmail] = useState("");
  const [selectedLessonIdToShow, setSelectedLessonIdToShow] = useState(null);

  useEffect(() => {
    if (props.userData && props.userData.group) {
      setUserEmail(props.userData.givenName);
      var url = `${config.api.url}getParticularUserboard?user=${props.userData.group}`;
      let dashUrl = url;
      if (selectedLessonIdToShow != null) {
        dashUrl = `${url}&lessonid=${selectedLessonIdToShow}`;
      }
      get(dashUrl).then((response) => {
        setDashboardData(response.data.dashboard);
      });
    }
  }, [selectedLessonIdToShow, props.userData]);

  const handleCardClick = (lessonRow) => {
    if (lessonRow.lessontype === "nestedcard") {
      setSelectedLessonIdToShow(lessonRow.id);
    }
  };

  const handleReturnBtnClick = () => {
    setSelectedLessonIdToShow(null);
  };

  return (
    <div>
      <Dialog
        // header={`Dashboard preview for ${userEmail}`}
        header={
          <div>
            <Row>
              <Col sm={9} md={9} lg={8}>
                <span className="">Dashboard preview for {userEmail} </span>
              </Col>
              <Col sm={3} md={3} lg={4}>
                <Button
                  label="Return to Dashboard"
                  onClick={() => {
                    handleReturnBtnClick();
                  }}
                  style={{
                    background: "black",
                    display: selectedLessonIdToShow != null ? "block" : "none",
                  }}
                />
              </Col>
            </Row>
          </div>
        }
        visible={props.dashboardSimulatorDialogVisible}
        position="top"
        style={{ width: "50vw", height: "80vh" }}
        onHide={() => {
          props.dashboardSimulatorDialogOnClose(false);
          props.setUserDataForDashboardSimulator(null);
          setUserEmail(null);
        }}
        dismissableMask={true }
        draggable={false}
        resizable={false}
      >
        <Container fluid>
          <Row style={{ width: "100%" }}>
            {dashboardData.map((lesson, k) => (
              <Col key={k} xs={12} md={4} lg={3} className="smi-card-outer">
                <Card
                  className="smi-card card-hover-shadow" /* card-hover-shadow */
                >
                  <Card.Header>
                    <div className="row ">
                      <h6 className="  col-9  truncateText text-left float-left">
                        {lesson.name}
                      </h6>
                      {lesson.status === "completed" ? (
                        <FontAwesomeIcon
                          icon={faAward}
                          color="green"
                          className="col-2 downloadCertificate  c-smi-green smi-btn text-right float-right mt-1"
                        />
                      ) : (
                        ""
                      )}
                    </div>
                  </Card.Header>
                  <Card.Body
                    className="smi-card-body onclickLesson"
                    data-id={lesson.id}
                  >
                    {lesson.lessontype === "nestedcard" ? (
                      <div>
                        <a
                          onClick={() => handleCardClick(lesson)}
                          className="img-link h-100 d-none d-sm-block d-md-block d-lg-block d-xl-block"
                        >
                          <div>
                            <Card.Img
                              className={`img-fluid d-flex align-items-center justify-content-center cardImg  ${
                                lesson.status === "completed"
                                  ? "completeLesson"
                                  : ""
                              }`}
                              loading="lazy"
                              src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                              alt={lesson.id}
                            />
                          </div>
                        </a>
                      </div>
                    ) : (
                      <div>
                        <a className="img-link h-100 d-none d-sm-block d-md-block d-lg-block d-xl-block">
                          <div>
                            <Card.Img
                              className={`img-fluid d-flex align-items-center justify-content-center cardImg  ${
                                lesson.status === "completed"
                                  ? "completeLesson"
                                  : ""
                              }`}
                              loading="lazy"
                              src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                              alt={lesson.id}
                            />
                          </div>
                        </a>
                        <a className="img-link h-100 d-block d-sm-none">
                          {" "}
                          {/* Mobile view tag */}
                          <div>
                            <Card.Img
                              className={`img-fluid d-flex align-items-center justify-content-center cardImg  ${
                                lesson.status === "completed"
                                  ? "completeLesson"
                                  : ""
                              }`}
                              loading="lazy"
                              src={`${config.content.url}${lesson.id}/${lesson.id}.png`}
                              alt={lesson.id}
                            />
                          </div>
                        </a>
                      </div>
                    )}
                    {lesson.status === "completed" ? (
                      <div className="col-12 text-left lessonStatus ">
                        COMPLETED
                      </div>
                    ) : (
                      ""
                    )}
                  </Card.Body>

                  <div className="smi-card-footer">
                    <div className="smi-lessoncard-header">
                      <div className="task-title mr-auto w-100">
                        <div className="row">
                          <div className="small p-0 text-left float-left">
                            {" "}
                            {lesson.lessonRequired === "true"
                              ? "REQUIRED"
                              : "OPTIONAL"}
                          </div>
                        </div>
                      </div>
                      {/* <Dropdown>
                                                <Dropdown.Toggle as={CustomToggle} >
                                                    <button className="btn btn-icon btn-light" id="dropdown-basic">
                                                        <FontAwesomeIcon icon={faEllipsisV} />
                                                    </button>
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu className="dropdown-menu-right">
                                                    <Dropdown.Item href="#">Added: {lesson.lessonAdded}</Dropdown.Item>
                                                    <Dropdown.Item href="#">Duration: {lesson.lessonDuration}</Dropdown.Item>
                                                    <Dropdown.Item href="#">Version: {lesson.version}</Dropdown.Item>
                                                </Dropdown.Menu>
                                            </Dropdown> */}
                    </div>
                  </div>
                </Card>
              </Col>
            ))}
          </Row>
        </Container>
      </Dialog>
    </div>
  );
};
export default DashboardSimulator;
