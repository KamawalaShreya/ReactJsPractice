import React from "react";
import { ErrorMessage } from "formik";
import { TreeSelect } from "primereact/treeselect";

const TreeSelectFieldComponent = ({ field, form, ...rest }) => {
  const handleChange = (event) => {
    form.setFieldValue(field.name, event.value);
  };

  return (
    <div className="p-field">
      <label htmlFor={field.name}>{rest.label}</label>
      <TreeSelect
        {...field}
        {...rest}
        onChange={handleChange}
        value={field.value}
        id={field.name}
        name={field.name}
      />
      <ErrorMessage name={field.name} component="div" className="p-error" />
    </div>
  );
};
export default TreeSelectFieldComponent;
