import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import DropdownField from "../Common/DropdownField";
import config from "../../config/config.json";
import { post } from "../../utils/HttpRequest";
import "./UserCreateForm.css";
// import TreeSelectFieldComponent from './TreeSelectFieldComponent';
// import config from '../../config/config.json'

var initialValues = {
  givenName: "",
  familyName: "",
  email: "",
  role: null,
  site: "",
  languagePreference: "English",
};

const UserCreateForm = (props) => {

  // const adminUser = config.api.url + 'adminCreateUser';

  var roleDropdownValue = false;
  var oldUser = null;
  // const [editFlagValue, seteditFlagValue] = useState(false);

  const validateForm = (values) => {
    const errors = {};
    if (!values.givenName) {
      errors.givenName = "Valid first name is required.";
    }

    if (!values.familyName) {
      errors.familyName = "Valid last name is required.";
    }

    if (!values.email) {
      errors.email = "Valid email is required.";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
      errors.email = "Valid email is required.";
    }
    if (!values.role || values.role.length === 0) {
      errors.role = "Valid role is required.";
    }
    if (!roleDropdownValue) {
      values.site = "";
    }

    return errors;
  };

  const handleSubmit = (values, { setSubmitting }) => {
    var createUserUrl = config.api.url + "adminCreateUser";
   
    var createUserTitle = "User Create";
    var createUserMessage = "User Created successfully.";
    // values.email = values.group;
    if (editFlag) {
      createUserUrl = config.api.url + "updateUserDetails";
      createUserTitle = "User Edit";
      createUserMessage = "User Saved successfully.";
      values.oldemail = oldUser.group;
    }
    if (!roleDropdownValue) {
      values.site = "";
    }
    let localValues = values;
    if (localValues.role.includes(";")) {
      let splittedval = localValues.role.split(";");
      localValues.role = splittedval[0];
      localValues.subrole = splittedval[1];
    } else {
      localValues.subrole = "";
    }

   
    if (props.submitDetect) {
      props.submitDetect("success");
    }

    post(createUserUrl, localValues)
      .then((res) => {
     
        if (res.status === 201 || res.status === 200) {
          props.toast.current.show({
            severity: "success",
            summary: createUserTitle,
            detail: createUserMessage,
          });

          if (props.submitDetect) {
            props.submitDetect("success");
          }
        } else if (res.response.status === 400) {
          props.toast.current.show({
            severity: "warn",
            summary: res.response.data.message,
            detail: res.response.data.message,
          });
        }
        props.setVisible(false);
        setSubmitting(false);
      })
      .catch((error) => {
        console.log(error, "TE");
        if (error.response && error.response.status === 400) {
          // Handle specific error case for duplicate email
          props.toast.current.show({
            severity: "warn",
            summary: createUserTitle,
            detail: "Email already exists.",
          });
        } else {
          props.toast.current.show({
            severity: "warn",
            summary: createUserTitle,
            detail: "Something went wrong.",
          });
        }
        props.setVisible(false);
        setSubmitting(false);
        if (props.submitDetect) {
          props.submitDetect("error");
        }
      });
  };

  const changeVisibilitySitesDropdown = (selectedValue) => {
  
    roleDropdownValue = ["kp", "crc", "sitepi", "kp;", "crc;", "sitepi;"].find(
      (v) => {
        let value = false;
        if (v.includes(";") && selectedValue.includes(v)) {
          value = true;
        }
        if (!v.includes(";") && selectedValue === v) {
          value = true;
        }
        return value;
      }
    );
  };

  let editFlag = false;

  // Block that checks for initial data - in case of editing user
  if (props.initialValues) {
    let userData = props.initialValues;
    if (userData.role && userData.subrole) {
      if (userData.role.includes(";")) {
        userData.role = userData.role.split(";")[0];
      }
      userData.role = userData.role + ";" + userData.subrole;
    }
    initialValues = userData;
    editFlag = true;
    oldUser = userData;
    changeVisibilitySitesDropdown(userData.role);
  } else {
    editFlag = false;
    oldUser = null;
    initialValues = {
      givenName: "",
      familyName: "",
      email: "",
      role: null,
      site: "",
      languagePreference: "English",
    };
  }

  return (
    <Formik
      initialValues={initialValues}
      validate={validateForm}
      onSubmit={handleSubmit}
    >
      {({ isSubmitting }) => (
        <Form>
          <div className="p-field mt-5">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="givenName"
                name="givenName"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="givenName">First Name</label>
            </span>
            <ErrorMessage
              name="givenName"
              component="div"
              className="p-error"
            />
          </div>

          <div className="p-field mt-4">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="text"
                id="familyName"
                name="familyName"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="familyName">Last Name</label>
            </span>
            <ErrorMessage
              name="familyName"
              component="div"
              className="p-error"
            />
          </div>

          <div className="p-field mt-4">
            <span
              className={`p-float-label ${isSubmitting ? "p-disabled" : ""}`}
            >
              <Field
                type="email"
                id="email"
                name="email"
                as={InputText}
                className={`p-inputtext ${isSubmitting ? "p-disabled" : ""}`}
              />
              <label htmlFor="email">Email</label>
            </span>
            <ErrorMessage name="email" component="div" className="p-error" />
          </div>

          {/* <div className="p-field mt-4">
                        <label htmlFor="selectedItems">Select Items</label>
                        <Field
                            id="selectedItems"
                            name="selectedItems"
                            component={TreeSelectFieldComponent}
                            options={options}
                            placeholder="Select items"
                        />
                    </div> */}
          <div className="p-field mt-5">
            <Field
              id="role"
              name="role"
              component={DropdownField}
              options={props.roleOptions}
              changeDetector={(selectedValue) => {
                // console.log(selectedValue)
                changeVisibilitySitesDropdown(selectedValue);
              }}
              placeholder="Select Role"
            />
          </div>
          <div className="p-field mt-5">
            <Field
              id="site"
              name="site"
              component={DropdownField}
              className={`${roleDropdownValue ? "" : "d-none"} `}
              options={props.sitesOptions}
              placeholder="Select Site"
            />
          </div>

          <div className="p-field mt-5">
            <Field
              id="languagePreference"
              name="languagePreference"
              component={DropdownField}
              options={props.languagesData}
              placeholder="Select Language"
            />
          </div>

          <Button
            type="submit"
            label={`${editFlag ? "Edit User" : "Create User"}`}
            style={{ background: "#4d4d4d", textAlign: "left" }}
            disabled={isSubmitting}
            className={`p-button-primary ${
              isSubmitting ? "p-disabled" : ""
            } mt-4`}
          />
        </Form>
      )}
    </Formik>
  );
};

export default UserCreateForm;
