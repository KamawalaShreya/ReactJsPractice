const Footerview = () => {
  return (
    <div
      className="footerBox"
      style={{ textAlign: "center", paddingTop: "15px" }}
    >
      <small>
        <a
          className="footerMessage mb-2 mr-2"
          href="https://www.sciencemedia.com"
          target="_blank"
        >
          {" "}
          Powered by ScienceMedia &nbsp; &nbsp; &nbsp; Version 4.0 17 8 &nbsp;
          &nbsp; &nbsp;
        </a>
      </small>
    </div>
  );
};

export default Footerview;
