import React from "react";
import Header from "../Header/Header";
import { Card, Container, Row } from "react-bootstrap";
import { useState } from "react";
import config from "../../config/config.json";
import { get } from "../../utils/HttpRequest";
import { useEffect } from "react";
import { useRef } from "react";
import Datatable from "../Common/Datatable";
import { useNavigate } from "react-router-dom";
import { Toast } from "primereact/toast";

const Sitedetails = () => {
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const siteid = params.get("siteid");

  const toast = useRef(null);

  const navigate = useNavigate();

  const [sitesUsers, setSiteUsers] = useState([]);
  const [siteDetails, setSiteDetails] = useState([]);

  // for datatable filteration
  const [searchText, setSearchText] = useState("");
  const [filteredData, setFilteredData] = useState(sitesUsers);

  useEffect(() => {
    let siteDetailsUrl = config.api.url + "getOneSite/" + siteid;
    let siteUsersUrl =
      config.api.url + "getSiteUsers?siteid=" + siteid + "&role=kp";
    let siteUsersRoleUrl =
      config.api.url + "getSiteUsersForRole?siteid=" + siteid + "&role=monitor";

    get(siteDetailsUrl).then((siteDetailsResponse) => {
      let sitedata = siteDetailsResponse.data;
      setSiteDetails(sitedata);
    });

    get(siteUsersUrl)
      .then((siteUsersResponse1) => {
        get(siteUsersRoleUrl)
          .then((siteUsersResponse2) => {
            setSiteUsers(
              siteUsersResponse1.data.concat(siteUsersResponse2.data)
            );
            setFilteredData(
              siteUsersResponse1.data.concat(siteUsersResponse2.data)
            );
          })
          .catch((error) => {
            console.log("Error fetching siteUsersRole ", error);
          });
      })
      .catch((error) => {
        console.log("Error fetching siteUsers ", error);
      });
  }, []);

  // Datatable search helper function
  const handleSearchChange = (e) => {
    const searchText = e.target.value;
    const filtered = searchText
      ? sitesUsers.filter((item) =>
          Object.values(item).some((value) =>
            String(value).toLowerCase().includes(searchText.toLowerCase())
          )
        )
      : sitesUsers;
    setFilteredData(filtered);
    setSearchText(searchText);
  };
  const defaultSorted = [
    {
      dataField: "givenName",
      order: "asc",
    },
  ];
  const siteUsersColumns = [
    {
      dataField: "givenName",
      text: "Name",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.givenName + " " + row.familyName;
      },
    },
    {
      dataField: "username",
      text: "Email",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
    },
    {
      dataField: "role",
      text: "Role",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.role ? row.role.toUpperCase() : row.role;
      },
    },
    {
      dataField: "subrole",
      text: "Subrole",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return row.subrole ? row.subrole.toUpperCase() : row.subrole;
      },
    },
  ];

  return (
    <div className="siteManagerPage app">
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%", marginLeft: "10px" }}>
        <Row style={{ width: "100%", padding: "20px" }}>
          <header className="sidebar-header d-xl-none w-100">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <li className="breadcrumb-item active">
                  <a
                    href={"/sitemanager"}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate("/sitemanager");
                    }}
                  >
                    <i
                      className="breadcrumb-icon pi pi-angle-left mr-2"
                      aria-hidden="true"
                    ></i>
                    Back
                  </a>
                </li>
              </ol>
            </nav>
          </header>
        </Row>
        <Row style={{ width: "100%", padding: "20px" }}>
          <h1
            className="smi-page-title smi-header d-sm-inline-block"
            style={{ fontWeight: 500, fontSize: "1.75rem" }}
          >
            <i
              className="pi pi-building text-muted2 mr-2"
              style={{ fontSize: "2rem" }}
            ></i>
            {siteDetails ? siteDetails.sitename : ""}
          </h1>
          <br />
          <p
            className="text-muted2 w-100 "
            style={{ textAlign: "left", fontSize: "1rem" }}
          >
            {siteDetails ? siteDetails.description : ""} <br />
            {siteDetails ? siteDetails.address : ""} <br />
            {siteDetails ? siteDetails.country : ""} <br />
          </p>
        </Row>
        <Row style={{ width: "100%", padding: "20px" }}>
          <Card style={{ width: "100%" }}>
            <Card.Body style={{ width: "100%" }}>
              <div className="mt-2">
                <Datatable
                  keyField="username"
                  defaultSorted={defaultSorted}
                  data={sitesUsers}
                  handleSearchChange={handleSearchChange}
                  columns={siteUsersColumns}
                  filteredData={filteredData}
                  searchText={searchText}
                />
              </div>
            </Card.Body>
          </Card>
        </Row>
      </Container>
    </div>
  );
};
export default Sitedetails;
