import React, { useRef } from "react";
import { Button, Card } from "react-bootstrap";
import { Editor, MultiSelect, Checkbox } from "primereact";
import { Dropdown } from "primereact/dropdown";
import { useState } from "react";
import { post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { useEffect } from "react";
import { InputText } from "primereact/inputtext";
import { useNavigate } from "react-router-dom";
import { Toast } from "primereact/toast";
import "./EmailRemindersForm.css";

const EmailRemindersForm = (props) => {
  const { subroleDatafilter, allRoles, getAllReminders } = props;
  const toast = useRef(null);
  const navigate = useNavigate();
  const formRef = useRef();
  const [text, setText] = useState("");
  const [validated, setValidated] = useState(false);
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [selectedSubRoles, setSelectedSubRoles] = useState([]);
  const [reminderType, setReminderType] = useState("");
  const [reminderFrequency, setReminderFrequency] = useState([]);
  const [reminderTiming, setReminderTiming] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      let payload = {};
      const rolesData = [...selectedRoles];
      if (!props.isEditNotification) {
        Object.keys(subroleDatafilter).forEach((roleGroup) => {
          selectedSubRoles.forEach((role) => {
            if (
              [...subroleDatafilter[roleGroup]].find(
                (subrole) => subrole === role
              )
            ) {
              rolesData.push(
                allRoles.find((item) => item.group === roleGroup).group
              );
            }
          });
        });
      }
      if (reminderType === "RequiredLessonsAreIncomplete") {
        if (
          !form.reminderTitle.value ||
          !reminderFrequency ||
          [...new Set([...rolesData])].length === 0 ||
          !text
        ) {
          alert(
            "Reminder subject, reminder frequency, reminder role, and message are required."
          );
          setValidated(true);
        }

        payload = {
          reminderTitle: form.reminderTitle.value,
          reminderType: reminderType,
          reminderFrequency: reminderFrequency,
          reminderRoles: [...new Set([...rolesData])],
          reminderSubroles: selectedSubRoles,
          reminderText: text,
        };
      } else if (reminderType === "UserHasNotLoggedIn") {
        if (!form.reminderTitle.value || reminderTiming.length === 0) {
          alert("Reminder subject and reminder timing are required.");
          setValidated(true);
        }

        payload = {
          reminderTitle: form.reminderTitle.value,
          reminderType: reminderType,
          reminderTiming: reminderTiming,
          reminderRoles: [...new Set([...rolesData])],
          reminderSubroles: selectedSubRoles,
          reminderText: text,
        };
      }
      if (props.isEditNotification) {
        payload = { ...payload, reminderGroup: props.selectedRow.group };
      }

      const url =
        config.api.url +
        (props.isEditNotification ? "editReminder" : "createReminder");

      post(url, payload)
        .then((response) => {
     
          if (response.status === 200 || response.status === 201) {
            toast.current.show({
              severity: "success",
              summary: "Successfully added",
              detail: "Success",
            });
            setTimeout(() => {
              props.closesetIsFormOpen();
              getAllReminders();
              navigate("/emailreminder");
            }, 2000);
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error fetching lesson data:", error);
    }
  };

  const Editdata = () => {
    if (props.isEditNotification) {
      formRef.current.reminderTitle.value = props.selectedRow.title;
      setReminderTiming(props.selectedRow.reminderTiming);
      setReminderFrequency(props.selectedRow.frequency);
      const roles = props.selectedRow.roles || [];
      const subroles = props.selectedRow.subroles || [];
      setSelectedSubRoles([...subroles]);
      setSelectedRoles([...roles]);
      setReminderType(props.selectedRow.type);
      setText(props.selectedRow.message);
    
    } else {
      formRef.current.reminderTitle.value = null;
      setSelectedRoles([]);
      setSelectedSubRoles([]);
      setText(null);
    }
  };

  const handleReminderTypeChange = (e) => {
    setReminderType(e.value);
  };

  const options = [
    { name: "User has not logged in", value: "UserHasNotLoggedIn" },
    {
      name: "Required lessons are incomplete",
      value: "RequiredLessonsAreIncomplete",
    },
  ];

  const optionsDayName = [
    { value: "Daily", name: "Daily" },
    { value: "Mon", name: "Monday" },
    { value: "Tue", name: "Tuesday" },
    { value: "Wed", name: "Wednesday" },
    { value: "Thu", name: "Thursday" },
    { value: "Fri", name: "Friday" },
    { value: "Sat", name: "Saturday" },
    { value: "Sun", name: "Sunday" },
  ];

  const ReminderTimingOption = [
    { name: "1 day", value: "1" },
    { name: "2 day", value: "2" },
    { name: "3 day", value: "3" },
    { name: "4 day", value: "4" },
    { name: "5 day", value: "5" },
    { name: "6 day", value: "6" },
    { name: "7 day", value: "7" },
    { name: "8 day", value: "8" },
    { name: "9 day", value: "9" },
    { name: "10 day", value: "10" },
    { name: "11 day", value: "11" },
    { name: "12 day", value: "12" },
    { name: "13 day", value: "13" },
    { name: "14 day", value: "14" },
    { name: "15 day", value: "15" },
  ];

  const optionGroups = Object.keys(subroleDatafilter).map((roleGroup) => ({
    label: allRoles.find((item) => item.group === roleGroup).description,
    value: allRoles.find((item) => item.group === roleGroup).group,
    items: [...subroleDatafilter[roleGroup]].map((subrole) => ({
      value: subrole,
      label: subrole,
    })),
  }));

  const removeItem = (item) => {
    setSelectedSubRoles(
      [...new Set([...selectedSubRoles])].filter(
        (selectedItem) => selectedItem !== item
      )
    );
    setSelectedRoles(
      [...new Set([...selectedRoles])].filter(
        (selectedItem) => selectedItem !== item
      )
    );
  };

  useEffect(() => {
    Editdata();
  }, [props]);

  return (
    <div>
      <Toast ref={toast}></Toast>{" "}
      <div className="page-section">
        <Card style={{ width: "100%" }} className="p-3">
          <div className="d-flex justify-content-between">
            <span className="card-title ">
              {props.isEditNotification ? "Edit Notification" : "New Reminder"}
            </span>
          </div>
          <form
            className="needs-validation"
            validated={validated}
            onSubmit={handleSubmit}
            ref={formRef}
          >
            <div className="mb-3">
              <label htmlFor="ReminderTitle">Reminder Email Subject*</label>
              <InputText
                type="text"
                name="reminderTitle"
                className="w-full p-inputtext-sm forminput"
                required
              />
              {validated && (
                <div className="invalid-feedback"> Valid name is required.</div>
              )}
            </div>

            {!props.isEditNotification && (
              <div className="mb-3">
                <label htmlFor="ReminderType">Reminder Type*</label>
                <Dropdown
                  value={reminderType}
                  onChange={handleReminderTypeChange}
                  options={options}
                  optionLabel="name"
                  name="reminderType"
                  className="w-full p-inputtext-sm forminput"
                  placeholder="Choose..."
                  required
                />
                {validated && (
                  <div className="invalid-feedback">
                    Reminder type is required.
                  </div>
                )}
              </div>
            )}

            {reminderType === "UserHasNotLoggedIn" && (
              <>
                <div className="mb-3">
                  <label htmlFor="ReminderType">Reminder Timing*</label>
                  <MultiSelect
                    value={reminderTiming}
                    onChange={(e) => setReminderTiming(e.value)}
                    options={ReminderTimingOption}
                    className="w-full p-inputtext-sm reminder-timing-chip forminput"
                    placeholder="Choose..."
                    required
                    optionLabel="name"
                    display="chip"
                  />
                  {validated && (
                    <div className="invalid-feedback">
                      Reminder type is required.
                    </div>
                  )}
                </div>
                <p>
                  Sending a 'user has not logged in' reminder will resend the
                  initial login email to users who have not logged in within the
                  specified number of days.This email will contain a new
                  temporary password for the user to log in with.
                </p>
              </>
            )}

            {reminderType === "RequiredLessonsAreIncomplete" && (
              <>
                <div className="mb-3">
                  <label htmlFor="ReminderFrequency">
                    Reminder Frequency<abbr>*</abbr>
                  </label>
                  <Dropdown
                    value={reminderFrequency}
                    onChange={(e) => setReminderFrequency(e.value)}
                    options={optionsDayName}
                    name="ReminderFrequency"
                    className="w-full p-inputtext-sm forminput"
                    placeholder="Choose..."
                    required
                    optionLabel="name"
                  />
                  {validated && (
                    <div className="invalid-feedback">
                      At least one day must be selected.
                    </div>
                  )}
                </div>
                <div className="mb-3">
                  <label htmlFor="Roles">Roles</label>
                  <MultiSelect
                    value={[
                      ...new Set([...selectedRoles, ...selectedSubRoles]),
                    ]}
                    options={optionGroups}
                    onChange={(e) => {
                      setSelectedSubRoles([...new Set(e.value)]);
                    }}
                    optionLabel="label"
                    ptionLabel="label"
                    optionGroupLabel="label"
                    optionGroupChildren="items"
                    display="chip"
                    selectedItemTemplate={(item) =>
                      item ? (
                        <div className="d-flex flex-wrap">
                          <div className="custom-chip">
                            {item}
                            <i
                              className="pi pi-times custom-chip-remove"
                              onClick={() => removeItem(item)}
                            ></i>
                          </div>
                        </div>
                      ) : null
                    }
                    optionGroupTemplate={(option) => {
                      return (
                        <div className="flex align-items-center gap-2">
                          <Checkbox
                            onChange={() => {
                              if ([...selectedRoles].includes(option.value)) {
                                setSelectedRoles((pre) =>
                                  [...pre].filter(
                                    (role) => role !== option.value
                                  )
                                );
                              } else {
                                setSelectedRoles([
                                  ...selectedRoles,
                                  option.value,
                                ]);
                              }
                            }}
                            checked={[...selectedRoles].includes(option.value)}
                          />
                          <div>{option.label}</div>
                        </div>
                      );
                    }}
                    optionValue="value"
                    // optionGroupLabel="label"
                    placeholder="Choose subroles"
                    className="w-full p-inputtext-sm forminput forminputscroll"
                    required
                  />
                </div>
                <label htmlFor="ReminderMessage">Reminder Message*</label>
                <Editor
                  value={text}
                  onTextChange={(e) => setText(e.htmlValue)}
                  style={{ height: "250px" }}
                />
              </>
            )}
            <div className="py-3">
              <Button className="btn btn-primary px-3" type="submit">
                Save
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};
export default EmailRemindersForm;
