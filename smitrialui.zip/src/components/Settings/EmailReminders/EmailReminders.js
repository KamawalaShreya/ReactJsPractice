import React, { useEffect } from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faPencil,
  faPlus,
  faDownload,
} from "@fortawesome/free-solid-svg-icons";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import { useState } from "react";
import Datatable from "../../Common/Datatable";
import { Toast } from "primereact";
import { useRef } from "react";
import EmailRemindersForm from "./EmailRemindersForm";
import ModelBox from "./Modelbox";

const EmailReminders = () => {
  const toast = useRef(null);
  const [subroleDatafilter, setSubroleDatafilter] = useState([]);
  const [allRoles, setAllRoles] = useState([]);
  const [allReminders, setAllReminders] = useState([]);

  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);
  const [filteredData, setFilteredData] = useState(allReminders);
  const [selectedRow, setSelectedRow] = useState(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isEditNotification, setIsEditNotification] = useState(false);
  const [modalShow, setModalShow] = useState(false);

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value.toLowerCase();
   
    let dataAll = newData ? newData : allReminders;

    const filtered = newsearchText
      ? // ? [...dataAll].filter((item) =>
        //     Object.values(item).some((value) => {
        //       return String(value)
        //         .toLowerCase()
        //         .includes(newsearchText.toLowerCase());
        //     })
        //   )
        // : dataAll;

        dataAll.filter((item) => {
          return Object.keys(item).some((key) => {
            if (key === "roles") {
              const rolesString = (item[key] || [])
                .map((role) => role.toLowerCase())
                .join(" ");
             
              return rolesString.includes(newsearchText);
            } else if (key === "subroles") {
              const subrolesArray = item[key];
              if (subrolesArray && subrolesArray.length > 0) {
                const subrolesString = subrolesArray
                  .map((subrole) => subrole.toLowerCase())
                  .join(" ");
                return subrolesString.includes(newsearchText);
              }
              return false;
            } else {
              return String(item[key]).toLowerCase().includes(newsearchText);
            }
          });
        })
      : dataAll;
  

    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getAllReminders = async () => {
    try {
      const url = config.api.url + "getAllReminders";
      get(url).then((response) => {
        const data = response.data.map((allReminders) => {
          if (allReminders.status === "active") {
            allReminders.reminderID = allReminders.group;
            allReminders.reminderType = allReminders.type.replaceAll("+", " ");
            if (
              allReminders.type.replaceAll("+", " ") ===
              "RequiredLessonsAreIncomplete"
            ) {
              allReminders.reminderType = "Incomplete lessons";
            } else if (
              allReminders.type.replaceAll("+", " ") === "UserHasNotLoggedIn"
            ) {
              allReminders.reminderType = "User hasn't logged in";
            }
            if (allReminders.roles == null && allReminders.subroles == null) {
              allReminders.roles = "";
              allReminders.subroles = "";
            }
          }
          if (allReminders.status === "inactive") {
            allReminders.reminderID = allReminders.group;
            allReminders.reminderType = allReminders.type.replaceAll("+", " ");
            if (allReminders.roles == null && allReminders.subroles == null) {
              allReminders.roles = "";
              allReminders.subroles = "";
            }
          }
          return allReminders;
        });
        setAllReminders(data);
        setFilteredData(data);
        handleSearchChange(
          {
            target: {
              value: searchTextRef.current ? searchTextRef.current : "",
            },
          },
          [...data]
        );
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const updateReminderStatus = async (row) => {
    try {
      const formData = {
        group: row?.group,
        status: row?.status === "active" ? "inactive" : "active",
      };
      var url = config.api.url + "updateReminderStatus";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getAllReminders();
            toast.current.show({
              severity: "success",
              summary: "successfully updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "something want wrong",
        });
      }
    }
  };

  const getAllSubroles = async (roleGroupData) => {
    try {
      const url = config.api.url + "getAllSubroles";
      get(url).then((response) => {
        let roleandsubroles = {};

        roleGroupData.map((role) => {
          roleandsubroles[role.group] = [];
          [...response.data].map((subrole) => {
            if (role.group === subrole.group.split("-")[0]) {
              roleandsubroles[role.group].push(subrole.subrolename);
            }
          });
        });
        setSubroleDatafilter(roleandsubroles);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getAllRoles = async () => {
    try {
      const url = config.api.url + "getAllRoles";
      get(url).then((response) => {
        setAllRoles(response.data);
        getAllSubroles(response.data);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const setEditSiteId = (row) => {
    setIsFormOpen(false);
    setIsEditNotification(true);
    setSelectedRow(row);
    setIsFormOpen(true);
  };

  const toggleFormVisibility = () => {
    setIsFormOpen(false);
    setIsEditNotification(false);
    setSelectedRow(null);
    setIsFormOpen(true);
  };

  const siteColumn = [
    {
      dataField: "title",
      text: "Reminder Email Subject",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "reminderType",
      text: "Reminder Type ",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "addedString",
      text: "Date Created",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "roles",
      text: "Roles",
      sort: true,
      // filterValue: (cell) => {
      //   console.log(cell);
      //   return cell.includes(searchText);
      // },
      formatter: (cell, row) => {
       
        return (
          <div className="d-flex flex-column text-center">
            {row?.roles.length &&
              row?.roles?.map((item) => <span>{item}</span>)}
          </div>
        );
      },
      filterValue: (cell) => {
        if (Array.isArray(cell) && cell.length > 0) {
         
          return cell.some((role) =>
            role ? role.includes(searchText) : false
          );
        }
        return false;
      },
    },
    {
      dataField: "subroles",
      text: "Subroles",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
      formatter: (cell, row) => {
        return (
          <div className="d-flex flex-column">
            {row?.subroles.length &&
              row?.subroles?.map((item) => <span>{item}</span>)}
          </div>
        );
      },
    },
    {
      dataField: "Status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "active" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "active" ? true : false}
                  onChange={() => {
                    setFilteredData((prev) =>
                      prev.map((statusdata) => {
                        if (statusdata.group === row.group) {
                          return {
                            ...statusdata,
                            status:
                              row.status === "active" ? "inactive" : "active",
                          };
                        } else {
                          return statusdata;
                        }
                      })
                    );
                    updateReminderStatus(row);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "Edit Message ",
      text: "Edit Message ",
      sort: true,
      formatter: (cell, row, index) => {
        return (
          <div className="text-center" key={index}>
            <div
              style={{ cursor: "pointer" }}
              className="btn btn-sm btn-icon btn-secondary "
              onClick={() => {
                setEditSiteId(row);
              }}
            >
              <FontAwesomeIcon className="text-teal" icon={faPencil} />
            </div>
          </div>
        );
      },
      filterValue: (cell) => cell.includes(searchText),
    },
  ];

  useEffect(() => {
    getAllReminders();
    getAllRoles();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="page-inner">
          <Row>
            <Col md={7}>
              <div className="page-section">
                <Card style={{ width: "100%" }}>
                  <div className="d-flex justify-content-between">
                    <span className="card-title">Email Reminders</span>
                    <div>
                      <div className="d-flex align-items-center card-title">
                        <span className="card-title ">
                          Download reminder history
                        </span>
                        <span>
                          <span
                            onClick={() => setModalShow(true)}
                            className="tile tile-circle tile-md text-white smi-tile-primary smi-btn"
                          >
                            <FontAwesomeIcon icon={faDownload} />
                          </span>
                        </span>
                        <span className="card-title ">Create Reminder</span>
                        <span>
                          <span
                            onClick={toggleFormVisibility}
                            className="tile tile-circle tile-md text-white smi-tile-primary createNotification smi-btn"
                          >
                            <FontAwesomeIcon icon={faPlus} />
                          </span>
                        </span>
                      </div>
                    </div>
                  </div>
                  <Datatable
                    keyField={"addedEpoch"}
                    data={filteredData}
                    columns={siteColumn}
                    filteredData={filteredData}
                    isActionEnable={false}
                    searchText={searchText}
                    handleSearchChange={handleSearchChange}
                  />
                </Card>
              </div>
            </Col>
            {isFormOpen && (
              <Col md={5}>
                <EmailRemindersForm
                  selectedRow={selectedRow}
                  isEditNotification={isEditNotification}
                  subroleDatafilter={subroleDatafilter}
                  allRoles={allRoles}
                  closesetIsFormOpen={() => setIsFormOpen(false)}
                  getAllReminders={getAllReminders}
                />
              </Col>
            )}
          </Row>
        </div>
      </Container>
      <ModelBox show={modalShow} onHide={() => setModalShow(false)} />
    </div>
  );
};
export default EmailReminders;
