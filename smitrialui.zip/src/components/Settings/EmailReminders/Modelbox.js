import React, { useRef, useState } from "react";
import { Container, Modal } from "react-bootstrap";
import { RadioButton } from "primereact/radiobutton";
import "./EmailRemindersForm.css";
import { Calendar } from "primereact/calendar";
import config from "../../../config/config.json";
import { post } from "../../../utils/HttpRequest";
import { Toast } from "primereact/toast";

const ModelBox = (props) => {
  const toast = useRef(null);
  const [selectedOption, setSelectedOption] = useState(null);
  const [dates, setDates] = useState(null);
  const [validated, setValidated] = useState(false);
  const [email] = useState(localStorage.getItem("email"));

  const options = [
    { label: "Last 1 Month", value: "Last 1 Month" },
    { label: "Last 3 Months", value: "Last 3 Months" },
    { label: "Date range", value: "customrange" },
  ];

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const form = event.currentTarget;
      if (form.checkValidity() === false) {
        setValidated(true);
        return;
      }
      const currDate = new Date();
      let d = new Date();
      let datesToGet = {};
      if (selectedOption === "Last 1 Month") {
        d.setMonth(currDate.getMonth() - 1);
        datesToGet.minDate = d.getTime();
        datesToGet.maxDate = currDate.getTime();
      } else if (selectedOption === "Last 3 Months") {
        d.setMonth(currDate.getMonth() - 3);
        datesToGet.minDate = d.getTime();
        datesToGet.maxDate = currDate.getTime();
      } else if (selectedOption === "customrange" && dates) {
        datesToGet.minDate = new Date(dates[0]).getTime();
        datesToGet.maxDate = new Date(dates[1]).getTime();
      }

      const formData = {
        ...datesToGet,
        userEmail: email,
      };
      const url = config.api.url + "getReminderHistory";
      post(url, formData)
        .then((response) => {
          if (response.data["signedURL"]) {
            window.open(response.data["signedURL"], "_blank");
            props.onHide();
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  return (
    <div className="app radiobutton">
      <Toast ref={toast}></Toast>{" "}
      <Modal show={props.show} onHide={() => props.onHide()}>
        <Modal.Header closeButton>
          <Modal.Title style={{ fontSize: "1.25rem" }}>
            Download reminder history
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Container>
            <p>Select duration of the report :</p>
            <form
              id="getReminderdatesForm"
              className="needs-validation"
              novalidate=""
              onSubmit={handleSubmit}
              validated={validated}
            >
              <div className="p-field-radiobutton">
                {options.map((option) => (
                  <div className="py-3" key={option.value}>
                    <RadioButton
                      inputId={option.value}
                      name="radio"
                      className=""
                      value={option.value}
                      onChange={(e) => setSelectedOption(e.value)}
                      checked={selectedOption === option.value}
                    />
                    <label htmlFor={option.value}>{option.label}</label>
                  </div>
                ))}
              </div>
              {selectedOption === "customrange" && (
                <div className="card flex justify-content-center">
                  <Calendar
                    value={dates}
                    onChange={(e) => setDates(e.value)}
                    selectionMode="range"
                    readOnlyInput
                  />
                </div>
              )}

              <div className="my-3">
                <button type="sumbit" className="btn btn-primary ">
                  Download report
                </button>
              </div>
            </form>
          </Container>
        </Modal.Body>
      </Modal>
    </div>
  );
};
export default ModelBox;
