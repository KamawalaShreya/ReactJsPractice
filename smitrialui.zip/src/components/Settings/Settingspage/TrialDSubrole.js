import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Button, Form } from "react-bootstrap";

const TrialDSubrole = () => {
  const toast = useRef(null);
  const formRef = useRef();
  const [validated, setValidated] = useState(false);
  const [trialdSubrole, setTrialdSubrole] = useState("");
  const [group, setgroup] = useState("");

  const getTrialdSubrole = async () => {
    try {
      const url = config.api.url + "getTrialConfig/trialdSubrole";
      get(url).then((response) => {
        let valueData = response.data;
        setTrialdSubrole(valueData.value);
        setgroup(valueData.group);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getTrialdSubrole();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      event.stopPropagation();
      return;
    }
    try {
      const formData = {
        name: group,
        value: form.trialdSubrole.value,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            toast.current.show({
              severity: "success",
              summary: "trialdSubrole data has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <span className="card-title">TrialD Subrole</span>{" "}
      <Form
        id="settingsPageTrialdSubroleForm"
        className="needs-validation"
        onSubmit={handleSubmit}
        noValidate
        ref={formRef}
        validated={validated}
      >
        <div className="col-sm-12 col-md-2  mb-3 mt-3">
          <Form.Group>
            <Form.Control
              type="text"
              className="form-control input-group"
              name="trialdSubrole"
              rows="4"
              required
              value={trialdSubrole}
              onChange={(e) => setTrialdSubrole(e.target.value)}
            />
          </Form.Group>
        </div>

        <div className="form-actions ml-2 mb-4">
          <Button className="btn btn-primary  px-3" type="submit">
            Save
          </Button>
        </div>
      </Form>
    </div>
  );
};
export default TrialDSubrole;
