import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Col, Form, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleQuestion } from "@fortawesome/free-solid-svg-icons";

const EnableLesson = () => {
  const toast = useRef(null);
  const [croLessonReview, setCroLessonReview] = useState(false);
  const [sponsorLessonReview, setSponsorLessonReview] = useState(false);

  const getShowCroLessonReview = async () => {
    try {
      const url = config.api.url + "getTrialConfig/croLessonReview";
      get(url).then((response) => {
       
        setCroLessonReview(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleShowCroLessonReview = async () => {
    try {
      setCroLessonReview(!croLessonReview);
      const formData = {
        name: "croLessonReview",
        value: !croLessonReview,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowCroLessonReview();
            toast.current.show({
              severity: "success",
              summary: "CRO Lesson Review Value updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const getShowSponsorLessonReview = async () => {
    try {
      const url = config.api.url + "getTrialConfig/sponsorLessonReview";
      get(url).then((response) => {
        setSponsorLessonReview(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleSponsorToggleForLessonReview = async () => {
    try {
      setSponsorLessonReview(!sponsorLessonReview);
      const formData = {
        name: "sponsorLessonReview",
        value: !sponsorLessonReview,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowSponsorLessonReview();
            toast.current.show({
              severity: "success",
              summary: "Sponsor Lesson Review Value updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  useEffect(() => {
    getShowCroLessonReview();
    getShowSponsorLessonReview();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <h6 className="card-title">Enable Lesson Review for Roles</h6>
      <Row>
        <Col lg={6}>
          <Form id="settingsPageLessonReview">
            <div className="form-check mb-3">
              <label
                className="form-check-label"
                htmlFor="croRoleToggleForLessonReview"
              >
                CRO Role
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon
                    icon={faCircleQuestion}
                    onClick={handleShowCroLessonReview}
                  />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="croRoleToggleForLessonReview"
                    checked={croLessonReview}
                    onClick={handleShowCroLessonReview}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
        <Col lg={6}>
          <Form id="settingsPageLessonReview">
            <div className="form-check mb-3">
              <label
                className="form-check-label"
                htmlFor="sponsorRoleToggleForLessonReview"
              >
                Sponsor Role
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon
                    icon={faCircleQuestion}
                    onClick={handleSponsorToggleForLessonReview}
                  />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="sponsorRoleToggleForLessonReview"
                    checked={sponsorLessonReview}
                    onClick={handleSponsorToggleForLessonReview}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
export default EnableLesson;
