import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Button, Form } from "react-bootstrap";

const TrialTitle = () => {
  const toast = useRef(null);
  const formRef = useRef();
  const [trialTitle, setTrialTitle] = useState("");
  const [group, setgroup] = useState("");
  const [validated, setValidated] = useState(false);

  const gettrialTitle = async () => {
    try {
      const url = config.api.url + "getTrialConfig/trialTitle";
      get(url).then((response) => {
        let data = response.data;
        setTrialTitle(data.value);
        setgroup(data.group);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    gettrialTitle();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      event.stopPropagation();
      return;
    }
    try {
      const formData = {
        name: group,
        value: form.trialTitle.value,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            toast.current.show({
              severity: "success",
              summary: "Trial title has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong.",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };
  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <span className="card-title">Trial Title</span>{" "}
      <span>(Maximum of 3 lines)</span>
      <Form
        className="needs-validation"
        onSubmit={handleSubmit}
        noValidate
        ref={formRef}
        validated={validated}
      >
        <div className="col-sm-12 mb-3 mt-3">
          <Form.Group controlId="exampleForm.ControlTextarea1">
            <Form.Control
              name="trialTitle"
              as="textarea"
              rows={4}
              required
              type="text"
              value={trialTitle}
              onChange={(e) => setTrialTitle(e.target.value)}
            />
          </Form.Group>
        </div>
        <div className="form-actions ml-2 mb-4">
          <Button className="btn btn-primary  px-3" type="submit">
            Save
          </Button>
        </div>
      </Form>
    </div>
  );
};
export default TrialTitle;
