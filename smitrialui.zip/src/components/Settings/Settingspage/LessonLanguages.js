import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import CreatableSelect from "react-select/creatable";
import "./LessonLanguages.css";

const LessonLanguages = () => {
  const toast = useRef(null);
  const formRef = useRef();
  const [validated, setValidated] = useState(false);
  const [lessonLanguages, setLessonLanguages] = useState([]);
  const [selectedLanguages, setSelectedLanguages] = useState([]);

  const getShowLessonLanguages = async () => {
    try {
      const url = config.api.url + "getTrialConfig/lessonLanguages";
      get(url).then((response) => {
        const data = JSON.parse(response.data.value);
        const languageNames = data.map((item) => item.languageName);
        setLessonLanguages(languageNames);
        setSelectedLanguages(languageNames);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleSettingsPageLessonLanguagesForm = async (event) => {
    event.preventDefault();
    const form = formRef.current;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      const formData = {
        name: "lessonLanguages",
        value: JSON.stringify(
          selectedLanguages.map((language) => ({ languageName: language }))
        ),
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            toast.current.show({
              severity: "success",
              summary: "Lesson languages has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error fetching lesson data:", error);
    }
  };

  useEffect(() => {
    getShowLessonLanguages();
  }, []);

  const customSelectStyles = {
    multiValue: (provided) => ({
      ...provided,
      backgroundColor: "#107639",
    }),
    multiValueLabel: (provided) => ({
      ...provided,
      color: "white",
    }),
  };

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <span className="card-title">Lesson Languages</span>{" "}
      <form
        onSubmit={handleSettingsPageLessonLanguagesForm}
        ref={formRef}
        validated={validated}
      >
        <div className="col-sm-12 col-md-4 mb-3 mt-3">
          <label className="control-label" htmlFor="settingsPageLanguageSelect">
            Lesson Language/s*
          </label>
          <CreatableSelect
            isMulti
            value={selectedLanguages.map((language) => ({
              label: language,
              value: language,
            }))}
            options={lessonLanguages.map((language) => ({
              label: language,
              value: language,
            }))}
            onChange={(values) =>
              setSelectedLanguages(values.map((value) => value.value))
            }
            placeholder="Select or create languages"
            className="w-full p-inputtext-sm"
            required
            styles={customSelectStyles}
          />
        </div>
        <div className="ml-2 mb-4">
          <button className="btn btn-primary px-3" type="submit">
            Save
          </button>
        </div>
      </form>
    </div>
  );
};
export default LessonLanguages;
