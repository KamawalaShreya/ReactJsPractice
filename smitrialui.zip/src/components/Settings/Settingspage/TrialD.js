import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Col, Form, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleQuestion } from "@fortawesome/free-solid-svg-icons";

const TrialD = () => {
  const toast = useRef(null);
  const [trialdEnabled, setTrialdEnabled] = useState(false);
  const [trialDusers, setTrialDusers] = useState(true);
  const [enableNavBarItems, setEnableNavBarItems] = useState(false);

  const getShowTrialdEnabled = async () => {
    try {
      const url = config.api.url + "getTrialConfig/trialdEnabled";
      get(url).then((response) => {
        setTrialdEnabled(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getShowTrialdUsers = async () => {
    try {
      const url = config.api.url + "getTrialConfig/trialDUserInReport";
      get(url).then((response) => {
        setTrialDusers(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleShowTrialdEnabled = async () => {
    try {
      setTrialdEnabled(!trialdEnabled);
      const formData = {
        name: "trialdEnabled",
        value: !trialdEnabled,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowTrialdEnabled();
            toast.current.show({
              severity: "success",
              summary: "TrialD toggle has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const handleShowTrialdUsers = async () => {
    try {
      setTrialDusers(!trialDusers);
      const formData = {
        name: "trialDUserInReport",
        value: !trialDusers,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowTrialdUsers();
            toast.current.show({
              severity: "success",
              summary: "Show TrialD toggle has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const getShowEnableNavBarItems = async () => {
    try {
      const url = config.api.url + "getTrialConfig/enableNavBarItems";
      get(url).then((response) => {
        setEnableNavBarItems(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleShowEnableNavBarItems = async () => {
    try {
      setEnableNavBarItems(!enableNavBarItems);
      const formData = {
        name: "enableNavBarItems",
        value: !enableNavBarItems,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowTrialdEnabled();
            toast.current.show({
              severity: "success",
              summary: "Navigation bar items toggle has been update",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  useEffect(() => {
    getShowTrialdEnabled();
    getShowEnableNavBarItems();
    getShowTrialdUsers();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <Row>
        <Col lg={6}>
          <span className="card-title">TrialD</span>{" "}
          <Form id="settingsPageTrialDEnabled">
            <div className="form-check mb-3">
              <label className="form-check-label" htmlFor="trialdEnabled">
                Enable TrialD
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon icon={faCircleQuestion} />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="enableNavBarItems"
                    checked={trialdEnabled}
                    onClick={handleShowTrialdEnabled}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
          <Form id="settingsPageTrialDUsers">
            <div className="form-check mb-3">
              <label className="form-check-label" htmlFor="trialdUsers">
                Do not show TrialD users in lesson reports
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon icon={faCircleQuestion} />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="trialdUsers"
                    checked={trialDusers}
                    onClick={handleShowTrialdUsers}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
        <Col lg={6}>
          <Form id="settingsPageTrialDEnabled">
            <div className="form-check mb-3">
              <label className="form-check-label" htmlFor="enableNavBarItems">
                Disable navigation bar items
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon icon={faCircleQuestion} />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="enableNavBarItems"
                    checked={enableNavBarItems}
                    onClick={handleShowEnableNavBarItems}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
export default TrialD;
