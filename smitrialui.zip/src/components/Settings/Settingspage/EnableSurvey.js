import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Button, Col, Form, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleQuestion, faSpinner } from "@fortawesome/free-solid-svg-icons";

const EnableSurvey = () => {
  const toast = useRef(null);
  const [showSurvey, setshowSurvey] = useState(false);
  const [lessons, setLessons] = useState([]);
  const [showSurveyLessonID, setShowSurveyLessonID] = useState("");
  const [loading, setLoading] = useState(false);

  const getShowSurveySettings = async () => {
    try {
      const url = config.api.url + "getTrialConfig/showSurvey";
      get(url).then((response) => {
        setshowSurvey(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleShowSurveySettings = async () => {
    try {
      setshowSurvey(!showSurvey);
      const formData = {
        name: "showSurvey",
        value: !showSurvey,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowSurveySettings();
            toast.current.show({
              severity: "success",
              summary: "trialVersion has been update",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  const getAllSurveyLessons = async () => {
    try {
      const url = config.api.url + "getLessons";
      get(url).then((response) => {
        setLessons(
          response.data.filter(
            (lesson) =>
              lesson.status === "active" && lesson.lessontype === "survey"
          )
        );
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getShowSurveyLessonID = async () => {
    try {
      const url = config.api.url + "getTrialConfig/showSurveyLessonID";
      get(url).then((response) => {
        let valueData = response.data;
        setShowSurveyLessonID(valueData.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleSurveyLessonIDChange = (event) => {
    setShowSurveyLessonID(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    try {
      setLoading(true);
      const formData = {
        name: "showSurveyLessonID",
        value: form.surveyLesson.value,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            toast.current.show({
              severity: "success",
              summary:
                "Survey Lesson to Display after lesson completion has been updated " +
                response.data.value,
              detail: "success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .finally(() => {
          setLoading(false);
        });
    } catch (error) {
      console.error("Error making API call:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    getShowSurveySettings();
    getAllSurveyLessons();
    getShowSurveyLessonID();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <Row>
        <Col lg={6}>
          <span className="card-title">
            Enable survey after each lesson completion
          </span>{" "}
          <Form id="settingsPageShowSurveyForm">
            <div className="form-check mb-3">
              <label className="form-check-label" htmlFor="showSurveySettings">
                Show survey
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon icon={faCircleQuestion} />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="showSurvey"
                    checked={showSurvey}
                    onClick={handleShowSurveySettings}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
        <Col lg={6}>
          <span className="card-title">
            Survey Lesson to Display after lesson completion
          </span>{" "}
          <Form name="settingsPageSurveyLessonForm" onSubmit={handleSubmit}>
            <div className="col-sm-12 col-md-4 mb-3 mt-3">
              <Form.Group controlId="validationCustom02">
                <Form.Label>Select lesson to share*</Form.Label>
                <Form.Select
                  className="form-control"
                  onChange={handleSurveyLessonIDChange}
                  value={showSurveyLessonID}
                  data-toggle="select2"
                  data-checklist-item-id="settingsPageSurveyLessonSelect"
                  data-options='{ "tags": false, "tokenSeparators": [",", " "] }'
                  required
                  name="surveyLesson"
                >
                  <option value=""> Select Survey Lesson</option>
                  {lessons?.map((lessonsdata) => {
                    return (
                      <option
                        value={lessonsdata?.lessonid}
                        key={lessonsdata.lessonid}
                      >
                        {lessonsdata?.lessonname}
                      </option>
                    );
                  })}
                </Form.Select>
              </Form.Group>
            </div>
            <div className="ml-2 mb-4">
              <Button
                className="btn btn-primary 
               px-3"
                type="submit"
                disabled={loading}
              >
                Save
                {loading && (
                  <span className="ml-2">
                    <FontAwesomeIcon
                      className=" loader"
                      icon={faSpinner}
                      spin
                    />
                  </span>
                )}
              </Button>
            </div>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
export default EnableSurvey;
