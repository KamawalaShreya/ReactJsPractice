import React, { useRef, useState } from "react";
import { Col, Container, Form, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleQuestion } from "@fortawesome/free-solid-svg-icons";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import { useEffect } from "react";
import { Toast } from "primereact/toast";
import TrialTitle from "./TrialTitle";
import ProtocolVersion from "./ProtocolVersion";
import DashboardAlert from "./DashboardAlert";
import EnableSurvey from "./EnableSurvey";
import TrialD from "./TrialD";
import EnableLesson from "./EnableLesson";
import TrialDSubrole from "./TrialDSubrole";
import LessonLanguages from "./LessonLanguages";
import AssessmentPassingScoreForm from "./AssessmentPassingScoreForm";

const Settings = () => {
  const toast = useRef(null);
  const [lessonReportDownload, setLessonReportDownload] = useState(false);

  const getData = async () => {
    try {
      const url = config.api.url + "getTrialConfig/lessonReportDownload";
      get(url).then((response) => {
        setLessonReportDownload(response.data.value);
      });
    } catch (error) {
      toast.current.show({
        severity: "error",
        summary: "something want wrong",
        detail: "something want wrong.",
      });
    }
  };

  const handleCheckboxClick = async () => {
    try {
      const data = {
        name: "lessonReportDownload",
        value: !lessonReportDownload,
      };
      const url = config.api.url + "updateTrialConfig";
      post(url, data).then((response) => {
        if (response.status === 201 || response.status === 200) {
          getData();
          toast.current.show({
            severity: "success",
            summary: "TrialConfig has been updated",
            detail: "Success",
          });
        } else {
          toast.current.show({
            severity: "error",
            summary: "something want wrong",
            detail: "something want wrong",
          });
        }
      });
    } catch (error) {
      toast.current.show({
        severity: "error",
        summary: "something want wrong",
        detail: "something want wrong",
      });
    }
  };

  useEffect(() => {
    getData();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Header />
      <Container
        fluid
        style={{
          paddingRight: "1.25rem",
          paddingLeft: "1.25rem",
        }}
      >
        <div className="SiteManagerPage" style={{ borderRadius: "5px" }}>
          <Row className="m-auto settingpage">
            <Col lg={12}>
              <TrialTitle />
            </Col>
            <Col lg={12}>
              <ProtocolVersion />
            </Col>
            <Col lg={12}>
              <DashboardAlert />
            </Col>
            <Col lg={12}>
              <EnableSurvey />
            </Col>
            <Col lg={12}>
              <TrialD />
            </Col>
            <Col lg={12}>
              <hr />
              <h6 className="card-title">Lesson Report Settings</h6>
              <Form id="settingsPageLessonReport">
                <div className="form-check mb-3">
                  <label
                    className="form-check-label"
                    htmlFor="lessonReportSettings"
                  >
                    Full Report / Download Only
                    <span
                      className="pl-2"
                      title="Full Report / Download Only"
                      style={{ fontSize: "1.1rem", fontWeight: "800" }}
                      aria-hidden="true"
                    >
                      <FontAwesomeIcon
                        icon={faCircleQuestion}
                        onClick={handleCheckboxClick}
                      />
                    </span>
                  </label>
                  <div className="list-group-item border-none py-3 col-md-2">
                    <label className="switcher-control switcher-control-success">
                      <input
                        type="checkbox"
                        className="switcher-input switcher-control-success"
                        name="lessonReportSettings"
                        checked={lessonReportDownload}
                        onClick={handleCheckboxClick}
                      />
                      <span className="switcher-indicator"></span>
                    </label>
                  </div>
                </div>
              </Form>
            </Col>
            <Col lg={12}>
              <EnableLesson />
            </Col>
            <Col lg={12}>
              <TrialDSubrole />
            </Col>
            <Col lg={12}>
              <LessonLanguages />
            </Col>
            <Col lg={12}>
              <AssessmentPassingScoreForm />
            </Col>
          </Row>
          <hr />
        </div>
      </Container>
    </div>
  );
};
export default Settings;
