import React, { useRef } from "react";
import { useEffect, useState } from "react";
import { get, post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { Toast } from "primereact/toast";
import { Button, Form, Col, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCircleQuestion } from "@fortawesome/free-solid-svg-icons";

const AssessmentPassingScoreForm = () => {
  const toast = useRef(null);
  const formRef = useRef();
  const [validated, setValidated] = useState(false);
  const [companyPassScore, setCompanyPassScore] = useState("");
  const [group, setgroup] = useState("");
  const [companyScore, setCompanyScore] = useState(false);

  const getCompanyPassScore = async () => {
    try {
      const url = config.api.url + "getTrialConfig/companyPassScore";
      get(url).then((response) => {
        let valueData = response.data;
        setCompanyPassScore(valueData.value);
        setgroup(valueData.group);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getShowCompanyScore = async () => {
    try {
      const url = config.api.url + "getTrialConfig/showAssessmentScore";
      get(url).then((response) => {
        setCompanyScore(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const handleShowCompanyScore = async () => {
    try {
      setCompanyScore(!companyScore);
      const formData = {
        name: "showAssessmentScore",
        value: !companyScore,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getShowCompanyScore();
            toast.current.show({
              severity: "success",
              summary: "Company score toggle has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      console.error("Error making API call:", error);
    }
  };

  useEffect(() => {
    getCompanyPassScore();
    getShowCompanyScore();
  }, []);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = event.currentTarget;
    if (form.checkValidity() === false) {
      setValidated(true);
      event.stopPropagation();
      return;
    }
    try {
      const formData = {
        name: group,
        value: form.companyPassScore.value,
      };
      var url = config.api.url + "updateTrialConfig";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            toast.current.show({
              severity: "success",
              summary: "Assesment passing percentage has been updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something went wrong",
              detail: "something went wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something went wrong",
              detail: "something went wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error while making API call:", error);
    }
  };
  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <hr />
      <Row>
        <Col lg={6}>
          <span className="card-title">Assesment Passing Percentage</span>{" "}
          <p className="px-2">
            Do not change the assessment passing percentage after the trial is
            started
          </p>
          <Form
            id="settingsPageCompanyPassScore"
            className="needs-validation"
            onSubmit={handleSubmit}
            noValidate
            ref={formRef}
            validated={validated}
          >
            <div className="col-sm-12 col-md-2  mb-3 mt-3">
              <Form.Group>
                <Form.Control
                  type="number"
                  className="form-control input-group"
                  name="companyPassScore"
                  rows="4"
                  required
                  value={companyPassScore}
                  onChange={(e) => setCompanyPassScore(e.target.value)}
                />
              </Form.Group>
            </div>

            <div className="form-actions ml-2 mb-4">
              <Button className="btn btn-primary  px-3" type="submit">
                Save
              </Button>
            </div>
          </Form>
        </Col>
        <Col lg={6}>
          <Form id="settingsPageTrialDEnabled">
            <div className="form-check mb-3">
              <label className="form-check-label" htmlFor="enableNavBarItems">
                Show company score and assessment percent
                <span
                  className="pl-2"
                  style={{ fontSize: "1.1rem", fontWeight: "800" }}
                  aria-hidden="true"
                >
                  <FontAwesomeIcon icon={faCircleQuestion} />
                </span>
              </label>
              <div className="list-group-item border-none py-3 col-md-2">
                <label className="switcher-control switcher-control-success">
                  <input
                    type="checkbox"
                    className="switcher-input switcher-control-success"
                    name="enableNavBarItems"
                    checked={companyScore}
                    onClick={handleShowCompanyScore}
                  />
                  <span className="switcher-indicator"></span>
                </label>
              </div>
            </div>
          </Form>
        </Col>
      </Row>
    </div>
  );
};
export default AssessmentPassingScoreForm;
