import React, { useRef } from "react";
import { Button, Card } from "react-bootstrap";
import { Editor, MultiSelect, Checkbox } from "primereact";
import { Dropdown } from "primereact/dropdown";
import { useState } from "react";
import { post } from "../../../utils/HttpRequest";
import config from "../../../config/config.json";
import { useEffect } from "react";
import { InputText } from "primereact/inputtext";
import { useNavigate } from "react-router-dom";
import { Toast } from "primereact/toast";
import "./NewNotificationForm.css";

const NewNotificationForm = (props) => {
  const navigate = useNavigate();
  const toast = useRef(null);
  const { subroleDatafilter, allRoles, getAllNotifications } = props;
  const [selectedvisibility, setSelectedvisibility] = useState(null);
  const [validated, setValidated] = useState(false);

  const formRef = useRef();
  const [text, setText] = useState("");
  const [selectedRoles, setSelectedRoles] = useState([]);
  const [selectedSubRoles, setSelectedSubRoles] = useState([]);

  const Editdata = () => {
    if (props.isEditNotification) {
      formRef.current.notificationtitle.value = props.selectedRow.title;
      const roles = props.selectedRow.roles || [];
      const subroles = props.selectedRow.subroles || [];
      setSelectedSubRoles([...subroles]);
      setSelectedRoles([...roles]);
      setText(props.selectedRow.message);
    } else {
      formRef.current.notificationtitle.value = null;
      setSelectedRoles([]);
      setSelectedSubRoles([]);
      setText(null);
    }
  };

  useEffect(() => {
    Editdata();
  }, [props]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const form = formRef.current;
    if (form.checkValidity() === false) {
      setValidated(true);
      return;
    }
    try {
      let apiEndpoint, payload;
      if (props.isEditNotification) {
        apiEndpoint = config.api.url + "editNotification";
        payload = {
          notificationTitle: form.notificationtitle.value,
          notificationRoles: selectedRoles,
          notificationGroup: props.selectedRow.group,
          notificationSubroles: selectedSubRoles,
          notificationText: text,
        };
      } else {
        payload = {
          notificationTitle: form.notificationtitle.value,
          notificationVisibility: selectedvisibility,
          notificationRoles: selectedRoles,
          notificationSubroles: selectedSubRoles,
          notificationText: text,
        };
        apiEndpoint = config.api.url + "createNotification";
      }
      post(apiEndpoint, payload)
        .then((response) => {
          if (response.status === 200 || response.status === 201) {
            toast.current.show({
              severity: "success",
              summary: "Successfully added",
              detail: "Success",
            });
            setTimeout(() => {
              props.closesetIsFormOpen();
              getAllNotifications();
              navigate("/notificationsettings");
            }, 2000);
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
      setValidated(false);
    } catch (error) {
      console.error("Error fetching lesson data:", error);
    }
  };

  const optionGroups = Object.keys(subroleDatafilter).map((roleGroup) => ({
    label: allRoles.find((item) => item.group === roleGroup).description,
    value: allRoles.find((item) => item.group === roleGroup).group,
    items: [...subroleDatafilter[roleGroup]].map((subrole) => ({
      value: subrole,
      label: subrole,
    })),
  }));

  const options = [
    { name: "Dashboard", value: "dashboard" },
    { name: "Training Record", value: "trainingrecord" },
  ];

  const removeItem = (item) => {
    setSelectedSubRoles(
      [...new Set([...selectedSubRoles])].filter(
        (selectedItem) => selectedItem !== item
      )
    );
    setSelectedRoles(
      [...new Set([...selectedRoles])].filter(
        (selectedItem) => selectedItem !== item
      )
    );
  };

  return (
    <div>
      <Toast ref={toast}></Toast>{" "}
      <div className="page-section">
        <Card style={{ width: "100%" }} className="p-3">
          <div className="d-flex justify-content-between">
            <span className="card-title ">
              {props.isEditNotification
                ? "Edit Notification"
                : "New Notification"}
            </span>
          </div>
          <form
            className="needs-validation"
            onSubmit={handleSubmit}
            ref={formRef}
            validated={validated}
          >
            <div className="mb-3">
              <label htmlFor="notificationtitle">Notification Title</label>
              <InputText
                type="text"
                name="notificationtitle"
                className="w-full p-inputtext-sm forminput"
                required
              />
            </div>

            {!props.isEditNotification && (
              <div className="mb-3">
                <label htmlFor="notificationvisibility">
                  Notification Visibility
                </label>
                <Dropdown
                  value={selectedvisibility}
                  onChange={(e) => setSelectedvisibility(e.value)}
                  options={options}
                  optionLabel="name"
                  optionValue="value"
                  name="notificationvisibility"
                  className="w-full p-inputtext-sm forminput"
                  placeholder="Choose..."
                  required
                />
                {validated && (
                  <div className="invalid-feedback">
                    {" "}
                    Valid role is required.{" "}
                  </div>
                )}
              </div>
            )}

            <div className="mb-3">
              <label htmlFor="Roles">Roles</label>
              <MultiSelect
                value={[...new Set([...selectedRoles, ...selectedSubRoles])]}
                options={optionGroups}
                onChange={(e) => {
                  setSelectedSubRoles([...new Set(e.value)]);
                }}
                optionLabel="label"
                ptionLabel="label"
                optionGroupLabel="label"
                optionGroupChildren="items"
                display="chip"
                selectedItemTemplate={(item) =>
                  item ? (
                    <div className="d-flex flex-wrap">
                      <div className="custom-chip">
                        {item}
                        <i
                          className="pi pi-times custom-chip-remove"
                          onClick={() => removeItem(item)}
                        ></i>
                      </div>
                    </div>
                  ) : null
                }
                optionGroupTemplate={(option) => {
                  return (
                    <div className="flex align-items-center gap-2">
                      <Checkbox
                        onChange={() => {
                          if ([...selectedRoles].includes(option.value)) {
                            setSelectedRoles((pre) =>
                              [...pre].filter((role) => role !== option.value)
                            );
                          } else {
                            setSelectedRoles([...selectedRoles, option.value]);
                          }
                        }}
                        checked={[...selectedRoles].includes(option.value)}
                      />
                      <div>{option.label}</div>
                    </div>
                  );
                }}
                optionValue="value"
                // optionGroupLabel="label"
                placeholder="Choose subroles"
                className="w-full p-inputtext-sm forminput forminputscroll"
                required
              />
            </div>
            <Editor
              value={text}
              onTextChange={(e) => setText(e.htmlValue)}
              style={{ height: "250px" }}
            />
            <div className="py-3">
              <Button className="btn btn-primary px-3" type="submit">
                Save
              </Button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  );
};
export default NewNotificationForm;
