import React, { useEffect } from "react";
import { Card, Col, Container, Row } from "react-bootstrap";
import Header from "../../Header/Header";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencil, faPlus } from "@fortawesome/free-solid-svg-icons";
import config from "../../../config/config.json";
import { get, post } from "../../../utils/HttpRequest";
import { useState } from "react";
import Datatable from "../../Common/Datatable";
import { Toast } from "primereact";
import { useRef } from "react";
import NewNotificationForm from "./NewNotificationForm";

const NotificationSettings = () => {
  const toast = useRef(null);
  const [notifications, setNotifications] = useState([]);
  // console.log(notifications);
  const [searchText, setSearchText] = useState("");
  const searchTextRef = useRef(searchText);
  const [filteredData, setFilteredData] = useState(notifications);
  const [subroleDatafilter, setSubroleDatafilter] = useState([]);
  const [allRoles, setAllRoles] = useState([]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isEditNotification, setIsEditNotification] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);

  const toggleFormVisibility = () => {
    setIsFormOpen(false);
    setIsEditNotification(false);
    setSelectedRow(null);
    setIsFormOpen(true);
  };

  const setEditSiteId = (row) => {
    setIsFormOpen(false);
    setIsEditNotification(true);
    setSelectedRow(row);
    setIsFormOpen(true);
  };

  const handleSearchChange = (e, newData) => {
    const newsearchText = e.target.value.toLowerCase();
    let dataAll = newData ? newData : notifications;
    const filtered = newsearchText
      ? // ? [...dataAll].filter((item) =>
        //     Object.values(item).some((value) => {
        //       return String(value)
        //         .toLowerCase()
        //         .includes(newsearchText.toLowerCase());
        //     })
        //   )
        // : dataAll;

        [...dataAll].filter((item) => {
          // return Object.keys(item).some((key) => {
          //   if (key === "roles" || key === "subroles") {
          //     const rolesAndSubrolesString = (item[key] || [])
          //       .join(" ")
          //       .toLowerCase();
          //     return rolesAndSubrolesString.includes(newsearchText);
          //   } else {
          //     return String(item[key]).toLowerCase().includes(newsearchText);
          //   }
          // });
          return (
            (item.roles && item.roles.includes(newsearchText)) ||
            (item.subroles && item.subroles.includes(newsearchText)) ||
            Object.values(item).some((value) =>
              String(value).toLowerCase().includes(newsearchText)
            )
          );
        })
      : dataAll;
    setFilteredData(filtered);
    searchTextRef.current = newsearchText;
    setSearchText(newsearchText);
  };

  const getAllSubroles = async (roleGroupData) => {
    try {
      const url = config.api.url + "getAllSubroles";
      get(url).then((response) => {
        let roleandsubroles = {};

        roleGroupData.map((role) => {
          roleandsubroles[role.group] = [];
          [...response.data].map((subrole) => {
            if (role.group === subrole.group.split("-")[0]) {
              roleandsubroles[role.group].push(subrole.subrolename);
            }
          });
        });
        setSubroleDatafilter(roleandsubroles);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getAllRoles = async () => {
    try {
      const url = config.api.url + "getAllRoles";
      get(url).then((response) => {
        setAllRoles(response.data);
        getAllSubroles(response.data);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getAllNotifications = async () => {
    try {
      const url = config.api.url + "getAllNotifications";
      get(url).then((response) => {
        response.data.forEach((allNotifications) => {
          allNotifications = allNotifications.group;

          if (allNotifications.status == "active") {
            console.log(allNotifications);
          }
        });
        const responseData = response.data.filter(
          (item) =>
            item?.pageName === "0" ||
            item?.pageName === "1" ||
            item?.pageName === "Dashboard" ||
            item?.pageName === "Trainingrecord" ||
            item.role
        );
        setNotifications(responseData);
        setFilteredData(responseData);
        handleSearchChange(
          {
            target: {
              value: searchTextRef.current ? searchTextRef.current : "",
            },
          },
          [...responseData]
        );
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const updateNotificationStatus = async (row) => {
    try {
      const formData = {
        group: row?.group,
        status: row?.status === "active" ? "inactive" : "active",
      };
      var url = config.api.url + "updateNotificationStatus";
      post(url, formData)
        .then((response) => {
          if (response.status === 201 || response.status === 200) {
            getAllNotifications();
            toast.current.show({
              severity: "success",
              summary: "successfully updated",
              detail: "Success",
            });
          } else {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "Error getting download metadata file.",
            });
          }
        })
        .catch(function (error) {
          if (error.response.status === 400 || error.response.status === 401) {
            toast.current.show({
              severity: "error",
              summary: "something want wrong",
              detail: "something want wrong",
            });
          }
        });
    } catch (error) {
      if (error.message) {
        toast.current.show({
          severity: "error",
          summary: "something want wrong",
          detail: "something want wrong",
        });
      }
    }
  };

  const siteColumn = [
    {
      dataField: "title",
      text: "Notification Title",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "pageName",
      text: "Page Name",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "addedString",
      text: "Date Created",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
    },
    // {
    //   dataField: "roles",
    //   text: "Roles",
    //   sort: true,

    //   // formatter: (cell, row) => {
    //   //   // return (
    //   //   //   <div style={{ textAlign: "center" }}>
    //   //   //     {row.roles && row.roles.length > 0
    //   //   //       ? row.roles?.map((role, index) => <div key={index}>{role}</div>)
    //   //   //       : ""}
    //   //   //   </div>
    //   //   // );
    //   // },
    //   filterValue: (cell) => {
    //     console.log(cell, "cell");
    //     return cell.includes(searchText);
    //   },
    // },
    {
      dataField: "roles",
      text: "Roles",
      sort: true,
      formatter: (cell, row) => {
        // console.log(row);
        if (row.roles && row.roles.length > 0) {
          return (
            <div style={{ textAlign: "center" }}>
              {row.roles.map((role, index) => (
                <div key={index}>{role}</div>
              ))}
            </div>
          );
        } else {
          return "";
        }
      },
      filterValue: (cell) => cell.includes(searchText),
    },
    {
      dataField: "subroles",
      text: "Subroles",
      sort: true,
      filterValue: (cell) => cell.includes(searchText),
      formatter: (cell, row) => {
        return (
          <div className="d-flex flex-column text-center">
            {row.subroles && row.subroles?.map((item) => <span>{item}</span>)}
          </div>
        );
      },
    },
    {
      dataField: "status",
      text: "Status",
      filterValue: (cell) => cell.includes(searchText),
      sort: true,
      formatter: (cell, row) => {
        return (
          <div>
            <span className="d-none"></span>
            <div className="d-flex requiredCheckbox">
              <label
                className={`switcher-control ${
                  row.status === "active" ? "switcher-control-success" : ""
                }`}
              >
                <input
                  type="checkbox"
                  className="switcher-input userStatusCheckBox"
                  name="userStatus"
                  checked={row.status === "active" ? true : false}
                  onChange={() => {
                    setFilteredData((prev) =>
                      prev.map((statusdata) => {
                        if (statusdata.group === row.group) {
                          return {
                            ...statusdata,
                            status:
                              row.status === "active" ? "inactive" : "active",
                          };
                        } else {
                          return statusdata;
                        }
                      })
                    );
                    updateNotificationStatus(row);
                  }}
                />
                <span className="switcher-indicator"></span>
              </label>
            </div>
          </div>
        );
      },
    },
    {
      dataField: "Edit Message ",
      text: "Edit Message ",
      sort: true,
      formatter: (cell, row, index) => {
        return (
          <div className="text-center" key={index}>
            <div
              style={{ cursor: "pointer" }}
              className="btn btn-sm btn-icon btn-secondary "
              onClick={() => {
                setEditSiteId(row);
              }}
            >
              <FontAwesomeIcon className="text-teal" icon={faPencil} />
            </div>
          </div>
        );
      },
      filterValue: (cell) => cell.includes(searchText),
    },
  ];

  useEffect(() => {
    getAllNotifications();
    getAllRoles();
  }, []);

  return (
    <div className="app">
      <Toast ref={toast}></Toast>
      <Container fluid>
        <Header />
        <div className="page-inner ">
          <Row>
            <Col md={7}>
              <div className="page-section">
                <Card style={{ width: "100%" }}>
                  <div className="d-flex justify-content-between">
                    <span className="card-title ">Notification</span>
                    <div className="d-flex align-items-center card-title">
                      <span className="card-title ">Create Notification</span>
                      <span onClick={toggleFormVisibility}>
                        <span className="tile tile-circle tile-md text-white smi-tile-primary">
                          <FontAwesomeIcon icon={faPlus} />
                        </span>
                      </span>
                    </div>
                  </div>
                  <Datatable
                    keyField={"addedEpoch"}
                    data={filteredData}
                    columns={siteColumn}
                    filteredData={filteredData}
                    isActionEnable={false}
                    searchText={searchText}
                    handleSearchChange={handleSearchChange}
                  />
                </Card>
              </div>
            </Col>
            {isFormOpen && (
              <Col md={5}>
                <NewNotificationForm
                  selectedRow={selectedRow}
                  isEditNotification={isEditNotification}
                  subroleDatafilter={subroleDatafilter}
                  allRoles={allRoles}
                  closesetIsFormOpen={() => setIsFormOpen(false)}
                  getAllNotifications={getAllNotifications}
                />
              </Col>
            )}
          </Row>
        </div>
      </Container>
    </div>
  );
};
export default NotificationSettings;
