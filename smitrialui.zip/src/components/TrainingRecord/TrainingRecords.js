import React, { useState, useEffect, useRef } from "react";
import config from "../../config/config.json";
import { useNavigate, useSearchParams } from "react-router-dom";
import { get, post } from "../../utils/HttpRequest";
// import { createAndDownloadBlobFile } from "../../utils/Common";
import Header from "../Header/Header";
import { Toast } from "primereact/toast";
import { Card, Col, Container, Modal, Row } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faAward,
  faCheckCircle,
  faSpinner,
  faTimesCircle,
} from "@fortawesome/free-solid-svg-icons";
import { Chart } from "primereact/chart";
import axios from "axios";

const TrainingRecord = () => {
  const [searchParams] = useSearchParams();
  const urlParams = new URLSearchParams(window.location.search);
  var email = urlParams.get("user");
  var username = urlParams.get("username");
  var lessonid = urlParams.get("lessonid");

  const toast = useRef();

  const [trainingRecordsData, setTrainingRecordsData] = useState([]);
  const [showCompletionColumn, setShowCompletionColumn] = useState(false);

  const [noReqMsg, setNoReqMsg] = useState("");

  const [pieChartData, setPieChartData] = useState({});
  const [pieChartOptions, setPieChartOptions] = useState({});

  const [changeCounter, setChangeCounter] = useState(0);
  const [showLoadingDialog, setShowLoadingDialog] = useState(false);
  const [completionMessage, setCompletionMessage] = useState(
    "Please wait while lesson is marked as Completed"
  );

  const [showNotificationDialog, setShowNotificationDialog] = useState(false);
  const [notificationData, setNotificationData] = useState(null);

  const [showSurveyDialog, setShowSurveyDialog] = useState(false);
  const [lessonDetailsMain, setLessonDetailsMain] = useState(null);
  const [surveyLessonData, setSurveyLessonData] = useState(null);
  const [currentQuestionCounter, setCurrentQuestionCounter] = useState(0);
  const [submittingAnswer, setSubmittingAnswer] = useState(false);
  const [userAnswer, setUserAnswer] = useState(null);
  const [isSurveyCompleted, setIsSurveyCompleted] = useState(false);
  const [loading, setLoading] = useState(false);

  const [companyScore, setCompanyScore] = useState(false);
  const [companyPassScore, setCompanyPassScore] = useState("");

  const navigate = useNavigate();

  window.chartColors = {
    red: "rgb(255, 99, 132)",
    orange: "rgb(255, 159, 64)",
    yellow: "rgb(255, 205, 86)",
    green: "rgb(75, 192, 192)",
    blue: "rgb(54, 162, 235)",
    purple: "rgb(153, 102, 255)",
    grey: "rgb(231,233,237)",
  };

  const getShowCompanyScore = async () => {
    try {
      const url = config.api.url + "getTrialConfig/showAssessmentScore";
      get(url).then((response) => {
        setCompanyScore(response.data.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const getCompanyPassScore = async () => {
    try {
      const url = config.api.url + "getTrialConfig/companyPassScore";
      get(url).then((response) => {
        let valueData = response.data;
        setCompanyPassScore(valueData.value);
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    getShowCompanyScore();
    getCompanyPassScore();
  }, []);

  useEffect(() => {
    let url = config.api.url + "getLessonsCompletionDetailsForMe";
    if (email != null && username != null) {
      url =
        config.api.url +
        "getLessonsCompletionDetailsOneUser/" +
        email.replace(/ /g, "+");
    }
    get(url)
      .then((result) => {
        let trainingRecords = result.data;
        setTrainingRecordsData(trainingRecords);
        if (
          email == undefined ||
          email == null ||
          (localStorage.getItem("userRole") !== "smiadmin" &&
            localStorage.getItem("userRole") !== "monitor" &&
            localStorage.getItem("userRole") !== "cro" &&
            localStorage.getItem("userRole") !== "sponsor" &&
            localStorage.getItem("userRole") !== "admin")
        ) {
          setShowCompletionColumn(false);
        } else {
          setShowCompletionColumn(true);
        }
        // show training record pie chart
        var percentcompletedPieData = 0;
        var percentincompletePieData = 0;
        // var percentNotStartedPieData =0 ;
        var requiredLessonCount = 0;

        trainingRecords.forEach((o) => {
          if (o.status == "completed" && o.lessonRequired == "required") {
            percentcompletedPieData++;
            requiredLessonCount++;
          } else if (
            o.status == "incomplete" &&
            o.lessonRequired == "required"
          ) {
            percentincompletePieData++;
            requiredLessonCount++;
          }
        });
        if (requiredLessonCount > 0) {
          percentcompletedPieData = Math.round(
            (percentcompletedPieData * 100) / requiredLessonCount
          );
          percentincompletePieData = Math.round(
            (percentincompletePieData * 100) / requiredLessonCount
          );
          // percentNotStartedPieData= Math.round((percentNotStartedPieData*100)/requiredLessonCount);
        } else {
          setNoReqMsg("You have no required assignments");
          percentcompletedPieData = 100;
        }
        const data = {
          labels: ["Completed", "Incomplete"],
          datasets: [
            {
              data: [percentcompletedPieData, percentincompletePieData],
              backgroundColor: [
                window.chartColors.green,
                window.chartColors.red,
              ],
              label: "Dataset 1",
            },
          ],
        };
        const options = {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            title: {
              display: false,
              text: "",
            },
            legend: {
              onClick: null,
              display: true,
              position: "bottom",
              labels: {
                fontColor: "rgb(255, 99, 132)",
              },
            },
            tooltip: {
              mode: "index",
              intersect: true,
              callbacks: {
                label: function (tooltipItem) {
                  const label = tooltipItem.label;
                  const percentage =
                    tooltipItem.dataset.data[tooltipItem.dataIndex];
                  return `${label} (%): ${percentage}`;
                },
              },
            },
          },
        };
        setPieChartData(data);
        setPieChartOptions(options);
      })
      .catch((err) => {
        console.log("Error occured fetching training records", err);
      });

    get(config.api.url + "getNotification?location=trainingrecord")
      .then((result) => {
        let notificationData = result.data;
        // let notificationData = {
        //   message: 'Hello there notification',
        //   title: 'Notification',
        //   group: '123'
        // }
        if (notificationData.group) {
          setShowNotificationDialog(true);
          var msg = notificationData.message; //gets the first item of the array
          var title = notificationData.title;
          var notifID = notificationData.group;
          setNotificationData({
            msg: msg,
            title: title,
            notifID: notifID,
          });
        } else {
          console.log("no active notifications for this role or page");
        }
      })
      .catch((err) => {
        console.log("Error occured fetching notification data", err);
      });

    // survey related processing
    let surveyUrl = config.api.url + "getTrialConfig/showSurvey";
    get(surveyUrl)
      .then((result) => {
        let showSurvey = result.data;
        if (lessonid != null && lessonid != "" && showSurvey.value) {
          let showSurveyLessonID = "";
          get(config.api.url + "getTrialConfig/showSurveyLessonID")
            .then((result) => {
              showSurveyLessonID = result.data.value;
              if (!showSurveyLessonID && showSurveyLessonID == "") {
                get(config.api.url + "getLessons").then((result) => {
                  let alllessonds = result.data;
                  let activeSurveyLessons = [];
                  for (let lesson of alllessonds) {
                    if (
                      lesson.status == "active" &&
                      lesson.lessontype == "survey"
                    ) {
                      activeSurveyLessons.push(lesson.lessonid);
                    }
                  }
                  if (activeSurveyLessons && activeSurveyLessons.length > 0) {
                    showSurveyLessonID = activeSurveyLessons[0];
                    post(config.api.url + "updateTrialConfig", {
                      name: "showSurveyLessonID",
                      value: showSurveyLessonID,
                    });
                  }
                });
              }
              if (
                showSurveyLessonID &&
                showSurveyLessonID.value &&
                showSurveyLessonID.value != ""
              ) {
                showSurveyLessonID = showSurveyLessonID.value;
              }
              setShowSurveyDialog(true);
              get(config.api.url + "getLessonDetails/" + lessonid)
                .then((result) => {
                  let lessonTopicDataMain = result.data;
                  setLessonDetailsMain(lessonTopicDataMain);
                  get(
                    config.api.url + "getLessonandTopics/" + showSurveyLessonID
                  )
                    .then((result) => {
                      let lessonTopicData = result.data;
                      setSurveyLessonData(lessonTopicData);
                    })
                    .catch((err) => {
                      console.log("Error getting survey lesson details", err);
                    });
                })
                .catch((err) => {
                  console.log("Error getting lesson details ", err);
                });
            })
            .catch((err) => {
              console.log("Error fetching showSurveyLessonID", err);
            });
        }
      })
      .catch((err) => {
        console.log("Error getting the survey URL", err);
      });
  }, [searchParams, changeCounter]);

  function createAndDownloadBlobFile(body, filename, extension = "txt") {
    const blob = new Blob([body]);
    const fileName = `${filename}.${extension}`;
    if (navigator.msSaveBlob) {
      // IE 10+
      navigator.msSaveBlob(blob, fileName);
    } else {
      const link = document.createElement("a");
      // Browsers that support HTML5 download attribute
      if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", fileName);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  const handleDownloadCertificate = (lessonid) => {
    setLoading(true);
    var url = config.api.url + "createCertificate";
    let data = { lessonid: lessonid };
    const urlParams = new URLSearchParams(window.location.search);
    var userEmail = urlParams.get("user");
    if (userEmail != null) {
      userEmail = userEmail.replace(/ /g, "+");
    }
    if (
      localStorage.getItem("userRole") === "smiadmin" &&
      userEmail !== null &&
      userEmail.length > 6
    ) {
      data = { lessonid: lessonid, email: userEmail };
    }
    post(url, data)
      .then((result) => {
        let certificateData = result.data;
        let fileName =
          "certificate_" +
          certificateData
            .substring(certificateData.lastIndexOf("/") + 1)
            .split(".")[0];
        const s3FetchInstance = axios.create();
        s3FetchInstance
          .get(certificateData, { responseType: "blob" })
          .then((result) => {
            createAndDownloadBlobFile(result.data, fileName, "pdf");
          })
          .catch((err) => {
            console.log("Error fetching certificate file from s3", err);
          })
          .finally(() => {
            setLoading(false);
          });
      })
      .catch((err) => {
        console.log("Error fetching certificate ", err);
        setLoading(false);
      });
  };

  const handleLessonMarking = (lessonid, marking) => {
    setShowLoadingDialog(true);
    let data = JSON.stringify({ lessonid: lessonid });
    const urlParams = new URLSearchParams(window.location.search);
    var userEmail = urlParams.get("user");
    if (userEmail != null) {
      userEmail = userEmail.replace(/ /g, "+");
    }
    if (
      (localStorage.getItem("userRole") === "smiadmin" ||
        localStorage.getItem("userRole") === "monitor" ||
        localStorage.getItem("userRole") === "cro" ||
        localStorage.getItem("userRole") === "sponsor" ||
        localStorage.getItem("userRole") === "admin") &&
      userEmail !== null &&
      userEmail.length > 6
    ) {
      data = { lessonid: lessonid, email: userEmail };
    }
    var url = config.api.url + "markLessonCompleteForUser";
    if (marking === "incomplete") {
      url = url + "?mark=incomplete";
      setCompletionMessage("Please wait while lesson is marked as Incompleted");
    } else {
      setCompletionMessage("Please wait while lesson is marked as Completed");
    }
    post(url, data)
      .then(() => {
        // window.location.reload();
        setChangeCounter(changeCounter + 1);
        if (marking === "incomplete") {
          setCompletionMessage("Lesson marked as incomplete");
        } else {
          setCompletionMessage("Lesson marked as complete");
        }
        setShowLoadingDialog(false);
      })
      .catch((err) => {
        console.log("Error calling markLessonCompletionForUser API ", err);
      });
  };

  const handleAnswerSubmit = () => {
    setSubmittingAnswer(true);
    // calling API here
    // {
    //     "answerbyuser": "Yes",
    //     "lessonid": "S-019",
    //     "survey_for_lesson_id": "RL-010",
    //     "testid": "S-019-s01-01",
    //     "assessmentid": "S-019-s01-01",
    //     "username": "neha+smiadmin@hatchery.com",
    //     "questionid": "1698101489201Did you enjoy the lesson?"
    // }
    let obj = {};
    let currentTopicData = surveyLessonData.topics[currentQuestionCounter];
    obj["answerbyuser"] = userAnswer;
    obj["lessonid"] = currentTopicData.lessonid;
    obj["survey_for_lesson_id"] = lessonid;
    obj["testid"] = currentTopicData.testid;
    obj["assessmentid"] = currentTopicData.testid;
    obj["username"] = localStorage.getItem("email");
    obj["questionid"] = currentTopicData.questionid;
    post(config.api.url + "insertAnswerData", obj)
      .then((result) => {
        console.log("topicDataResponse ", result.data);
        setSubmittingAnswer(false);
        setUserAnswer(null);
        if (currentQuestionCounter + 1 >= surveyLessonData.topics.length) {
          setIsSurveyCompleted(true);
          setTimeout(() => {
            setShowSurveyDialog(false);
            setCurrentQuestionCounter(0);
            setIsSurveyCompleted(false);
          }, 2000);
        } else {
          setCurrentQuestionCounter(currentQuestionCounter + 1);
        }
      })
      .catch((err) => {
        console.log("Error submitting survey answer", err);
      });
  };

  const dismissNotification = () => {
    var url = config.api.url + "dismissNotification";
    post(url, { notificationID: notificationData.notifID })
      .then((result) => {
        console.log("Dismissed the notification ", result.data);
      })
      .catch((err) => {
        console.log("Error dismissing notification ", err);
      });
  };

  return (
    <div className="trainingRecordsPage app" tyle={{ width: "100%" }}>
      {loading && (
        <div
          style={{
            position: "fixed",
            zIndex: "999",
            backgroundColor: "rgb(14 8 8 / 82%)",
            top: "0",
            left: "0",
            right: "0",
            bottom: "0",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <FontAwesomeIcon
            style={{ fontSize: "30px" }}
            className="c-smi-green"
            icon={faSpinner}
            spin
          />
        </div>
      )}
      <Header />
      <Toast ref={toast}></Toast>
      <Container fluid style={{ width: "100%" }} className="page-inner">
        <Row style={{ width: "100%", margin: "auto" }}>
          <Card style={{ width: "100%" }}>
            {trainingRecordsData ? (
              <Card.Body className="bar-chart" style={{ width: "100%" }}>
                <div style={{ display: "flex", flexDirection: "column" }}>
                  <h6 className="card-title float-left ml-2">
                    Training Record
                    {username ? " for " + username : ""}
                  </h6>
                </div>
                <Row style={{ width: "100%" }} className="ml-2 mt-2">
                  <Col xl={6} md={6} lg={6} sm={6}>
                    <div>
                      <table className="table table-responsive">
                        <thead>
                          <tr>
                            <th className="align-middle text-left">
                              {" "}
                              Lesson Name{" "}
                            </th>
                            <th className="align-middle text-left">
                              {" "}
                              Assignment{" "}
                            </th>
                            <th className="align-middle text-left"> Status </th>
                            {companyScore ? (
                              <th className="align-middle text-center">
                                {" "}
                                Assessment score{" "}
                              </th>
                            ) : null}

                            <th className="align-middle text-center otherUser">
                              {" "}
                              Download Certificate
                            </th>
                            {showCompletionColumn ? (
                              <th className="align-middle text-center actionsColumn">
                                {" "}
                                Mark/Unmark completion{" "}
                              </th>
                            ) : (
                              <></>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {trainingRecordsData.map((record) => (
                            <tr key={record.id}>
                              <td className="align-middle text-left">
                                <a
                                  className="d-none d-sm-block d-md-block d-lg-block d-xl-block"
                                  href={`/lessonview?lessonid=${record.id}`}
                                  onClick={(e) => {
                                    e.preventDefault();
                                    navigate(
                                      `/lessonview?lessonid=${record.id}`
                                    );
                                  }}
                                >
                                  {record.name}
                                </a>
                                <a
                                  className="d-block d-sm-none"
                                  href={`lessonviewmobile?lessonid=${record.id}`}
                                >
                                  {record.name}
                                </a>
                              </td>
                              <td>
                                {record.lessonRequired === "required"
                                  ? "Required"
                                  : "Optional"}
                              </td>
                              {record.status === "completed" ? (
                                record.lessontype === "assessment" ? (
                                  record.result === "Pass" ? (
                                    <td>Pass</td>
                                  ) : (
                                    <td>Fail</td>
                                  )
                                ) : (
                                  <td>Completed</td>
                                )
                              ) : (
                                <td>Incomplete</td>
                              )}
                              {companyScore ? (
                                record.percentage &&
                                record.lessontype === "assessment" ? (
                                  <td className="text-center">
                                    {record.percentage}%
                                  </td>
                                ) : (
                                  <td></td>
                                )
                              ) : (
                                ""
                              )}

                              {record.status === "completed" ? (
                                record.result === "Pass" ? (
                                  <td className="text-center">
                                    <div
                                      className="downloadCertificate otherUser btn-xs smi-btn text"
                                      id={record.id}
                                      onClick={(e) => {
                                        e.preventDefault();
                                        handleDownloadCertificate(record.id);
                                      }}
                                    >
                                      <FontAwesomeIcon
                                        icon={faAward}
                                        className="c-smi-green"
                                        title="View Certificate"
                                      />
                                    </div>
                                  </td>
                                ) : (
                                  <td></td>
                                )
                              ) : (
                                <td></td>
                              )}

                              {showCompletionColumn ? (
                                record.status === "completed" ? (
                                  record.result === "Pass" ? (
                                    <td className="text-center actionsColumn">
                                      <a
                                        href="#"
                                        title="Mark Lesson as Incomplete"
                                        onClick={(e) => {
                                          e.preventDefault();
                                          handleLessonMarking(
                                            record.id,
                                            "incomplete"
                                          );
                                        }}
                                      >
                                        <FontAwesomeIcon
                                          icon={faTimesCircle}
                                          id="markLessonInCompleteButton"
                                          style={{ color: "red" }}
                                          data-id={record.id}
                                          aria-hidden="true"
                                        />
                                      </a>
                                    </td>
                                  ) : record.lessontype !== "assessment" ? (
                                    <td className="text-center actionsColumn">
                                      <a
                                        href="#"
                                        title="Mark Lesson as Completed"
                                        onClick={(e) => {
                                          e.preventDefault();
                                          handleLessonMarking(record.id, "");
                                        }}
                                      >
                                        <FontAwesomeIcon
                                          icon={faCheckCircle}
                                          id="markLessonCompleteButton"
                                          style={{ color: "green" }}
                                          data-id={record.id}
                                          aria-hidden="true"
                                        />
                                      </a>
                                    </td>
                                  ) : null
                                ) : record.lessontype !== "assessment" ? (
                                  <td className="text-center actionsColumn">
                                    <a
                                      href="#"
                                      title="Mark Lesson as Completed"
                                      onClick={(e) => {
                                        e.preventDefault();
                                        handleLessonMarking(record.id, "");
                                      }}
                                    >
                                      <FontAwesomeIcon
                                        icon={faCheckCircle}
                                        id="markLessonCompleteButton"
                                        style={{ color: "green" }}
                                        data-id={record.id}
                                        aria-hidden="true"
                                      />
                                    </a>
                                  </td>
                                ) : (
                                  <td></td>
                                )
                              ) : (
                                <></>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </Col>
                  <Col xl={6} md={6} lg={6} sm={6}>
                    <div>
                      <span className="d-flex justify-content-center mb-4">
                        Required Curriculum Completion
                      </span>
                      {noReqMsg !== "" ? (
                        <p
                          id="trainingRecordMessage"
                          className="d-flex justify-content-center small"
                        >
                          {noReqMsg}
                        </p>
                      ) : (
                        <></>
                      )}
                      <Chart
                        type="pie"
                        className="ml-2"
                        data={pieChartData}
                        options={pieChartOptions}
                      />
                    </div>
                  </Col>
                </Row>
                {companyScore && (
                  <div
                    className="ml-2"
                    style={{
                      padding: "10px 20px",
                      fontSize: "16px",
                    }}
                  >
                    Company passing score for assessment is {""}
                    {companyPassScore}%
                  </div>
                )}
              </Card.Body>
            ) : (
              <></>
            )}
          </Card>
        </Row>
      </Container>
      <div>
        <Modal
          show={showLoadingDialog}
          onHide={() => setShowLoadingDialog(false)}
        >
          <Card.Body
            style={{ height: "200px" }}
            className="d-flex justify-content-center align-items-center"
          >
            <Row>
              <Col lg={12}>
                <div className="text-center">
                  <h6 className="card-title">{completionMessage}</h6>
                  <div className="mb-3">
                    {completionMessage.includes("Please wait") ? (
                      <i
                        className="pi pi-spin pi-spinner"
                        style={{ fontSize: "3rem" }}
                      ></i>
                    ) : (
                      <i
                        className="pi pi-check"
                        style={{ fontSize: "3rem", color: "green" }}
                      ></i>
                    )}
                  </div>
                </div>
              </Col>
            </Row>
          </Card.Body>
        </Modal>
      </div>
      <div>
        <Modal
          show={showSurveyDialog}
          onHide={() => setShowSurveyDialog(false)}
        >
          <Modal.Header className="w-100">
            <Modal.Title className="w-100">
              {surveyLessonData &&
                (!isSurveyCompleted ? (
                  <h6 className="modal-title w-100">
                    Please complete this survey for the lesson{" "}
                    {lessonDetailsMain?.lessonname}
                    <span
                      className="float-right"
                      onClick={() => {
                        setShowSurveyDialog(false);
                      }}
                    >
                      <FontAwesomeIcon
                        icon={faTimesCircle}
                        style={{ fontSize: "1.25rem" }}
                      />
                    </span>
                  </h6>
                ) : (
                  <h5 id="SurveyPopupSuccessTitle" className="modal-title">
                    Thank you for completing this survey.
                  </h5>
                ))}
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Card.Body
              style={{ height: "auto", padding: "20px 10px" }}
              className={isSurveyCompleted ? "d-none" : ""}
            >
              <Row>
                <Col lg={12}>
                  {surveyLessonData ? (
                    <div className="">
                      <span>
                        Question {currentQuestionCounter + 1} of{" "}
                        {surveyLessonData?.topics?.length}
                      </span>
                      <div className="text-left mt-2 pt-2 ml-5 pr-5 embed-responsive-item d-block w-100">
                        <h6
                          id="assessmentDataQuestion"
                          className="mt-2"
                          dangerouslySetInnerHTML={{
                            __html:
                              surveyLessonData?.topics[currentQuestionCounter]
                                ?.question,
                          }}
                        />

                        {surveyLessonData?.topics[currentQuestionCounter]
                          ?.questiontype !== undefined &&
                        surveyLessonData?.topics[currentQuestionCounter]
                          ?.questiontype === "text" ? (
                          <div id="SurveyTextAnswer">
                            <textarea
                              className="form-control"
                              onChange={(e) => {
                                setUserAnswer(e.target.value);
                              }}
                              name="answerbyuser"
                              id="surveyTextAnswer"
                              rows="3"
                              cols="50"
                            ></textarea>
                          </div>
                        ) : (
                          Array.from({ length: 10 }).map((value, index) => (
                            <div
                              key={`answer` + index}
                              className={`custom-control custom-radio mt-4 ${
                                surveyLessonData?.topics[
                                  currentQuestionCounter
                                ]["answer" + (index + 1)] !== ""
                                  ? ""
                                  : "d-none"
                              }`}
                              id={`divAssessmentDataAnswer${index + 1}`}
                            >
                              <input
                                className="custom-control-input"
                                id={`a${index + 1}`}
                                onClick={() => {
                                  setUserAnswer(
                                    surveyLessonData?.topics[
                                      currentQuestionCounter
                                    ]["answer" + (index + 1)]
                                  );
                                }}
                                type="radio"
                                name="answerbyuser"
                                value={
                                  surveyLessonData?.topics.length &&
                                  surveyLessonData?.topics[
                                    currentQuestionCounter
                                  ]["answer" + (index + 1)]
                                }
                                required=""
                              />
                              <label
                                id={`assessmentDataAnswer${index + 1}`}
                                className="custom-control-label"
                                htmlFor={`a${index + 1}`}
                              >
                                {surveyLessonData?.topics.length &&
                                  surveyLessonData?.topics[
                                    currentQuestionCounter
                                  ]["answer" + (index + 1)]}
                              </label>
                            </div>
                          ))
                        )}
                        <button
                          id="submitAnswerSurveyPopup"
                          disabled={userAnswer === null || submittingAnswer}
                          className="btn btn-success mt-4"
                          type="submit"
                          onClick={(e) => {
                            e.preventDefault();
                            handleAnswerSubmit();
                          }}
                        >
                          Save Answer
                          {submittingAnswer && (
                            <>
                              &nbsp;
                              <i
                                className="loader pi pi-spinner pi-spin"
                                aria-hidden="true"
                              ></i>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div id="SurveyPopupLoaderBlock">
                      <div className="row">
                        <div className="col pb-5 pt-5 m-5 pr-0 d-flex justify-content-center">
                          <div
                            className="spinner-border"
                            style={{
                              width: "3rem",
                              height: "3rem",
                              color: "green !important",
                            }}
                            role="status"
                          ></div>
                          <h6
                            className="card-title"
                            id="SurveyPopupLoaderBlockMessage"
                          >
                            {" "}
                            Please wait loading Question.
                          </h6>
                        </div>
                      </div>
                    </div>
                  )}
                </Col>
              </Row>
            </Card.Body>
          </Modal.Body>
        </Modal>
      </div>
      <div>
        <Modal
          show={showNotificationDialog}
          onHide={() => setShowNotificationDialog(false)}
        >
          <Modal.Header>
            <Modal.Title>
              <h5 id="notificationModalLabel" className="modal-title">
                {notificationData?.title}
              </h5>
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <span
              id="notificationText"
              dangerouslySetInnerHTML={{
                __html: notificationData?.msg ? notificationData.msg : "",
              }}
            ></span>
          </Modal.Body>
          <Modal.Footer className="float-right">
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                setShowNotificationDialog(false);
              }}
            >
              Close
            </button>
            <button
              id="displayNotificationModalDismiss"
              type="button"
              onClick={() => {
                setShowNotificationDialog(false);
                dismissNotification();
              }}
              className="btn btn-light"
            >
              Dismiss
            </button>
          </Modal.Footer>
        </Modal>
      </div>
    </div>
  );
};
export default TrainingRecord;
