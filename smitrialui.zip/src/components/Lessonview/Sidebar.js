import { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import { faCheckCircle } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import "./Sidebar.css";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";

const Sidebar = (props) => {
  var [topics, setTopics] = useState(null);

  const navigate = useNavigate();
  useEffect(() => {
    setTopics(props.topics);
  }, [props.topics]);
  if (topics !== undefined && topics !== null && props.topicToLoad) {
    return (
      <Card className="scroll" style={{ margin: "0px" }}>
        {props.isLargeLessonView ? (
          <>
            <h5
              className="card-header"
              id="sideBarLessonName"
              title={props.lessonName}
            >
              {props.lessonName}{" "}
              <a
                id="lessonviewPageShare"
                href={`messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessonid}&lessonname=${props.lessonName}#messagePageMessageCard`}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(
                    `/messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessonid}&lessonname=${props.lessonName}#messagePageMessageCard`
                  );
                }}
              >
                <FontAwesomeIcon
                  icon={faEnvelope}
                  style={{ fontSize: "1.25rem" }}
                />
              </a>
            </h5>
          </>
        ) : (
          <></>
        )}
        {/* <div
          className={`pl-5 pr-5 sidebar-border-botton ${
            props.lessondetails.languages &&
            props.lessondetails.languages.length > 1
              ? "d-inline-flex"
              : "d-none"
          }`}
          id="languageSelectDiv"
        >
          <label
            className="mt-2 sidebar-center-content d-inline-flex"
            htmlFor="languageSelect"
          >
            {" "}
            Available languages
          </label>
          <select
            className="custom-select custom-select-sm d-inline-block mt-2 ml-1 mb-2 d-block col-md-5"
            id="languageSelect"
            value={props.selectedLanguage ? props.selectedLanguage : ""}
            onChange={(e) => {
              if (props.languageChangeHandler) {
                props.languageChangeHandler(e.target.value);
              }
            }}
          >
            {props.lessondetails.languages &&
              props.lessondetails.languages?.length > 1 &&
              props.lessondetails.languages.map((value, index) => (
                <option key={value} value={value}>
                  {value}
                </option>
              ))}
          </select>
        </div> */}
        {/* <div className="mt-3 mb-2 d-inline-flex sidebar-border-bottom sidebar-center-content"> */}
        {/* {props.  && <button
            type="button"
            id="lessonComplete"
            onClick={(e) => {
              const url =
                "/acknowledge?lessonid=" + props.lessondetails.lessonid;
              console.log("url: " + url);
              navigate(url);
            }}
            className={`lessonViewLessonComplete  btn btn-primary btn-xs ml-3 ${
              props.ackFlag ? "" : "d-none"
            }`}
          >
            Acknowledge Completion
          </button>} */}
        {/* </div> */}
        {topics.map((topic) => (
          // href={`lessonview?lessonid=${props.lessonid}&topicid=${topic.topic_id}`}
          <a
            onClick={props.onClickTopics}
            key={topic.topic_id}
            id={topic.topic_id}
            className={`list-group-item list-group-item-action smi-list-group-item p-1 border-bottom-1 border-left-0 border-right-0 border-light smi-topic-${topic.topic_id
              } ${topic.topic_id === props.topicToLoad.topic_id
                ? "smi-list-group-item-action-hover text-white"
                : ""
              }`}
          >
            <div className="list-group-item-figure">
              <div className="">
                {topic.topicviewed === "true" ? (
                  <FontAwesomeIcon
                    icon={faCheckCircle}
                    className="c-smi-green pl-3"
                  />
                ) : (
                  <></>
                )}
              </div>
            </div>
            {props && props.isAssessment ? (
              <div
                className="list-group-item-body pr-3 py-3"
                id={topic.topic_id}
              >
                Question {topic.topicorder}{" "}
              </div>
            ) : (
              <div
                className="list-group-item-body pr-3 py-3"
                id={topic.topic_id}
              >
                {topic.topicname}{" "}
              </div>
            )}
          </a>
        ))}
      </Card>
    );
  } else {
    return null;
  }
};
export default Sidebar;
