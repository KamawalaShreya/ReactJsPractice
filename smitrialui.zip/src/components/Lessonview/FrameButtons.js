import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faAngleRight,
  faAngleLeft,
  faAlignJustify,
} from "@fortawesome/free-solid-svg-icons";

export const nextBtn = (props) => {
  let topics = JSON.parse(localStorage.getItem("topics"));
  let currentTopic = localStorage.getItem("topicid");
  let indexOfTopic = topics.findIndex((x) => x.topic_id === currentTopic);
  // console.log('indexOfTopic nextBtn', indexOfTopic)
  if (props.topics.length <= 1 || indexOfTopic === topics.length - 1) {
    return (
      <div className="col-md-1 col-sm-2">
        <div
          className="mt-4 ml-2 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext ml-4 align-items-center align-self-center d-none d-block"
          style={{ visibility: "hidden" }}
        >
          <FontAwesomeIcon icon={faAngleRight} className="fa-4x c-smi-green" />
        </span>
      </div>
    );
  } else {
    return (
      <div className="col-md-1 col-sm-2" onClick={props.clickNextBtnFunc}>
        <div
          className="mt-4 ml-2 align-items-start align-self-start"
          style={{ height: "40%" }}
        ></div>
        <span
          id="topicNext"
          className="lessonViewNext ml-4 align-items-center align-self-center d-none d-block"
          style={{ visibility: "visible" }}
        >
          <FontAwesomeIcon icon={faAngleRight} className="fa-4x c-smi-green" />
        </span>
      </div>
    );
  }
};
export const prevBtn = (props) => {
  let topics = JSON.parse(localStorage.getItem("topics"));
  let currentTopic = localStorage.getItem("topicid");
  let indexOfTopic = topics.findIndex((x) => x.topic_id === currentTopic);
  // console.log('indexOfTopic prevBtn', indexOfTopic)
  if (props.topics.length <= 1 || indexOfTopic === 0) {
    return (
      <div className="col-md-1 col-sm-2">
        <div
          className="mt-2 ml-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        >
          {props.topics.length > 1 && (
            <div
              className="toggle-sidebar"
              onClick={() => {
                if (props.setSideBarToggle) {
                  props.setSideBarToggle(!props.sideBarToggle);
                }
                if (props.setIsLargeLessonView) {
                  props.setIsLargeLessonView(props.isLargeLessonView);
                }
              }}
            >
              <FontAwesomeIcon
                icon={props.sideBarToggle ? faAlignJustify : faAlignJustify}
                className="fa-2x c-smi-green"
                title="Close the Sidebar"
              />
            </div>
          )}
        </div>
        <span
          id="topicNext"
          className="lessonViewNext ml-4 align-items-center align-self-center d-none d-block"
          style={{ visibility: "hidden" }}
        >
          <FontAwesomeIcon icon={faAngleLeft} className="fa-4x c-smi-green" />
        </span>
      </div>
    );
  } else {
    return (
      <div className="col-md-1 col-sm-2">
        <div
          className="mt-2 ml-4 align-items-start align-self-start"
          style={{ height: "40%" }}
        >
          {props.topics.length > 1 && (
            <div
              className="toggle-sidebar"
              onClick={() => {
                if (props.setSideBarToggle) {
                  props.setSideBarToggle(!props.sideBarToggle);
                }
              }}
            >
              <FontAwesomeIcon
                icon={faAlignJustify}
                className="fa-2x c-smi-green"
              />
            </div>
          )}
        </div>
        <span
          id="topicNext"
          onClick={props.clickPrevBtnFunc}
          className="lessonViewNext ml-4 align-items-center align-self-center d-none d-block"
          style={{ visibility: "visible" }}
        >
          <FontAwesomeIcon icon={faAngleLeft} className="fa-4x c-smi-green" />
        </span>
      </div>
    );
  }
};
