import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";
import { useNavigate } from "react-router-dom";

const LessonHeader = (props) => {
  const navigate = useNavigate();

  return (
    <div
      className="card card-fluid d-block m-2"
      id="lessonviewMobilePageLessonList"
    >
      <div className="card-header" style={{ paddingLeft: "26px !important" }}>
        <div className="form-inline">
          <button
            className="hamburger hamburger-squeeze mr-2 sidebarToggleMobile d-none"
            type="button"
            aria-label="toggle menu"
          >
            <span className="hamburger-box">
              {" "}
              <span className="hamburger-inner"></span>
            </span>
          </button>
          <h5 className="mt-2 d-inline-block mr-1 ml-2" id="lessonName">
            {props.lessondetails.lessonname}
          </h5>
          <a
            id="lessonviewPageShare"
            href={`messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessondetails.lessonid}&lessonname=${props.lessondetails.lessonname}#messagePageMessageCard`}
            onClick={(e) => {
              e.preventDefault();
              navigate(
                `/messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${props.lessondetails.lessonid}&lessonname=${props.lessondetails.lessonname}#messagePageMessageCard`
              );
            }}
          >
            <FontAwesomeIcon
              icon={faEnvelope}
              style={{ fontSize: "1.25rem" }}
            />
          </a>
          <div
            className={`pl-5 pr-5 custom-control-inline  ${props.lessondetails.languages &&
              props.lessondetails.languages.length > 1
              ? "d-inline-flex"
              : "d-none"
              }`}
            id="languageSelectDiv"
          >
            <label className="" htmlFor="languageSelect">
              {" "}
              Available languages
            </label>
            <select
              className="custom-select custom-select-sm d-inline-block mt-2 ml-1 mb-2 d-block col-md-5"
              id="languageSelect"
              value={props.selectedLanguage ? props.selectedLanguage : ""}
              onChange={(e) => {
                if (props.languageChangeHandler) {
                  props.languageChangeHandler(e.target.value);
                }
              }}
            >
              {props.lessondetails.languages &&
                props.lessondetails.languages?.length > 1 &&
                props.lessondetails.languages.map((value) => (
                  <option key={value} value={value}>
                    {value}
                  </option>
                ))}
            </select>
          </div>
          <button
            type="button"
            id="retakeAssessment"
            onClick={() => {
              if (props.retakeHandler) {
                props.retakeHandler();
              }
            }}
            className={`lessonViewLessonComplete btn btn-primary btn-xs  ml-3 ${props.retakeFlag ? "" : "d-none"
              }`}
            data-toggle="modal"
            data-target="#retakeAssessmentModel"
          >
            Retake Assessment
          </button>

          <button
            type="button"
            id="lessonComplete"
            onClick={() => {
              const url =
                "/acknowledge?lessonid=" + props.lessondetails.lessonid;
              navigate(url);
            }}
            className={`lessonViewLessonComplete  btn btn-primary btn-xs ml-3 ${props.ackFlag ? "" : "d-none"
              }`}
          >
            Acknowledge Completion
          </button>
        </div>
      </div>
    </div>
  );
};
export default LessonHeader;
