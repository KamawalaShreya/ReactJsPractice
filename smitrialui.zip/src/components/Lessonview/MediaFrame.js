import React, { useState } from "react";
import { Player } from "video-react";
import { Card } from "react-bootstrap";
import "video-react/dist/video-react.css";
import config from "../../config/config.json";
import { nextBtn, prevBtn } from "./FrameButtons";
import { Button } from "primereact/button";
import { post } from "../../utils/HttpRequest";
import { useEffect } from "react";
import { Dialog } from "primereact/dialog";
import "./Sidebar.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faAlignJustify } from "@fortawesome/free-solid-svg-icons";
import EditorComponent from "./EditorComponent";

const MediaFrame = (props) => {
  const [selectedValue, setSelectedValue] = useState(null);
  const [topicToLoad, setTopicToLoad] = useState(null);
  const [url, setUrl] = useState(null);
  const [iframeStyle, setIframeStyle] = useState(null);
  const [iframeStyleImage, setIframeStyleImage] = useState(null);
  const [isSubmittingAnswer, setIsSubmittingAnswer] = useState(false);
  const [visible, setVisible] = useState(false);

  const search = window.location.search;
  const params = new URLSearchParams(search);

  const lessonid = params.get("lessonid");



  useEffect(() => {
    setTopicToLoad(props.topicToLoad);

    if (props.topicToLoad) {
      if (props.selectedLanguage && props.selectedLanguage !== "English") {
        setUrl(
          config.content.url +
          props.lessonid +
          "/" +
          props.selectedLanguage +
          "/" +
          props.topicToLoad.topic_id +
          "/" +
          props.topicToLoad.topicmedia
        );
      } else {
        setUrl(
          config.content.url +
          props.lessonid +
          "/" +
          props.topicToLoad.topic_id +
          "/" +
          props.topicToLoad.topicmedia
        );
      }
    }
    setIframeStyle({
      // width: "-webkit-fill-available", // Commented because it was not wokring on Mozilla Firefox
      width: "100%",
      height: "71vh",
    });
    setIframeStyleImage({
      // width: "-webkit-fill-available", // Commented because it was not wokring on Mozilla Firefox
      width: "100%",
      height: "71vh",
      alignItems: "center",
    });
    setIsSubmittingAnswer(false);
  }, [props.topicToLoad]);

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
  };

  const handleAnswerSubmittion = () => {
    let obj = {};
    obj["answerbyuser"] = topicToLoad['questiontype'] == 'text' ? selectedValue : topicToLoad[selectedValue];
    obj["lessonid"] = topicToLoad.lessonid;
    obj["testid"] = topicToLoad.testid;
    obj["assessmentid"] = topicToLoad.testid;
    obj["username"] = localStorage.getItem("email");
    obj["questionid"] = topicToLoad.questionid;
    setIsSubmittingAnswer(true);
    if (props.clickNextBtnFunc) {
      let url = config.api.url + "insertAnswerData";
      post(url, JSON.stringify(obj))
        .then((result) => {
          let topicData = result.data;
          props.clickNextBtnFunc();
          setSelectedValue("");
        })
        .catch((err) => {
          console.log("err ", err);
        });
      setSelectedValue("");
    }
  };

  if (props && props.isAssessment && topicToLoad) {
    return (
      <div
        className={`topicViewer`}
        style={{
          height: props.retakeFlag ? "100%" : "100%",
          // display: props.retakeFlag ? "flex" : "",
          // justifyContent: props.retakeFlag ? "center" : "",
          // alignItems: props.retakeFlag ? "center" : "",
        }}
      >
        {!props.retakeFlag ? (
          <Card style={{ border: "none", boxShadow: "none" }}>
            {/* <div
              style={{
                alignItems: "center",
                backgroundColor: "#eeeeee",
                borderBottom: "1px solid rgba(0, 0, 0, 0.1)",
                display: "flex",
                padding: "4px",
              }}
            ></div> */}
            <div className="row">
              <div className="col-md-1 col-sm-2">
                <div
                  className="mt-2 ml-4 align-items-start align-self-start"
                  style={{ height: "40%" }}
                >
                  {props.topics.length > 1 && (
                    <div
                      className="toggle-sidebar"
                      onClick={() => {
                        if (props.setSideBarToggle) {
                          props.setSideBarToggle(!props.sideBarToggle);
                        }
                        if (props.setIsLargeLessonView) {
                          props.setIsLargeLessonView(props.isLargeLessonView);
                        }
                      }}
                    >
                      <FontAwesomeIcon
                        icon={
                          props.sideBarToggle ? faAlignJustify : faAlignJustify
                        }
                        className="fa-2x c-smi-green"
                        title="Close the Sidebar"
                      />
                    </div>
                  )}
                </div>
              </div>
              <div className="col-md-10 col-sm-8 ">
                <div
                  id="assessmentData"
                  className=" text-left pt-2 ml-5 pr-5 embed-responsive-item"
                >
                  <EditorComponent value={topicToLoad["question"]} />
                  {topicToLoad["questiontype"] === "text" && (
                    <div id="SurveyTextAnswer">
                      <textarea
                        className="form-control"
                        name="answerbyuser"
                        id="surveyTextAnswer"
                        onChange={handleChange}
                        value={selectedValue}
                        rows="3"
                        cols="50"
                      ></textarea>
                    </div>
                  )}
                  {topicToLoad["questiontype"] === "Multiplechoice" &&
                    Array.from({ length: 10 }).map((_, index) => (
                      <div
                        className={`custom-control custom-radio mt-4 ${topicToLoad[`answer${index + 1}`] !== ""
                            ? ""
                            : "d-none"
                          }`}
                        key={`divAssessmentDataAnswer${index + 1}`}
                      >
                        <input
                          className="custom-control-input"
                          id={`a${index + 1}`}
                          type="radio"
                          value={`answer${index + 1}`}
                          onChange={handleChange}
                          checked={selectedValue === `answer${index + 1}`}
                          name="answerbyuser"
                          required=""
                        />
                        <label
                          className="custom-control-label"
                          htmlFor={`a${index + 1}`}
                          id={`assessmentDataAnswer${index + 1}`}
                        >
                          {topicToLoad[`answer${index + 1}`]}
                        </label>
                      </div>
                    ))}
                  <Button
                    label={`Save Answer`}
                    style={{ background: "#0f7439", textAlign: "left" }}
                    disabled={!selectedValue}
                    icon={isSubmittingAnswer ? "pi pi-spinner pi-spin" : ""}
                    onClick={() => {
                      handleAnswerSubmittion();
                    }}
                    className={`btn btn-success ${!selectedValue ? "disabled" : ""
                      } mt-4 mb-4`}
                  />
                </div>
              </div>
            </div>
          </Card>
        ) : (
          <>
            <div className="row">
              <div className="col-md-1 col-sm-2">
                <div
                  className="mt-2 ml-4 align-items-start align-self-start"
                  style={{ height: "40%" }}
                >
                  {props.topics.length > 1 && (
                    <div
                      className="toggle-sidebar"
                      onClick={() => {
                        if (props.setSideBarToggle) {
                          props.setSideBarToggle(!props.sideBarToggle);
                        }
                        if (props.setIsLargeLessonView) {
                          props.setIsLargeLessonView(props.isLargeLessonView);
                        }
                      }}
                    >
                      <FontAwesomeIcon
                        icon={
                          props.sideBarToggle ? faAlignJustify : faAlignJustify
                        }
                        className="fa-2x c-smi-green"
                        title="Close the Sidebar"
                      />
                    </div>
                  )}
                </div>
              </div>
              <div
                className="col-md-10 col-sm-8"
                style={{
                  display: "flex",
                  justifyContent: "center",
                  position: "absolute",
                  top: "50%",
                  right: "5%",
                }}
              >
                <div>
                  <button
                    type="button"
                    id="retakeAssessment"
                    onClick={() => setVisible(true)}
                    className={`lessonViewLessonComplete btn btn-primary btn-xs mb-3 `}
                    data-toggle="modal"
                    data-target="#retakeAssessmentModel"
                  >
                    Retake Assessment
                  </button>
                </div>
                <Dialog
                  style={{ maxWidth: "500px" }}
                  header=" Are you sure? "
                  position="top"
                  visible={visible}
                  onHide={() => setVisible(false)}
                  draggable={false}
                  resizable={false}
                  dismissableMask={true}
                  // style={{ width: "50vw" }}
                  breakpoints={{ "960px": "75vw", "641px": "100vw" }}
                >
                  <div className="modal-body">
                    <p>
                      {" "}
                      Please note, choosing to retake the assessment will erase
                      your prior training record for this lesson. Are you sure
                      you wish to proceed?{" "}
                    </p>
                  </div>
                  <div className="modal-footer p-0">
                    <button
                      type="button"
                      className="btn btn-primary"
                      data-dismiss="modal"
                      onClick={() => setVisible(false)}
                    >
                      Cancel
                    </button>{" "}
                    <button
                      id="retakeAssessmentSure"
                      type="button"
                      className="btn btn-light"
                      onClick={props.handleRetakeAction}
                    >
                      <span
                        className={`pi pi-spinner pi-spin mr-1 ${props.isRetakeClicked ? "" : "d-none"
                          }`}
                      ></span>
                      Retake Assessment
                    </button>
                  </div>
                </Dialog>
              </div>
            </div>
          </>
        )}
      </div>
    );
  } else if (topicToLoad && topicToLoad.topicmedia?.includes(".mp4")) {
    return (
      <Card className="topicViewer">
        <div className="row">
          {prevBtn(props)}
          <div className="col-md-10 col-sm-8 ">
            <Player key={url} autoPlay playsInline>
              <source src={url} />
            </Player>
          </div>
          {nextBtn(props)}
        </div>
      </Card>
    );
  } else if (
    topicToLoad &&
    topicToLoad.topicmedia &&
    topicToLoad.topicmedia?.toLowerCase()?.includes(".pdf")
  ) {
    var topicURL =
      "https://mozilla.github.io/pdf.js/web/viewer.html?file=" + url;
    return (
      <div className="topicViewer">
        <div className="row">
          {prevBtn(props)}
          <div className="col-md-10 col-sm-8 ">
            <Card style={iframeStyle}>
              <iframe
                className="embed-responsive-item"
                id="topicIframe"
                style={iframeStyle}
                src={topicURL}
                title="pdf_frame"
              // frameBorder="0"
              ></iframe>
            </Card>
          </div>
          {nextBtn(props)}
        </div>
      </div>
    );
  } else if (
    topicToLoad &&
    topicToLoad.topicmedia &&
    topicToLoad.topicmedia.toLowerCase()?.includes(".html")
  ) {
    return (
      <div className="topicViewer">
        <div className="row">
          {prevBtn(props)}
          <div className="col-md-10 col-sm-8 ">
            <div style={iframeStyle}>
              <iframe
                className="embed-responsive-item"
                id="topicIframe"
                src={url}
                style={iframeStyle}
                title="html_frame"
                frameBorder="0"
              ></iframe>
            </div>
          </div>
          {nextBtn(props)}
        </div>
      </div>
    );
  } else if (
    topicToLoad &&
    topicToLoad.topicmedia &&
    (topicToLoad.topicmedia.toLowerCase()?.includes(".png") ||
      topicToLoad.topicmedia.toLowerCase()?.includes(".jpg"))
  ) {
    return (
      <div className="topicViewer">
        <div className="row">
          {prevBtn(props)}
          <div className="col-md-10 col-sm-8 ">
            <div style={iframeStyleImage}>
              <img
                className=""
                title="image_frame"
                style={{ maxWidth: "100%", maxHeight: "100%" }}
                alt="image_frame"
                src={url}
              ></img>
            </div>
          </div>
          {nextBtn(props)}
        </div>
      </div>
    );
  }
};

export default MediaFrame;
