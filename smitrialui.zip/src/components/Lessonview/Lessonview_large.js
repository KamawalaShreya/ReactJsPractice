import React, { useState, useEffect } from "react";
import { get, post } from "../../utils/HttpRequest";
import config from "../../config/config.json";
import Header from "../Header/Header";
import { Row, Col, Container, Card } from "react-bootstrap";
import MediaFrame from "./MediaFrame";
import Sidebar from "./Sidebar";
// import LessonHeader from "./LessonHeader";
import { Dialog } from "primereact/dialog";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEnvelope } from "@fortawesome/free-solid-svg-icons";

const LessonviewLarge = () => {
  const search = window.location.search;
  const params = new URLSearchParams(search);
  const lessonid = params.get("lessonid");

  const navigate = useNavigate();
  var topicid = params.get("topicid");
  var [selectedLanguage, setSelectedLanguage] = useState(
    params.get("language")
  );
  var [lessonData, setlessonData] = useState(null);

  var [topicToLoad, settopicToLoad] = useState(null);
  // var [lessonurl, setlessonurl] = useState(null);
  var [isAssessment, setIsAssessment] = useState(false);
  var [notTopicsDialogVisible, setNoTopicsDialogVisible] = useState(false);
  var [otherRoleReviewFlag, setOtherRoleReviewFlag] = useState(false);
  var [retakeFlag, setRetakeFlag] = useState(false);
  var [ackFlag, setAckFlag] = useState(false);
  var [retakeDialogVisible, setRetakeDialogVisible] = useState(false);
  var [sideBarToggle, setSideBarToggle] = useState(true);
  // var [isRetakeClicked, setIsRetakeClicked] = useState(false);
  var [isLargeLessonView, setIsLargeLessonView] = useState(true);
  var [searchDashboardData, setSearchDashboardData] = useState([]);

  var [isRetakeClicked, setIsRetakeClicked] = useState(false);

  var [hideNavbar] = useState(true);

  var parentids = params.get("parentids");
  var parentNames = params.get("parentNames");
  var [parentLessonNames, setparentLessonNames] = useState([]);
  var [parentLessonIds, setparentLessonIds] = useState([]);

  const loadLessondata = (lessonurl) => {
    localStorage.removeItem("lessonid");
    localStorage.removeItem("topicid");

    get(config.api.url + "getSearchTerms").then((result) => {
      setSearchDashboardData(result.data.dashboard);
    });

    post(lessonurl).then(async (response) => {
      const lesson = response.data.getLessonandTopicsFuncResponse;

      let topicToPass = null;
      // var topicViewedCounts = {};
      if (
        localStorage.getItem("userRole") != null &&
        `${localStorage.getItem("userRole")}`.toLowerCase() == "cro"
      ) {
        let url = config.api.url + "getTrialConfig/croLessonReview";
        await get(url)
          .then((result) => {
            let sponsorLessonReview = result.data;
            if (sponsorLessonReview.value == true) {
              // hide review tile from topmenubar
              setOtherRoleReviewFlag(true);
            }
          })
          .catch((err) => {
            console.log("Error getting croLessonReview data.", err);
          });
      } else if (
        localStorage.getItem("userRole") != null &&
        `${localStorage.getItem("userRole")}`.toLowerCase() == "sponsor"
      ) {
        let url = config.api.url + "getTrialConfig/sponsorLessonReview";
        await get(url)
          .then((result) => {
            let sponsorLessonReview = result.data;
            if (sponsorLessonReview.value == true) {
              // hide review tile from topmenubar
              setOtherRoleReviewFlag(true);
            }
          })
          .catch((err) => {
            console.log("Error getting sponsorLessonReview data.", err);
          });
      }

      if (
        lesson.lessondetails.status === "active" ||
        otherRoleReviewFlag ||
        (localStorage.getItem("userRole") != null &&
          `${localStorage.getItem("userRole")}`.toLowerCase() === "smiadmin")
      ) {
        if (lesson && lesson.topics && lesson.topics.length === 0) {
          setNoTopicsDialogVisible(true);
          setlessonData(lesson);
        } else {
          if (lesson.topics.length > 0) {
            let tempTopic = lesson.topics.find(
              (t) =>
                t.topic_id ===
                response.data.getTopicDetailsFuncResponse.topic_id
            );
            topicToPass = response.data.getTopicDetailsFuncResponse;
            if (tempTopic && tempTopic["topicfolder"]) {
              topicToPass["topicfolder"] = tempTopic["topicfolder"];
            }
            localStorage.setItem("topicid", topicToPass.topic_id);
            setNoTopicsDialogVisible(false);
          } else {
            setNoTopicsDialogVisible(true);
          }
          if (
            !selectedLanguage &&
            localStorage.getItem("userLanguage") &&
            topicToPass.language
          ) {
            let topicLanguage = topicToPass.language
              .split(",")
              .map((x) => x.trim());
            if (
              topicLanguage.indexOf(localStorage.getItem("userLanguage")) !=
              -1 &&
              localStorage.getItem("userLanguage") != "English"
            ) {
              setSelectedLanguage(localStorage.getItem("userLanguage"));
            } else {
              setSelectedLanguage("English");
            }
          } else {
            let topicLanguage = topicToPass?.language
              ?.split(",")
              .map((x) => x.trim());
            if (
              selectedLanguage !== "" &&
              topicLanguage &&
              topicLanguage.indexOf(selectedLanguage) != -1 &&
              selectedLanguage !== "English"
            ) {
              setSelectedLanguage(selectedLanguage);
            } else {
              setSelectedLanguage("English");
            }
          }
          localStorage.setItem("prevLanguage", selectedLanguage);
          let topicViewedCounts = {};

          let viewedLessonData =
            response.data.getTopicsViewedByUserFuncResponse;

          if (
            response.data.getTopicsViewedByUserFuncResponse &&
            viewedLessonData.topics &&
            viewedLessonData.topics.length > 0
          ) {
            viewedLessonData.topics.forEach((value) => {
              topicViewedCounts[value.topicviewed] =
                (topicViewedCounts[value.topicviewed] || 0) + 1;
              if (selectedLanguage) {
                value.selectedLanguage = selectedLanguage;
              }
            });
          }
          if (!topicViewedCounts.false) {
            if (
              topicToPass &&
              viewedLessonData.lessondetails.lessontype === "assessment"
            ) {
              setIsAssessment(true);
              if (viewedLessonData.lessondetails.lessonComplete == "true") {
                // show retake button / UI from here
                setRetakeFlag(true);
              } else if (
                viewedLessonData.lessondetails.lessonComplete == "false"
              ) {
                let url =
                  "/acknowledge?lessonid=" +
                  viewedLessonData.lessondetails.lessonid;
                if (selectedLanguage && selectedLanguage !== "") {
                  url = url + "&language=" + selectedLanguage;
                }

                navigate(url);
              }
            } else if (viewedLessonData.lessondetails.status == "review") {
              // hide acknowledge button in topmenu bar
              setAckFlag(false);
            } else if (
              viewedLessonData.lessondetails.lessonComplete == "false" &&
              viewedLessonData.lessondetails.acknowledgementRequired &&
              viewedLessonData.lessondetails.acknowledgementRequired != "no"
            ) {
              // show acknowledge button in topmenu bar
              setAckFlag(true);
            }
          } else {
            if (
              topicToPass &&
              lesson.lessondetails.lessontype === "assessment"
            ) {
              setIsAssessment(true);
              let obj = [];
              Object.keys(topicToPass).map((key) => {
                if (key.includes("answer") && key !== "answer") {
                  obj.push({ key: key, value: topicToPass[key] });
                }
              });
              topicToPass["answersToLoad"] = obj;
            }
          }
          if (
            viewedLessonData.lessondetails?.lessonlanguages &&
            viewedLessonData.lessondetails?.lessonlanguages.includes(",")
          ) {
            viewedLessonData.lessondetails["languages"] =
              viewedLessonData.lessondetails.lessonlanguages
                .split(",")
                .map((x) => x.trim());
          }
          settopicToLoad(topicToPass);
          localStorage.setItem("topics", JSON.stringify(lesson.topics));
          localStorage.setItem("lessonid", lessonid);
          setlessonData(viewedLessonData);
        }
      }
    });
  };

  useEffect(() => {
    if (parentNames !== null && parentids !== null) {
      setparentLessonNames(
        parentNames
          .split("|")
          .filter((n) => n)
          .slice(0, -1)
      );
      setparentLessonIds(
        parentids
          .split("|")
          .filter((n) => n)
          .slice(0, -1)
      );
    } else {
      setparentLessonNames([]);
      setparentLessonIds([]);
    }
    let lesson_url =
      config.api.url + "getLessonViewDetails?lessonid=" + lessonid;
    if (topicid !== null && topicid !== "") {
      lesson_url = lesson_url + "&topicid=" + topicid;
    }
    lesson_url = lesson_url + "&limit=5";
    // setlessonurl(lesson_url);
    loadLessondata(lesson_url, topicid);
  }, [topicid]);

  const onClickTopics = (event) => {
    let topicid = event.target.id;
    navigate({
      pathname: window.location.pathname,
      search: `?lessonid=${lessonid}&topicid=${topicid}`,
      replace: true,
    });
    loadLessondata(
      config.api.url +
      "getLessonViewDetails?lessonid=" +
      lessonid +
      "&topicid=" +
      topicid +
      "&limit=5",
      topicid
    );
  };

  // Functions to handle next and previous clicks
  const clickNextBtnFunc = () => {
    let topics = JSON.parse(localStorage.getItem("topics"));
    let currentTopic = localStorage.getItem("topicid");
    let indexOfTopic = topics.findIndex((x) => x.topic_id == currentTopic);
    if (
      indexOfTopic != null &&
      indexOfTopic != null &&
      indexOfTopic + 1 >= topics.length - 1
    ) {
      if (
        lessonData?.lessondetails?.lessontype === "regularlesson" &&
        lessonData?.lessondetails?.status === "active"
      ) {
        setAckFlag(true);
      }
    }
    if (
      indexOfTopic != null &&
      indexOfTopic != null &&
      indexOfTopic < topics.length - 1
    ) {
      let topicid = topics[indexOfTopic + 1].topic_id;
      loadLessondata(
        config.api.url +
        "getLessonViewDetails?lessonid=" +
        lessonid +
        "&topicid=" +
        topicid +
        "&limit=5",
        topicid
      );
    }
    if (
      indexOfTopic != null &&
      indexOfTopic != null &&
      indexOfTopic === topics.length - 1
    ) {
      // redirect to acknowledgement page, or show ack not allowed based on review flag
      let topicid = topics[indexOfTopic].topic_id;
      loadLessondata(
        config.api.url +
        "getLessonViewDetails?lessonid=" +
        lessonid +
        "&topicid=" +
        topicid +
        "&limit=5",
        topicid
      );
    }
  };

  const clickPrevBtnFunc = () => {
    let topics = JSON.parse(localStorage.getItem("topics"));
    let currentTopic = localStorage.getItem("topicid");
    let indexOfTopic = topics.findIndex((x) => x.topic_id == currentTopic);
    if (indexOfTopic != null && indexOfTopic != null && indexOfTopic >= 1) {
      let topicid = topics[indexOfTopic - 1].topic_id;
      loadLessondata(
        config.api.url +
        "getLessonViewDetails?lessonid=" +
        lessonid +
        "&topicid=" +
        topicid +
        "&limit=5",
        topicid
      );
    }
  };

  const handleRetakeAction = () => {
    var url = config.api.url + "retakeAssessmentForMe";
    const lessonid = lessonData.lessondetails.lessonid;
    setIsRetakeClicked(true);
    post(url, JSON.stringify({ lessonid: lessonid }))
      .then(() => {
        // let userData = result.data;
        let urlToRedirect = "";

        if (window.location.pathname.includes("lessonviewassessmentmobile")) {
          urlToRedirect = "/lessonviewassessmentmobile?lessonid=" + lessonid;
        } else {
          urlToRedirect = "/lessonview?lessonid=" + lessonid;
        }
        window.location.href = urlToRedirect;
        // navigate(urlToRedirect)
      })
      .catch((err) => {
        console.log("Error in retake assessment api call", err);
      });
  };

  const handleLanguageChange = (language) => {
    let urlToRedirect = "";
    if (window.location.pathname.includes("lessonviewassessmentmobile")) {
      urlToRedirect =
        "/lessonviewassessmentmobile?lessonid=" +
        lessonid +
        "&language=" +
        language;
    } else {
      urlToRedirect =
        "/lessonview?lessonid=" + lessonid + "&language=" + language;
    }
    window.location.href = urlToRedirect;
  };

  if (lessonData !== null && lessonData !== undefined) {
    return (
      <div className="lessonviewPage app" style={{ overflowX: "hidden" }}>
        {/* pass `isLargeLessonView` instead of true to get the header disappear in realtime when clicking hamburger icon */}
        <Header
          isLargeLessonView={isLargeLessonView}
          searchDashboardData={searchDashboardData}
          hideNavbar={hideNavbar}
        />

        {/* <LessonHeader
          lessondetails={lessonData.lessondetails}
          retakeFlag={retakeFlag}
          ackFlag={ackFlag}
          selectedLanguage={selectedLanguage}
          retakeHandler={(e) => {
            setRetakeDialogVisible(true);
          }}
          languageChangeHandler={(language) => {
            handleLanguageChange(language);
          }}
        /> */}
        <nav
          aria-label="breadcrumb"
          id="nestedlessonBreadcrumb"
          className={`pl-4 mr-2 mb-0 pb-0  ${!isLargeLessonView ? "mt-3" : "m-0"
            }`}
        >
          <ol
            className="breadcrumb breadcrumb-no-gutter"
            style={{ alignItems: "center" }}
          >
            <li className="breadcrumb-item">
              <a
                className="breadcrumb-link"
                href="dashboard"
                onClick={(e) => {
                  e.preventDefault();
                  navigate(`/dashboard`);
                }}
              >
                Home
              </a>
            </li>
            {parentLessonNames.length > 0
              ? parentLessonNames.map((parentName, j) => (
                <li className="breadcrumb-item" key={parentName}>
                  <a
                    className="breadcrumb-link"
                    href={`dashboard?lessonid=${parentLessonIds[j]
                      }&parentids=${parentLessonIds
                        .slice(0, j + 1)
                        .join("|")}&parentNames=${parentLessonNames
                          .slice(0, j + 1)
                          .join("|")}`}
                    onClick={(e) => {
                      e.preventDefault();
                      navigate(
                        `/dashboard?lessonid=${parentLessonIds[j]
                        }&parentids=${parentLessonIds
                          .slice(0, j + 1)
                          .join("|")}&parentNames=${parentLessonNames
                            .slice(0, j + 1)
                            .join("|")}`
                      );
                    }}
                  >
                    {parentLessonNames[j]}
                  </a>
                </li>
              ))
              : // <li className="breadcrumb-item" >
              //   <a
              //     className="breadcrumb-link"
              //     >
              //       {lessonData.lessondetails.lessonname}
              //   </a>
              // </li>
              null}

            <li>
              <h5
                style={{ border: "none" }}
                className="card-header"
                id="sideBarLessonName"
                title={lessonData.lessondetails.lessonname}
              >
                {lessonData.lessondetails.lessonname}{" "}
                <a
                  id="lessonviewPageShare"
                  href={`messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${lessonData.lessondetails.lessonid}&lessonname=${lessonData.lessondetails.lessonname}#messagePageMessageCard`}
                  onClick={(e) => {
                    e.preventDefault();
                    navigate(
                      `/messages?newmessage=yes&lessonlink=${window.location}/lessonview?lessonid=${lessonData.lessondetails.lessonid}&lessonname=${lessonData.lessondetails.lessonname}#messagePageMessageCard`
                    );
                  }}
                >
                  <FontAwesomeIcon
                    icon={faEnvelope}
                    style={{ fontSize: "1.25rem" }}
                  />
                </a>
              </h5>
            </li>
            <li>
              <div
                className={`pl-5 pr-5 ${lessonData.lessondetails.languages &&
                  lessonData.lessondetails.languages.length > 1
                  ? "d-inline-flex"
                  : "d-none"
                  }`}
                id="languageSelectDiv"
              >
                <label
                  className="mt-2 sidebar-center-content d-inline-flex"
                  htmlFor="languageSelect"
                >
                  {" "}
                  Available languages
                </label>
                <select
                  className="custom-select custom-select-sm d-inline-block mt-2 ml-1 mb-2 d-block col-md-5"
                  id="languageSelect"
                  value={selectedLanguage ? selectedLanguage : ""}
                  onChange={(e) => {
                    handleLanguageChange(e.target.value);
                  }}
                >
                  {lessonData.lessondetails.languages &&
                    lessonData.lessondetails.languages?.length > 1 &&
                    lessonData.lessondetails.languages.map((value) => (
                      <option key={value} value={value}>
                        {value}
                      </option>
                    ))}
                </select>
              </div>
            </li>

            <li>
              <button
                type="button"
                id="lessonComplete"
                onClick={() => {
                  const url =
                    "/acknowledge?lessonid=" +
                    lessonData.lessondetails.lessonid;
                  navigate(url);
                }}
                className={`lessonViewLessonComplete  btn btn-primary btn-xs ml-3 ${ackFlag ? "" : "d-none"
                  }`}
              >
                Acknowledge Completion
              </button>
            </li>
          </ol>
        </nav>
        <Container className="m-1" fluid>
          {lessonData.topics.length > 1 ? (
            <Row style={{ width: "100%" }} className="mt-3">
              <Col
                lg="3"
                md="3"
                sm="3"
                xs="12"
                className={sideBarToggle ? "" : "d-none"}
                style={{ height: "100vh - 70px" }}
              >
                <Sidebar
                  isLargeLessonView={false}
                  lessonName={lessonData.lessondetails.lessonname}
                  isAssessment={isAssessment}
                  topics={lessonData.topics}
                  topicToLoad={topicToLoad}
                  lessonid={lessonid}
                  onClickTopics={onClickTopics}
                  handleRetakeAction={handleRetakeAction}
                  isRetakeClicked={isRetakeClicked}
                  lessondetails={lessonData.lessondetails}
                  selectedLanguage={selectedLanguage}
                  languageChangeHandler={(language) => {
                    handleLanguageChange(language);
                  }}
                  ackFlag={ackFlag}
                />
              </Col>
              <Col
                lg={sideBarToggle ? "9" : "12"}
                md={sideBarToggle ? "9" : "12"}
                sm={sideBarToggle ? "9" : "12"}
                xs="12"
              // className={`${retakeFlag ? "d-none" : ""}`}
              >
                <MediaFrame
                  retakeFlag={retakeFlag}
                  isAssessment={isAssessment}
                  topicToLoad={topicToLoad}
                  selectedLanguage={selectedLanguage}
                  topics={lessonData.topics}
                  lessonid={lessonid}
                  clickNextBtnFunc={clickNextBtnFunc}
                  clickPrevBtnFunc={clickPrevBtnFunc}
                  sideBarToggle={sideBarToggle}
                  handleRetakeAction={handleRetakeAction}
                  isRetakeClicked={isRetakeClicked}
                  isLargeLessonView={isLargeLessonView}
                  setIsLargeLessonView={setIsLargeLessonView}
                  setSideBarToggle={setSideBarToggle}
                />
              </Col>
            </Row>
          ) : (
            <Row
              style={{ width: "100%" }}
              className={`mt-3 ${retakeFlag ? "d-none" : ""}`}
            >
              <Col lg="12" md="12" sm="12" xs="12">
                <MediaFrame
                  isAssessment={isAssessment}
                  topicToLoad={topicToLoad}
                  selectedLanguage={selectedLanguage}
                  topics={lessonData.topics}
                  lessonid={lessonid}
                  clickNextBtnFunc={clickNextBtnFunc}
                  clickPrevBtnFunc={clickPrevBtnFunc}
                  sideBarToggle={sideBarToggle}
                  isLargeLessonView={isLargeLessonView}
                  setIsLargeLessonView={setIsLargeLessonView}
                  setSideBarToggle={setSideBarToggle}
                />
              </Col>
            </Row>
          )}
        </Container>
        <Dialog
          header={`No Topics to Display`}
          visible={notTopicsDialogVisible}
          position={"top"}
          style={{ width: "50Vw" }}
          onHide={() => setNoTopicsDialogVisible(false)}
          draggable={false}
          resizable={false}
        >
          <Card className="mt-1">
            <Card.Body className="p-2">
              No active topics are available for this Lesson, please try gain
              later.
            </Card.Body>
          </Card>
        </Dialog>
        <Dialog
          header={`Are you sure?`}
          visible={retakeDialogVisible}
          position={"center"}
          style={{ width: "50Vw" }}
          onHide={() => setRetakeDialogVisible(false)}
          draggable={false}
          resizable={false}
        >
          <p>
            {" "}
            Please note, choosing to retake the assessment will erase your prior
            training record for this lesson. Are you sure you wish to proceed?{" "}
          </p>
          <div className="float-right">
            <button
              type="button"
              className="btn btn-primary mr-2"
              onClick={() => {
                setRetakeDialogVisible(false);
              }}
              data-dismiss="modal"
            >
              Cancel
            </button>
            <button
              id="retakeAssessmentSure"
              onClick={(e) => {
                handleRetakeAction(e);
              }}
              type="button"
              className="btn btn-light"
            >
              {/*   */}
              Retake Assessment
            </button>
          </div>
        </Dialog>
      </div>
    );
  } else {
    return null;
  }
};
export default LessonviewLarge;
