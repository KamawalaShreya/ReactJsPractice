import React, { useEffect, useRef } from "react";
import Quill from "quill";
import "quill/dist/quill.snow.css";
import './EditorComponent.css'

const EditorComponent = ({ value }) => {
    const quillRef = useRef(null);

    useEffect(() => {
        const quill = new Quill(quillRef.current, {
            theme: "snow", 
            readOnly: true,

        });

        quill.root.innerHTML = value;
    }, [value]);

    return <h6 id="questionField" ref={quillRef} style={{ height: "300px" }} />;
};

export default EditorComponent;
