<div class="col-12 col-sm-6 col-lg-0">
          <div class="card card-fluid p-4 pb-4" >
            <div class="form-group mb-0 mt-3" id="profilePageResetPasswordDiv">
              <input type="submit" class="btn btn-lg btn-block btn-primary profilePageResetPassword" value="Reset My Password" />
              <p class="pt-4">Click on the button above to reset your password. We will email you a verification code. You will need to enter the verification code and new password on the next page.</p>
            </div>

            <form id="profilePageVerifyCode" class="needs-validation1 d-none">
              <div class="px-3">
                <p>We have emailed you a verification code.</p>
                  <div class="form-group mt-3 mb-3">
                      <label  for="profilePageCode"> Enter your verification code from email. </label> 
                      <input type="text" name="code" class="form-control form-control-lg d-none " placeholder="Code"/>
                      <input type="text" name="code" id="profilePageCode" class="form-control form-control-lg " placeholder="Code" required=""/>
                      <div class="invalid-feedback"> Verification code is required. </div>
                  </div>
                  <div class="form-group mt-3 mb-3">
                      <label  for="profilePageNewPassword"> Enter new password. </label> 
                      <input type="password" name="newPassword" class="form-control form-control-lg d-none " placeholder="Password"/>
                      <input type="password" name="newPassword" id="profilePageNewPassword" class="form-control form-control-lg " placeholder="Password" required=""/>
                      <div class="invalid-feedback"> New password is required. </div>
                  </div>
                  <div class="form-group mt-3 mb-3">
                      <label  for="profilePageConfimPassword"> Confirm password. </label> 
                      <input type="password" name="confirmPassword" id="profilePageConfimPassword" class="form-control form-control-lg " placeholder="Password" required=""/>
                      <div class="invalid-feedback"> Confirm password is required. </div>
                  </div>
                  <div class="form-group mb-0 ">
                      <input type="submit" class="btn btn-lg btn-block btn-primary mt-3" value="Reset Password"/>
                  </div>
                  <p id="profilePageMessage" class="pt-3"></p>
              </div>
              
            </form>        
          </div>
          <div class="card card-fluid p-4">
          <div class="form-group">
            <h6 class="card-title"> Email reminders</h6>
            <div class="table-responsive" id="emailRemindersDiv">
                <table class="table" id="emailRemindersTable">
                    <thead>
                        <tr>
                            <th> Actions </th>
                            <th class="text-center1"> Status</th>
                        </tr>
                        <tr>
                          <td>Email reminders</td>
                          <td>
                            <div class="list-group-item">
                              <label class="switcher-control switcher-control-success">
                                <input type="checkbox" class="switcher-input switcher-control-success" id="emailSwitch"/>
                                <span class="switcher-indicator"></span>
                              </label>
                            </div>
                          </td>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
          </div>
        </div>

        
        <div class="modal fade has-shown" id="setLanguage" tabindex="-1" role="dialog" aria-labelledby="setLanguage" aria-hidden="true" style="display: none;">
        
          <div class="modal-dialog modal-dialog-centered" role="document">
            
              <div class="modal-content">
                
                <div class="modal-header">
                  <h5 id="exampleModalCenterLabel" class="modal-title"> Set you default language</h5>
                </div>
              
                <div class="modal-body">
                  <p> You must set your language preference before you can start using SMi Trial. </p>
                  <p> Please select one language from the available language options.  </p>
                </div>
                
                <div class="modal-footer">
                  <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button> 
                </div>
              </div>
          </div>
        </div> 
        <Footerview/>
        </div>