import { env } from '../env';
let config = {
    "cognito": {
        "userPoolId": env.REACT_APP_cognito_userPoolId,
        "userPoolClientId": env.REACT_APP_cognito_userPoolClientId,
        "region": env.REACT_APP_cognito_region
    },
    "api": {
        "url": env.REACT_APP_api_url
    },
    "content": {
        "url": env.REACT_APP_content_url
    },
    "site": {
        "logo": env.REACT_APP_site_logo
    }
}
export default config;