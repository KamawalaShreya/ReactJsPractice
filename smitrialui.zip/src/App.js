import "./App.css";
import "./asset/css/smitrial.css";

import { BrowserRouter, Route, Routes } from "react-router-dom";

import Acknowledge from "./components/Acknowledge/Acknowledge";
import Allassessmentreports from "./components/Reports/Allassessmentreports/Allassessmentreports";
import Assessmentquestionreports from "./components/Reports/Assessmentquestionreports/Assessmentquestionreports";
import Assessmentreports from "./components/Reports/Assessmentreports/Assessmentreports";
import Auth from "./components/Auth/Auth";
import ComingSoonPage from "./components/comingpage/ComingSoon";
import Dashboard from "./components/Dashboard/Dashboard";
import DashboardSettings from "./components/AssetManagement/DashboardSettings/DashboardSettings";
import EmailReminders from "./components/Settings/EmailReminders/EmailReminders";
import ForgotPassword from "./components/Auth/ForgotPassword";
import Helperview from "./components/Help/Helperview";
import LessonAssignmentOverview from "./components/AssetManagement/LessonAssignmentOverview/LessonAssignmentOverview";
import LessonManager from "./components/AssetManagement/LessonManager/LessonManager";
import Lessonmanagertreeview from "./components/AssetManagement/Lessonmanagertreeview/Lessonmanagertreeview";
import Lessonreports from "./components/Reports/Lessonreports/Lessonreports";
import Lessonreportsoverview from "./components/Reports/Lessonreportsoverview/Lessonreportsoverview";
import LessonviewMobile from "./components/Lessonviewmobile/Lessonviewmobile";
import Lessonview_large from "./components/Lessonview/Lessonview_large";
import Lessonwizard from "./components/LessonWizardPage/Lessonwizard";
import Messages from "./components/Messages/Messages";
import NewPassword from "./components/Auth/NewPassword";
import NotificationSettings from "./components/Settings/NotificationSettings/NotificationSettings";
import Passwordless from "./components/Passwordless/Passwordless";
import Profile from "./components/Profile/Profile";
import Reportsaggregate from "./components/Reports/Reportsaggregate/reportsaggregate";
import Review from "./components/Review/Review";
import Roles from "./components/AssetManagement/Roles/Roles";
import Settings from "./components/Settings/Settingspage/Settings";
import SignUp from "./components/Auth/SignUp";
import Sitedetails from "./components/Sitedetails/Sitedetails";
import Sitemanager from "./components/Sitemanager/Sitemanager";
import Sitereports from "./components/Reports/Sitereports/Sitereports";
import Sitesreports from "./components/Reports/Sitesreports/Sitesreports";
import Surveyreports from "./components/Reports/Surveyreports/Surveyreports";
import TrainingRecord from "./components/TrainingRecord/TrainingRecords";
import Triaidshare from "./components/TriaIdShare/TrialdShare";
import UploadLessonCompletion from "./components/UploadLessonCompletion/uploadLessonCompletion";
import Usermanager from "./components/Usermanager/Usermanager";
import Userreports from "./components/Reports/Userreports/Userreports";
import Usersummaryreports from "./components/Reports/Usersummaryreports/Usersummaryreports";

const App = () => {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Auth />} />
          <Route path="/html/login.html" element={<Auth />} />
          <Route path="/html/login" element={<Auth />} />
          <Route path="/login" element={<Auth />} />
          <Route path="/SignUp" element={<SignUp />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/html/passwordless.html" element={<Passwordless />} />
          <Route path="/passwordless" element={<Passwordless />} />

          <Route path="/newpassword" element={<NewPassword />} />
          <Route path="/password" element={<ForgotPassword />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/lessonview" element={<Lessonview_large />} />
          <Route path="/Lessonview_large" element={<Lessonview_large />} />
          <Route path="/lessonviewmobile" element={<LessonviewMobile />} />
          <Route
            path="/lessonviewassessmentmobile"
            element={<LessonviewMobile />}
          />
          <Route path="/usermanager" element={<Usermanager />} />
          <Route path="/sitemanager" element={<Sitemanager />} />
          <Route path="/sitedetails" element={<Sitedetails />} />
          <Route path="/triaidshare" element={<Triaidshare />} />
          <Route
            path="/uploadlessoncompletion"
            element={<UploadLessonCompletion />}
          />

          <Route path="/reportsaggregate" element={<Reportsaggregate />} />

          <Route path="/lessonreviewmanager" element={<Review />} />
          <Route path="/comingsoon" element={<ComingSoonPage />} />
          <Route path="/help" element={<Helperview />} />

          {/* routes for Asset Management pages */}
          <Route path="/lessonmanager" element={<LessonManager />} />
          <Route
            path="/lessonassignmentoverview"
            element={<LessonAssignmentOverview />}
          />
          <Route path="/dashboardsettings" element={<DashboardSettings />} />
          <Route
            path="/lessonmanagertreeview"
            element={<Lessonmanagertreeview />}
          />
          <Route path="/roles" element={<Roles />} />

          {/* routes for Settings pages */}
          <Route path="/settings" element={<Settings />} />
          <Route
            path="/notificationsettings"
            element={<NotificationSettings />}
          />

          <Route path="/emailreminder" element={<EmailReminders />} />

          {/* routes for Reports pages */}
          <Route path="/sitereports" element={<Sitereports />} />
          <Route path="/sitesreports" element={<Sitesreports />} />
          <Route path="/userreports" element={<Userreports />} />
          <Route path="/usersummaryreports" element={<Usersummaryreports />} />
          <Route
            path="/lessonreportsoverview"
            element={<Lessonreportsoverview />}
          />
          <Route
            path="/allassessmentreports"
            element={<Allassessmentreports />}
          />
          <Route path="/assessmentreports" element={<Assessmentreports />} />
          <Route
            path="/assessmentquestionreports"
            element={<Assessmentquestionreports />}
          />
          <Route path="/surveyreports" element={<Surveyreports />} />

          <Route
            path="/lessonreports"
            element={<Lessonreports flag={false} />}
          />
          <Route path="/lessonwizard" element={<Lessonwizard flag={false} />} />
          <Route path="/acknowledge" element={<Acknowledge flag={false} />} />

          <Route
            path="/trainingrecord"
            element={<TrainingRecord flag={false} />}
          />
          <Route path="/messages" element={<Messages flag={false} />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
};

export default App;
