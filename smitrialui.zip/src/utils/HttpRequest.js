import axios from "axios";
import { getToken } from "../utils/Common";

axios.interceptors.request.use(
  (config) => {
    const token = getToken();
    config.headers["Authorization"] = "Bearer " + token;
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  (response) => {
    if(response.status == 401) {
      localStorage.clear();
      localStorage.setItem("logout", "1");
      window.location.href = "/";
    }
    return response;
  },
  (error) => {
    if (error.response && error.response.status == 401) {
      document.cookie = "io=; expires=Thu, 01 Jan 1970 00:00:00 UTC;";
      localStorage.clear();
      localStorage.setItem("logout", "1");
      window.location.href = "/";
    }
    return error;
  }
);

export const get = (url) => {
  return axios.get(url);
};

export const post = (url, body) => {
  return axios.post(url, body);
};
