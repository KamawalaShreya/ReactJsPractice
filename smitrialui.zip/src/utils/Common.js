import UserPool from "./UserPool";

export const isUserLoggedin = () => {
  const cognitoUser = UserPool.getCurrentUser();
  if (cognitoUser) {
   
    return cognitoUser.getSession((err, session) => {
      if (err) {
        return { error: err };
      } else if (!session.isValid()) {
        return { error: "Invalid sesson" };
      } else {
        
        return { data: session.getIdToken().getJwtToken() };
      }
    });
  } else {
    console.log("cognito user not found");
    return { error: "cognito user not found" };
  }
};
export const getToken = () => {
  const cognitoUser = UserPool.getCurrentUser();

  if (cognitoUser != null) {
    return cognitoUser.getSession((err, session) => {
      //Adding await causes the other request to not wait for token.
      cognitoUser.refreshSession(session.refreshToken, (err, session) => {
        const { idToken } = session;
        return idToken.jwtToken;
      });
      if (session) {
        return session.getIdToken().getJwtToken();
      } else {
        console.log("unable to get session. Signing out");
        cognitoUser.globalSignOut();
        window.location.href = "/";
      }
    });
  } else {
    window.location.href = "/";
  }
};

export const createAndDownloadBlobFile = (
  body,
  filename,
  extension = "txt"
) => {
  const blob = new Blob([body]);
  const fileName = `${filename}.${extension}`;
  if (navigator.msSaveBlob) {
    // IE 10+
    navigator.msSaveBlob(blob, fileName);
  } else {
    const link = document.createElement("a");
    // Browsers that support HTML5 download attribute
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", fileName);
      link.style.visibility = "hidden";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
};
