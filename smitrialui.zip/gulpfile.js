var gulp = require('gulp'),
    gutil = require('gulp-util'),
    contact = require('gulp-concat'),
    browserify = require('gulp-browserify'),
    gulpif = require('gulp-if'),
    uglify = require('gulp-uglify'),
    minifyHTML = require('gulp-minify-html'),
    fileinclude = require('gulp-file-include'),
    glob = require("glob"),
    debug = require('gulp-debug'),
    browserSync = require('browser-sync').create(),
    connect = require('gulp-connect');
    var gulp = require("gulp");
    var babel = require("gulp-babel");

var src = "src/", // source files
    build_dev = "build/developement/", // dev build files
    build_prod = "build/production/", // prod build files
    htmlSource = "src/html/*.html",
    partialsSource = "src/html/partials/*.html",
    cssSource = "src/asset/css/*.css",
    jsSource = "src/asset/js/**/*.js",
    imageSource = "src/asset/image/**/*",
    vendorSource = "src/asset/vendor/**/*";


gulp.task('check', done => {
    gutil.log('gulp works');
    done();
});

gulp.task('js', done => {
    gulp.src(jsSource)
        //.pipe(babel())
        .pipe(gulp.dest(build_dev + '/asset/js/'));
    done();
});

gulp.task('css', done => {
    gulp.src(cssSource)
        .pipe(gulp.dest(build_dev + '/asset/css/'));
    done();
});

gulp.task('image', done => {
    gulp.src(imageSource)
        .pipe(gulp.dest(build_dev + '/asset/image/'));
    done();
});

gulp.task('vendor', done => {
    gulp.src(vendorSource)
        .pipe(gulp.dest(build_dev + '/asset/vendor/'));
    done();
});

gulp.task('html', done => {
    gulp.src(htmlSource)
        .pipe(debug())
        .pipe(fileinclude({
            prefix: '@@',
            basepath: '@file',
            indent: true
        }))
        .pipe(gulp.dest(build_dev + '/html/'));
    done();
});

gulp.task('watch', done => {
    gulp.watch(jsSource, gulp.series('js')).on('change', browserSync.reload);
    gulp.watch(htmlSource, gulp.series('html')).on('change', browserSync.reload);
    gulp.watch(partialsSource, gulp.series('html')).on('change', browserSync.reload);
    gulp.watch(cssSource, gulp.series('css')).on('change', browserSync.reload);
});


var fileName, i = process.argv.indexOf("--option");
if (i > -1) {
    fileName = process.argv[i + 1];
} else {
    fileName = "index.html";
}

gulp.task('serve', gulp.series('html', done => {
    browserSync.init({
        server: {
            baseDir: "build/developement/",
            index: 'html/' + fileName,
            directory: false
        },
        notify: true,
        middleware: function (req, res, next) {
            // console.log("req.url :", req.url)
            // alert(req.url)
            if (req.url === '/') {
                console.log('redirectingt to login')
                res.write('<script>window.location.href="/html/login.html"</script>');
            } 
            return next();
        }
    }, 
    (err, bs) => {
        bs.addMiddleware("*", (req, res) => {
            // Provides the 404 content without redirect.
            res.write('<script>window.location.href="/html/login.html"</script>');
            res.end();
        });
    }
    );
    gulp.watch(jsSource, gulp.series('js')).on('change', browserSync.reload);
    gulp.watch(htmlSource, gulp.series('html')).on('change', browserSync.reload);
    gulp.watch(partialsSource, gulp.series('html')).on('change', browserSync.reload);
    gulp.watch(cssSource, gulp.series('css')).on('change', browserSync.reload);
}));

gulp.task('default', gulp.series('serve', done => {

    gulp.start('watch');
}));


/*
Git Helpful commands

git init
git add .
git status
git commit -m "First commit"
git remote add origin http://
git push -u origin master


*/